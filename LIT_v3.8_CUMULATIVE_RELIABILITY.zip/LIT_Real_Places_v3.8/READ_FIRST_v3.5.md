# LIT v3.5 — private Crew backend

This is a cumulative release. Business verification, owner/reviewer permissions, GO, business profiles, shared venues and the v3.4 bookmark tools remain included. Your owner setup email remains Nickmccrae11@gmail.com.

## Install

**If the v3.3 business migration is already installed:** run only `SUPABASE_v3.5_CREW_BACKEND.sql` in the same Supabase project's SQL Editor, then deploy the entire v3.5 app folder through Netlify once. No new environment variables or third-party services are needed for Crew.

**If you have not installed v3.3:** run `SUPABASE_COMPLETE_v3.5.sql`, then `SUPABASE_OWNER_SETUP.sql`. Follow `READ_FIRST_v3.3.md` for the server environment variables and full Netlify deployment. The complete script runs the business migration and then the Crew migration. Owner setup requires your existing confirmed LIT account.

Do not run the old business migration alone after the Crew migration; it would restore the older aggregate/dashboard definitions. If reinstalling, run the complete script in order. Both migrations preserve existing records on rerun. The owner bootstrap refuses to replace a different configured owner.

## What works

- Confirmed, signed-in accounts with a username create private Crews.
- Crew owners invite confirmed accounts by username, remove members, share or rotate invite links, and delete their Crew.
- Invite links use random 32-character tokens, expire after 7 days, and require an explicit Join action. New links disable older links. Existing members are unaffected.
- Invited accounts see only their own invitation and the owner's name until they join; they cannot see the Crew's plans or full membership.
- Joined members create plans at registered real venues, select a start within 30 days, and answer In, Maybe or Pass.
- New members receive waiting responses for the Crew's active plans. The organizer starts as In.
- Only the organizer or Crew owner can cancel a plan. Removing/leaving cancels that person's organized plans and removes their responses.
- Plans end 6 hours after their scheduled start and stop appearing/counting automatically. Cancellation or Crew deletion removes access immediately on subsequent requests.
- Private plans show the venue, schedule, names and responses; they contain no participant GPS locations, account emails or business review information.
- Anonymous venue and verified-business totals count distinct joined members marked In for active plans starting within 12 hours before/after now. Ended/cancelled plans and removed members are excluded. Multiple accepted plans at one venue count a person once. GO and planning counts can overlap and must not be added together.
- Crew data and dashboard totals refresh while their screens are visible. Forms and sheets are preserved during quiet refresh. Manual refresh is available.

## Permissions and limits

Crew ownership is separate from LIT platform ownership/business verification. LIT reviewers get no special access to private Crews. Crew owners cannot verify business accounts just because they own a Crew.

Storage uses functions in the public API with server-side authorization and a private schema denied to browser roles. No browser-supplied membership, response aggregate or organizer identity is trusted. Existing legacy Crew/outing tables are preserved, but this new workflow uses the private v3.5 tables.

Limits: 30 members/invitations per Crew, 20 Crews/invitations per account, 50 active plans per Crew. Successful creation is limited to 20/hour, planning to 60/hour, invitation lookups to 60/hour and code join attempts to 20/hour per account. Invalid join attempts consume quota. These are account-level database limits, not a network-wide denial-of-service system. Membership capacity changes serialize through a transaction lock; individual requests make no external service calls while holding it.

No background worker is required for expiry. Expired records are excluded using server time; old records are retained in the database. There are no push/email notifications in this batch; recipients see invitations and updated plans inside LIT.

## Check after deploying

Use separate real accounts in separate browsers:

1. Create a Crew and invite the other account by its username.
2. Confirm the invited account cannot see existing plans until it joins.
3. Make a venue plan, respond In/Maybe/Pass, and check planning totals on that venue.
4. Verify the claimed business sees the same anonymous count, without member names.
5. Cancel a plan, remove a member, rotate the invite link and delete a test Crew; confirm removed/cancelled data stops appearing.
6. Sign out and confirm all Crew actions require sign-in.

## Still outstanding

Video server enforcement/processing and global moderation; Events/RSVP publishing; arrival/feedback backend; account deletion/blocking; trusted activity scoring; production monitoring and physical device acceptance tests. These are not implemented by this Crew release. This package has not been deployed or applied to your production database.
