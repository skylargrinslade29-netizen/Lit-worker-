# LIT source readiness audit — v3.2

**Conclusion: nearby discovery is working per your v2.4 report, but the complete app is not yet verified as ready for a public user launch.** This cumulative patch fixes concrete frontend defects and includes the v2.5 nightlife improvements. The database, storage rules, moderation operations and real-device recording still need verification.

## What was inspected

The ZIP you provided and the cumulative v2.5 source: all frontend modules, three Netlify functions, redirects/headers/configuration, and the original handoff. This is a source audit, not an authenticated production/database scan. You confirmed v2.4 live places work; you have not confirmed deploying v2.5/v3.2. No production source comparison, backend SQL inspection or new deployment was possible in this session.

## Fixed in this package

| Area | Concrete issue | Patch |
| --- | --- | --- |
| Camera | Permission result arriving after close could leak the returned camera/microphone stream or affect another capture. | Each request owns its stream; obsolete streams are stopped, with camera-request version checks. |
| Camera | GPS denial during preparation left recordingPending set, preventing a retry. | Reset pending state and allow retry; stale GPS callbacks cannot update a new capture. |
| Camera | Late recorder events could append chunks or previews to another recording. | Callbacks are scoped to their capture; teardown clears handlers/tracks/timers. |
| Camera | Backgrounding could leave an incomplete clip labeled fresh; publish fell back to older GPS. | Stop on background/page exit, reject short/empty clips, require fresh GPS before upload/publish, and check proximity. These are client protections, not proof of server enforcement. |
| Posting/discovery | Selecting a venue for capture overwrote the user's manually chosen discovery location. | Separate GPS lookup for capture; a real provider-returned candidate can be registered without replacing discovery state. |
| Account/privacy | Profile/Crew/GO/business requests started under an old account could overwrite new-account state. | Account generation checks, loader versions, immediate private-state clearing and modal/camera cleanup. |
| Video | Cached signed video URLs were never renewed before expiration. | Expiry tracking and refresh; responses from old accounts are discarded. |
| GO | Directions/share ignored signed-out destinations restored from device storage. | Resolve the saved local GO destination even when it is outside the current nearby list. |
| GO/Crew | Repeated GO taps could race; Crew plans outside current discovery could not become GO. | Serialize GO updates and use the real outing's backend place ID. |
| Links | HTML escaping alone allowed a business website with a javascript: URL scheme. | HTTP/HTTPS allowlist for clickable website links. Database validation remains required. |
| Modal/navigation | Keyboard focus escaped dialogs; navigation from a settings sheet left the sheet covering the destination. | Focus cycling, inert background controls, scroll lock, and sheet dismissal on navigation. |
| Device cache | Clear device data removed only the old discovery cache key. | Remove all versioned discovery caches; reset saved filters/local GO. |
| Resilience | JSON null in saved preferences could crash initialization; rejected action promises could be unhandled. | Validate stored objects and catch delegated action failures; prevent repeated submission of one pending action. |
| Evidence display | Malformed/missing score values could render unsafe or invented numeric output. | Numeric bounds/escaping and unknown-value labels; watch time does not cross account generations. |
| Ask LIT | A distance of zero sorted like a missing distance; malformed/oversized bodies lacked clear limits. | Preserve zero, normalize numeric inputs, validate JSON shape and cap request text. |
| Backend errors | Missing RPC messages exposed implementation names to users and never set missing backend state. | Friendly user error with safe diagnostic function/code logging. |
| Nightlife | Food consumed the same discovery/result limits as clubs. | Separate category budgets, category-balanced All/feed selection, and explicit Nightclubs label; retains v2.5 changes. |

## Before a full public launch

The items below are missing from the supplied source or cannot be verified with it. They are **not claims that the live database is broken**.

### 1. Verify database contracts and access control — release blocker

The frontend calls **27 distinct Supabase RPCs**. BACKEND_CONTRACTS.json lists each function, argument names and call-site files. Implementations/migrations were not included. Confirm the exact signatures and JSON return shapes before changing schema.

Run SUPABASE_READONLY_CHECK.sql in the existing project's SQL editor to inventory function signatures/grants, table RLS status, policy names and the video bucket. It changes nothing and reads no user rows. Its output is a starting point; RLS being enabled or a function existing does not establish correct permissions.

Verify with two separate real test accounts that:
- Profile edits, GO, arrivals/feedback and video deletion are limited to the caller's records.
- Crew membership, private names/responses/invite codes cannot be read or changed by outsiders; invitation/response operations deduplicate.
- Unverified claimants cannot gain business privileges, read private analytics or edit other venues.
- Security-definer functions use a safe namespace/permission design and do not bypass these checks accidentally.
- Anonymous access is limited to the intended public feed/discovery behavior. Client-supplied venue records and activity numbers are not trusted as authoritative evidence.

### 2. Verify real recording/upload/publish — release blocker for POST/WATCH

Confirm lit_begin_capture and lit_publish_capture bind sessions and storage paths to the authenticated owner and enforce expiration, single-use publish, venue match and a 10–30 second media duration. Do not trust p_duration_ms, client timestamps, GPS claims or MIME declarations alone. Validate file size/actual media metadata, safely process uploads, and clean up abandoned uploads/expired sessions.

Verify storage upload/read/delete policies for lit-fresh-videos, the signed URL lifetime, feed expiry after 24 hours, and private/business video access. Browser camera-only UI does not prevent an attacker from crafting API/storage calls. Server controls and abuse monitoring are required for the freshness promise.

Test on real iPhone Safari and Android Chrome: allow/deny camera/mic/GPS; record 10 and 30 seconds; flip/retake; background/close; poor connectivity; retry; publish; then view from a different account. Local tests cannot validate the actual media codecs or hardware.

### 3. Complete operational trust/safety — release blocker for public video

The frontend submits reports through lit_report_post, but no moderation queue/tool, operator workflow or review process is included. Provide those, enforce user-only deletion versus venue permissions, and verify removal propagates to feeds/caches. Add measured anti-spam/rate limits for posting, invitations, reports, activity/GO and public provider endpoints. Discovery's public function can spend the provider quota; warm caches are not a distributed abuse-control system.

Sign-up refers to terms/privacy without supplying documents or links. Publish accurate terms/privacy and appropriate age rules based on the actual data handling. Define retention, deletion/account support and contacts. Avoid promises about never storing coordinates until database/log retention is confirmed.

### 4. Verify the score and analytics — release blocker for claimed live proof

The UI draws server score/components/history but no scoring implementation is included. Verify genuine independent video/GO/engagement evidence, server-side decay, expiry, distinct users, deduplication, throttling, fraud resistance and score history. Verify business metrics against known test actions. Missing data must remain unknown, and promotions/payment must not buy the score or ON FIRE status.

### 5. Finish dedicated Events/RSVP before advertising them

Current business UI includes promotion kind=event and start/end timestamps. It does not implement the complete requested event lifecycle, event-specific Going/Interested/cancel, timezone-aware event records, invite acceptance-to-Going mapping, future feed cards or event attribution analytics. A promotion card is not the full event/RSVP feature. Add schema/RPCs/RLS and UI together, separately from present-tense venue GO.

Business Pro/paid promotion billing/entitlements/campaign attribution are not implemented here; parts are correctly labeled coming later. Keep them unadvertised as working features until implemented/tested. No price or payment-to-score connection was added.

## Important remaining product work

- Verify Supabase Auth confirmation/reset redirects allow https://glowing-crepe-8a40b0.netlify.app, not the old domain. Test confirmation, reset, logout, session expiry and profile creation.
- Shared venue links currently depend on loading that venue into the recipient's nearby list. Add a provider/backend venue-detail lookup for a durable link outside the recipient's current radius. Provider-specific Geoapify/OSM IDs also need a deliberate backend identity mapping to avoid splitting history when the provider changes; existing IDs were preserved to avoid a speculative migration.
- Discovery is a bounded list, not a complete directory. Check the missing Orlando examples against provider records (Aero Rooftop, Euphoria Downtown, Tier); listings may be absent or classified as bars. Limits and dataset coverage still apply.
- Verify larger-radius category coverage, incoming Crew links, GO persistence/cancel, fresh arrival and feedback, claim verification and dashboard date ranges against the actual backend.
- Real browser/device QA is still needed for safe-area controls, keyboard navigation, focus/scroll restoration, low-power/network behavior and video playback accessibility. The local DOM harness is not a browser rendering test.

## Validation completed

All JavaScript syntax and local import checks; static entry assets/API routing; server mocked-provider tests; discovery/client race tests; new readiness regressions for account isolation, signed URL renewal, safe links/scores, local GO directions, duplicate GO, camera cleanup/GPS retries/short recordings, capture venue lookup independent of discovery, fresh GPS before upload, modal focus and cache cleanup. Ask request limits and zero-distance ordering are covered.

Netlify function bundling, live provider calls, database/storage enforcement, real camera recording and deployed end-to-end flows remain unverified. No deployment, account/schema changes or Netlify build was performed. Use the existing project and one cumulative deployment if you deploy this patch; the ZIP is not a certification that all backend launch gates pass.
