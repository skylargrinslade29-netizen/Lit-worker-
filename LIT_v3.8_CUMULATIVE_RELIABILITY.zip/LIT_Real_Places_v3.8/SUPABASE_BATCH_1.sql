-- LIT v3.2: profile and existing-place GO RPCs.
-- Does not implement feed registration, video, Crew, business, or moderation.
begin;

-- Stop rather than replace functions installed since the inventory was taken.
do $$
begin
  if exists (
    select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname in
      ('lit_my_profile','lit_save_profile','lit_my_go','lit_set_go')
  ) then
    raise exception 'Batch 1 functions already exist. Export their definitions before continuing.';
  end if;
end $$;

create function public.lit_my_profile()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare u uuid := auth.uid(); result jsonb;
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  insert into public.profiles(id,account_type) values(u,'consumer')
    on conflict(id) do nothing;
  select jsonb_build_object('id',id,'username',username,
    'display_name',display_name,'account_type',account_type,
    'avatar_url',avatar_url) into result
    from public.profiles where id=u;
  return result;
end $$;

create function public.lit_save_profile(p_display_name text, p_username text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare u uuid := auth.uid(); display text := btrim(p_display_name);
  handle text := lower(btrim(p_username));
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  if display is null or length(display) not between 1 and 80 then
    raise exception 'Display name must be 1–80 characters.';
  end if;
  if handle is null or handle !~ '^[a-z0-9_]{3,30}$' then
    raise exception 'Username must be 3–30 letters, numbers or underscores.';
  end if;
  -- Serialize case-insensitive username allocation through this RPC.
  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended('lit:username:' || handle,0));
  if exists(select 1 from public.profiles
    where lower(username)=handle and id<>u) then
    raise exception 'That username is already taken.';
  end if;
  insert into public.profiles(id,display_name,username,account_type)
    values(u,display,handle,'consumer')
    on conflict(id) do update set
      display_name=excluded.display_name, username=excluded.username;
  return public.lit_my_profile();
end $$;

create function public.lit_my_go()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare u uuid := auth.uid(); result jsonb;
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  select jsonb_build_object(
    'place_id',p.id,
    'pid',case
      when p.provider_place_id like 'geoapify:%' or p.provider_place_id like 'osm:%'
        then p.provider_place_id
      when p.provider='geoapify' then 'geoapify:' || p.provider_place_id
      when p.provider in ('osm','openstreetmap') then 'osm:' || p.provider_place_id
      else p.provider || ':' || p.provider_place_id end,
    'name',p.name,'lat',p.latitude,'lon',p.longitude,
    'category',p.category,'since',g.created_at,'arrival',null
  ) into result
  from public.lit_go_intents_v2 g
  join public.lit_places_v2 p on p.id=g.place_id
  where g.user_id=u order by g.created_at desc,g.place_id limit 1;
  return result;
end $$;

create function public.lit_set_go(p_place uuid,p_going boolean)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare u uuid := auth.uid();
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  if p_place is null or p_going is null then raise exception 'Choose a venue and GO state.'; end if;
  -- One destination per user, including concurrent requests from different devices.
  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended('lit:go:' || u::text,0));
  if p_going then
    if not exists(select 1 from public.lit_places_v2
      where id=p_place and latitude is not null and longitude is not null
      and provider in ('geoapify','osm','openstreetmap')
      and nullif(btrim(provider_place_id),'') is not null) then
      raise exception 'This venue needs a registered provider identity and coordinates.';
    end if;
    delete from public.lit_go_intents_v2 where user_id=u and place_id<>p_place;
    insert into public.lit_go_intents_v2(user_id,place_id)
      values(u,p_place) on conflict(user_id,place_id) do nothing;
  else
    delete from public.lit_go_intents_v2 where user_id=u and place_id=p_place;
  end if;
  return public.lit_my_go();
end $$;

revoke all on function public.lit_my_profile() from public,anon;
revoke all on function public.lit_save_profile(text,text) from public,anon;
revoke all on function public.lit_my_go() from public,anon;
revoke all on function public.lit_set_go(uuid,boolean) from public,anon;
grant execute on function public.lit_my_profile() to authenticated;
grant execute on function public.lit_save_profile(text,text) to authenticated;
grant execute on function public.lit_my_go() to authenticated;
grant execute on function public.lit_set_go(uuid,boolean) to authenticated;
notify pgrst, 'reload schema';
commit;
