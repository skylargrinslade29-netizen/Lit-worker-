# Video reliability and processing — v3.2

## Active frontend improvements
A transient object-upload failure retries once using the same server-owned upload path/blob with upsert:false. Permission/client errors are not retried. Publishing is NOT automatically replayed. Closing/changing the capture prevents the retry from continuing to publish.

Failed WATCH playback offers an explicit retry. Retry renews the signed URL and reloads playback; account-generation checks prevent old media appearing under another account. Existing sound, autoplay, data saving, timestamps and expiry controls remain.

## Runnable processing worker
Python 3 plus FFmpeg/FFprobe are required. Run on a trusted session-owned quarantined upload:

    python workers/video_prepare.py INPUT.webm NEW_OUTPUT.mp4

It measures media duration (10–30 seconds with 0.1s container tolerance), validates video dimensions/input size (75 MiB maximum), transcodes to H.264/AAC MP4 with fast-start layout, limits output dimensions to 1280, removes embedded metadata, remeasures output duration and prevents overwriting an existing output. Source uploads are preserved; cleanup belongs to the backend's retention process. Real FFmpeg tests are included:

    python checks/video_worker.py

workers/Dockerfile provides an isolated non-root image definition. It has not been built/deployed here. Production should add resource limits, no network, a read-only filesystem and narrowly scoped input/output mounts; keep FFmpeg updated. Do not run media parsing on the public Netlify function path.

## Required backend wiring (not connected by this ZIP)
The backend must validate ownership/session expiry/single-use and bind the quarantine object to the recording, queue an idempotent job, run this worker in isolation, verify the result, store the processed object and expose only authorized media URLs. Publish fresh timestamps/24h expiry from server time. Do not accept arbitrary filesystem paths or job rows from browsers. Validate GPS/venue claims separately; transcoding cannot prove footage was freshly recorded or that GPS claims are honest.

Use a processing state before a clip becomes viewable, retry/failed-job handling, abandoned-upload cleanup and monitored storage/CDN delivery. This worker does not provide a job queue, CDN, automatic gallery upload, live storage adapter or authenticated publish implementation. It is prepared runnable processing code; current live uploads do not automatically pass through it.

Actual iPhone/Android camera codecs and delivery performance still need real-device tests.
