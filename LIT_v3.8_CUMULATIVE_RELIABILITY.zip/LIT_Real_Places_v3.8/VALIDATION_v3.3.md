# v3.3 validation

## Completed locally

- `npm test`: JavaScript syntax/imports, static routes, all four Netlify function entries, provider and client regressions, account isolation, capture recovery, media preferences, signed URLs, GO behavior and authenticated provider registration.
- Real PostgreSQL (PGlite) fixture matching the exported table/constraint/policy structure: cumulative migration and rerun, owner bootstrap protection, delegated access and revocation, self-review denial, inability to grant oneself reviewer status, profile account-type spoofing, private audit/claim fields, verified-only business access and safe website validation. Follow-up/resubmission, stale versions, additional-account approval acknowledgment, cursor paging and persistent lookup quotas are checked.
- GO save/cancel/switch/expiry, anonymous consumer counts and owner totals use the same database rows. Unverified registration is rejected; legacy provider UUIDs are preserved when reverified.
- Real Chromium at 390px mobile and 1280px desktop, using local PostgreSQL RPCs and a test-only Supabase SDK: applicant request, owner delegation, reviewer approval, signed-out authentication gate, signed-in Going/cancel, owner counts, profile editing and draft-preserving refresh, out-of-radius shared links, permission revocation and unauthorized queue denial. Delayed private responses after an account switch are ignored; expired authentication clears private client state and opens sign-in. Mobile horizontal overflow is checked.
- Desktop and mobile screenshots were inspected. The samples are test fixtures, not data seeded into the app.

## Reproduce

The deployed app has no PGlite dependency. Install the optional database test dependency in a separate folder and set `LIT_PGLITE_MODULE` to the absolute `@electric-sql/pglite/dist/index.js` file there.

```
npm test
LIT_PGLITE_MODULE=/absolute/path/to/pglite/dist/index.js npm run test:database
```

For browser checks, install Python Playwright and Chromium, then run the test-only server in one terminal:

```
LIT_PGLITE_MODULE=/absolute/path/to/pglite/dist/index.js node checks/browser-server.mjs
```

In another terminal:

```
python checks/browser_business.py
```

The browser harness uses `/usr/bin/chromium` and writes screenshots to `/workspace/lit-validation/previews` by default; set `LIT_BROWSER_OUTPUT` to choose another path. The fixture server binds only to `127.0.0.1:8765`. It is under `checks`, outside the `public` and `netlify/functions` deployment paths, and is never a production API. Its login/reset routes are for local fixtures only.

## Not performed

No production SQL execution, owner bootstrap, production deployment, Netlify build, real user registration, live provider verification or physical iPhone/Android camera tests were performed. The embedded PostgreSQL tests do not emulate all Supabase Auth/Storage/PostgREST hosting behavior. The existing video worker was retained without changes; this release does not connect it to production uploads. Complete the live acceptance check in `READ_FIRST_v3.3.md` after installation.
