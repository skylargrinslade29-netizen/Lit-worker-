// Public Supabase client configuration. NEVER include a secret or service_role key.
window.LIT_CONFIG = {
  // Enable only after implementing and verifying the authenticated server contracts.
  features: { accountBlocking: true, moderationTools: true, accountDeletion: true },
  // Add real, published HTTPS URLs. Empty values do not show inactive links.
  links: { terms: '', privacy: '', support: '', deletion: '' },
  supabaseUrl: 'https://mvyjaoxenjnjoquhadds.supabase.co',
  supabaseAnonKey: 'sb_publishable_8CYIY2BDA6Pd9JJ8tG52Lg_ovi2kYBk'
};
