// Business review permissions come only from authenticated server functions.
import { S, $, esc, icon, on, emit, actionsFor, toast, openSheet, closeSheet, ago, safeWebUrl } from './core.js'
import { rpc } from './api.js'
import { requireAuth } from './account.js'

const V = { access: null, claims: [], status: 'pending', cursor: null, more: false, summary: {}, reviewers: [], loading: false, error: null }
let accessVersion = 0, queueVersion = 0, detailVersion = 0
const methods = [['public_phone','Public business phone'],['business_email','Business email confirmed independently'],['official_website','Official business website'],['in_person','Verified in person'],['business_documents','Business authorization documents']]
const decisionNames = { approve: 'Approve access', reject: 'Reject request', request_info: 'Request information', revoke: 'Revoke access' }

export async function loadReviewAccess() {
  const version = ++accessVersion, account = S.authVersion
  if (!S.user) { V.access = S.reviewAccess = null; return null }
  try {
    const access = await rpc('lit_review_access')
    if (version !== accessVersion || account !== S.authVersion) return null
    V.access = S.reviewAccess = { can_review: access?.can_review === true, is_owner: access?.is_owner === true }
  } catch {
    if (version !== accessVersion || account !== S.authVersion) return null
    V.access = S.reviewAccess = null
  }
  if (version === accessVersion && account === S.authVersion) emit('reviewAccess')
  return V.access
}

let accessRefreshPending = false
export async function refreshReviewAccess() {
  if (accessRefreshPending || document.hidden || S.screen !== 'verification' || !S.user) return
  accessRefreshPending = true
  const account = S.authVersion
  try {
    const access = await loadReviewAccess()
    if (account !== S.authVersion) return
    if (!access?.can_review) {
      ++queueVersion; ++detailVersion
      V.claims = []; V.reviewers = []; V.loading = false
      V.error = 'Your review access is unavailable. Contact the LIT owner if you need access.'
      closeSheet(); renderVerification()
    }
  } finally { accessRefreshPending = false }
}

export async function loadVerification({ more = false } = {}) {
  const version = ++queueVersion, account = S.authVersion
  V.loading = true; V.error = null; renderVerification()
  try {
    const access = await loadReviewAccess()
    if (version !== queueVersion || account !== S.authVersion) return
    if (!access?.can_review) throw new Error('Business verification is available only to the LIT owner and authorized reviewers.')
    const result = await rpc('lit_verification_queue', { p_status: V.status, p_cursor: more ? V.cursor : null, p_limit: 25 })
    if (version !== queueVersion || account !== S.authVersion) return
    V.claims = more ? [...V.claims, ...(result.claims || [])].filter((c, i, all) => all.findIndex(x => x.id === c.id) === i) : result.claims || []
    V.more = result.has_more === true; V.cursor = result.next_cursor; V.summary = result.summary || {}
    if (access.is_owner) {
      const reviewers = await rpc('lit_list_reviewers')
      if (version !== queueVersion || account !== S.authVersion) return
      V.reviewers = reviewers || []
    }
  } catch (error) {
    if (version !== queueVersion || account !== S.authVersion) return
    V.claims = []; V.reviewers = []; V.more = false; V.error = error.message
  } finally {
    if (version === queueVersion && account === S.authVersion) { V.loading = false; renderVerification() }
  }
}

export function renderVerification() {
  if (S.screen !== 'verification') return
  const el = $('verification')
  if (!el) return
  const header = `<button class="link" data-action="nav" data-to="business">${icon('chev-left')} Back to Business</button>
    <div class="review-heading"><div><div class="eyebrow">LIT OPERATIONS</div><h1 class="title">Business verification</h1><p class="lede">Give genuine business representatives access to their venue.</p>${V.access?.is_owner ? '<button class="link" data-action="reviewTeamJump">Manage review team</button>' : ''}</div><span class="tag ok">${icon('shield','i-sm')} ${V.access?.is_owner ? 'Owner' : 'Review team'}</span></div>`
  if (!S.user) { el.innerHTML = header + '<div class="card stack"><p>Sign in with your authorized LIT account.</p><button class="btn" data-action="openVerification">Sign in</button></div>'; return }
  if (V.error) { el.innerHTML = header + `<div class="card stack" role="alert"><strong>Review queue unavailable</strong><p>${esc(V.error)}</p><button class="btn alt" data-action="reviewRefresh">Retry</button></div>`; return }
  if (V.loading && !V.claims.length) { el.innerHTML = header + '<div class="card" role="status">Checking access and loading requests…</div>'; return }
  if (!V.access?.can_review) { el.innerHTML = header + '<div class="card">Checking your review access…</div>'; return }
  const rows = V.claims.map(c => `<article class="card review-request">
    <div class="row between"><span class="tag ${c.status === 'verified' ? 'ok' : ''}">${c.status === 'verified' ? 'Verified' : c.status === 'rejected' ? 'Rejected' : c.message ? 'Follow-up needed' : 'Awaiting review'}</span><span class="tiny faint">${ago(c.updated_at)}</span></div>
    <h2>${esc(c.name)}</h2><p class="small muted">${esc(c.address || 'Address unavailable')}</p>
    <div class="review-facts"><span><small>Applicant role</small>${esc(c.business_role || 'Not provided')}</span><span><small>Business email</small>${esc(c.business_email || 'Not provided')}</span></div>
    ${c.other_verified_accounts ? `<p class="review-warning">${esc(c.other_verified_accounts)} other verified account(s) already have access. Check the applicant’s authorization.</p>` : ''}
    <button class="btn ${c.status === 'pending' ? '' : 'alt'} block" data-action="reviewOpen" data-id="${esc(c.id)}">${c.status === 'pending' ? 'Review request' : 'View record'}</button></article>`).join('')
  el.innerHTML = header + `<div class="review-layout"><div>
    <div class="row between review-toolbar"><div class="seg">${['pending','verified','rejected'].map(s => `<button data-action="reviewFilter" data-status="${s}" class="${V.status === s ? 'on' : ''}">${s === 'pending' ? 'Pending' : s === 'verified' ? 'Verified' : 'Rejected'}${V.summary[s] != null ? ` (${esc(V.summary[s])})` : ''}</button>`).join('')}</div><button class="link" data-action="reviewRefresh" ${V.loading ? 'disabled' : ''}>Refresh</button></div>
    <div class="review-requests">${rows || '<div class="empty-card">No requests in this queue.</div>'}</div>
    ${V.more ? '<button class="btn alt block" data-action="reviewMore">Load more</button>' : ''}</div>
    <aside class="review-sidebar"><div class="card stack-sm"><strong>Review checklist</strong><ol class="review-checklist"><li>Match the venue name and address.</li><li>Find the official website or a public business listing independently.</li><li>Confirm the person is authorized through that contact.</li><li>Record the method, source and decision.</li></ol><p class="tiny faint">A confirmed LIT email proves control of the account, not authority over the business. Applicant-provided links and phone numbers are not independent proof.</p><p class="tiny faint">Keep notes limited to business authorization. Do not collect passwords, payment details or government ID numbers.</p></div>
    ${V.access.is_owner ? reviewerManagement() : '<div class="card"><strong>Your access</strong><p class="small muted">You can review business claims. Only the LIT owner can add or remove reviewers.</p></div>'}</aside></div>`
}

function reviewerManagement() {
  return `<div class="card stack" id="reviewTeam"><div><strong>Review team</strong><p class="small muted">Only you can grant or revoke reviewer access. Reviewers cannot invite other reviewers.</p></div>
    <form class="stack-sm" data-submit="reviewerGrant"><label class="field">LIT account email<input name="email" type="email" required maxlength="254" placeholder="teammate@example.com" autocomplete="off"></label><button class="btn alt" type="submit">Grant reviewer access</button><p class="tiny faint">The person must already have a LIT account with a confirmed email.</p><p class="form-msg" role="status"></p></form>
    <div class="stack-sm">${V.reviewers.map(r => `<div class="review-team-row"><div><strong class="small">${esc(r.email)}</strong><div class="tiny faint">${r.active ? 'Active reviewer' : 'Access revoked'}</div></div>${r.active ? `<button class="link" data-action="reviewerRevoke" data-email="${esc(r.email)}">Revoke</button>` : ''}</div>`).join('') || '<p class="small muted">No additional reviewers. You retain owner access.</p>'}</div></div>`
}

function externalLink(value, label) {
  const url = safeWebUrl(value)
  return url ? `<a class="link" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(label)}</a>` : ''
}

export async function openClaimReview(id) {
  const claim = V.claims.find(c => c.id === id)
  if (!claim) return
  const account = S.authVersion, version = ++detailVersion
  const audit = await rpc('lit_claim_audit', { p_claim: id })
  if (account !== S.authVersion || version !== detailVersion || S.screen !== 'verification') return
  const maps = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${claim.name} ${claim.address || ''}`)}`
  const decisions = claim.status === 'pending' ? ['approve','request_info','reject'] : claim.status === 'verified' ? ['revoke'] : []
  openSheet(claim.name, `<div class="stack">
    <div class="card"><dl class="kv"><dt>Venue</dt><dd>${esc(claim.name)}<br>${esc(claim.address || '')}</dd><dt>Account</dt><dd>${esc(claim.account_email)} · ${claim.account_email_confirmed ? 'Email confirmed' : 'Email not confirmed'}</dd><dt>Applicant role</dt><dd>${esc(claim.business_role || 'Not supplied')}</dd><dt>Business email</dt><dd>${esc(claim.business_email || 'Not supplied')}</dd><dt>Applicant phone</dt><dd>${esc(claim.business_phone || 'Not supplied')}</dd></dl><div class="btn-row" style="margin-top:12px">${externalLink(maps,'Find public business listing')}${externalLink(claim.evidence_url,'Applicant-provided business page')}</div></div>
    ${claim.note ? `<div class="card"><strong>Applicant’s note</strong><p class="small review-note">${esc(claim.note)}</p></div>` : ''}
    ${claim.other_verified_accounts ? `<div class="review-warning">This venue already has ${esc(claim.other_verified_accounts)} verified account(s). Confirm whether this person should also receive access.</div>` : ''}
    ${decisions.length ? `<form class="stack" data-submit="reviewDecision" data-id="${esc(claim.id)}" data-version="${esc(claim.version)}">
      <label class="field">Decision<select name="decision">${decisions.map(d => `<option value="${d}">${decisionNames[d]}</option>`).join('')}</select></label>
      ${claim.status === 'pending' ? `<div class="card stack-sm" data-approval-fields><label class="field">Verification method<select name="method"><option value="">Choose a method</option>${methods.map(([k,l]) => `<option value="${k}">${l}</option>`).join('')}</select></label><label class="field">Independent source<input name="source" maxlength="500" placeholder="Official website URL or public listing checked"></label><label class="review-checkbox"><input type="checkbox" name="checked">I independently confirmed this person is authorized for this venue.</label>${claim.other_verified_accounts ? '<label class="review-checkbox"><input type="checkbox" name="shared">I confirmed this additional account should have access.</label>' : ''}</div>` : ''}
      <label class="field">Internal review note<textarea name="note" required minlength="3" maxlength="1000" placeholder="What you checked and what was confirmed"></textarea></label>
      <label class="field">Message to applicant<textarea name="message" maxlength="600" placeholder="Required for follow-up, rejection or revoked access. Visible in their Business dashboard."></textarea></label>
      <p class="tiny faint">Internal notes stay in the reviewer audit history. Applicants see only your message and their claim status.</p>
      <button class="btn block" type="submit">Save decision</button><p class="form-msg" role="status"></p></form>` : '<div class="card">This request was rejected. The applicant can update and resubmit it.</div>'}
    <details class="card"><summary>Review history (${audit?.length || 0})</summary><div class="review-timeline">${(audit || []).map(entry => `<div><strong class="small">${esc(entry.action.replace(/^claim_/, '').replaceAll('_',' '))}</strong><div class="tiny faint">${esc(entry.reviewer || 'Former account')} · ${ago(entry.at)}</div>${entry.details?.note ? `<p class="small review-note">${esc(entry.details.note)}</p>` : ''}${entry.details?.source ? `<p class="tiny faint">Source: ${esc(entry.details.source)}</p>` : ''}</div>`).join('')}</div></details>
  </div>`, { eyebrow: 'Business verification', full: true })
}

actionsFor({
  reviewTeamJump: () => $('reviewTeam')?.scrollIntoView({ behavior:'smooth',block:'start' }),
  openVerification: async () => {
    if (!requireAuth('Sign in to review business claims.', () => emit('navigate','verification'))) return
    closeSheet(); emit('navigate','verification')
  },
  reviewRefresh: () => loadVerification(),
  reviewMore: () => loadVerification({ more: true }),
  reviewFilter: d => { V.status = d.status; V.claims = []; V.cursor = null; return loadVerification() },
  reviewOpen: d => openClaimReview(d.id),
  reviewDecision: async (d, form) => {
    const msg = form.querySelector('.form-msg'), button = form.querySelector('button[type=submit]')
    const account = S.authVersion
    button.disabled = true
    try {
      const field = name => form.elements.namedItem(name)
      const decision = field('decision').value
      if (decision === 'revoke' && !confirm('Revoke this account’s venue access? They will lose business permissions immediately.')) return
      const result = await rpc('lit_review_claim', { p_claim: d.id, p_version: Number(d.version), p_decision: decision,
        p_method: field('method')?.value || '', p_source: field('source')?.value || '', p_note: field('note').value,
        p_message: field('message').value, p_checked: field('checked')?.checked === true, p_allow_shared: field('shared')?.checked === true })
      if (account !== S.authVersion) return
      if (result?.saved !== true) throw new Error('The decision could not be confirmed. Refresh the queue before retrying.')
      closeSheet(); toast('Decision saved'); await loadVerification()
    } catch (error) { if (account === S.authVersion) { msg.textContent = error.message; msg.classList.add('err') } }
    finally { button.disabled = false }
  },
  reviewerGrant: async (d, form) => {
    const msg = form.querySelector('.form-msg'), button = form.querySelector('button[type=submit]'), account = S.authVersion
    button.disabled = true
    try {
      const result = await rpc('lit_manage_reviewer', { p_email: form.email.value, p_enabled: true })
      if (account !== S.authVersion) return
      if (result?.saved !== true) throw new Error('Reviewer access could not be confirmed.')
      toast('Reviewer access granted'); await loadVerification()
    } catch (error) { if (account === S.authVersion) { msg.textContent = error.message; msg.classList.add('err') } }
    finally { button.disabled = false }
  },
  reviewerRevoke: async d => {
    if (!confirm(`Revoke business review access for ${d.email}?`)) return
    const account = S.authVersion
    const result = await rpc('lit_manage_reviewer', { p_email: d.email, p_enabled: false })
    if (account !== S.authVersion) return
    if (result?.saved !== true) throw new Error('Access revocation could not be confirmed.')
    toast('Reviewer access revoked'); await loadVerification()
  },
})

document.addEventListener('change', e => {
  const form = e.target.closest?.('[data-submit="reviewDecision"]')
  if (e.target.name !== 'decision' || !form) return
  const fields = form.querySelector('[data-approval-fields]')
  if (fields) fields.hidden = e.target.value !== 'approve'
})
on('auth', () => {
  ++accessVersion; ++queueVersion; ++detailVersion
  Object.assign(V, { access: null, claims: [], reviewers: [], cursor: null, summary: {}, more: false, loading: false, error: null })
  S.reviewAccess = null
  if (S.screen === 'verification') loadVerification()
  else loadReviewAccess()
})
on('navigate', id => { if (id === 'verification') loadVerification() })
