import { uploadRecording } from './upload.js'
// POST — camera-only, 10–30 second fresh capture with server-issued sessions.
// There is deliberately no <input type=file>, gallery picker or upload of existing media.
import { S, $, esc, icon, actionsFor, toast, openSheet, closeSheet, getPosition, distKm, fmtMiles, miles, emit, on, syncModalState } from './core.js'
import { sb, rpc } from './api.js'
import { requireAuth } from './account.js'
import { nearbyVenues, loadFeed, ensurePlaceId } from './places.js'
import { pauseWatch, resumeWatch } from './watch.js'

const MIN = 10
const MAX = 30
const NEAR_KM = 0.4

let C = null // capture state

function supported() {
  return window.isSecureContext && !!navigator.mediaDevices?.getUserMedia && typeof window.MediaRecorder !== 'undefined'
}

function pickMime() {
  const types = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
  return types.find((t) => MediaRecorder.isTypeSupported?.(t)) || ''
}

export async function openCapture(pid) {
  if (!supported()) {
    openSheet(
      'Camera not available',
      `<div class="stack"><p class="muted" style="margin:0">LIT only accepts videos recorded live in the LIT camera, and this browser can’t record in-app video${window.isSecureContext ? '' : ' on an insecure connection'}.</p>
      <p class="small muted" style="margin:0">Try the latest Safari on iPhone or Chrome on Android. Uploading saved videos isn’t possible — that’s how LIT keeps every clip fresh.</p>
      <button class="btn block" data-action="closeSheet">OK</button></div>`,
      { eyebrow: 'POST' },
    )
    return
  }
  if (!requireAuth('Sign in to post a fresh video', () => openCapture(pid))) return
  pauseWatch()
  if (C) closeCapture()
  C = { account: S.user.id, pid: pid || null, facing: 'environment', stream: null, recorder: null, chunks: [], startedAt: 0, session: null, blob: null, url: null, pos: null, timer: null, stage: 'camera' }
  const active = C
  renderCamera()
  getPosition({ fresh: true, timeout: 15000 }).then(
    (p) => C === active && (active.pos = p),
    (e) => C === active && (active.posError = e.message),
  )
  await startStream()
}

async function startStream() {
  if (!C) return
  const active = C
  const version = active.streamVersion = (active.streamVersion || 0) + 1
  stopStream()
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: true,
      video: { facingMode: { ideal: C.facing }, width: { ideal: 1080 }, height: { ideal: 1920 }, frameRate: { ideal: 30 } },
    })
    if (C !== active || version !== active.streamVersion) { stream.getTracks().forEach(t => t.stop()); return }
    active.stream = stream
    const v = $('capView')
    if (v) {
      v.srcObject = C.stream
      v.play().catch(() => {})
    }
    const shutter = $('shutter')
    if (shutter) shutter.disabled = false
  } catch (e) {
    if (C !== active || version !== active.streamVersion) return
    const denied = e.name === 'NotAllowedError' || e.name === 'SecurityError'
    closeCapture()
    openSheet(
      denied ? 'Camera access needed' : 'Camera unavailable',
      `<div class="stack"><p class="muted" style="margin:0">${denied ? 'Allow camera and microphone access for this site in your browser settings, then tap POST again.' : 'LIT could not start your camera. Close other apps using it and try again.'}</p><button class="btn block" data-action="closeSheet">OK</button></div>`,
      { eyebrow: 'POST' },
    )
  }
}

function stopStream() {
  C?.stream?.getTracks().forEach((t) => t.stop())
  if (C) C.stream = null
}

function renderCamera() {
  $('captureRoot').innerHTML = `<div class="capture" role="dialog" aria-modal="true" aria-label="Record a fresh video">
    <video id="capView" autoplay playsinline muted ${C.facing === 'user' ? 'style="transform:scaleX(-1)"' : ''}></video>
    <div class="capture-top"><button class="cap-btn" data-action="capClose" aria-label="Close camera">${icon('close')}</button>
      <span class="cap-timer" id="capTimer">0:00 / 0:30</span>
      <button class="cap-btn" data-action="capFlip" id="capFlip" aria-label="Switch camera">${icon('flip')}</button></div>
    <div class="cap-progress" aria-hidden="true"><i id="capBar"></i><b title="10 second minimum"></b></div>
    <div class="capture-bottom">
      <div class="cap-note" id="capNote">Record ${MIN}–${MAX} seconds of what’s happening right now. Recording stops automatically at ${MAX}s.</div>
      <button class="shutter" id="shutter" data-action="capShutter" aria-label="Start recording" disabled><i></i></button>
    </div></div>`
  syncModalState()
}

async function startRecording() {
  if (!C?.stream) return toast('Camera is still starting')
  if (C.stage !== 'camera' || C.recordingPending) return
  C.recordingPending = true
  const active = C
  const shutter = $('shutter')
  shutter.disabled = true
  const mime = pickMime()
  // Server opens the capture session first: its timestamp bounds how old the clip can be.
  let pos = C.pos
  if (!pos) {
    $('capNote').textContent = 'Getting your location…'
    try {
      pos = await getPosition({ fresh: true, timeout: 15000 })
      if (C !== active) return
      active.pos = pos
    } catch (e) {
      if (C !== active) return
      active.recordingPending = false
      $('capNote').textContent = 'LIT needs your location to attach the video to a real venue. Enable location and try again.'
      shutter.disabled = false
      return
    }
  }
  try {
    const session = await rpc('lit_begin_capture', { p_lat: pos.lat, p_lon: pos.lon, p_mime: (mime || 'video/webm').split(';')[0], p_accuracy: pos.accuracy })
    if (C !== active) return
    C.session = session
  } catch (e) {
    if (C !== active) return
    C.recordingPending = false
    $('capNote').textContent = e.message
    shutter.disabled = false
    return
  }
  try {
    C.recorder = new MediaRecorder(C.stream, { ...(mime ? { mimeType: mime } : {}), videoBitsPerSecond: 2_500_000 })
  } catch {
    C.recordingPending = false
    $('capNote').textContent = 'Recording isn’t supported on this device.'
    shutter.disabled = false
    return
  }
  C.chunks = []
  C.recorder.ondataavailable = (e) => C === active && e.data?.size && active.chunks.push(e.data)
  C.recorder.onstop = () => C === active && finishRecording()
  C.recorder.onerror = () => { if (C !== active) return; closeCapture(); toast('Recording failed. Please record again.') }
  try { C.recorder.start(1000) } catch { C.recordingPending = false; $('capNote').textContent = 'Recording could not start. Please retry.'; shutter.disabled = false; return }
  C.recordingPending = false
  C.startedAt = performance.now()
  shutter.disabled = false
  shutter.classList.add('rec')
  shutter.setAttribute('aria-label', 'Stop recording')
  $('capFlip').disabled = true
  $('capTimer').classList.add('rec')
  C.timer = setInterval(tick, 100)
  tick()
}

function tick() {
  if (!C) return
  const s = (performance.now() - C.startedAt) / 1000
  const shown = Math.min(s, MAX)
  $('capTimer').textContent = `0:${String(Math.floor(shown)).padStart(2, '0')} / 0:${MAX}`
  $('capBar').style.width = `${(shown / MAX) * 100}%`
  $('capNote').textContent = s < MIN ? `Keep recording — ${Math.ceil(MIN - s)}s until you can stop` : 'Tap to stop, or LIT stops at 30s'
  if (s >= MAX) stopRecording(true)
}

function stopRecording(automatic = false) {
  if (!C?.recorder || C.recorder.state === 'inactive') return
  const s = (performance.now() - C.startedAt) / 1000
  if (s < MIN && !automatic) return toast(`Record at least ${MIN} seconds`)
  clearInterval(C.timer)
  C.duration = Math.min(s, MAX)
  C.recorder.stop()
}

function finishRecording() {
  if (!C) return
  if (!(C.duration >= MIN && C.duration <= MAX) || !C.chunks.some((x) => x.size)) { closeCapture(); toast('Record a complete 10–30 second clip. Please try again.'); return }
  stopStream()
  C.blob = new Blob(C.chunks, { type: (C.recorder.mimeType || C.session.mime_type).split(';')[0] })
  C.url = URL.createObjectURL(C.blob)
  renderPreview()
}

function renderPreview() {
  C.stage = 'preview'
  $('captureRoot').innerHTML = `<div class="capture" role="dialog" aria-modal="true" aria-label="Review your video">
    <video src="${C.url}" autoplay loop playsinline controls></video>
    <div class="capture-top"><button class="cap-btn" data-action="capClose" aria-label="Discard and close">${icon('close')}</button>
      <span class="cap-timer">${Math.round(C.duration)}s · fresh</span><span style="width:44px"></span></div>
    <div class="capture-bottom"><div class="btn-row" style="width:100%;max-width:420px">
      <button class="btn ghost" data-action="capRetake">Retake</button>
      <button class="btn" data-action="capNext">Choose venue ${icon('chev-right')}</button></div></div></div>`
  syncModalState()
}

async function renderVenuePick() {
  if (!C?.blob) return
  const active = C, version = active.venueVersion = (active.venueVersion || 0) + 1
  const current = () => C === active && version === active.venueVersion
  C.stage = 'venue'
  const root = $('captureRoot')
  root.innerHTML = `<div class="capture" role="dialog" aria-modal="true" aria-label="Confirm venue">
    <video src="${C.url}" autoplay loop playsinline muted></video>
    <div class="capture-top"><button class="cap-btn" data-action="capBack" aria-label="Back to preview">${icon('chev-left')}</button><span></span><span style="width:44px"></span></div>
    <div class="cap-panel" id="capPanel"><div class="eyebrow">Confirm venue</div><h3>Where are you right now?</h3><div class="skel" style="height:60px"></div><div class="skel" style="height:60px"></div></div></div>`
  let pos
  try {
    pos = await getPosition({ fresh: true, timeout: 15000 })
    if (!current()) return
    active.pos = pos
  } catch (e) {
    if (!current()) return
    pos = active.pos
  }
  if (!current()) return
  if (!pos) return panel(`<p class="small muted">LIT needs your location to match this video to a real venue. Enable location and try again.</p><button class="btn block" data-action="capNext">Try again</button>`)
  try {
    active.venueController?.abort()
    active.venueController = new AbortController()
    const list = await nearbyVenues(pos, active.venueController)
    if (!current()) return
    active.nearby = list
  } catch (error) {
    if (!current()) return
    return panel(`<p class="small muted">${esc(error.message)}</p><button class="btn block" data-action="capNext">Try again</button><button class="btn ghost block" data-action="capClose">Discard video</button>`)
  }
  const near = active.nearby
    .map((v) => ({ v, km: distKm(pos.lat, pos.lon, v.lat, v.lon) }))
    .filter((x) => x.km <= NEAR_KM)
    .sort((a, b) => a.km - b.km)
    .slice(0, 8)
  if (!near.length)
    return panel(`<p class="small muted" style="margin:0">No venues found within ${Math.round(NEAR_KM * 1000)} m of you${pos.accuracy > 100 ? ` (GPS accuracy is about ${Math.round(pos.accuracy)} m — try moving near a window or outside)` : ''}. LIT only publishes videos to real venues you’re at.</p>
      <button class="btn block" data-action="capNext">Check again</button><button class="btn ghost block" data-action="capClose">Discard video</button>`)
  if (!C.pick || !near.some((x) => x.v.id === C.pick)) C.pick = near.find((x) => x.v.id === C.pid)?.v.id || near[0].v.id
  panel(`<div class="stack-sm" role="radiogroup" aria-label="Nearby venues">${near
    .map(
      (x) => `<button class="venue-pick ${x.v.id === C.pick ? 'on' : ''}" role="radio" aria-checked="${x.v.id === C.pick}" data-action="capPick" data-pid="${esc(x.v.id)}"><span class="radio"></span>
      <span><strong>${esc(x.v.name)}</strong><div class="tiny faint">${esc(x.v.category)}${x.v.address ? ' · ' + esc(x.v.address) : ''}</div></span><span class="tiny muted">${fmtMiles(miles(x.km))}</span></button>`,
    )
    .join('')}</div>
    <button class="btn block" data-action="capPublish" id="capPublish">${icon('flame')} Publish to ${esc(C.nearby?.find((v) => v.id === C.pick)?.name || 'venue')}</button>
    <p class="form-msg" id="capMsg" role="status"></p>
    <p class="tiny faint" style="margin:0">Your clip is checked and processed before it appears. It expires 24 hours after recording started. Check My videos in Settings for progress. Your exact position is not shown on the post.</p>`)
}

function panel(html) {
  const p = $('capPanel')
  if (p) p.innerHTML = `<div class="eyebrow">Confirm venue</div><h3>Where are you right now?</h3>${html}`
}

async function publish() {
  if (!C?.session || !C?.blob || !C?.pick || C.publishing) return
  C.publishing = true
  const active = C
  const btn = $('capPublish')
  const msg = $('capMsg')
  btn.disabled = true
  const set = (t) => (btn.innerHTML = t)
  try {
    const chosen = active.nearby?.find((v) => v.id === active.pick)
    const placeId = await ensurePlaceId(active.pick, chosen)
    if (C !== active) return
    if (!placeId) throw new Error('This venue could not be registered')
    const pos = await getPosition({ fresh: true, timeout: 10000 })
    if (C !== active) return
    if (!chosen || distKm(pos.lat, pos.lon, chosen.lat, chosen.lon) > NEAR_KM) throw new Error('You need to be at this venue to publish. Check your location and try again.')
    if (!C.uploaded) {
      set('Uploading…')
      const { error } = await uploadRecording(sb.storage.from(C.session.bucket || 'lit-video-quarantine'), C.session.upload_path, C.blob, { contentType: C.session.mime_type, upsert: false, cacheControl: '3600' }, () => C === active)
      if (error && !/exists/i.test(error.message)) throw new Error(error.message.includes('row-level') ? 'This recording session expired. Please record again.' : error.message)
      if (C !== active) return
      C.uploaded = true
    }
    set('Verifying freshness…')
    const res = await rpc('lit_publish_capture', { p_session: C.session.session_id, p_place: placeId, p_duration_ms: Math.round(C.duration * 1000), p_lat: pos.lat, p_lon: pos.lon, p_accuracy: pos.accuracy })
    if (C !== active) return
    const name = C.nearby?.find((v) => v.id === C.pick)?.name
    C.submitted = true
    closeCapture()
    toast(res.state === 'ready' ? `Live at ${name}` : `Video submitted at ${name}. Processing before it goes live.`)
    await loadFeed()
    emit('navigate', 'watch')
    const { scrollToPost } = await import('./watch.js')
    if(res.state === 'ready')setTimeout(() => scrollToPost(res.post_id), 80)
  } catch (e) {
    if (C !== active) return
    C.publishing = false
    msg.textContent = e.message
    msg.classList.add('err')
    btn.disabled = false
    set(`${icon('flame')} Try again`)
  }
}

function closeCapture() {
  if (!C) return
  if(C.session && !C.submitted && C.account===S.user?.id)rpc('lit_discard_capture',{p_session:C.session.session_id}).catch(()=>{})
  clearInterval(C.timer)
  C.venueController?.abort()
  if (C.recorder) { C.recorder.ondataavailable = null; C.recorder.onerror = null }
  if (C.recorder && C.recorder.state !== 'inactive') {
    C.recorder.onstop = null
    C.recorder.stop()
  }
  stopStream()
  if (C.url) URL.revokeObjectURL(C.url)
  C = null
  $('captureRoot').innerHTML = ''
  syncModalState()
  if (S.screen === 'watch') resumeWatch()
}

actionsFor({
  post: (d) => {
    closeSheet()
    openCapture(d.pid)
  },
  capClose: () => {
    if (C?.blob && !confirm('Discard this video?')) return
    closeCapture()
  },
  capFlip: () => {
    if (!C || C.stage !== 'camera' || C.recordingPending || C.recorder?.state === 'recording') return
    C.facing = C.facing === 'environment' ? 'user' : 'environment'
    renderCamera()
    startStream()
  },
  capShutter: () => (C?.recorder?.state === 'recording' ? stopRecording() : startRecording()),
  capRetake: () => {
    // A retake uses a brand-new server session.
    if(C.session)rpc('lit_discard_capture',{p_session:C.session.session_id}).catch(()=>{})
    if (C.url) URL.revokeObjectURL(C.url)
    Object.assign(C, { recordingPending: false, publishing: false, blob: null, url: null, session: null, submitted: false, recorder: null, chunks: [], uploaded: false, stage: 'camera' })
    renderCamera()
    startStream()
  },
  capNext: renderVenuePick,
  capBack: renderPreview,
  capPick: (d) => {
    C.pick = d.pid
    document.querySelectorAll('.venue-pick').forEach((b) => {
      const on = b.dataset.pid === d.pid
      b.classList.toggle('on', on)
      b.setAttribute('aria-checked', on)
    })
    $('capPublish').innerHTML = `${icon('flame')} Publish to ${esc(C.nearby?.find((v) => v.id === d.pid)?.name || 'venue')}`
  },
  capPublish: publish,
})

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && C && !C.blob) closeCapture()
})

window.addEventListener('pagehide', closeCapture)
on('auth', closeCapture)
document.addEventListener('visibilitychange', () => {
  if (document.hidden && C?.recorder?.state === 'recording') stopRecording(true)
})
