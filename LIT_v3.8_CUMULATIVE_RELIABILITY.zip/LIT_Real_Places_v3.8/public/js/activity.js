// Display only anonymous server aggregates. No client-side crowd estimates.
import { S, esc, ago, on } from './core.js'
const integer = (value) => typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 ? value : null
export function publicActivity(place, now = Date.now()) {
  const a = place?.activity
  const updated = Date.parse(a?.updated_at), start = Date.parse(a?.window_start), end = Date.parse(a?.window_end)
  const fresh = Number.isFinite(updated) && updated <= now + 60000 && updated >= now - 15 * 60000 && Number.isFinite(start) && Number.isFinite(end) && start <= now && end > now && end > start && updated >= start && updated < end
  return { going: fresh ? integer(a.going_count) : null, planning: fresh ? integer(a.planning_count) : null, updated: fresh ? a.updated_at : null, start: fresh ? a.window_start : null, end: fresh ? a.window_end : null }
}
export function activityMarkup(place, { compact = false, now = Date.now(), pid = place?.pid || '' } = {}) {
  const a = publicActivity(place, now)
  const score = place?.score?.score
  const knownScore = typeof score === 'number' && Number.isFinite(score) && score >= 0 && score <= 100
  const number = (n) => n == null ? '—' : n.toLocaleString('en-US')
  const labels = `<span><strong>${number(a.going)}</strong> going</span><span><strong>${number(a.planning)}</strong> planning to go</span><span>LIT score <strong>${knownScore ? esc(Math.round(score)) + '/100' : '—'}</strong></span>`
  const timing = a.updated ? `Updated ${esc(ago(a.updated, now))} · plans through ${esc(new Date(a.end).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }))}` : 'Live intent counts unavailable'
  return `<div data-activity-place="${esc(pid)}" class="activity-summary ${compact ? 'compact' : ''}" aria-label="Anonymous venue activity"><div class="activity-values">${labels}</div><div class="tiny faint">${timing}</div>${compact ? '' : '<p class="tiny faint">GO taps and accepted plans express intent, not attendance. Totals can overlap; do not add them together. Names and identities are not displayed here.</p>'}</div>`
}

on('activityTick', () => {
  document.querySelectorAll('[data-activity-place]').forEach((el) => {
    const pid = el.dataset.activityPlace
    if (pid) el.outerHTML = activityMarkup(S.places[pid], { compact: el.classList.contains('compact'), pid })
  })
})
