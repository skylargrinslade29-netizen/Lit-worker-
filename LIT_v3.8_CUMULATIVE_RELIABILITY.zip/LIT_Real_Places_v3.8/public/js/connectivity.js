import { $, actionsFor } from './core.js'
export function updateConnectionNotice(restored = false) {
  const el = $('connectionNotice')
  if (!el) return
  const offline = navigator.onLine === false
  el.hidden = !offline && !restored
  el.innerHTML = offline ? 'You are offline. Loaded places may be out of date. Your unsent supported form drafts stay in this browser tab. Reconnect before saving changes.' : 'Connection restored. <button class="link" data-action="retryConnection">Refresh connection</button> <button class="link" data-action="dismissConnection">Dismiss</button>'
}
actionsFor({ retryConnection: async () => {
 const { loadGo } = await import('./go.js')
 const { loadFeed, loadPlaces } = await import('./places.js')
 await loadGo()
 await loadPlaces()
 await loadFeed()
 updateConnectionNotice()
}, dismissConnection: () => { const el = $('connectionNotice'); if (el) el.hidden = true } })
window.addEventListener('offline', () => updateConnectionNotice())
window.addEventListener('online', () => updateConnectionNotice(true))
