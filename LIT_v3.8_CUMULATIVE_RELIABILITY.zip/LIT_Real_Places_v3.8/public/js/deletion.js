import {S,esc,actionsFor,openSheet,closeSheet,toast,emit} from './core.js'
import {sb,rpc} from './api.js'
import {clearSavedVenues} from './saved.js'
import {clearHiddenPosts} from './safety.js'
const receiptKey='lit-deletion-receipt'
function confirmation(){
 if(!S.user)return toast('Sign in to delete your account')
 openSheet('Delete your account',`<form class="stack" data-submit="deleteAccount"><div class="card"><strong>This is permanent.</strong><p class="small muted">Your account will stop making changes immediately. LIT removes your videos, profile, GO and private Crew data, then deletes your sign-in account. Shared venue listings remain. Minimal deletion receipts and safety audit records may remain; this does not remove copies other people already downloaded.</p><p class="small muted">A processing service must be available to start this request. If you sign in with a provider, set an account password using the reset link first. Your platform-owner account cannot be deleted here.</p></div><label class="field">Current password<input name="password" type="password" autocomplete="current-password" required maxlength="512"></label><label class="field">Type DELETE to confirm<input name="confirmation" required autocomplete="off" pattern="DELETE" maxlength="6"></label><button class="btn danger block" type="submit">Permanently request account deletion</button><p class="form-msg" role="status"></p></form>`)
}
async function status(receipt){
 const result=await rpc('lit_deletion_status',{p_receipt:receipt})
 openSheet('Account deletion',`<div class="stack"><strong>${result.state==='completed' ? 'Account deletion completed' : result.state==='needs_operator' ? 'Deletion needs operator attention' : 'Account deletion is pending'}</strong><p class="small muted">${result.state==='completed' ? 'Your LIT account and its application data were removed.' : 'Your account access is disabled. Keep this receipt to check progress; a pending request is not confirmation that deletion finished.'}</p><label class="field">Private receipt<input readonly value="${esc(receipt)}" onclick="this.select()"></label><p class="tiny faint">Keep this receipt private. Anyone with it can check the deletion status.</p><button class="btn alt" data-action="checkDeletion" data-receipt="${esc(receipt)}">Check status</button></div>`)
}
actionsFor({deleteAccount:async(d,form)=>{
 const account=S.authVersion,user=S.user?.id;if(!user)return
 const password=form.elements.namedItem('password').value,confirmation=form.elements.namedItem('confirmation').value
 if(confirmation!=='DELETE' || !password){form.querySelector('.form-msg').textContent='Enter your password and type DELETE.';return}
 const button=form.querySelector('button[type=submit]');button.disabled=true
 try{
  const {data}=await sb.auth.getSession();if(account!==S.authVersion || !data.session?.access_token)throw new Error('Sign in again before continuing.')
  const response=await fetch('/api/delete-account',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+data.session.access_token},body:JSON.stringify({password,confirmation}),signal:AbortSignal.timeout(30000)})
  const result=await response.json();if(account!==S.authVersion)return
  if(!response.ok || result.requested!==true || !result.receipt)throw new Error(result.error || 'The request could not be confirmed.')
  form.password.value='';try{localStorage.setItem(receiptKey,result.receipt)}catch{}
  clearSavedVenues();clearHiddenPosts();closeSheet()
  await sb.auth.signOut();S.posts=[];S.go=null;S.crews=null;S.profile=null;S.urls={};emit('navigate','watch');await status(result.receipt)
 }catch(e){if(account===S.authVersion){form.querySelector('.form-msg').textContent=e.name==='TimeoutError' ? 'The response timed out. Check your account before retrying; the request may have been received.' : e.message;button.disabled=false}}
},deleteAccountStart:confirmation,checkDeletion:d=>status(d.receipt),deletionReceipt:()=>{const receipt=localStorage.getItem(receiptKey);if(receipt)return status(receipt);toast('No deletion receipt saved on this device')}})
