// Device-local bookmarks contain public venue details, never account or GO data.
import { S, esc, actionsFor, openSheet, toast, directionsUrl, emit, distKm, miles, fmtMiles } from './core.js'
const KEY='lit-saved-venues'
const valid=v=>v && typeof v.id==='string' && v.id.length<=500 && typeof v.name==='string' && v.name.trim() && v.name.length<=300 && Number.isFinite(v.lat) && Number.isFinite(v.lon) && Math.abs(v.lat)<=90 && Math.abs(v.lon)<=180
const clean=v=>({id:v.id,name:v.name.trim(),lat:v.lat,lon:v.lon,category:typeof v.category==='string'?v.category.slice(0,100):'',address:typeof v.address==='string'?v.address.slice(0,500):''})
let saved=[]
try{const data=JSON.parse(localStorage.getItem(KEY)||'[]');if(Array.isArray(data))saved=[...new Map(data.filter(valid).map(v=>[v.id,clean(v)])).values()].slice(0,100)}catch{}
function persist(){let ok=true;try{localStorage.setItem(KEY,JSON.stringify(saved))}catch{ok=false;toast('Device storage is unavailable. Export a backup to keep these places.')}emit('saved');return ok}
export const savedVenues=()=>saved.map(v=>({...v}))
export const isSaved=id=>saved.some(v=>v.id===id)
export function toggleSaved(id){if(isSaved(id)){saved=saved.filter(v=>v.id!==id);persist();return false}const v=S.byPid[id]||S.sharedVenues[id];if(!valid(v))throw new Error('Choose a loaded real venue to save.');if(saved.length>=100)throw new Error('You have 100 saved places. Remove one before saving another.');saved.push(clean(v));persist();return true}
export function clearSavedVenues(){saved=[];try{localStorage.removeItem(KEY)}catch{}emit('saved')}
function rows(body){
 const q=body.querySelector('[name=savedQuery]').value.trim().toLowerCase(),sort=body.querySelector('[name=savedSort]').value
 const distance=v=>S.coords?miles(distKm(S.coords.lat,S.coords.lon,v.lat,v.lon)):null
 const list=saved.filter(v=>[v.name,v.address,v.category].some(t=>t.toLowerCase().includes(q)))
 if(sort==='name')list.sort((a,b)=>a.name.localeCompare(b.name))
 if(sort==='nearest'&&S.coords)list.sort((a,b)=>distance(a)-distance(b))
 body.querySelector('#savedCount').textContent=`${list.length} of ${saved.length} saved places`
 body.querySelector('#savedRows').innerHTML=list.length?list.map(v=>`<div class="card stack-sm"><strong>${esc(v.name)}</strong><p class="small muted">${esc(v.address||v.category)}${S.coords?' · '+fmtMiles(distance(v))+' away':''}</p><div class="row wrap"><button class="btn sm" data-action="openSaved" data-pid="${esc(v.id)}">View venue</button><a class="btn sm alt" href="${esc(directionsUrl(v))}" target="_blank" rel="noopener noreferrer">Directions</a><button class="link" data-action="removeSaved" data-pid="${esc(v.id)}">Remove</button></div></div>`).join(''):'<p role="status">'+(saved.length?'No saved places match your search.':'No places saved yet. Use Save place on a venue.')+'</p>'
}
function showSaved(){
 const body=openSheet('Saved places',`<div class="stack"><p class="small muted">Saved on this device, separate from GO. Export a backup to move bookmarks to another device.</p><label class="field">Search saved places<input class="input" name="savedQuery" type="search" maxlength="300" placeholder="Name, address or category"></label><label class="field">Sort<select name="savedSort"><option value="saved">Saved order</option><option value="name">Name</option>${S.coords?'<option value="nearest">Nearest</option>':''}</select></label><p class="tiny muted" id="savedCount" aria-live="polite"></p><div class="stack" id="savedRows"></div><button class="btn alt" data-action="exportSaved">Export backup</button><label class="field">Import backup<input type="file" name="savedImport" accept="application/json,.json"></label><p id="savedImportStatus" class="small muted" role="status"></p></div>`)
 body.querySelector('[name=savedQuery]').addEventListener('input',()=>rows(body));body.querySelector('[name=savedSort]').addEventListener('change',()=>rows(body))
 body.querySelector('[name=savedImport]').addEventListener('change',async e=>{
 const status=body.querySelector('#savedImportStatus'),file=e.target.files?.[0];if(!file)return
 try{if(file.size>256000)throw new Error('Choose a LIT backup smaller than 256 KB.');const data=JSON.parse(await file.text());if(data.format!=='lit-saved-places'||data.version!==1||!Array.isArray(data.places)||data.places.length>100||!data.places.every(valid))throw new Error('This is not a valid LIT saved places backup.');if(!body.isConnected)return;const merged=[...new Map([...saved,...data.places.map(clean)].map(v=>[v.id,v])).values()];if(merged.length>100)throw new Error('This backup would exceed 100 saved places. Remove some places first.');const added=merged.length-saved.length;saved=merged;const kept=persist();rows(body);status.textContent=`Imported ${added} additional places.${kept?'':' Export a backup before closing; device storage is unavailable.'}`}catch(error){if(body.isConnected)status.textContent=error.message||'Unable to import this backup.'}e.target.value=''
 });rows(body)
}
actionsFor({savedPlaces:showSaved,saveVenue:(d,button)=>{const yes=toggleSaved(d.pid);button.textContent=yes?'Saved ✓':'Save place';button.setAttribute('aria-pressed',String(yes));toast(yes?'Place saved on this device':'Saved place removed')},removeSaved:d=>{saved=saved.filter(v=>v.id!==d.pid);persist();const body=document.getElementById('sheetBody');if(body?.querySelector('#savedRows'))rows(body)},openSaved:async d=>{const v=saved.find(v=>v.id===d.pid);if(!v)return;const {openSharedVenue}=await import('./venue.js');await openSharedVenue(v.id,{lat:v.lat,lon:v.lon})},exportSaved:()=>{const url=URL.createObjectURL(new Blob([JSON.stringify({format:'lit-saved-places',version:1,places:saved},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='LIT-saved-places.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Backup contains public venue bookmarks only')}})
