// Shared state, events, DOM helpers, sheets and formatting.
export const $ = (id) => document.getElementById(id)
export const esc = (x) =>
  String(x ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
export const icon = (name, cls = '') => `<svg class="i ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`

const PREFS_KEY = 'lit-v2-prefs'
const LEGACY_KEY = 'lit-launch-ready-local-v1'
let prefs = {}
try {
  const stored = JSON.parse(localStorage.getItem(PREFS_KEY) || '{}')
  prefs = stored && typeof stored === 'object' && !Array.isArray(stored) ? stored : {}
} catch {}
let legacy = {}
try {
  const stored = JSON.parse(localStorage.getItem(LEGACY_KEY) || '{}')
  legacy = stored && typeof stored === 'object' && !Array.isArray(stored) ? stored : {}
} catch {}

export const S = {
  autoplay: prefs.autoplay !== false,
  dataSaver: prefs.dataSaver === true,
  radius: [5, 10, 25, 50].includes(prefs.radius) ? prefs.radius : [5, 10, 25, 50].includes(legacy.radius) ? legacy.radius : 10,
  category: prefs.category || legacy.category || 'All',
  when: prefs.when || 'now',
  localGo: null, // Legacy device-only GO is no longer supported.
  coords: null,
  area: null,
  venues: [],
  byPid: {},
  sharedVenues: {}, // Shared links are separate from current radius results.
  places: {}, // pid -> {place_id, score, promos, claimed}
  posts: [],
  urlExpires: {},
  urls: {}, // video_path -> signed URL
  feedState: 'idle', // idle | locating | loading | ready | error | denied
  placesError: null,
  feedError: null,
  locationQuery: '',
  locationSource: null,
  placesWarning: null,
  placesProvider: null,
  coverageMiles: null,
  serverTime: null,
  user: null,
  authVersion: 0,
  profile: null,
  reviewAccess: null,
  go: null,
  crews: null,
  backend: 'unknown', // unknown | ready | missing | offline
  screen: 'watch',
}

export function savePrefs() {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify({ autoplay: S.autoplay, dataSaver: S.dataSaver, radius: S.radius, category: S.category, when: S.when, localGo: S.localGo }))
  } catch {}
}

// Tiny event bus
const bus = new EventTarget()
export const on = (name, fn) => bus.addEventListener(name, (e) => fn(e.detail))
export const emit = (name, detail) => bus.dispatchEvent(new CustomEvent(name, { detail }))

// Delegated actions: <button data-action="name" data-x="..">
const actions = {}
export const actionsFor = (map) => Object.assign(actions, map)
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-action]')
  if (!el || el.disabled) return
  const fn = actions[el.dataset.action]
  if (fn) {
    e.preventDefault()
    invokeAction(fn, el.dataset, el, e)
  }
})
document.addEventListener('submit', (e) => {
  const form = e.target.closest('form[data-submit]')
  if (!form) return
  e.preventDefault()
  const fn = actions[form.dataset.submit]
  if (fn) invokeAction(fn, form.dataset, form, e)
})

const pendingActions = new WeakSet()
function invokeAction(fn, data, element, event) {
  if (pendingActions.has(element)) return
  pendingActions.add(element)
  try { Promise.resolve(fn(data, element, event)).catch((error) => toast(error.message || 'Something went wrong. Please retry.')).finally(() => pendingActions.delete(element)) }
  catch (error) { pendingActions.delete(element); toast(error.message || 'Something went wrong. Please retry.') }
}

export function safeWebUrl(value) {
  if (typeof value !== 'string') return null
  try { const url = new URL(value.trim()); return ['https:', 'http:'].includes(url.protocol) ? url.href : null } catch { return null }
}

// Toast
let toastTimer
export function toast(text) {
  const t = $('toast')
  t.textContent = text
  t.classList.add('show')
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => t.classList.remove('show'), 3200)
}

// Sheets
let sheetCleanup = null
let lastFocus = null
export function openSheet(title, body, { eyebrow = '', full = false, onClose } = {}) {
  closeSheet(true)
  lastFocus = document.activeElement
  $('sheetRoot').innerHTML = `<div class="scrim" data-scrim>
    <div class="sheet ${full ? 'full' : ''}" role="dialog" tabindex="-1" aria-modal="true" aria-labelledby="sheetTitle">
      <div class="grabber" aria-hidden="true"></div>
      <div class="sheet-head"><div>${eyebrow ? `<div class="eyebrow">${esc(eyebrow)}</div>` : ''}<h2 id="sheetTitle">${esc(title)}</h2></div>
      <button class="x" data-action="closeSheet" aria-label="Close">${icon('close')}</button></div>
      <div id="sheetBody">${body}</div>
    </div></div>`
  sheetCleanup = onClose || null
  const scrim = $('sheetRoot').firstElementChild
  scrim.addEventListener('click', (e) => {
    if (e.target === scrim) closeSheet()
  })
  syncModalState()
  setTimeout(() => { if (scrim.isConnected) (scrim.querySelector('input,select,textarea,button:not(.x)') || scrim.querySelector('.sheet'))?.focus({ preventScroll: true }) }, 60)
  return $('sheetBody')
}
export function closeSheet(silent) {
  if (!$('sheetRoot').children.length) return
  const fn = sheetCleanup
  sheetCleanup = null
  $('sheetRoot').innerHTML = ''
  syncModalState()
  fn?.()
  if (!silent) lastFocus?.focus?.({ preventScroll: true })
}
export const sheetOpen = () => $('sheetRoot').children.length > 0
export function syncModalState() {
  const open = Boolean($('sheetRoot')?.children.length || $('captureRoot')?.children.length)
  for (const id of ['main', 'hdr', 'tabbar', 'connectionNotice']) { const element = $(id); if (element) element.inert = open }
}

actionsFor({ closeSheet: () => closeSheet() })
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && sheetOpen()) closeSheet()
  if (e.key !== 'Tab') return
  const dialog = $('captureRoot')?.querySelector('[role=dialog]') || $('sheetRoot')?.querySelector('[role=dialog]')
  if (!dialog) return
  const items = [...dialog.querySelectorAll('button,input,select,textarea,a[href],[tabindex="0"]')].filter((x) => !x.disabled && x.getClientRects().length)
  if (!items.length) { e.preventDefault(); dialog.focus(); return }
  const first = items[0], last = items.at(-1)
  if (!dialog.contains(document.activeElement) || (e.shiftKey && document.activeElement === first) || (!e.shiftKey && document.activeElement === last)) {
    e.preventDefault(); (e.shiftKey ? last : first).focus()
  }
})

// Formatting
export const miles = (km) => km * 0.621371
export function distKm(a, b, c, d) {
  const r = Math.PI / 180
  const p = Math.min(1, Math.max(0, Math.sin(((c - a) * r) / 2) ** 2 + Math.cos(a * r) * Math.cos(c * r) * Math.sin(((d - b) * r) / 2) ** 2))
  return 6371 * 2 * Math.atan2(Math.sqrt(p), Math.sqrt(1 - p))
}
export function fmtMiles(mi) {
  if (mi == null || !Number.isFinite(mi)) return ''
  if (mi < 0.1) return `${Math.max(50, Math.round((mi * 5280) / 50) * 50)} ft`
  return `${mi < 10 ? mi.toFixed(1) : Math.round(mi)} mi`
}
export function ago(iso, now = Date.now()) {
  if (!iso) return ''
  const s = Math.max(0, (now - new Date(iso).getTime()) / 1000)
  if (s < 60) return 'just now'
  if (s < 3600) return `${Math.floor(s / 60)} min ago`
  if (s < 86400) return `${Math.floor(s / 3600)} hr ago`
  return `${Math.floor(s / 86400)} d ago`
}
export const fmtTime = (iso) => new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
export function fmtWhen(iso) {
  const d = new Date(iso)
  const today = new Date()
  const tmr = new Date(Date.now() + 86400000)
  const day = d.toDateString() === today.toDateString() ? 'Today' : d.toDateString() === tmr.toDateString() ? 'Tomorrow' : d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })
  return `${day} · ${fmtTime(iso)}`
}
export const fmtNum = (n) => (n == null ? '—' : Number(n).toLocaleString())
export function fmtDuration(sec) {
  if (sec == null) return '—'
  if (sec < 60) return `${Math.round(sec)}s`
  if (sec < 3600) return `${Math.floor(sec / 60)}m ${Math.round(sec % 60)}s`
  return `${Math.floor(sec / 3600)}h ${Math.round((sec % 3600) / 60)}m`
}
export const initials = (name) => (String(name || '?').trim()[0] || '?').toUpperCase()

// LIT score badge — never invents a number.
export function litBadge(score) {
  if (!score || score.score == null || !Number.isFinite(Number(score.score))) return `<span class="lit none" title="Not enough recent independent evidence">NO FRESH PROOF</span>`
  return `<span class="lit" data-s="${esc(score.status)}"><b>${Math.min(100, Math.max(0, Number(score.score)))}</b>${esc(score.status)}</span>`
}
export function litDial(score) {
  if (!score || score.score == null || !Number.isFinite(Number(score.score))) return `<div class="dial none" aria-label="No fresh proof"><span>NO<br>PROOF</span></div>`
  const c = { 'ON FIRE': '#ff4d2e', LIT: '#ff8a3d', 'HEATING UP': '#ffc46b', ACTIVE: '#e8d9c4', 'COOLING DOWN': '#8b8f9c' }[score.status] || '#8b8f9c'
  return `<div class="dial" style="--v:${Math.min(100, Math.max(0, Number(score.score)))};--c:${c}" aria-label="LIT Score ${Math.min(100, Math.max(0, Number(score.score)))}, ${esc(score.status)}"><span>${Math.min(100, Math.max(0, Number(score.score)))}</span></div>`
}

export function isIOS() {
  return /iP(hone|ad|od)/.test(navigator.platform) || (navigator.userAgent.includes('Mac') && 'ontouchend' in document)
}

export function directionsUrl(v) {
  const dest = `${v.lat},${v.lon}`
  return isIOS()
    ? `https://maps.apple.com/?daddr=${encodeURIComponent(dest)}&q=${encodeURIComponent(v.name)}`
    : `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(dest)}&travelmode=driving`
}

export function getPosition({ fresh = false, timeout = 12000 } = {}) {
  return new Promise((resolve, reject) => {
    if (window.isSecureContext === false) return reject(Object.assign(new Error('Location requires HTTPS. Open the secure LIT website.'), { code: 'insecure' }))
    if (!navigator.geolocation) return reject(Object.assign(new Error('Location is unavailable in this browser. Open LIT in Safari or Chrome, or enter a ZIP/city.'), { code: 'unsupported' }))
    let settled = false
    const finish = (callback, value) => {
      if (settled) return
      settled = true; clearTimeout(timer); callback(value)
    }
    const failure = (error) => {
      const message = error.code === 1 ? 'Location permission is off. Allow location for LIT in your browser settings, then try again. You can also enter a ZIP or city.'
        : error.code === 3 ? 'Location timed out. Try again outdoors or enter a ZIP or city.'
        : 'Your device could not get a location. Check that Location Services is on, then retry or enter a ZIP or city.'
      finish(reject, Object.assign(new Error(message), { code: error.code }))
    }
    // Some mobile browsers never invoke a callback while a permission prompt is open.
    const timer = setTimeout(() => failure({ code: 3 }), timeout + 1000)
    try {
      navigator.geolocation.getCurrentPosition(
        (p) => {
          const lat = p.coords?.latitude, lon = p.coords?.longitude
          if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return failure({ code: 2 })
          finish(resolve, { lat, lon, accuracy: p.coords.accuracy })
        }, failure,
        { enableHighAccuracy: fresh, timeout, maximumAge: fresh ? 0 : 120000 },
      )
    } catch { failure({ code: 2 }) }
  })
}
