import { esc, safeWebUrl } from './core.js'
// Operator-provided URLs only. No fictional legal documents or support contacts.
export function resourceLinks() {
  const labels = { terms: 'Terms', privacy: 'Privacy policy', support: 'Contact support', deletion: 'Request account deletion' }
  return Object.entries(labels).map(([key, label]) => {
    const url = safeWebUrl(window.LIT_CONFIG?.links?.[key])
    return url ? `<a class="link" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${label}</a>` : ''
  }).filter(Boolean).join(' · ')
}
