// GPS and manual locations share one real-venue discovery pipeline.
import { S, $, emit, savePrefs, distKm, miles, getPosition, toast } from './core.js'
import { sb, rpc, signedUrls } from './api.js'
import { visiblePosts } from './safety.js'

const CACHE = 'lit-v3.2-places'
const validCoords = (p) => p && Number.isFinite(p.lat) && Number.isFinite(p.lon) && Math.abs(p.lat) <= 90 && Math.abs(p.lon) <= 180
let locationVersion = 0, requestVersion = 0, feedVersion = 0
let geocodeController = null, placesController = null
export const venue = (pid) => S.byPid[pid] || S.sharedVenues[pid] || null
export const placeOf = (pid) => S.places[pid] || null

function setVenues(list) {
  S.venues = list.filter((v) => v && typeof v.id === 'string' && typeof v.name === 'string' && v.name.trim() && validCoords(v))
  S.byPid = Object.fromEntries(S.venues.map((v) => [v.id, v]))
  recomputeDistances()
}
export function recomputeDistances() {
  if (!S.coords) return
  for (const v of S.venues) v.mi = miles(distKm(S.coords.lat, S.coords.lon, v.lat, v.lon))
}
async function fetchJson(path, params, controller, timeout = 24000) {
  const timer = setTimeout(() => controller.abort(), timeout)
  try {
    const response = await fetch(`${path}?${new URLSearchParams(params)}`, { signal: controller.signal })
    let data
    try { data = await response.json() } catch { throw new Error('Location service returned an invalid response. Please retry.') }
    if (!response.ok) throw new Error(data.error || 'Location service is temporarily unavailable. Please retry.')
    return data
  } catch (error) {
    if (controller.signal.aborted) throw new Error('Location search took too long. Please retry or choose another location.')
    if (error instanceof TypeError) throw new Error('Could not reach the location service. Check your connection and retry.')
    throw error
  } finally { clearTimeout(timer) }
}
export async function nearbyVenues(coords, controller = new AbortController()) {
  if (!validCoords(coords)) throw new Error('A valid GPS position is required.')
  const data = await fetchJson('/api/places', { lat: coords.lat.toFixed(5), lon: coords.lon.toFixed(5), radius: '5' }, controller)
  if (!Array.isArray(data.venues)) throw new Error('Places service returned an invalid response. Please retry.')
  return data.venues.filter((v) => v && typeof v.id === 'string' && typeof v.name === 'string' && v.name.trim() && validCoords(v))
}

export function restoreCache() {
  try {
    const c = JSON.parse(sessionStorage.getItem(CACHE) || 'null')
    if (c && Date.now() - c.at < 20 * 60 * 1000 && c.radius === S.radius && validCoords(c.coords) && Array.isArray(c.venues)) {
      S.coords = c.coords; S.area = c.area; S.locationSource = c.source
      S.placesProvider = c.provider; S.placesWarning = c.warning || null; S.coverageMiles = c.coverage
      setVenues(c.venues); S.feedState = 'ready'; return true
    }
  } catch {}
  return false
}
function beginLocation() {
  const version = ++locationVersion
  ++requestVersion; ++feedVersion
  geocodeController?.abort(); placesController?.abort()
  S.coords = null; S.area = null; S.venues = []; S.byPid = {}; S.places = {}; S.posts = []
  S.locationError = null; S.placesError = null; S.feedError = null; S.placesWarning = null; S.placesProvider = null; S.coverageMiles = null
  S.feedState = 'locating'
  try { sessionStorage.removeItem(CACHE) } catch {}
  emit('places'); emit('feed')
  return version
}
export async function locate({ silent = false } = {}) {
  const keys = ['coords', 'area', 'locationSource', 'venues', 'byPid', 'places', 'posts', 'placesError', 'feedError', 'placesWarning', 'placesProvider', 'coverageMiles', 'feedState']
  const previous = Object.fromEntries(keys.map((key) => [key, S[key]]))
  const version = beginLocation()
  try {
    const p = await getPosition({ fresh: true })
    if (version !== locationVersion) return
    if (!validCoords(p)) throw new Error('Could not determine your location. Enter a ZIP code or city.')
    S.coords = { lat: p.lat, lon: p.lon }; S.area = 'Near you'; S.locationSource = 'gps'
    await loadPlaces({ keepArea: true })
  } catch (error) {
    if (version !== locationVersion) return
    if (previous.coords) {
      Object.assign(S, previous)
      S.feedState = previous.venues.length ? 'ready' : 'error'
      S.locationError = `${error.message} Keeping your previous search location.`
    } else {
      S.feedState = error.code === 1 ? 'denied' : 'error'; S.placesError = error.message
      S.locationError = error.message
    }
    emit('places'); emit('feed'); if (!silent) toast(error.message)
  }
}
export async function searchLocation(query) {
  const q = String(query || '').trim()
  if (q.length < 2 || q.length > 100) throw new Error('Enter a ZIP code or city (2–100 characters).')
  S.locationQuery = q
  const version = beginLocation(), controller = geocodeController = new AbortController()
  try {
    const data = await fetchJson('/api/geocode', { q }, controller, 14000)
    if (version !== locationVersion) return
    if (!validCoords(data)) throw new Error('Could not find that location. Try a ZIP code or city and state.')
    S.coords = { lat: data.lat, lon: data.lon }; S.area = data.area || q; S.locationSource = 'manual'
    await loadPlaces({ keepArea: true })
  } catch (error) {
    if (version !== locationVersion) return
    S.feedState = 'error'; S.placesError = error.message; emit('feed'); throw error
  }
}
export async function loadPlaces({ keepArea = true } = {}) {
  if (!S.coords) return S.feedState === 'locating' ? undefined : locate()
  const version = ++requestVersion, location = locationVersion, coords = { ...S.coords }, radius = S.radius
  ++feedVersion; placesController?.abort()
  const controller = placesController = new AbortController()
  S.feedState = 'loading'; S.placesError = null; emit('feed')
  try {
    const data = await fetchJson('/api/places', { lat: coords.lat.toFixed(5), lon: coords.lon.toFixed(5), radius: String(radius) }, controller)
    if (version !== requestVersion || location !== locationVersion) return
    if (!Array.isArray(data.venues)) throw new Error('Places service returned an invalid response. Please retry.')
    S.area = keepArea ? (S.area || data.area) : (data.area || S.area)
    S.placesWarning = data.warning || null; S.placesProvider = data.provider || null
    S.coverageMiles = Number.isFinite(data.coverage_miles) ? data.coverage_miles : radius
    setVenues(data.venues)
    S.places = {}; S.posts = []; S.feedError = null; S.feedState = 'ready'
    try { sessionStorage.setItem(CACHE, JSON.stringify({ at: Date.now(), radius, coords, area: S.area, venues: S.venues,
      source: S.locationSource, provider: S.placesProvider, warning: S.placesWarning, coverage: S.coverageMiles })) } catch {}
    emit('places'); emit('feed'); await loadFeed()
  } catch (error) {
    if (version !== requestVersion || location !== locationVersion) return
    S.feedState = S.venues.length ? 'ready' : 'error'
    S.placesError = error.message
    if (S.venues.length) S.placesWarning = 'Refresh failed. Showing previously loaded real places; expanded coverage may be unavailable.'
    emit('feed')
  }
}
export async function setRadius(radius) {
  if (![5, 10, 25, 50].includes(radius) || S.radius === radius) return
  S.radius = radius; savePrefs()
  if (S.coords) await loadPlaces(); else emit('places')
}
function rank(post) {
  const ageMin = (Date.now() - new Date(post.created_at).getTime()) / 60000
  return Math.exp(-ageMin / 240) / (1 + (S.byPid[post.pid]?.mi ?? 5) / 4)
}
export async function loadFeed() {
  const version = ++feedVersion, location = locationVersion, request = requestVersion
  const current = () => version === feedVersion && location === locationVersion && request === requestVersion
  if (S.feedState === 'locating' || S.feedState === 'loading') return
  if (!S.venues.length || !sb) {
    S.posts = []; S.feedError = !sb && S.venues.length ? 'Fresh video is temporarily unavailable. You can still browse real nearby places.' : null
    emit('feed'); return
  }
  try {
    const groups = new Map()
    for (const v of S.venues) { if (!groups.has(v.category)) groups.set(v.category, []); groups.get(v.category).push(v) }
    const balanced = []
    while (balanced.length < 250 && [...groups.values()].some((g) => g.length)) {
      for (const group of groups.values()) if (group.length && balanced.length < 250) balanced.push(group.shift())
    }
    const list = balanced.map((v) => ({ id: v.id, name: v.name, lat: v.lat, lon: v.lon, category: v.category, address: v.address }))
    const data = await rpc('lit_nearby_feed', { p_places: list })
    if (!current()) return
    const cutoff = Date.now() - 24 * 60 * 60 * 1000
    const posts = (data.posts || []).filter((p) => { const timestamp = Date.parse(p.created_at)
      return S.byPid[p.pid] && Number.isFinite(timestamp) && timestamp >= cutoff && timestamp <= Date.now() + 60000
    }).sort((a, b) => rank(b) - rank(a))
    await signedUrls(posts.map((p) => p.video_path))
    if (!current()) return
    S.serverTime = data.server_time; S.places = Object.fromEntries((data.places || []).map((p) => [p.pid, p])); S.posts = freshPosts(posts); S.feedError = null
  } catch {
    if (!current()) return
    S.places = {}; S.posts = []; S.feedError = 'Fresh video is temporarily unavailable. You can still browse real nearby places.'
  }
  if (!current()) return
  emit('feed'); emit('places')
}
export async function ensurePlaceId(pid, candidate = null) {
  if (S.places[pid]?.place_id && S.places[pid].provider_verified !== false) return S.places[pid].place_id
  const v = venue(pid) || candidate
  if (!v || v.id !== pid || !validCoords(v) || typeof v.name !== 'string') return null
  const data = await rpc('lit_nearby_feed', { p_places: [{ id: v.id, name: v.name, lat: v.lat, lon: v.lon, category: v.category, address: v.address }] })
  let p = data.places?.[0]
  if ((!p || p.provider_verified === false) && S.user) {
    const account = S.authVersion
    const { data: session } = await sb.auth.getSession()
    if (account !== S.authVersion || !session.session?.access_token) return null
    const response = await fetch('/api/register-place', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.session.access_token}` },
      body: JSON.stringify({ id: v.id, lat: v.lat, lon: v.lon }),
      signal: AbortSignal.timeout(25000),
    })
    let registered
    try{registered=await response.json()}catch{throw new Error('Venue saving returned an unexpected response. Refresh LIT and try again.')} 
    if (account !== S.authVersion) return null
    if (!response.ok) throw new Error((registered.error || 'Venue registration is temporarily unavailable.')+(registered.reference ? ` Reference: ${String(registered.reference).slice(0,8)}.` : ''))
    p = registered.place
  }
  if (p && venue(pid)) S.places[pid] = { ...S.places[pid], ...p }
  return p?.place_id || null
}

export async function resolveSharedVenue(pid, hints = {}) {
  if (typeof pid !== 'string' || pid.length > 512 || !/^(geoapify:.+|osm:(node|way|relation):\d+)$/.test(pid)) throw new Error('This venue link is invalid.')
  if (venue(pid)) return venue(pid)
  const account = S.authVersion
  let found = null
  try { found = await rpc('lit_public_place', { p_pid: pid }) } catch { /* A provider lookup can recover an unregistered link. */ }
  let v = found?.venue
  if (!v && validCoords(hints)) {
    const params = new URLSearchParams({ lat: hints.lat, lon: hints.lon, radius: 5 })
    const response = await fetch(`/api/places?${params}`, { signal: AbortSignal.timeout(25000) })
    const result = await response.json()
    if (!response.ok) throw new Error(result.error || 'Venue lookup is temporarily unavailable. Try again.')
    v = result.venues?.find(row => row.id === pid)
  }
  if (account !== S.authVersion) throw new Error('Your account changed. Open the venue link again.')
  if (!v || v.id !== pid || !validCoords(v) || typeof v.name !== 'string' || !v.name.trim()) throw new Error('This venue could not be found. Ask for a new shared link or try again later.')
  const distance = S.coords ? miles(distKm(S.coords.lat,S.coords.lon,v.lat,v.lon)) : null
  if (Object.keys(S.sharedVenues).length >= 100) delete S.sharedVenues[Object.keys(S.sharedVenues)[0]]
  S.sharedVenues[pid] = { ...v, mi: distance }
  if (found?.place) S.places[pid] = found.place
  return S.sharedVenues[pid]
}

let activityRefreshPending = false
export async function refreshActivity() {
  if (activityRefreshPending || document.hidden || !sb) return
  const places = [...new Set(Object.values(S.places).map(p => p.place_id).filter(Boolean))].slice(0,250)
  if (!places.length) return
  const account = S.authVersion
  activityRefreshPending = true
  try {
    const counts = await rpc('lit_activity_counts', { p_places: places })
    if (account !== S.authVersion || !Array.isArray(counts)) return
    const byId = Object.fromEntries(counts.map(row => [row.place_id,row]))
    for (const p of Object.values(S.places)) if (byId[p.place_id]) {
      p.activity = byId[p.place_id].activity; p.claimed = byId[p.place_id].claimed
    }
    emit('activityTick')
  } catch { emit('activityTick') /* Timestamp validation makes stale totals unavailable. */ }
  finally { activityRefreshPending = false }
}
export function updateLocationLabel() {
  const el = $('locLabel')
  if (el) el.textContent = S.coords ? S.area || 'Near you' : 'Set location'
}

// Fresh clips should not linger in an already-open page past their expiry.
export function freshPosts(posts, now = Date.now()) {
  return visiblePosts(posts).filter((post) => {
    const created = Date.parse(post.created_at)
    const expires = post.expires_at == null ? created + 24 * 60 * 60 * 1000 : Date.parse(post.expires_at)
    return Number.isFinite(created) && Number.isFinite(expires) && created >= now - 24 * 60 * 60 * 1000 && created <= now + 60000 && expires > now
  })
}
export function pruneExpiredPosts() {
  const fresh = freshPosts(S.posts)
  if (fresh.length === S.posts.length) { emit('activityTick'); return false }
  S.posts = fresh; emit('feed'); emit('places'); emit('activityTick'); return true
}
