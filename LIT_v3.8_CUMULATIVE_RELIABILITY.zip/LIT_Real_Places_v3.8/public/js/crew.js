// CREW — real LIT users coordinating outings. No followers, no public profiles, no locations.
import { S, $, esc, icon, on, emit, actionsFor, toast, openSheet, closeSheet, initials, fmtWhen, sheetOpen } from './core.js'
import { rpc } from './api.js'
import { venue, ensurePlaceId } from './places.js'
import { openSharedVenue } from './venue.js'
import { requireAuth, profileForm } from './account.js'

let loading = false
let crewVersion = 0
let openCrew = null
let pendingJoinCode = null

export async function loadCrews() {
  const version = ++crewVersion, user = S.user?.id
  const current = () => version === crewVersion && user === S.user?.id
  if (!S.user) {
    S.crews = null
    return
  }
  loading = true
  try {
    const crews = await rpc('lit_my_crews')
    if (!current()) return
    if (!Array.isArray(crews)) throw new Error('Crew data is unavailable. Please retry.')
    S.crews = crews
    S.crewError = null
  } catch (e) {
    if (!current()) return
    S.crewError = e.message || 'Unable to load Crew'
    S.crews = S.crews || []
  }
  loading = false
  if (S.screen === 'crew') renderCrew()
}

const RESP = { in: "I'm In", maybe: 'Maybe', pass: 'Pass', waiting: 'Waiting' }

function outingCard(o, crew) {
  const mine = o.responses.find((r) => r.me)?.response || 'waiting'
  const groups = ['in', 'maybe', 'pass', 'waiting']
    .map((k) => {
      const names = o.responses.filter((r) => r.response === k).map((r) => (r.me ? 'You' : r.name))
      return names.length ? `<span><strong style="color:var(--text)">${RESP[k]}</strong> ${esc(names.join(', '))}</span>` : ''
    })
    .join('')
  return `<div class="card stack-sm">
    <div class="row between"><span class="tag hot">${esc(crew.name)}</span><span class="tiny faint">${fmtWhen(o.starts_at)}</span></div>
    <button class="row between" style="text-align:left" data-action="crewVenue" data-pid="${esc(o.pid)}" data-lat="${esc(o.lat)}" data-lon="${esc(o.lon)}"><h3>${esc(o.place_name)}</h3>${icon('chev-right', 'i-sm')}</button>
    ${o.note ? `<div class="small muted">“${esc(o.note)}”</div>` : ''}
    <div class="rsvp" role="group" aria-label="Your response">${['in', 'maybe', 'pass'].map((k) => `<button class="${mine === k ? 'on' : ''}" data-action="rsvp" data-outing="${esc(o.id)}" data-v="${k}" aria-pressed="${mine === k}">${RESP[k]}</button>`).join('')}</div>
    <div class="tally">${groups}</div>
    <div class="btn-row"><button class="btn sm alt" data-action="outingDirections" data-lat="${esc(o.lat)}" data-lon="${esc(o.lon)}" data-name="${esc(o.place_name)}" data-place="${esc(o.place_id)}">${icon('route')} Directions</button>
    ${o.can_cancel ? `<button class="btn sm ghost" data-action="cancelOuting" data-outing="${esc(o.id)}">Cancel plan</button>` : ''}
    ${mine === 'in' ? `<button class="btn sm alt" data-action="goOuting" data-pid="${esc(o.pid)}">${icon('go')} Set as GO</button>` : ''}</div>
  </div>`
}

function crewCard(c) {
  if (c.my_status === 'invited') {
    const owner = c.members.find((m) => m.role === 'owner')
    return `<div class="card stack-sm"><div class="row between"><h3>${esc(c.name)}</h3><span class="tag">Invite</span></div>
      <p class="small muted" style="margin:0">${esc(owner?.name || 'A LIT member')} invited you to this Crew.</p>
      <div class="btn-row"><button class="btn sm" data-action="crewInvite" data-crew="${esc(c.id)}" data-v="1">Join Crew</button><button class="btn sm ghost" data-action="crewInvite" data-crew="${esc(c.id)}" data-v="0">Decline</button></div></div>`
  }
  const expanded = openCrew === c.id
  const joined = c.members.filter((m) => m.status === 'joined').length
  return `<div class="card stack-sm">
    <button class="row between" style="text-align:left" data-action="toggleCrew" data-crew="${esc(c.id)}" aria-expanded="${expanded}">
      <div class="row"><div class="row" style="gap:0">${c.members.slice(0, 4).map((m, i) => `<span class="initial" style="margin-left:${i ? -10 : 0}px">${esc(initials(m.name))}</span>`).join('')}</div>
      <div><h3>${esc(c.name)}</h3><div class="tiny faint">${joined} member${joined === 1 ? '' : 's'}${c.outings.length ? ` · ${c.outings.length} plan${c.outings.length === 1 ? '' : 's'}` : ''}</div></div></div>
      ${icon(expanded ? 'chev-down' : 'chev-right', 'i-sm')}</button>
    ${expanded ? `<div class="divider"></div>
      ${c.members.map((m) => `<div class="member"><span class="initial">${esc(initials(m.name))}</span><div class="grow"><strong>${esc(m.me ? 'You' : m.name)}</strong>${m.username ? `<div class="tiny faint">@${esc(m.username)}</div>` : ''}</div>
        ${m.role === 'owner' ? '<span class="tag">Owner</span>' : m.status === 'invited' ? '<span class="tag">Invited</span>' : ''}
        ${c.my_role === 'owner' && !m.me ? `<button class="x" data-action="removeMember" data-crew="${esc(c.id)}" data-user="${esc(m.user_id)}" aria-label="Remove ${esc(m.name)}">${icon('close')}</button>` : ''}</div>`).join('')}
      ${c.my_role === 'owner' ? `<form class="inline-form" data-submit="addMember" data-crew="${esc(c.id)}"><input class="input" name="username" maxlength="25" placeholder="Invite by @username" autocomplete="off" autocapitalize="none" aria-label="LIT username"><button class="btn sm" type="submit">${icon('plus')} Invite</button></form>
      <p class="tiny muted">Only you manage membership. Anyone with your current link can join until it expires. Generate a new link to disable the old one.</p>
      <div class="row wrap"><span class="tiny muted">Invite ${Date.parse(c.invite_expires_at)>Date.now() ? 'expires '+fmtWhen(c.invite_expires_at) : 'expired'}</span><button class="btn sm alt" data-action="shareCode" data-code="${esc(c.invite_code)}" data-name="${esc(c.name)}" ${Date.parse(c.invite_expires_at)<=Date.now() ? 'disabled' : ''}>${icon('share')} Share invite</button><button class="btn sm ghost" data-action="rotateCrewInvite" data-crew="${esc(c.id)}">New invite link</button></div>` : ''}
      <button class="btn sm ghost" data-action="leaveCrew" data-crew="${esc(c.id)}" data-owner="${c.my_role === 'owner' ? 1 : 0}">${c.my_role === 'owner' ? 'Delete Crew' : 'Leave Crew'}</button>` : ''}
  </div>`
}

export function renderCrew() {
  const el = $('crew')
  const head = `<div class="eyebrow">CREW</div><h1 class="title">Go out together.</h1>`
  if (!S.user) {
    el.innerHTML = `${head}<p class="lede">Make plans with real LIT friends: pick a venue, set a time, and see who’s in. Crews are private — members only see names and responses, never locations.</p>
      <div class="card glow stack"><strong>Sign in to start a Crew</strong><button class="btn block" data-action="account">Log in or sign up</button></div>`
    return
  }
  if (!S.profile?.username) {
    el.innerHTML = `${head}<p class="lede">Choose a username so friends can add you. LIT never shows followers or public profiles.</p><div class="card">${profileForm()}</div>`
    return
  }
  if (S.crewError) {
    el.innerHTML = `${head}<div class="card stack"><strong>Crew connection needs attention</strong><p class="small muted">${esc(S.crewError)}</p><button class="btn sm" data-action="crewRetry">Try again</button></div>`
    return
  }
  if (S.crews == null) {
    el.innerHTML = `${head}<div class="list"><div class="skel"></div><div class="skel"></div></div>`
    if (!loading) loadCrews()
    return
  }
  const crews = S.crews
  const plans = crews.flatMap((c) => c.outings.map((o) => ({ o, c }))).sort((a, b) => new Date(a.o.starts_at) - new Date(b.o.starts_at))
  el.innerHTML = `${head}<p class="lede">You’re <strong style="color:var(--text)">@${esc(S.profile.username)}</strong>. Plans show who’s in — never where anyone is.</p>
    <div class="row between"><h2 class="sec">Plans</h2><button class="link" data-action="crewRetry">Refresh Crew</button></div>
    ${plans.length ? `<div class="list">${plans.map(({ o, c }) => outingCard(o, c)).join('')}</div>` : `<div class="empty-card">${icon('crew', 'i-lg')}<div>No plans yet. Open a venue and tap <strong>Invite Crew</strong>.</div><button class="btn sm" data-action="nav" data-to="pick">Find a place</button></div>`}
    <h2 class="sec">My Crews</h2>
    <div class="list">${crews.map(crewCard).join('') || '<p class="small muted">You’re not in a Crew yet.</p>'}</div>
    <div class="card stack" style="margin-top:12px">
      <form class="inline-form" data-submit="createCrew"><input class="input" name="name" maxlength="60" placeholder="New Crew name" aria-label="New Crew name" required><button class="btn sm" type="submit">${icon('plus')} Create</button></form>
      <form class="inline-form" data-submit="joinCrew"><input class="input" name="code" maxlength="32" placeholder="Have an invite code?" aria-label="Invite code" autocapitalize="characters"><button class="btn sm alt" type="submit">Join</button></form>
    </div>`
}

export async function openInvite(pid) {
  const account=S.authVersion
  const v = venue(pid) || (S.go?.pid === pid ? S.go : null)
  if (!v) return toast('Choose a real venue first')
  if (!requireAuth('Sign in to invite your Crew')) return
  if (!S.profile?.username) {
    openSheet('Set up your profile', profileForm(), { eyebrow: 'Crew' })
    return
  }
  if (S.crews == null) await loadCrews()
  if (account!==S.authVersion || !S.user) return
  if (S.crewError) return toast(S.crewError)
  const crews = (S.crews || []).filter((c) => c.my_status === 'joined')
  const start = new Date(Date.now() + 60 * 60 * 1000)
  start.setMinutes(start.getMinutes() < 30 ? 30 : 60, 0, 0)
  const local = new Date(start.getTime() - start.getTimezoneOffset() * 60000).toISOString().slice(0, 16)
  openSheet(
    `Plan ${v.name}`,
    crews.length
      ? `<form class="stack" data-submit="createOuting" data-pid="${esc(pid)}">
        <label class="field">Crew<select name="crew">${crews.map((c) => `<option value="${esc(c.id)}">${esc(c.name)} (${c.members.filter((m) => m.status === 'joined').length})</option>`).join('')}</select></label>
        <label class="field">When<input type="datetime-local" name="when" value="${local}" required></label>
        <label class="field">Note (optional)<input name="note" maxlength="200" placeholder="Meet at the bar at 9"></label>
        <button class="btn block" type="submit">${icon('crew')} Send to Crew</button><p class="form-msg" role="status"></p>
        <p class="tiny faint" style="margin:0">Members see the venue, time and who’s in. Your location is never shared.</p></form>`
      : `<div class="stack"><p class="small muted" style="margin:0">Create a Crew first, then invite friends by username or invite code.</p>
        <form class="inline-form" data-submit="createCrew" data-then="${esc(pid)}"><input class="input" name="name" maxlength="60" placeholder="Crew name" required aria-label="Crew name"><button class="btn sm" type="submit">Create</button></form></div>`,
    { eyebrow: 'Invite Crew' },
  )
}

const busy = (form, on) => form.querySelectorAll('button').forEach((b) => (b.disabled = on))

actionsFor({
  crewRetry: () => { S.crewError = null; S.crews = null; loadCrews() },
  invite: (d) => openInvite(d.pid),
  noop: () => {},
  crewVenue: d => openSharedVenue(d.pid,{lat:Number(d.lat),lon:Number(d.lon)}),
  rotateCrewInvite: async d => {
    if(!confirm('Disable the current invite link and create a new one? Existing members stay in your Crew.'))return
    await rpc('lit_rotate_crew_invite',{p_crew:d.crew});await loadCrews();toast('New invite link is ready')
  },
  cancelOuting: async d => {
    if(!confirm('Cancel this plan for everyone in the Crew?'))return
    await rpc('lit_cancel_outing',{p_outing:d.outing});await loadCrews()
    const {refreshActivity}=await import('./places.js');await refreshActivity();toast('Plan cancelled')
  },
  confirmJoinCode: async d => {
    closeSheet()
    if(!requireAuth('Sign in to join this Crew',()=>handleJoinCode(d.code)))return
    await handleJoinCode(d.code)
  },
  toggleCrew: (d) => {
    openCrew = openCrew === d.crew ? null : d.crew
    renderCrew()
  },
  createCrew: async (d, form) => {
    const name = form.name.value.trim()
    if (!name) return
    busy(form, true)
    try {
      const id = await rpc('lit_create_crew', { p_name: name })
      openCrew = id
      await loadCrews()
      toast('Crew created')
      if (d.then) openInvite(d.then)
      else renderCrew()
    } catch (e) {
      toast(e.message)
      busy(form, false)
    }
  },
  joinCrew: async (d, form) => {
    const code = form.code.value.trim()
    if (!code) return
    busy(form, true)
    try {
      const joined=await rpc('lit_join_crew', { p_code: code })
      if(joined.error) throw new Error(joined.error)
      openCrew=joined.crew_id
      await loadCrews()
      toast('You joined the Crew')
    } catch (e) {
      toast(e.message)
      busy(form, false)
    }
  },
  addMember: async (d, form) => {
    const u = form.username.value.trim()
    if (!u) return
    busy(form, true)
    try {
      const result=await rpc('lit_add_crew_member', { p_crew: d.crew, p_username: u })
      if(result.error) throw new Error(result.error)
      await loadCrews()
      toast(result.already_member ? 'Already in this Crew or invited' : 'Invite sent')
    } catch (e) {
      toast(e.message)
      busy(form, false)
    }
  },
  removeMember: async (d) => {
    if (!confirm('Remove this member from the Crew?')) return
    try {
      await rpc('lit_leave_crew', { p_crew: d.crew, p_user: d.user })
      await loadCrews()
    } catch (e) {
      toast(e.message)
    }
  },
  leaveCrew: async (d) => {
    if (!confirm(d.owner === '1' ? 'Delete this Crew and its plans for everyone?' : 'Leave this Crew?')) return
    try {
      await rpc('lit_leave_crew', { p_crew: d.crew, p_user: null })
      openCrew = null
      await loadCrews()
    } catch (e) {
      toast(e.message)
    }
  },
  crewInvite: async (d) => {
    try {
      await rpc('lit_respond_crew_invite', { p_crew: d.crew, p_accept: d.v === '1' })
      if (d.v === '1') openCrew = d.crew
      await loadCrews()
    } catch (e) {
      toast(e.message)
    }
  },
  shareCode: async (d) => {
    const url = `${location.origin}/?join=${encodeURIComponent(d.code)}`
    const text = `Join my Crew “${d.name}” on LIT`
    try {
      if (navigator.share) await navigator.share({ title: 'LIT Crew invite', text, url })
      else {
        await navigator.clipboard.writeText(`${text}: ${url}`)
        toast('Invite link copied')
      }
    } catch (e) {
      if (e.name !== 'AbortError') toast('Sharing is unavailable')
    }
  },
  createOuting: async (d, form) => {
    const msg = form.querySelector('.form-msg')
    busy(form, true)
    try {
      const id = await ensurePlaceId(d.pid)
      if (!id) throw new Error('Venue could not be saved')
      await rpc('lit_create_outing', { p_crew: form.crew.value, p_place: id, p_starts_at: new Date(form.when.value).toISOString(), p_note: form.note.value })
      closeSheet()
      await loadCrews()
      toast('Plan sent to your Crew')
      emit('navigate', 'crew')
    } catch (e) {
      msg.textContent = e.message
      msg.classList.add('err')
      busy(form, false)
    }
  },
  rsvp: async (d) => {
    try {
      await rpc('lit_respond_outing', { p_outing: d.outing, p_response: d.v })
      await loadCrews()
      const { loadFeed } = await import('./places.js')
      await loadFeed()
    } catch (e) {
      toast(e.message)
    }
  },
  outingDirections: async (d) => {
    const { directionsUrl } = await import('./core.js')
    window.open(directionsUrl({ lat: d.lat, lon: d.lon, name: d.name }), '_blank', 'noopener,noreferrer')
    const { track } = await import('./api.js')
    track(d.place, 'directions')
  },
  goOuting: async (d) => {
    const { toggleGo, isGoing } = await import('./go.js')
    const outing = (S.crews || []).flatMap((c) => c.outings || []).find((o) => o.pid === d.pid)
    if (!isGoing(d.pid)) await toggleGo(d.pid, outing ? { pid: outing.pid, place_id: outing.place_id, name: outing.place_name, lat: outing.lat, lon: outing.lon, category: outing.category } : null)
    emit('navigate', 'go')
  },
})

// Join links: /?join=CODE
export async function handleJoinLink() {
  const code = new URLSearchParams(location.search).get('join')
  if (!code) return
  history.replaceState(null, '', location.pathname)
  if(!/^[a-f0-9]{32}$/i.test(code))return toast('This Crew invite is invalid. Ask the owner for a new link.')
  openSheet('Crew invitation',`<div class="stack"><p>Join this private Crew to see its members and plans. Your location is never shared.</p><button class="btn" data-action="confirmJoinCode" data-code="${esc(code)}">${S.user ? 'Join Crew' : 'Sign in to join'}</button><button class="btn alt" data-action="closeSheet">Not now</button></div>`)
}
async function handleJoinCode(code) {
  try {
    if(!S.profile?.username){
      const profile=await rpc('lit_my_profile')
      S.profile=profile
      if(!profile?.username){pendingJoinCode=code;openSheet('Choose your Crew username',profileForm(),{eyebrow:'Join Crew'});return}
    }
    const joined=await rpc('lit_join_crew', { p_code: code })
    if(joined.error)throw new Error(joined.error)
    openCrew=joined.crew_id
    await loadCrews()
    emit('navigate', 'crew')
    toast('You joined the Crew')
  } catch (e) {
    toast(e.message)
  }
}

on('auth', () => {
  ++crewVersion
  loading = false
  openCrew = null
  pendingJoinCode = null
  S.crews = null
  S.crewError = null
  if (S.user) loadCrews()
})
on('profile', () => { if(pendingJoinCode && S.user && S.profile?.username){const code=pendingJoinCode;pendingJoinCode=null;handleJoinCode(code);return} if(S.user && S.profile?.username && (S.crews==null || S.crewError))loadCrews(); else if(S.screen==='crew')renderCrew() })

export async function refreshCrewsQuietly() {
  if(S.screen!=='crew' || !S.user || !S.profile?.username || loading || document.hidden || sheetOpen() || document.activeElement?.closest('form'))return
  const account=S.authVersion,version=++crewVersion
  try{const data=await rpc('lit_my_crews');if(account!==S.authVersion || version!==crewVersion || !Array.isArray(data))return
    if(JSON.stringify(data)!==JSON.stringify(S.crews)){S.crews=data;S.crewError=null;renderCrew()}
  }catch{ /* Manual Refresh Crew remains available; private drafts are not replaced. */ }
}
