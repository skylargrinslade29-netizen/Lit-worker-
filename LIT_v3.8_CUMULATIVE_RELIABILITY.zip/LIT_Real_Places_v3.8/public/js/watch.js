import { activityMarkup } from './activity.js'
// WATCH — full-screen, vertical, fresh video from real venues nearby.
import { S, $, esc, icon, on, actionsFor, ago, fmtMiles, litBadge } from './core.js'
import { track, signedUrls } from './api.js'
import { isGoing } from './go.js'

let observer = null
let current = null // {el, post, startedAt, watched}
let soundOn = false

function emptySlide(kind) {
  const common = (title, text, buttons) => `<article class="slide empty"><div class="empty-art"></div><div class="empty-body">
    <div class="eyebrow">Right now${S.area ? ' · ' + esc(S.area) : ''}</div><h1 class="title">${title}</h1>
    <p class="lede" style="margin:0">${text}</p><div class="stack-sm">${buttons}</div></div></article>`
  if (kind === 'locate')
    return common(
      'See what’s happening <em style="font-style:normal;background:var(--heat);-webkit-background-clip:text;background-clip:text;color:transparent">right now.</em>',
      'LIT shows fresh 10–30 second videos recorded at real venues near you in the last 24 hours. Share your location to start.',
      `<button class="btn block" data-action="locate">${icon('pin')} Use my location</button><button class="btn ghost block" data-action="nav" data-to="pick">Browse without video</button>`,
    )
  if (kind === 'denied')
    return common(
      'Location is off.',
      'Location permission is off. You can still find real nearby venues by entering a ZIP code or city.',
      `<button class="btn block" data-action="nav" data-to="pick">Enter ZIP or city</button><button class="btn ghost block" data-action="locate">Try location again</button>`,
    )
  if (kind === 'error')
    return common(
      'Couldn’t load places.',
      esc(S.placesError || 'The places provider did not respond.') + ' Nothing has been made up in the meantime.',
      `<button class="btn block" data-action="nav" data-to="pick">Set location another way</button><button class="btn ghost block" data-action="reloadPlaces">Retry</button>`,
    )
  if (kind === 'none')
    return common(
      S.venues.length ? 'Real places are ready.' : 'No nearby places found.',
      esc(S.feedError || (S.venues.length ? `${S.venues.length} real venues are nearby. Browse them in PICK; no fresh videos are available to show right now.` : 'Try another location or a larger radius in PICK.')),
      `<button class="btn block" data-action="post">${icon('camera')} Record what’s happening</button><button class="btn ghost block" data-action="nav" data-to="pick">Pick a place nearby</button>`,
    )
  return ''
}

function skeletonSlide() {
  return `<article class="slide skeleton" aria-busy="true" aria-label="Loading fresh videos"><div class="empty-body" style="align-self:flex-end;padding-bottom:30px">
    <div class="sk-line" style="width:40%"></div><div class="sk-line" style="width:70%;height:26px"></div><div class="sk-line" style="width:55%"></div></div></article>`
}

function slide(post, i) {
  const v = S.byPid[post.pid]
  const place = S.places[post.pid]
  const url = S.urls[post.video_path]
  const going = isGoing(post.pid)
  const promo = place?.promos?.[0]
  return `<article class="slide" data-i="${i}" data-post="${esc(post.id)}" data-pid="${esc(post.pid)}">
    ${url ? `<video playsinline muted loop preload="${S.dataSaver || navigator.connection?.saveData ? 'none' : i < 2 ? 'auto' : 'metadata'}" src="${esc(url)}" aria-label="Fresh video at ${esc(v.name)}"></video>` : ''}
    <div class="slide-shade"></div>
    <button class="tap-layer" data-action="togglePlay" aria-label="Pause or play"></button>
    <div class="slide-progress"><i></i></div>
    <div class="slide-fresh"><span class="pill"><span class="live"></span>${esc(ago(post.created_at).toUpperCase())}</span>${post.post_type === 'business' ? '<span class="pill">VENUE POST</span>' : ''}</div>
    <button class="sound" data-action="sound" aria-label="${soundOn ? 'Mute' : 'Unmute'}">${icon(soundOn ? 'sound' : 'mute')}</button>
    <div class="slide-info">
      <div>${litBadge(place?.score)}</div>
      ${activityMarkup(place, { compact: true, pid: post.pid })}
      <button class="slide-venue" data-action="venue" data-pid="${esc(post.pid)}"><span>${esc(v.name)}</span>${icon('chev-right')}</button>
      <div class="slide-meta">${esc(v.category)} · ${fmtMiles(v.mi)} away${v.cuisine ? ' · ' + esc(v.cuisine) : ''}</div>
      ${promo ? `<button class="slide-promo" data-action="venue" data-pid="${esc(post.pid)}" data-promo="${esc(promo.id)}">${icon('spark', 'i-sm')}<span>${esc(promo.title)}</span></button>` : ''}
    </div>
    <div class="rail">
      <button class="${going ? 'going' : ''}" data-action="go" data-pid="${esc(post.pid)}" aria-pressed="${going}"><span>${icon(going ? 'check' : 'go')}</span>${going ? 'GOING' : 'GO'}</button>
      <button data-action="invite" data-pid="${esc(post.pid)}"><span>${icon('crew')}</span>CREW</button>
      <button data-action="directions" data-pid="${esc(post.pid)}"><span>${icon('route')}</span>ROUTE</button>
      <button data-action="share" data-pid="${esc(post.pid)}" data-post="${esc(post.id)}"><span>${icon('share')}</span>SHARE</button>
      <button data-action="postMenu" data-post="${esc(post.id)}" aria-label="More options"><span>${icon('more')}</span>MORE</button>
    </div>
  </article>`
}

function endSlide() {
  return `<article class="slide empty"><div class="empty-art"></div><div class="empty-body">
    <div class="eyebrow">You’re caught up</div><h1 class="title">That’s everything fresh within ${S.radius} mi.</h1>
    <p class="lede" style="margin:0">Videos expire after about 24 hours, so LIT only ever shows what’s happening now.</p>
    <div class="stack-sm"><button class="btn block" data-action="post">${icon('camera')} Post from where you are</button>
    <button class="btn ghost block" data-action="nav" data-to="pick">Compare places</button></div></div></article>`
}

export function renderWatch() {
  const feed = $('feed')
  if (!feed) return
  deactivate()
  const st = S.feedState
  let html
  if (!S.coords && (st === 'idle' || st === 'denied' || st === 'error')) html = emptySlide(st === 'idle' ? 'locate' : st)
  else if (st === 'locating' || (st === 'loading' && !S.posts.length)) html = skeletonSlide()
  else if (st === 'error' && !S.venues.length) html = emptySlide('error')
  else {
    const posts = S.posts.filter((p) => S.byPid[p.pid] && S.urls[p.video_path])
    html = posts.length ? posts.map(slide).join('') + endSlide() : emptySlide('none')
  }
  feed.innerHTML = html
  observe()
}

function observe() {
  observer?.disconnect()
  observer = new IntersectionObserver(
    (entries) => {
      for (const en of entries) {
        const vid = en.target.querySelector('video')
        if (!vid) continue
        if (en.isIntersecting && en.intersectionRatio > 0.6) activate(en.target, vid)
        else if (current?.el === en.target) deactivate()
        else vid.pause()
      }
    },
    { root: $('feed'), threshold: [0, 0.6, 1] },
  )
  $('feed').querySelectorAll('.slide').forEach((el) => observer.observe(el))
}

function activate(el, vid) {
  if (current?.el === el) return
  deactivate()
  const post = S.posts.find((p) => p.id === el.dataset.post)
  current = { el, post, watched: 0, last: null, account: S.authVersion }
  vid.muted = !soundOn
  vid.currentTime = 0
  if (S.autoplay) vid.play().catch(() => {})
  const bar = el.querySelector('.slide-progress i')
  vid.onerror = () => {
    const button = el.querySelector('.tap-layer')
    if (button) { button.dataset.action = 'retryVideo'; button.setAttribute('aria-label', 'Retry video playback'); button.innerHTML = '<span class="playback-error">Video could not play. Tap to retry.</span>' }
  }
  vid.ontimeupdate = () => {
    if (bar && vid.duration) bar.style.width = `${(vid.currentTime / vid.duration) * 100}%`
    if (current?.el !== el) return
    const t = performance.now()
    if (current.last && !vid.paused) current.watched += Math.min((t - current.last) / 1000, 1)
    current.last = t
  }
}

function deactivate() {
  if (!current) return
  const vid = current.el.querySelector('video')
  vid?.pause()
  flushWatch()
  if (vid) { vid.ontimeupdate = null; vid.onerror = null }
  current = null
}

// Report unique watch time (seconds, capped server-side at 30).
function flushWatch() {
  if (!current?.post || current.watched < 1) return
  if (current.account !== S.authVersion) { current.watched = 0; return }
  const place = S.places[current.post.pid]
  track(place?.place_id || current.post.place_id, 'view', { post: current.post.id, value: Math.round(current.watched) })
  current.watched = 0
}

export function scrollToPost(id) {
  const el = $('feed')?.querySelector(`[data-post="${CSS.escape(id)}"]`)
  el?.scrollIntoView({ behavior: 'auto', block: 'start' })
}

export async function retryVideo(el) {
  const slide = el.closest('.slide'), video = slide?.querySelector('video')
  const post = S.posts.find((p) => p.id === slide?.dataset.post)
  if (!video || !post) return
  const account = S.authVersion
  await signedUrls([post.video_path], { force: true })
  if (account !== S.authVersion || !S.posts.some((p) => p.id === post.id)) return
  const url = S.urls[post.video_path]
  if (!url) return
  video.src = url; video.load()
  try { await video.play(); el.dataset.action = 'togglePlay'; el.setAttribute('aria-label', 'Pause or play'); el.innerHTML = '' } catch { el.innerHTML = '<span class="playback-error">Playback unavailable. Try again or skip this video.</span>' }
}
actionsFor({
  retryVideo: (d, el) => retryVideo(el),
  togglePlay: (d, el) => {
    const vid = el.closest('.slide')?.querySelector('video')
    if (!vid) return
    vid.paused ? vid.play().catch(() => {}) : vid.pause()
  },
  sound: (d, el) => {
    soundOn = !soundOn
    document.querySelectorAll('#feed video').forEach((v) => (v.muted = true))
    const vid = el.closest('.slide')?.querySelector('video')
    if (vid) vid.muted = !soundOn
    document.querySelectorAll('#feed .sound').forEach((b) => {
      b.innerHTML = icon(soundOn ? 'sound' : 'mute')
      b.setAttribute('aria-label', soundOn ? 'Mute' : 'Unmute')
    })
  },
})

document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    current?.el.querySelector('video')?.pause()
    flushWatch()
  } else if (current && S.screen === 'watch' && S.autoplay) current.el.querySelector('video')?.play().catch(() => {})
})
window.addEventListener('pagehide', flushWatch)

export function pauseWatch() {
  flushWatch()
  current?.el.querySelector('video')?.pause()
}
export function resumeWatch() {
  if (current && S.autoplay) current.el.querySelector('video')?.play().catch(() => {})
}

on('go', () => {
  document.querySelectorAll('#feed .rail [data-action="go"]').forEach((b) => {
    const g = isGoing(b.dataset.pid)
    b.classList.toggle('going', g)
    b.setAttribute('aria-pressed', g)
    b.innerHTML = `<span>${icon(g ? 'check' : 'go')}</span>${g ? 'GOING' : 'GO'}`
  })
})

// Keyboard: arrow keys step through clips on desktop.
document.addEventListener('keydown', (e) => {
  if (S.screen !== 'watch' || $('sheetRoot').children.length || /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName)) return
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault()
    const feed = $('feed')
    feed.scrollBy({ top: (e.key === 'ArrowDown' ? 1 : -1) * feed.clientHeight, behavior: 'smooth' })
  }
})

on('mediaPrefs', () => { if (S.screen === 'watch') renderWatch() })
