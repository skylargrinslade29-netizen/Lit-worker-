// Supabase connection (existing LIT project), RPC wrapper and signal tracking.
import { S, emit, closeSheet } from './core.js'

export let sb = null

function setUser(user) {
  const changed = (user?.id || null) !== (S.user?.id || null)
  S.user = user
  if (changed) {
    closeSheet()
    S.authVersion++
    S.profile = null; S.crews = null; S.go = null; S.places = {}; S.posts = []; S.urls = {}; S.urlExpires = {}
    S.reviewAccess = null
    emit('feed')
  }
  return changed
}

export async function initSupabase() {
  const cfg = window.LIT_CONFIG || {}
  if (!cfg.supabaseUrl || !cfg.supabaseAnonKey) {
    S.backend = 'offline'
    emit('auth')
    return
  }
  for (let i = 0; i < 40 && !window.supabase; i++) await new Promise((r) => setTimeout(r, 150))
  if (!window.supabase) {
    S.backend = 'offline'
    emit('auth')
    return
  }
  sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
  })
  const { data } = await sb.auth.getSession()
  setUser(data.session?.user || null)
  sb.auth.onAuthStateChange((event, session) => {
    const changed = setUser(session?.user || null)
    if (event === 'PASSWORD_RECOVERY') emit('recovery')
    if (changed) emit('auth')
  })
  emit('auth')
}

const MISSING = /PGRST202|Could not find the function|schema cache/i

export class LitError extends Error {}

export async function rpc(name, args = {}) {
  if (!sb) throw new LitError('LIT is offline right now. Please try again shortly.')
  const account = S.authVersion
  let response
  try { response = await sb.rpc(name, args) }
  catch { throw new LitError('Could not connect to LIT. Check your connection and try again.') }
  const { data, error } = response
  if (account !== S.authVersion) throw new LitError('Your account changed. Please retry.')
  if (error) {
    if (/PGRST301|JWT expired|invalid JWT|refresh token/i.test(`${error.code} ${error.message}`)) {
      if (setUser(null)) emit('auth')
      emit('sessionExpired')
      throw new LitError('Your session expired. Sign in again to continue.')
    }
    if (/Failed to fetch|NetworkError|fetch failed|Load failed/i.test(error.message || '')) throw new LitError('Could not connect to LIT. Check your connection and try again.')
    if (MISSING.test(`${error.code} ${error.message}`)) {
      S.backend = 'missing'
      emit('backend')
      console.warn(JSON.stringify({ event: 'backend_feature_unavailable', function: name, code: error.code || null }))
      throw new LitError('This feature is temporarily unavailable. Please try again later.')
    }
    throw new LitError(cleanError(error.message))
  }
  if (S.backend !== 'ready') {
    S.backend = 'ready'
    emit('backend')
  }
  if (!data?.error) emit('rpcSaved',{name,args})
  return data
}

export function cleanError(msg) {
  return String(msg || 'Something went wrong. Please try again.').replace(/^.*?ERROR:\s*/, '').slice(0, 180)
}

// Fire-and-forget activity signal. Only signed-in activity is counted server-side.
export function track(placeId, kind, { post = null, promo = null, value = 0 } = {}) {
  if (!sb || !S.user || !placeId) return
  sb.rpc('lit_track', { p_place: placeId, p_kind: kind, p_post: post, p_promo: promo, p_value: value }).then(
    () => {},
    () => {},
  )
}

export async function signedUrls(paths, { force = false } = {}) {
  const account = S.authVersion
  const need = [...new Set(paths)].filter((p) => p && (force || !S.urls[p] || !S.urlExpires[p] || S.urlExpires[p] <= Date.now()))
  if (!sb || !need.length) return
  for (let i = 0; i < need.length; i += 100) {
    const { data } = await sb.storage.from('lit-fresh-videos').createSignedUrls(need.slice(i, i + 100), 120)
    if (account !== S.authVersion) return
    for (const row of data || []) if (row.signedUrl) { S.urls[row.path] = row.signedUrl; S.urlExpires[row.path] = Date.now() + 90 * 1000 }
  }
}
