import { resourceLinks } from './resources.js'
import { clearSavedVenues } from './saved.js'
import { clearHiddenPosts } from './safety.js'
// Accounts (existing Supabase Auth), profile, settings & privacy.
import { S, $, esc, icon, on, emit, actionsFor, toast, openSheet, closeSheet, initials, savePrefs } from './core.js'
import { sb, rpc, cleanError } from './api.js'

let pendingAfterAuth = null
let profileVersion = 0

export function requireAuth(message, after) {
  if (S.user) return true
  pendingAfterAuth = after || null
  authSheet('login', message)
  return false
}

export async function loadProfile() {
  const version = ++profileVersion
  const user = S.user?.id
  if (!S.user) {
    S.profile = null
    emit('profile')
    return
  }
  try {
    const profile = await rpc('lit_my_profile')
    if (version !== profileVersion || user !== S.user?.id) return
    S.profile = profile
  } catch {
    if (version !== profileVersion || user !== S.user?.id) return
    S.profile = null
  }
  emit('profile')
}

export function updateAvatar() {
  const b = $('avatarBtn')
  if (!b) return
  if (S.user) {
    b.classList.add('signed')
    b.textContent = initials(S.profile?.display_name || S.user.email)
    b.setAttribute('aria-label', 'Profile and settings')
  } else {
    b.classList.remove('signed')
    b.innerHTML = icon('user')
    b.setAttribute('aria-label', 'Log in or sign up')
  }
}

export function authSheet(kind = 'login', message = '') {
  if (!sb) {
    openSheet('LIT account', `<p class="small muted">Accounts are temporarily unavailable. You can still discover nearby places and watch fresh videos.</p><button class="btn block" data-action="closeSheet">OK</button>`)
    return
  }
  const signup = kind === 'signup'
  const reset = kind === 'reset'
  const title = reset ? 'Reset password' : signup ? 'Join LIT' : 'Welcome back'
  openSheet(
    title,
    `<form class="stack" data-submit="auth" data-kind="${kind}" novalidate>
      ${message ? `<div class="banner">${icon('user')}<span>${esc(message)}</span></div>` : ''}
      <p class="small muted" style="margin:0">${reset ? 'We’ll email you a secure reset link.' : signup ? 'One account for WATCH, CREW, PICK, GO — and Business Mode if you run a venue.' : 'Log in to post, plan with your Crew and save GO.'}</p>
      <label class="field">Email<input name="email" type="email" autocomplete="email" inputmode="email" maxlength="254" required placeholder="you@example.com"></label>
      ${reset ? '' : `<label class="field">Password<div style="position:relative"><input name="password" type="password" autocomplete="${signup ? 'new-password' : 'current-password'}" minlength="${signup ? 8 : 1}" required placeholder="${signup ? 'At least 8 characters' : 'Your password'}" style="padding-right:72px"><button type="button" class="chip" style="position:absolute;right:6px;top:6px" data-action="togglePw">Show</button></div></label>`}
      ${signup ? `<label class="check"><input type="checkbox" name="terms" required> I agree to LIT’s terms and privacy policy, and confirm I’m old enough to use nightlife features where I live.</label>` : ''}
      ${resourceLinks() ? `<p class="small">${resourceLinks()}</p>` : ''}
      <button class="btn block" type="submit">${reset ? 'Email reset link' : signup ? 'Create account' : 'Log in'}</button>
      <p class="form-msg" role="status" aria-live="polite"></p>
      <div class="row between wrap">${
        signup
          ? `<button type="button" class="link" data-action="authKind" data-kind="login">Have an account? Log in</button>`
          : reset
            ? `<button type="button" class="link" data-action="authKind" data-kind="login">Back to log in</button>`
            : `<button type="button" class="link" data-action="authKind" data-kind="signup">Create account</button><button type="button" class="link" data-action="authKind" data-kind="reset">Forgot password?</button>`
      }</div></form>`,
    { eyebrow: 'Account' },
  )
}

export function profileForm() {
  const p = S.profile || {}
  return `<form class="stack" data-submit="saveProfile">
    <label class="field">Display name<input name="display" maxlength="40" required value="${esc(p.display_name || '')}" placeholder="What your Crew sees" autocomplete="nickname"></label>
    <label class="field">Username<input name="username" maxlength="24" required value="${esc(p.username || '')}" placeholder="letters, numbers, _ or ." autocapitalize="none" autocomplete="username" pattern="[A-Za-z0-9_.]{3,24}"></label>
    <button class="btn block" type="submit">Save profile</button><p class="form-msg" role="status"></p></form>`
}

function accountSheet() {
  if (!S.user) return authSheet('login')
  const p = S.profile
  openSheet(
    p?.display_name || 'Your account',
    `<div class="stack">
      <div class="card row"><span class="initial" style="width:48px;height:48px;font-size:19px;background:var(--heat);color:#1d0a04;border:0">${esc(initials(p?.display_name || S.user.email))}</span>
        <div class="grow"><strong>${esc(p?.display_name || 'LIT member')}</strong><div class="small muted">${p?.username ? '@' + esc(p.username) + ' · ' : ''}${esc(S.user.email || '')}</div></div></div>
      <button class="btn alt block" data-action="editProfile">${icon('user')} Edit profile</button>
      <button class="btn alt block" data-action="openBusiness">${icon('store')} Business dashboard</button>
      ${S.reviewAccess?.can_review ? `<button class="btn alt block" data-action="openVerification">${icon('shield')} Business verification</button>` : ''}
      <button class="btn alt block" data-action="settings">${icon('gear')} Settings & privacy</button>
      <button class="btn ghost block" data-action="signOut">${icon('logout')} Log out</button>
    </div>`,
    { eyebrow: 'Profile' },
  )
}

function settingsSheet() {
  openSheet(
    'Settings & privacy',
    `<div class="stack">
      ${resourceLinks() ? `<div class="card stack-sm"><strong>Support & policies</strong><p>${resourceLinks()}</p></div>` : ''}
      <div class="card stack-sm"><strong>Location</strong><p class="small muted" style="margin:0">Your browser sends rounded coordinates for discovery and fresh GPS coordinates for posting or arrival checks. Your position is not displayed to your Crew or on venue pages.</p>
        <button class="btn sm alt" data-action="location">Update location</button></div>
      <div class="card stack-sm"><strong>Discovery radius</strong><p class="small muted" style="margin:0">Currently ${S.radius} miles.</p><button class="btn sm alt" data-action="nav" data-to="pick">Change in PICK</button></div>
      <div class="card stack-sm"><strong>Data on this device</strong><p class="small muted" style="margin:0">Clears saved places, filters and hidden-video preferences. Signed-in GO is saved to your account.</p><button class="btn sm ghost" data-action="clearLocal">Clear device data</button></div>
      ${S.user ? `<div class="card stack-sm"><strong>Password</strong><button class="btn sm alt" data-action="authKind" data-kind="reset">Email a reset link</button></div>` : ''}
      <div class="card stack-sm"><strong>Video preferences</strong><button class="btn sm alt" data-action="autoplay" aria-pressed="${S.autoplay}">Autoplay: ${S.autoplay ? 'On' : 'Off'}</button><button class="btn sm alt" data-action="dataSaver" aria-pressed="${S.dataSaver}">Reduce video preloading: ${S.dataSaver ? 'On' : 'Off'}</button><p class="small muted">These preferences are saved on this device.</p></div>
      ${window.LIT_CONFIG?.features?.accountBlocking ? '<button class="btn alt block" data-action="myBlocks">Blocked creators</button>' : ''}
      ${window.LIT_CONFIG?.features?.moderationTools && S.safetyAccess?.can_moderate ? '<button class="btn alt block" data-action="moderation">Report review tools</button>' : ''}
      ${S.safetyAccess?.is_owner ? '<button class="btn alt block" data-action="launchChecklist">Owner launch checklist</button>' : ''}
      ${S.user ? '<button class="btn alt block" data-action="myVideos">My videos & processing status</button>' : ''}
      ${S.user && window.LIT_CONFIG?.features?.accountDeletion ? '<button class="btn danger block" data-action="deleteAccountStart">Delete account</button>' : ''}
      ${localStorage.getItem('lit-deletion-receipt') ? '<button class="btn alt block" data-action="deletionReceipt">Check account deletion</button>' : ''}
      <button class="btn alt block" data-action="savedPlaces">Saved places</button>
      <button class="btn alt block" data-action="help">Help & safety</button>
      <div class="card stack-sm"><strong>Trust & safety</strong><p class="small muted" style="margin:0">Videos are recorded live in the LIT camera and expire after about 24 hours. Venues can’t buy scores or remove community videos. Report anything that breaks the rules from a video’s MORE menu.</p></div>
    </div>`,
    { eyebrow: 'Settings' },
  )
}

function welcome() {
  openSheet(
    'See what’s happening now.',
    `<div class="stack">
      <p class="muted" style="margin:0">Fresh 10–30s videos from real venues near you, a live LIT Score you can trust, and plans with your Crew.</p>
      <div class="steps" aria-hidden="true" style="grid-template-columns:repeat(4,1fr)"><div class="step now"><i></i>WATCH</div><div class="step now"><i></i>CREW</div><div class="step now"><i></i>PICK</div><div class="step now"><i></i>GO</div></div>
      <button class="btn block" data-action="authKind" data-kind="signup">Create account</button>
      <button class="btn alt block" data-action="authKind" data-kind="login">Log in</button>
      <button class="btn ghost block" data-action="welcomeExplore">Explore first</button>
    </div>`,
    { eyebrow: 'Welcome to LIT' },
  )
}

export function maybeWelcome() {
  if (S.user) return
  try { if (localStorage.getItem('lit-v2-welcomed')) return; localStorage.setItem('lit-v2-welcomed', '1') } catch {}
  setTimeout(() => !$('sheetRoot').children.length && welcome(), 500)
}

actionsFor({
  account: accountSheet,
  authKind: (d) => authSheet(d.kind),
  settings: settingsSheet,
  autoplay: () => { S.autoplay = !S.autoplay; savePrefs(); emit("mediaPrefs"); settingsSheet() },
  dataSaver: () => { S.dataSaver = !S.dataSaver; savePrefs(); emit("mediaPrefs"); settingsSheet() },
  help: () => openSheet('Help & safety', `<div class="stack"><div class="card"><strong>Location</strong><p>Open LIT in Safari or Chrome over HTTPS. Turn on device Location Services and allow location for this website. ZIP/city search is available if GPS is blocked.</p><button class="btn alt" data-action="location">Choose location</button></div><div class="card"><strong>Missing venues</strong><p>Try Bars as well as Nightclubs and check your radius. Provider listings can be incomplete. A venue listing is not confirmation that it is open.</p></div><div class="card"><strong>Video concerns</strong><p>Use a video's options to report concerns or hide it on this device. Hiding is a personal preference and does not remove the video for others. Do not record private information or people without appropriate consent. For an emergency, contact local emergency services.</p></div><div class="card"><strong>Camera</strong><p>Allow camera, microphone and location access. Keep LIT open during recording and check your connection before publishing.</p></div></div>`),
  editProfile: () => openSheet('Edit profile', profileForm(), { eyebrow: 'Profile' }),
  welcomeExplore: async () => {
    closeSheet()
    const { locate } = await import('./places.js')
    locate()
  },
  togglePw: (d, btn) => {
    const input = btn.previousElementSibling
    input.type = input.type === 'password' ? 'text' : 'password'
    btn.textContent = input.type === 'password' ? 'Show' : 'Hide'
  },
  auth: async (d, form) => {
    const kind = d.kind
    const msg = form.querySelector('.form-msg')
    const btn = form.querySelector('button[type=submit]')
    const email = form.email.value.trim()
    const password = form.password?.value || ''
    const fail = (t) => {
      msg.textContent = t
      msg.classList.add('err')
    }
    msg.classList.remove('err')
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return fail('Enter a valid email address.')
    if (kind === 'signup' && password.length < 8) return fail('Use at least 8 characters for your password.')
    if (kind === 'signup' && !form.terms.checked) return fail('Please accept the terms to continue.')
    if (kind === 'login' && !password) return fail('Enter your password.')
    const label = btn.textContent
    btn.disabled = true
    btn.textContent = 'Please wait…'
    try {
      const redirect = location.origin + '/'
      if (kind === 'reset') {
        const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: redirect })
        if (error) throw error
        msg.textContent = 'If an account exists for this email, a reset link is on its way.'
        return
      }
      const { data, error } =
        kind === 'signup'
          ? await sb.auth.signUp({ email, password, options: { emailRedirectTo: redirect } })
          : await sb.auth.signInWithPassword({ email, password })
      if (error) throw error
      if (kind === 'signup' && !data.session) {
        msg.innerHTML = `Check your inbox to confirm your email, then log in. <button type="button" class="link" data-action="resend" data-email="${esc(email)}">Resend email</button>`
        return
      }
      closeSheet()
      toast(kind === 'signup' ? 'Welcome to LIT' : 'Welcome back')
    } catch (e) {
      fail(cleanError(e.message))
    } finally {
      btn.disabled = false
      btn.textContent = label
    }
  },
  resend: async (d) => {
    const { error } = await sb.auth.resend({ type: 'signup', email: d.email })
    toast(error ? cleanError(error.message) : 'Confirmation email sent if eligible')
  },
  saveProfile: async (d, form) => {
    const msg = form.querySelector('.form-msg')
    try {
      S.profile = await rpc('lit_save_profile', { p_display_name: form.display.value, p_username: form.username.value })
      emit('profile')
      if ($('sheetRoot').children.length && form.closest('.sheet')) closeSheet()
      toast('Profile saved')
    } catch (e) {
      msg.textContent = e.message
      msg.classList.add('err')
    }
  },
  signOut: async () => {
    if (!sb) return toast('Unable to sign out: connection unavailable')
    try {
      const { error } = await sb.auth.signOut()
      if (error) throw error
      S.profile = null
      S.crews = null
      S.go = null
      S.urls = {}
      emit('auth')
      closeSheet()
      emit('navigate', 'watch')
      toast('Signed out securely')
    } catch (e) {
      toast(`Sign out failed: ${String(e.message || e).slice(0, 110)}`)
    }
  },
  clearLocal: () => {
    if (!confirm('Clear LIT data saved on this device?')) return
    ;['lit-v2-prefs', 'lit-launch-ready-local-v1'].forEach((k) => localStorage.removeItem(k))
    for (let i = sessionStorage.length - 1; i >= 0; i--) { const key = sessionStorage.key(i); if (/^lit-v[\d.]+-places$/.test(key) || key?.startsWith('lit-form-draft:')) sessionStorage.removeItem(key) }
    emit('clearDrafts')
    clearSavedVenues()
    clearHiddenPosts()
    S.autoplay = true
    S.dataSaver = false
    emit('mediaPrefs')
    S.localGo = null
    S.radius = 10
    S.category = 'All'
    S.when = 'now'
    savePrefs()
    emit('go')
    emit('places')
    toast('Device data cleared')
  },
  newPassword: async (d, form) => {
    const msg = form.querySelector('.form-msg')
    if (form.password.value.length < 8) {
      msg.textContent = 'Use at least 8 characters.'
      return
    }
    const { error } = await sb.auth.updateUser({ password: form.password.value })
    if (error) {
      msg.textContent = cleanError(error.message)
      return
    }
    closeSheet()
    toast('Password updated')
  },
})

on('recovery', () =>
  openSheet(
    'Choose a new password',
    `<form class="stack" data-submit="newPassword"><label class="field">New password<input name="password" type="password" minlength="8" required autocomplete="new-password" placeholder="At least 8 characters"></label><button class="btn block" type="submit">Save password</button><p class="form-msg" role="status"></p></form>`,
    { eyebrow: 'Account' },
  ),
)

on('auth', async () => {
  updateAvatar()
  await loadProfile()
  if (S.user && pendingAfterAuth) {
    const fn = pendingAfterAuth
    pendingAfterAuth = null
    fn()
  }
})
on('profile', updateAvatar)
on('sessionExpired', () => authSheet('login', 'Your session expired. Sign in again to continue.'))
