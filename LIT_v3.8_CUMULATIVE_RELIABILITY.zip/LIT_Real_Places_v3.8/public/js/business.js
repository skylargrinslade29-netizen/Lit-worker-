// LIT BUSINESS — private analytics for verified venue owners (free tier), claims, promotions, profile.
import { S, $, esc, icon, on, emit, actionsFor, toast, openSheet, closeSheet, fmtNum, fmtDuration, ago, fmtWhen, fmtTime, litBadge } from './core.js'
import { rpc, signedUrls } from './api.js'
import { requireAuth } from './account.js'
import { scoreExplainer } from './venue.js'
import { ensurePlaceId, venue, resolveSharedVenue } from './places.js'

const B = { claims: null, active: null, dash: null, state: 'idle', range: '24h', claimPid: null, claimQuery: '', error: null }

let businessVersion = 0, dashVersion = 0
export async function loadBusiness() {
  const version = ++businessVersion, user = S.user?.id
  if (!user) return
  const current = () => version === businessVersion && user === S.user?.id
  B.state = 'loading'; B.error = null; render()
  try {
    const claims = await rpc('lit_my_business')
    if (!current()) return
    if (!Array.isArray(claims)) throw new Error('Business data is unavailable. Please retry.')
    B.claims = claims
    const verified = claims.filter((c) => c.status === 'verified')
    if (!B.active || !verified.some((c) => c.place_id === B.active)) B.active = verified[0]?.place_id || null
    if (B.active && verified.some((c) => c.place_id === B.active)) await loadDash()
    if (!current()) return
    B.state = 'ready'
  } catch (error) { if (!current()) return; B.state = 'error'; B.error = error.message }
  if (current()) render()
}
async function loadDash() {
  const version = ++dashVersion, user = S.user?.id, place = B.active
  B.dash = null; render()
  const dash = await rpc('lit_business_dashboard', { p_place: place })
  if (version === dashVersion && user === S.user?.id && place === B.active) B.dash = dash
}

// ---------- charts (inline SVG, no dependencies) ----------
function lineChart(points) {
  const W = 340, H = 120, P = 22
  const pts = points.filter((p) => p.score != null)
  if (pts.length < 2)
    return `<div class="empty-card" style="padding:18px">${icon('chart', 'i-lg')}<div class="small">Score history builds as LIT records snapshots (every 15 min while the venue has activity).</div></div>`
  const t0 = new Date(points[0].at).getTime()
  const t1 = new Date(points[points.length - 1].at).getTime() || t0 + 1
  const x = (t) => P + ((new Date(t).getTime() - t0) / Math.max(t1 - t0, 1)) * (W - P - 6)
  const y = (s) => H - 16 - (s / 100) * (H - 28)
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${x(p.at).toFixed(1)},${y(p.score).toFixed(1)}`).join('')
  const area = `${d}L${x(pts[pts.length - 1].at).toFixed(1)},${H - 16}L${x(pts[0].at).toFixed(1)},${H - 16}Z`
  const grid = [0, 35, 65, 85].map((g) => `<line class="grid" x1="${P}" x2="${W}" y1="${y(g)}" y2="${y(g)}"/><text x="0" y="${y(g) + 3}">${g}</text>`).join('')
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="LIT Score history, last 7 days">
    <defs><linearGradient id="lg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#ff6a34" stop-opacity=".35"/><stop offset="1" stop-color="#ff6a34" stop-opacity="0"/></linearGradient></defs>
    ${grid}<path d="${area}" fill="url(#lg)"/><path d="${d}" fill="none" stroke="#ff8a3d" stroke-width="2" stroke-linejoin="round"/>
    <text x="${P}" y="${H - 2}">${new Date(points[0].at).toLocaleDateString([], { weekday: 'short' })}</text><text x="${W - 30}" y="${H - 2}">Now</text></svg>`
}

function barChart(rows, keys, labelFn, title) {
  const W = 340, H = 130, P = 4
  const max = Math.max(1, ...rows.map((r) => keys.reduce((s, [k]) => s + (r[k] || 0), 0)))
  const bw = (W - P * 2) / rows.length
  const bars = rows
    .map((r, i) => {
      let acc = 0
      return keys
        .map(([k, color]) => {
          const v = r[k] || 0
          if (!v) return ''
          const h = (v / max) * (H - 30)
          const yv = H - 18 - acc - h
          acc += h
          return `<rect x="${(P + i * bw + 1).toFixed(1)}" y="${yv.toFixed(1)}" width="${Math.max(bw - 2, 1).toFixed(1)}" height="${h.toFixed(1)}" rx="2" fill="${color}"><title>${labelFn(r.t)}: ${v} ${k}</title></rect>`
        })
        .join('')
    })
    .join('')
  const ticks = rows.map((r, i) => (i % Math.ceil(rows.length / 6) === 0 ? `<text x="${(P + i * bw).toFixed(1)}" y="${H - 4}">${labelFn(r.t)}</text>` : '')).join('')
  const empty = rows.every((r) => keys.every(([k]) => !r[k]))
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(title)}"><line class="grid" x1="0" x2="${W}" y1="${H - 18}" y2="${H - 18}"/>${bars}${ticks}
    ${empty ? `<text x="${W / 2}" y="${H / 2}" text-anchor="middle" style="font-size:12px">No recorded activity in this period</text>` : ''}<text x="${W - 4}" y="10" text-anchor="end">max ${max}</text></svg>
    <div class="legend">${keys.map(([k, c, l]) => `<span><i style="background:${c}"></i>${l}</span>`).join('')}</div>`
}

// ---------- views ----------
function claimView() {
  const pending = (B.claims || []).filter((c) => c.status !== 'verified')
  const q = B.claimQuery.toLowerCase()
  const matches = S.venues.filter((v) => !q || v.name.toLowerCase().includes(q)).slice(0, 8)
  const chosen = B.claimPid ? venue(B.claimPid) : null
  const existing = B.claims?.find(c => c.pid === B.claimPid)
  return `${pending.length ? `<h2 class="sec">Your claims</h2><div class="list">${pending.map((c) => `<div class="card stack-sm"><div class="row between"><div><h3>${esc(c.name)}</h3><div class="tiny faint">Requested ${ago(c.requested_at)}</div></div><span class="tag">${c.status === 'rejected' ? 'Rejected' : c.needs_information ? 'More information needed' : 'Pending review'}</span></div><p class="small muted">${c.status === 'rejected' ? 'Read the reviewer message and update your request if you can provide further proof.' : c.needs_information ? 'Update your request with the information the reviewer needs.' : 'Your request is waiting for an authorized reviewer. Refresh to check for updates.'}</p>${c.message ? `<p class="small review-note">${esc(c.message)}</p>` : ''}${c.pid ? `<button class="btn sm alt" data-action="claimUpdate" data-pid="${esc(c.pid)}">Update request</button>` : ''}</div>`).join('')}</div>
      <p class="tiny faint">The LIT team verifies ownership (usually by calling the venue’s public number or checking a business email) before any analytics unlock.</p>` : ''}
    <h2 class="sec">Claim your venue</h2>
    <div class="card stack">
      ${chosen
        ? `<div class="row between"><div><div class="tiny faint">Selected venue</div><h3>${esc(chosen.name)}</h3><div class="tiny faint">${esc(chosen.address || chosen.category)}</div></div><button class="btn sm ghost" data-action="claimChange">Change</button></div>
        <form class="stack" data-submit="claimSubmit" data-pid="${esc(B.claimPid)}">
          <label class="field">Your role<select name="role">${['Owner','General manager','Marketing / social','Staff (authorised)'].map(r => `<option ${existing?.business_role === r ? 'selected' : ''}>${r}</option>`).join('')}</select></label>
          <label class="field">Business email<input name="email" type="email" required maxlength="254" placeholder="you@yourvenue.com" value="${esc(existing?.business_email || S.user?.email || '')}"></label>
          <label class="field">Business phone (optional)<input name="phone" type="tel" maxlength="40" placeholder="Public venue number" value="${esc(existing?.business_phone || '')}"></label>
          <label class="field">Official business page (optional)<input name="evidence" type="url" maxlength="500" placeholder="https://yourbusiness.com" value="${esc(existing?.evidence_url || '')}"></label>
          <label class="field">How can we verify you? (optional)<textarea name="note" maxlength="600" placeholder="e.g. listed on our website, reach me at the bar Tue–Sat">${esc(existing?.note || '')}</textarea></label>
          <button class="btn block" type="submit">Request verification</button><p class="form-msg" role="status"></p>
          <p class="tiny faint" style="margin:0">An authorized LIT reviewer checks your business access before approval. Check this dashboard for updates or requests for information. Do not submit passwords, payment information or sensitive ID documents. Verification never lets you edit scores or remove community videos.</p></form>`
        : `<input class="input" id="claimSearch" placeholder="Search nearby venues" value="${esc(B.claimQuery)}" aria-label="Search venues to claim">
        ${S.venues.length ? `<div class="list">${matches.map((v) => `<button class="venue-pick" data-action="claimPick" data-pid="${esc(v.id)}"><span class="radio"></span><span><strong>${esc(v.name)}</strong><div class="tiny faint">${esc(v.category)}${v.address ? ' · ' + esc(v.address) : ''}</div></span><span></span></button>`).join('') || '<p class="small muted">No matches nearby.</p>'}</div>` : `<div class="empty-card">${icon('pin', 'i-lg')}<div>Set your location to find your venue.</div><button class="btn sm" data-action="locate">Use my location</button></div>`}`}
    </div>`
}

function kpis(t) {
  const k = (v, l, fmt = fmtNum) => `<div class="kpi"><b>${fmt(v)}</b><span>${l}</span></div>`
  return `<div class="kpis">
    ${k(t.fresh_videos, 'Fresh videos')}${k(t.unique_viewers, 'Unique viewers')}${k(t.watch_seconds, 'Watch time', fmtDuration)}
    ${k(t.qualified_views, 'Engaged views (3s+)')}${k(t.shares, 'Shares')}${k(t.venue_opens, 'Venue page opens')}
    ${k(t.go_intent, 'GO intent')}${k(t.crew_interest, 'Crew interest')}${k(t.directions, 'Directions taps')}
    ${k(t.arrivals, 'Location checks')}${k(t.feedback, 'Feedback responses')}${k(t.crew_plans, 'Crew plans made')}</div>`
}

function videosView(videos) {
  if (!videos.length) return `<div class="empty-card">${icon('camera', 'i-lg')}<div>No videos at your venue in the last 7 days.</div></div>`
  return videos
    .map(
      (v) => `<div class="vid-row"><button class="vid-thumb" ${v.video_path ? `data-action="bizPlay" data-path="${esc(v.video_path)}" aria-label="Play video"` : 'disabled aria-label="Expired"'}>${icon(v.live ? 'play' : 'clock')}</button>
      <div style="min-width:0"><div class="row" style="gap:6px"><strong class="small">${fmtWhen(v.created_at)}</strong><span class="tag ${v.post_type === 'business' ? '' : 'ok'}">${v.post_type === 'business' ? 'Venue' : 'Community'}</span></div>
      <div class="vid-stats"><span>${fmtNum(v.unique_viewers)} viewers</span><span>${fmtNum(v.qualified_views)} engaged</span><span>${fmtDuration(v.unique_viewers ? v.watch_seconds / v.unique_viewers : 0)} avg watch</span><span>${fmtNum(v.shares)} shares</span>${v.open_reports ? `<span style="color:#ff9b8a">${v.open_reports} report(s)</span>` : ''}</div></div>
      <span class="tiny ${v.live ? '' : 'faint'}">${v.moderation_status !== 'visible' ? 'In review' : v.live ? 'Live' : 'Expired'}</span></div>`,
    )
    .join('')
}

function feedbackView(f) {
  if(f.suppressed)return `<p class="small muted">Guest feedback appears after at least ${esc(f.privacy_threshold || 3)} different guests respond within 30 days. Each guest contributes their latest response; no account identities are shared.</p>`
  const total = Object.values(f.accuracy || {}).reduce((a, b) => a + b, 0)
  const parts = [
    ['accurate', '#7fd3a5', 'Accurate'],
    ['busier', '#ff8a3d', 'Busier'],
    ['quieter', '#8b8f9c', 'Quieter'],
    ['inaccurate', '#ff5a4a', 'Not accurate'],
    ['not_shown', '#b8a69b', 'No activity info'],
  ]
  return `${total
    ? `<div class="acc-bar">${parts.map(([k, c]) => (f.accuracy[k] ? `<i style="width:${(f.accuracy[k] / total) * 100}%;background:${c}"></i>` : '')).join('')}</div>
      <div class="legend">${parts.map(([k, c, l]) => `<span><i style="background:${c}"></i>${l} ${f.accuracy[k] || 0}</span>`).join('')}</div>
      <div class="row between small"><span class="muted">${f.count_30d} guests · 30 days</span><span>Avg vibe <strong>${f.avg_vibe ?? '—'}</strong>/5</span></div>`
    : '<p class="small muted" style="margin:0">No post-arrival feedback yet. Guests are asked after they complete a location check via GO.</p>'}
    ${f.recent.filter((r) => r.note).slice(0, 6).map((r) => `<div class="small" style="border-left:2px solid var(--line-2);padding-left:10px"><span class="faint tiny">${ago(r.at)} · ${esc(r.accuracy)}${r.vibe ? ' · vibe ' + r.vibe : ''}</span><div>“${esc(r.note)}”</div></div>`).join('')}`
}

function promosView(list) {
  const now = new Date()
  const local = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16)
  const later = new Date(now.getTime() + 4 * 3600000)
  return `${list.length ? list.map((p) => `<div class="promo-card stack-sm"><div class="row between"><span class="tiny">${esc(p.kind)} · ${p.archived ? 'Ended by venue' : p.active ? 'Live now' : new Date(p.starts_at) > now ? 'Starts ' + fmtWhen(p.starts_at) : 'Ended'}</span>
      ${!p.archived ? `<div class="row"><button class="link" data-action="promoEdit" data-id="${esc(p.id)}">Edit</button><button class="x" data-action="promoArchive" data-id="${esc(p.id)}" data-version="${esc(p.version)}" aria-label="End ${esc(p.title)}">${icon('close')}</button></div>` : ''}</div>
      <strong>${esc(p.title)}</strong>${p.details ? `<div class="small muted">${esc(p.details)}</div>` : ''}
      <div class="vid-stats"><span>Views and taps are not measured yet</span>${p.ends_at ? `<span>Ends ${fmtTime(p.ends_at)}</span>` : ''}</div></div>`).join('') : '<p class="small muted" style="margin:0">No active specials or events.</p>'}
    <form class="stack" data-submit="promoSave" data-place="${esc(B.active)}" style="margin-top:6px">
      <div class="seg" role="radiogroup">${['special', 'event', 'promotion'].map((k, i) => `<label style="display:contents"><input type="radio" name="kind" value="${k}" ${i === 0 ? 'checked' : ''} class="sr"><span class="chip ${i === 0 ? 'on' : ''}" style="justify-content:center" data-kind-label>${k[0].toUpperCase() + k.slice(1)}</span></label>`).join('')}</div>
      <label class="field">Title<input name="title" maxlength="80" minlength="2" required placeholder="$5 margaritas until 10pm"></label>
      <label class="field">Details (optional)<input name="details" maxlength="300" placeholder="Patio only · DJ from 9"></label>
      <div class="btn-row promo-timing"><label class="field">Starts<input type="datetime-local" name="starts" value="${local(now)}"></label><label class="field">Ends<input type="datetime-local" name="ends" value="${local(later)}"></label></div>
      <button class="btn alt block" type="submit">${icon('plus')} Publish to venue page</button>
      <p class="tiny faint" style="margin:0">Shown on your venue and in WATCH. Promotions never change your LIT Score.</p></form>`
}

function profileView(p) {
  p = p || {}
  return `<form class="stack" data-submit="bizProfile" data-place="${esc(B.active)}">
    <label class="field">Description<textarea name="description" maxlength="600" placeholder="What makes your place worth the trip?">${esc(p.description || '')}</textarea></label>
    <label class="field">Hours<input name="hours" maxlength="200" value="${esc(p.hours || '')}" placeholder="Thu–Sat 5pm–2am"></label>
    <div class="btn-row"><label class="field">Phone<input name="phone" type="tel" maxlength="40" value="${esc(p.phone || '')}"></label><label class="field">Website<input name="website" type="url" maxlength="200" value="${esc(p.website || '')}" placeholder="https://"></label></div>
    <button class="btn alt block" type="submit">Save business profile</button></form>`
}

function dashView(d) {
  const t = d.totals?.[B.range] || {}
  const s = d.score
  const verified = (B.claims || []).filter((c) => c.status === 'verified')
  const hourLabel = (iso) => new Date(iso).toLocaleTimeString([], { hour: 'numeric' }).replace(' ', '').toLowerCase()
  const dayLabel = (iso) => new Date(iso).toLocaleDateString([], { month: 'numeric', day: 'numeric' })
  return `
    ${verified.length > 1 ? `<div class="biz-switch"><select class="input" id="bizVenue" aria-label="Switch venue">${verified.map((c) => `<option value="${esc(c.place_id)}" ${c.place_id === B.active ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select><button class="btn sm alt" data-action="bizRefresh">Refresh</button></div>` : ''}
    <div class="row between" style="margin:6px 0 14px"><span class="tag ok">${icon('shield', 'i-sm')} Verified owner</span><button class="link" data-action="bizRefresh">Updated ${ago(d.generated_at)} · refresh</button></div>

    ${d.go ? `<div class="card stack-sm"><h2>Current GO intent</h2><strong id="bizGoCount" style="font-size:32px">${fmtNum(d.go.current_count)}</strong><p class="small muted">People with this venue saved as their current GO destination. GO expires 12 hours after saving. Cancelling or choosing another venue removes them from this total. Intent is not attendance.</p><p class="tiny faint" id="bizGoUpdated">Anonymous total · updated ${ago(d.go.updated_at)} · refreshes while this dashboard is open</p></div>` : ''}
    ${d.crew ? `<div class="card stack-sm"><h2>Crew planning intent</h2><strong id="bizPlanningCount" style="font-size:32px">${fmtNum(d.crew.planning_count)}</strong><p class="small muted">Unique active Crew members who are In for a plan at this venue starting within 12 hours before or after now. Cancelled or ended plans and removed members are excluded. People can also appear in GO totals; do not add the two counts together.</p></div>` : ''}
    ${d.capabilities?.full_analytics === false ? '<p class="small muted">GO and Crew intent totals are connected. Location checks, guest feedback and promotions are connected when enabled below. Video and engagement analytics remain unavailable.</p>' : ''}
    ${s ? `<div class="card glow">${scoreExplainer(s, { detailed: true })}
      <div class="divider" style="margin:14px 0"></div>
      <div class="kv"><dt>Confidence</dt><dd>${esc(s.confidence)} — ${s.unique_people} independent people, ${s.independent_videos} independent video${s.independent_videos === 1 ? '' : 's'} (3h)</dd>
      <dt>Momentum</dt><dd>${esc(s.trend)} · ${s.counts?.activity_last_hour ?? 0} people active last hour vs ${s.counts?.activity_prior_hourly ?? 0}/hr before</dd>
      <dt>Freshness</dt><dd>${s.last_post_at ? 'Last video ' + ago(s.last_post_at) : 'No video in 3 hours'} · evidence decays with a 60-min half-life</dd></div>
      <p class="tiny faint" style="margin:12px 0 0">Your own posts and activity count at reduced weight and never as independent evidence. Scores can’t be bought or edited.</p></div>` : `<div class="card">${scoreExplainer(null)}</div>`}

    <h2 class="sec">Score history <span class="tiny faint">7 days</span></h2><div class="card">${lineChart(d.history || [])}</div>

    <h2 class="sec">Activity <div class="seg" style="width:140px">${['24h', '7d'].map((r) => `<button class="${B.range === r ? 'on' : ''}" data-action="bizRange" data-v="${r}">${r}</button>`).join('')}</div></h2>
    ${kpis(t)}

    <h2 class="sec">Hourly <span class="tiny faint">last 24h</span></h2>
    <div class="card">${barChart(d.hourly || [], [['viewers', '#ff8a3d', 'Viewers'], ['go', '#ffc46b', 'GO'], ['directions', '#e8d9c4', 'Directions']], hourLabel, 'Hourly activity')}</div>
    <h2 class="sec">Daily <span class="tiny faint">14 days</span></h2>
    <div class="card">${barChart(d.daily || [], [['viewers', '#ff8a3d', 'Viewers'], ['go', '#ffc46b', 'GO'], ['directions', '#e8d9c4', 'Directions']], dayLabel, 'Daily activity')}</div>

    <h2 class="sec">Video performance <span class="tiny faint">7 days</span></h2>
    <div class="card">${videosView(d.videos || [])}
      <button class="btn block" style="margin-top:12px" data-action="post" data-pid="${esc(d.place?.pid || '')}">${icon('camera')} Record a fresh venue video</button>
      <p class="tiny faint" style="margin:8px 0 0">${icon('shield', 'i-sm')} Community videos can’t be removed or hidden by venues. Use a video’s MORE → Report in WATCH for rule violations; reports go to independent moderation.</p></div>

    ${d.arrivals ? `<div class="card stack-sm"><h2>Location checks · 24 hours</h2><strong id="bizArrivalCount" style="font-size:32px">${fmtNum(d.arrivals.count_24h)}</strong><p class="small muted">Unique accounts that passed a device-location proximity check. Client GPS can be spoofed; this count is not proof of attendance.</p></div>` : ''}
    <h2 class="sec">Customer feedback</h2><div class="card stack">${feedbackView(d.feedback || { accuracy: {}, recent: [] })}</div>
    <h2 class="sec">Specials, events & promotions</h2><div class="card stack">${d.capabilities?.promotions === false ? '<p class="small muted">Venue promotion publishing is not connected yet.</p>' : promosView(d.promotions || [])}</div>
    <h2 class="sec">Business profile</h2><div class="card">${d.capabilities?.business_profile === false ? '<p class="small muted">Business profile editing is not connected yet.</p>' : profileView(d.profile)}</div>

    <h2 class="sec">Business Pro</h2>
    <div class="card pro stack-sm"><div class="row between"><strong>Coming later</strong><span class="tag">No charge today</span></div>
      <ul><li>AI forecasts for tonight’s activity</li><li>Deeper history & comparisons with nearby venues</li><li>Promotion attribution, alerts and scheduled reports</li><li>Posting-time recommendations</li></ul>
      <p class="tiny faint" style="margin:4px 0 0">Everything on this page stays free.</p></div>

    <button class="btn ghost block" style="margin-top:22px" data-action="claimAnother">${icon('plus')} Claim another venue</button>`
}

// Full free-tier dashboard shell: real sections, honest empty states, no fabricated metrics.
// Visible even before venue verification or while an RPC is unavailable.
function dashboardShell({ connectionError = null, hasClaim = false } = {}) {
  const metric = (label, note) => `<div class="kpi"><b>—</b><span>${label}</span><div class="tiny faint">${note}</div></div>`
  const section = (title, description, content = '') => `<h2 class="sec">${title}</h2><div class="card stack-sm"><p class="small muted" style="margin:0">${description}</p>${content}</div>`
  return `<div class="card glow stack-sm"><div class="row between"><div><div class="eyebrow">LIT BUSINESS · FREE</div><h2 style="margin:5px 0">Your venue intelligence</h2></div><span class="tag">${hasClaim ? 'Verification pending' : 'Not connected'}</span></div>
    <div class="score-hero"><div class="score-num none">NO FRESH<br>PROOF</div><div class="stack-sm"><strong>No verified live score yet</strong><div class="small muted">A score only appears after genuine, recent, independent activity. Zero traffic is not a zero score.</div></div></div>
    <p class="tiny faint" style="margin:0">This is your actual Business Mode layout. Dashes mean no verified data is available, not simulated statistics.</p></div>
    ${connectionError ? `<div class="card stack-sm" role="status"><strong>Analytics connection needs attention</strong><p class="small muted">${esc(connectionError)}</p><button class="btn sm" data-action="bizRefresh">Retry connection</button></div>` : ''}
    <h2 class="sec">Live demand overview <span class="tiny faint">Real data only</span></h2>
    <div class="kpis">${metric('Fresh venue videos','Awaiting evidence')}${metric('Unique viewers','Not measured')}${metric('Qualified views','Not measured')}${metric('Watch time','Not measured')}${metric('GO intent','Not measured')}${metric('Crew interest','Not measured')}${metric('Directions taps','Not measured')}${metric('Shares','Not measured')}${metric('Location checks','Not measured')}${metric('Venue opens','Not measured')}${metric('Feedback responses','Not measured')}${metric('Crew plans','Not measured')}</div>
    ${section('Why is this venue LIT?', 'Fresh independent video evidence (35%), meaningful engagement (20%), GO and Crew intent (20%), directions and supported arrivals (15%), and momentum (10%). These are proposed weights, not fabricated activity.', '<div class="small muted">Confidence: Not enough evidence · Momentum: Unknown · Latest fresh post: None confirmed</div>')}
    ${section('LIT Score history', 'When verified score snapshots arrive, the trend chart will appear here.', '<div class="empty-card">No score history recorded yet</div>')}
    ${section('Hourly and daily activity', 'Qualified views, GO intent, directions and genuine activity over time.', '<div class="empty-card">No recorded activity in this period</div>')}
    ${section('Video performance', 'Community and venue posts, unique viewers, engaged plays, watch time, completion and shares.', '<div class="empty-card">No venue videos available to analyze yet</div>')}
    ${section('Customer feedback', 'Actual post-arrival responses, accuracy signals and guest sentiment.', '<div class="empty-card">No verified feedback yet</div>')}
    ${section('Specials, events & promotions', 'Publish venue-authored updates after your business claim is verified.', '<div class="empty-card">Venue management unlocks after verification</div>')}
    ${section('Business profile and venue settings', 'Claim status, verified owner permissions, contact information, and venue management.')}
    <h2 class="sec">Business Pro</h2><div class="card pro stack-sm"><div class="row between"><strong>Advanced intelligence · Coming later</strong><span class="tag">No charge today</span></div><p class="small muted">Forecasts, deeper history, promotion attribution, configurable alerts, best posting times and AI reports. All free dashboard sections remain free.</p></div>`
}

function render() {
  const el = $('business')
  if (!el || S.screen !== 'business') return
  const head = `<button class="link" data-action="nav" data-to="watch" style="display:inline-flex;align-items:center;gap:4px">${icon('chev-left', 'i-sm')} Back to LIT</button>
    <div class="eyebrow" style="margin-top:8px">LIT BUSINESS</div><h1 class="title">${esc(B.dash?.place?.name || 'Venue insights')}</h1>${S.reviewAccess?.can_review ? '<button class="btn alt" data-action="openVerification">Business verification queue</button>' : ''}${S.user && (!B.active || B.showClaim) ? '<button class="link" data-action="bizRefresh">Refresh claim status</button>' : ''}`
  if (!S.user) {
    el.innerHTML = `${head}<p class="lede">Free, private analytics for verified venues: live LIT Score, video performance, GO intent, directions and real guest feedback.</p><div class="card glow stack"><button class="btn block" data-action="account">Log in to continue</button></div>`
    return
  }
  if (B.state === 'error') {
    el.innerHTML = head + dashboardShell({ connectionError: B.error }) + '<h2 class="sec">Venue access</h2>' + claimView()
    return
  }
  if (B.claims == null || (B.state === 'loading' && !B.dash)) {
    el.innerHTML = `${head}<div class="list"><div class="skel" style="height:180px"></div><div class="skel"></div><div class="skel"></div></div>`
    return
  }
  const hasVerified = B.claims.some((c) => c.status === 'verified')
  if (!hasVerified || B.showClaim) {
    el.innerHTML = head + dashboardShell({ hasClaim: (B.claims || []).length > 0 }) + `<h2 class="sec">Verify your venue</h2><p class="lede">Claim your venue to unlock private real analytics. Everyone can still WATCH videos and see public LIT Scores.</p>${claimView()}
      ${hasVerified ? '<button class="btn ghost block" style="margin-top:14px" data-action="claimDone">Back to dashboard</button>' : ''}`
    $('claimSearch')?.addEventListener('input', (e) => {
      B.claimQuery = e.target.value
      const pos = e.target.selectionStart
      render()
      const input = $('claimSearch')
      input.focus()
      input.setSelectionRange(pos, pos)
    })
    return
  }
  el.innerHTML = head + (B.dash ? dashView(B.dash) : '<div class="list"><div class="skel" style="height:180px"></div><div class="skel"></div></div>')
  $('bizVenue')?.addEventListener('change', async (e) => {
    B.active = e.target.value
    try {
      await loadDash()
    } catch (err) {
      toast(err.message)
    }
    render()
  })
}

export function renderBusiness() {
  if (!S.user) return render()
  if (B.claims == null && B.state !== 'loading') loadBusiness()
  else render()
}

actionsFor({
  openBusiness: () => {
    closeSheet()
    emit('navigate', 'business')
  },
  bizRefresh: () => loadBusiness(),
  bizRange: (d) => {
    B.range = d.v
    render()
  },
  bizPlay: async (d) => {
    await signedUrls([d.path])
    const url = S.urls[d.path]
    if (!url) return toast('Video unavailable')
    openSheet('Video preview', `<video src="${esc(url)}" controls autoplay playsinline style="width:100%;max-height:70dvh;border-radius:14px;background:#000"></video>`)
  },
  claimPick: (d) => {
    B.claimPid = d.pid
    render()
  },
  claimChange: () => {
    B.claimPid = null
    render()
  },
  claimAnother: () => {
    B.showClaim = true
    render()
  },
  claimDone: () => {
    B.showClaim = false
    render()
  },
  claimUpdate: async d => {
    const account = S.authVersion
    const claim = B.claims?.find(c => c.pid === d.pid)
    await resolveSharedVenue(d.pid, { lat: claim?.lat, lon: claim?.lon })
    if (account !== S.authVersion) return
    B.claimPid = d.pid; B.showClaim = true; render()
  },
  claimSubmit: async (d, form) => {
    const account = S.authVersion, pid = B.claimPid
    const msg = form.querySelector('.form-msg')
    form.querySelector('button[type=submit]').disabled = true
    try {
      const id = await ensurePlaceId(pid)
      if (account !== S.authVersion) return
      if (!id) throw new Error('This venue could not be registered')
      const result = await rpc('lit_request_claim', { p_place: id, p_role: form.role.value, p_email: form.email.value, p_phone: form.phone.value, p_note: form.note.value, p_evidence_url: form.evidence.value })
      if (result?.submitted !== true) throw new Error('Your request could not be confirmed. Refresh before retrying.')
      emit('draftSaved',form)
      B.claimPid = null
      B.showClaim = false
      toast('Claim submitted for verification')
      await loadBusiness()
    } catch (e) {
      msg.textContent = e.message
      msg.classList.add('err')
      form.querySelector('button[type=submit]').disabled = false
    }
  },
  promoEdit: d => {
    const promo=B.dash?.promotions?.find(p=>p.id===d.id)
    if(!promo || promo.archived)return
    const body=openSheet('Edit promotion',promosView([]),{eyebrow:'Business'})
    const form=body.querySelector('[data-submit=promoSave]')
    form.dataset.id=promo.id;form.dataset.version=promo.version
    form.elements.namedItem('title').value=promo.title;form.details.value=promo.details
    const local=iso=>{const date=new Date(iso);return new Date(date.getTime()-date.getTimezoneOffset()*60000).toISOString().slice(0,16)}
    form.starts.value=local(promo.starts_at);form.ends.value=local(promo.ends_at)
    form.querySelector(`[name=kind][value="${promo.kind}"]`).checked=true
    form.querySelectorAll('[data-kind-label]').forEach(l=>l.classList.toggle('on',l.previousElementSibling.checked))
    form.querySelector('button[type=submit]').textContent='Save changes'
  },
  promoSave: async (d, form) => {
    const account=S.authVersion,place=B.active,button=form.querySelector('button[type=submit]')
    button.disabled=true
    if(!form.dataset.id)form.dataset.id=crypto.randomUUID()
    try {
      await rpc('lit_save_promotion', {
        p_place: place,
        p_id: form.dataset.id,
        p_version: form.dataset.version ? Number(form.dataset.version) : null,
        p_kind: form.kind.value,
        p_title: form.elements.namedItem('title').value,
        p_details: form.details.value,
        p_starts_at: form.starts.value ? new Date(form.starts.value).toISOString() : null,
        p_ends_at: form.ends.value ? new Date(form.ends.value).toISOString() : null,
      })
      if(account!==S.authVersion || place!==B.active)return
      if(form.closest('.sheet'))closeSheet()
      toast(form.dataset.version ? 'Promotion updated' : 'Published to your venue page')
      await loadDash()
      render()
    } catch (e) {
      toast(e.message)
      button.disabled=false
    }
  },
  promoArchive: async (d) => {
    if (!confirm('End this promotion? It will disappear from the public venue page.')) return
    try {
      await rpc('lit_archive_promotion', { p_id: d.id, p_version: Number(d.version) })
      await loadDash()
      render()
    } catch (e) {
      toast(e.message)
    }
  },
  bizProfile: async (d, form) => {
    try {
      const profile = await rpc('lit_save_business_profile', { p_place: B.active, p_description: form.description.value, p_website: form.website.value, p_phone: form.phone.value, p_hours: form.hours.value })
      if (B.dash) B.dash.profile = profile
      toast('Business profile saved')
    } catch (e) {
      toast(e.message)
    }
  },
})

// Promotion kind segmented control: reflect the checked radio.
document.addEventListener('change', (e) => {
  if (e.target.name !== 'kind' || !e.target.closest('[data-submit="promoSave"]')) return
  e.target.closest('.seg').querySelectorAll('[data-kind-label]').forEach((l) => l.classList.toggle('on', l.previousElementSibling.checked))
})

on('claim', (pid) => {
  if (!requireAuth('Sign in to claim your venue')) return
  B.claimPid = pid
  B.showClaim = true
  emit('navigate', 'business')
})
on('auth', () => {
  ++businessVersion; ++dashVersion
  Object.assign(B, { state: 'idle', error: null, showClaim: false, claimPid: null, claimQuery: '', range: '24h' })
  B.claims = null
  B.dash = null
  B.active = null
  if (S.screen === 'business') renderBusiness()
})
on('reviewAccess', () => { if (S.screen === 'business' && !document.activeElement?.closest?.('form')) render() })

let quietRefreshPending = false
export async function refreshBusinessQuietly() {
  if (quietRefreshPending || document.hidden || S.screen !== 'business' || !S.user || B.state === 'loading') return
  const account = S.authVersion, place = B.active, version = ++dashVersion
  quietRefreshPending = true
  try {
    if (place && B.dash && !B.showClaim) {
      const dash = await rpc('lit_business_dashboard', { p_place: place })
      if (account !== S.authVersion || version !== dashVersion || place !== B.active) return
      B.dash = dash
      if ($('bizGoCount')) $('bizGoCount').textContent = fmtNum(dash.go?.current_count)
      if ($('bizArrivalCount')) $('bizArrivalCount').textContent=fmtNum(dash.arrivals?.count_24h)
      if ($('bizPlanningCount')) $('bizPlanningCount').textContent=fmtNum(dash.crew?.planning_count)
      if ($('bizGoUpdated')) $('bizGoUpdated').textContent = 'Anonymous total · just updated · refreshes while this dashboard is open'
    } else if (!document.activeElement?.closest?.('form')) {
      const claims = await rpc('lit_my_business')
      if (account !== S.authVersion || version !== dashVersion || !Array.isArray(claims)) return
      if (JSON.stringify(claims) !== JSON.stringify(B.claims)) await loadBusiness()
    }
  } catch (error) {
    if (account !== S.authVersion || version !== dashVersion) return
    if (/verified claim|required|permission|access/i.test(error.message)) { B.dash = null; await loadBusiness() }
    else if ($('bizGoUpdated')) $('bizGoUpdated').textContent = 'Refresh failed · tap refresh to retry'
  } finally { quietRefreshPending = false }
}
