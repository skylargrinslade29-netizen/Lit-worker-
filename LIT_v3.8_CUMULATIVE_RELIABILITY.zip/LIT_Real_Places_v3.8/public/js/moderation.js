// Optional backend-connected moderation. Client buttons do not grant moderator rights.
import { S, esc, on, actionsFor, openSheet, closeSheet, toast } from './core.js'
import { sb, rpc } from './api.js'
import { loadFeed } from './places.js'
export async function reviewQueue() {
  if (!S.user) return toast('Sign in to access review tools')
  const user = S.user.id
  const data = await rpc('lit_moderation_queue', { p_limit: 25 })
  if (user !== S.user?.id) return
  if (data?.authorized !== true || !Array.isArray(data.reports) || !data.reports.every((r) => r && typeof r.id === 'string' && r.id)) throw new Error('Review access is unavailable.')
  const access=await rpc('lit_safety_access')
  const moderators=access.is_owner ? await rpc('lit_list_moderators') : []
  if(user!==S.user?.id)return
  const health=access.is_owner ? await rpc('lit_operator_status') : null
  if(user!==S.user?.id)return
  const operations=health ? `<div class="card stack-sm"><strong>Processing & deletion service</strong><p class="small muted">Worker ${health.worker_online ? 'online' : 'offline'} · ${Number(health.video_pending)} videos waiting · ${Number(health.media_cleanup_pending)} files awaiting cleanup · ${Number(health.deletions_pending)} deletions pending.</p>${health.deletions_needing_attention ? `<p class="small">${Number(health.deletions_needing_attention)} deletion requests need attention. Check worker connection logs before retrying.</p><button class="btn alt" data-action="retryDeletions">Retry stalled deletions</button>` : ''}</div>` : ''
  const team=access.is_owner ? `<div class="card stack"><strong>Content moderation team</strong><p class="small muted">Only you can grant or revoke moderation access. This is separate from business verification.</p><form class="stack" data-submit="moderatorGrant"><label class="field">Confirmed LIT account email<input name="email" type="email" required maxlength="254"></label><button class="btn alt" type="submit">Grant moderator access</button><p class="form-msg" role="status"></p></form>${moderators.map(m=>`<div class="row between wrap"><span class="small">${esc(m.email)}</span><button class="link" data-action="moderatorRevoke" data-email="${esc(m.email)}">Revoke</button></div>`).join('') || '<p class="small muted">No additional moderators.</p>'}</div>` : ''
  openSheet('Report review', `<div class="stack"><p class="small muted">Only server-authorized reviewers can resolve reports. Every decision needs a reason. Venue ownership does not grant these permissions.</p>${operations}${team}${data.reports.map((r) => `<form class="card stack" data-submit="resolveReport" data-report="${esc(r.id)}"><strong>${esc(r.reason || 'Reported video')}</strong><div class="small muted">${esc(r.venue || 'Venue unavailable')}</div>${!r.unavailable ? `<button class="btn alt" type="button" data-action="moderationPreview" data-report="${esc(r.id)}">Preview reported clip</button>` : '<p class="small muted">Clip expired or removed.</p>'}<p class="small muted">${esc(r.details || '')}</p><div data-preview></div><label class="field">Decision<select name="decision"><option value="remove">Remove reported video</option><option value="dismiss">Dismiss report</option></select></label><label class="field">Review reason<textarea name="note" required minlength="3" maxlength="500"></textarea></label><button class="btn" type="submit">Save review decision</button></form>`).join('') || '<p>No reports are awaiting review.</p>'}</div>`)
}
export async function blockPostAuthor(postId) {
  if (!S.user) return toast('Sign in to block a creator')
  if (!confirm('Block this creator? Their videos will be excluded from your account feed once the server confirms.')) return
  const data = await rpc('lit_block_post_author', { p_post: postId })
  if (data?.blocked !== true) throw new Error('The block could not be confirmed.')
  closeSheet(); await loadFeed(); toast('Creator blocked for your account')
}
async function showBlocks() {
  if (!S.user) return toast('Sign in to manage blocks')
  const blocks = await rpc('lit_my_blocks')
  if (!Array.isArray(blocks)) throw new Error('Blocked creators are unavailable.')
  openSheet('Blocked creators', `<div class="stack"><p class="small muted">Blocks apply to your account. Creator identities are not listed here.</p>${blocks.map((b, i) => `<div class="card row between"><strong>Blocked creator ${i + 1}</strong><button class="link" data-action="unblockCreator" data-block="${esc(b.id)}">Unblock</button></div>`).join('') || '<p>No blocked creators.</p>'}</div>`)
}
async function myVideos(){
 const items=await rpc('lit_my_uploads');const state=s=>({recording:'Recording not submitted',pending:'Waiting to process',processing:'Processing',ready:'Published',failed:'Could not process — record again',removed:'Removed'})[s]||'Unavailable'
 openSheet('My videos',`<div class="stack"><p class="small muted">Recordings appear publicly only after processing succeeds. Published clips expire 24 hours after recording started.</p><button class="btn alt" data-action="myVideos">Refresh status</button>${items.map(v=>`<div class="card stack-sm"><strong>${esc(v.state==='ready' && Date.parse(v.expires_at)<=Date.now() ? 'Expired' : state(v.state))}</strong><div class="tiny faint">${esc(new Date(v.created_at).toLocaleString())}</div>${v.state!=='removed' ? `<button class="link" data-action="discardVideo" data-session="${esc(v.id)}">${v.state==='ready' ? 'Remove video' : 'Discard recording'}</button>` : ''}</div>`).join('') || '<p>No recent recordings.</p>'}</div>`)
}
actionsFor({
 myVideos,
 retryDeletions:async()=>{await rpc('lit_retry_deletions');await reviewQueue();toast('Stalled deletions queued for retry')},
 discardVideo:async d=>{if(!confirm('Remove this recording? This cannot be undone.'))return;await rpc('lit_discard_capture',{p_session:d.session});await myVideos();await loadFeed()},
  moderatorGrant:async(d,form)=>{const button=form.querySelector('button[type=submit]');button.disabled=true;try{await rpc('lit_manage_moderator',{p_email:form.email.value,p_enabled:true});await reviewQueue();toast('Moderator access granted')}catch(e){form.querySelector('.form-msg').textContent=e.message}finally{button.disabled=false}},
  moderatorRevoke:async d=>{if(!confirm('Revoke this account’s content moderator access?'))return;await rpc('lit_manage_moderator',{p_email:d.email,p_enabled:false});await reviewQueue();toast('Moderator access revoked')},
  moderationPreview:async(d,button)=>{const account=S.authVersion;const preview=await rpc('lit_moderation_preview',{p_report:d.report});const {data,error}=await sb.storage.from('lit-fresh-videos').createSignedUrl(preview.path,120);if(account!==S.authVersion || !button.isConnected)return;if(error || !data?.signedUrl)throw new Error('Clip preview is unavailable.');button.closest('form').querySelector('[data-preview]').innerHTML=`<video controls playsinline preload="metadata" style="width:100%;max-height:360px" src="${esc(data.signedUrl)}"></video>`},
  moderation: reviewQueue, blockAuthor: (d) => blockPostAuthor(d.post), myBlocks: showBlocks,
  unblockCreator: async (d) => { const result = await rpc('lit_unblock_creator', { p_block: d.block }); if (result?.unblocked !== true) throw new Error('Unblock could not be confirmed.'); await showBlocks(); await loadFeed() },
  resolveReport: async (d, form) => {
    const note = form.note.value.trim()
    if (note.length < 3 || note.length > 500) return toast('Add a review reason of 3–500 characters')
    if (!['remove', 'dismiss'].includes(form.decision.value)) return
    const button=form.querySelector('button[type=submit]');button.disabled=true
    try{
    const result = await rpc('lit_resolve_report', { p_report: d.report, p_decision: form.decision.value, p_note: note })
    if (result?.resolved !== true) throw new Error('The review decision could not be confirmed.')
    await reviewQueue(); await loadFeed(); toast('Review decision saved')
    }finally{button.disabled=false}
  },
})

let accessVersion=0
on('auth',async()=>{const version=++accessVersion,user=S.user?.id;S.safetyAccess=null;if(!user)return;try{const access=await rpc('lit_safety_access');if(version===accessVersion && user===S.user?.id)S.safetyAccess=access}catch{}})
