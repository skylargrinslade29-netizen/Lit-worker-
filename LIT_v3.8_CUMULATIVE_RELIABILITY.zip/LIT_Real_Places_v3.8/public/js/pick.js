import { activityMarkup } from './activity.js'
import { isSaved } from './saved.js'
// PICK — choose the best nearby venue from genuine evidence.
import { S, $, esc, icon, on, actionsFor, savePrefs, toast, fmtMiles, litDial, ago } from './core.js'
import { locate, loadPlaces, searchLocation, setRadius } from './places.js'
import { isGoing } from './go.js'

const CATS = ['All', 'Bars', 'Food', 'Party', 'Live Music', 'Comedy', 'Entertainment']
const CAT_LABEL = { Party: 'Nightclubs' }
const NIGHT = new Set(['Bars', 'Party', 'Live Music', 'Comedy'])
let shown = 30
let askVersion = 0, askController = null
let ask = { q: '', state: 'idle', result: null }

function evidence(pid) {
  const p = S.places[pid]
  const count = S.posts.filter((x) => x.pid === pid).length
  const last = S.posts.find((x) => x.pid === pid)?.created_at
  return { p, count, last, score: p?.score?.score ?? null, promos: p?.promos || [] }
}

export function tonightPromo(promos) {
  const end = new Date()
  end.setHours(29, 0, 0, 0) // through ~5am
  const now = Date.now()
  return promos.find((x) => Number.isFinite(Date.parse(x.starts_at)) && Date.parse(x.starts_at) < end.getTime() && Number.isFinite(Date.parse(x.ends_at)) && Date.parse(x.ends_at) > now)
}

export function rankedVenues() {
  let list = S.venues.filter((v) => (S.category === 'All' || v.category === S.category) && (!S.venueQuery || `${v.name} ${v.address || ''}`.toLowerCase().includes(S.venueQuery.toLowerCase())) && (v.mi == null || v.mi <= S.radius))
  const e = Object.fromEntries(list.map((v) => [v.id, evidence(v.id)]))
  if (S.when === 'tonight') {
    const t = (v) => (tonightPromo(e[v.id].promos) ? 2 : 0) + (NIGHT.has(v.category) ? 1 : 0)
    list.sort((a, b) => t(b) - t(a) || (e[b.id].score ?? -1) - (e[a.id].score ?? -1) || a.mi - b.mi)
  } else {
    list.sort((a, b) => (e[b.id].score ?? -1) - (e[a.id].score ?? -1) || e[b.id].count - e[a.id].count || a.mi - b.mi)
  }
  if (S.category === 'All') {
    // Preserve real evidence ordering, then mix categories within each evidence tier.
    const tiers = new Map()
    for (const v of list) {
      const key = S.when === 'now' ? `${e[v.id].score ?? -1}|${e[v.id].count}` : `${(tonightPromo(e[v.id].promos) ? 2 : 0) + (NIGHT.has(v.category) ? 1 : 0)}|${e[v.id].score ?? -1}`
      if (!tiers.has(key)) tiers.set(key, new Map())
      const groups = tiers.get(key)
      if (!groups.has(v.category)) groups.set(v.category, [])
      groups.get(v.category).push(v)
    }
    list = [...tiers.values()].flatMap((groups) => {
      const order = ['Bars', 'Party', 'Live Music', 'Comedy', 'Entertainment', 'Food']
      const queues = [...new Set([...order, ...groups.keys()])].map((c) => groups.get(c) || [])
      const mixed = []
      while (queues.some((q) => q.length)) for (const q of queues) if (q.length) mixed.push(q.shift())
      return mixed
    })
  }
  return { list, e }
}

function card(v, ev) {
  const going = isGoing(v.id)
  const promo = S.when === 'tonight' ? tonightPromo(ev.promos) : ev.promos[0]
  return `<div class="venue">
    ${litDial(ev.p?.score)}
    <button style="text-align:left;min-width:0" data-action="venue" data-pid="${esc(v.id)}">
      <h3>${esc(v.name)}</h3>
      <div class="meta">${esc(CAT_LABEL[v.category] || v.category)}${v.cuisine ? ' · ' + esc(v.cuisine) : ''} · ${fmtMiles(v.mi)}</div>
      <div class="ev ${ev.count ? 'hot' : ''}">${ev.count ? `${icon('camera')} ${ev.count} fresh clip${ev.count === 1 ? '' : 's'} · ${ago(ev.last)}` : 'No fresh proof yet'}</div>
      ${activityMarkup(ev.p, { compact: true, pid: v.id })}
      <span class="tiny faint">${isSaved(v.id) ? 'Saved on this device' : ''}</span>
      ${promo ? `<div class="spec">${icon('spark', 'i-sm')} ${esc(promo.title)}</div>` : ''}
    </button>
    <div class="venue-actions"><button class="link" data-action="saveVenue" data-pid="${esc(v.id)}" aria-pressed="${isSaved(v.id)}">${isSaved(v.id) ? 'Unsave' : 'Save place'}</button>
    <button class="go-mini ${going ? 'on' : ''}" data-action="go" data-pid="${esc(v.id)}" aria-label="${going ? 'Cancel GO' : 'GO'} to ${esc(v.name)}" aria-pressed="${going}">${icon(going ? 'check' : 'go')}</button></div>
  </div>`
}

function askBlock() {
  let out = ''
  if (ask.state === 'loading') out = `<div class="ask-picks"><div class="skel" style="height:58px"></div></div>`
  else if (ask.state === 'error') out = `<p class="small muted" style="margin:10px 0 0">${esc(ask.result)}</p>`
  else if (ask.state === 'done') {
    const r = ask.result
    out = `<p class="small" style="margin:12px 0 0">${esc(r.summary || '')}</p><div class="ask-picks">${(r.picks || [])
      .map((p) => {
        const v = S.byPid[p.id]
        return v ? `<button class="ask-pick" data-action="venue" data-pid="${esc(v.id)}"><span><strong>${esc(v.name)}</strong><span class="small muted">${esc(p.reason)}</span></span>${icon('chev-right', 'i-sm')}</button>` : ''
      })
      .join('')}</div><p class="tiny faint" style="margin:8px 0 0">Ask LIT only uses real venues and the evidence shown here.</p>`
  }
  return `<form class="card ask" data-submit="ask"><div class="row" style="margin-bottom:10px">${icon('spark')}<strong>Ask LIT</strong></div>
    <div class="inline-form"><input class="input" name="q" maxlength="240" value="${esc(ask.q)}" placeholder="Date night, cheap drinks, live band…" aria-label="Ask LIT"><button class="btn sm" type="submit">Ask</button></div>${out}</form>`
}

function locationBlock() {
  return `<div class="card location-card"><form class="manual-location" data-submit="manualLocation">
    <label class="sr-only" for="manualLocation">ZIP code or city</label>
    <input class="input" id="manualLocation" name="location" autocomplete="postal-code" maxlength="100" value="${esc(S.locationQuery || '')}" placeholder="ZIP code or city, state" aria-label="ZIP code or city">
    <button class="btn alt" type="submit">Find places</button></form>
    <button type="button" class="link location-gps" data-action="locate" ${S.feedState === 'locating' ? 'disabled aria-busy="true"' : ''}>${icon('pin', 'i-sm')} ${S.feedState === 'locating' ? 'Finding your location…' : 'Use my current location'}</button>
    ${S.locationError ? `<p class="muted" role="status">${esc(S.locationError)}</p>` : ''}</div>`
}

document.addEventListener('input', (event) => {
  if (event.target.id === 'manualLocation') S.locationQuery = event.target.value
})

export function renderPick() {
  const el = $('pick')
  const head = `<div class="eyebrow">PICK${S.area ? ' · ' + esc(S.area) : ''}</div><h1 class="title">Where’s it happening?</h1>`
  const filters = `<div class="filters">
    <div class="seg" role="tablist" aria-label="Time">${[['now', 'Right now'], ['tonight', 'Tonight']].map(([k, l]) => `<button role="tab" class="${S.when === k ? 'on' : ''}" aria-selected="${S.when === k}" data-action="when" data-v="${k}">${l}</button>`).join('')}</div>
    <div class="seg" aria-label="Radius">${[5, 10, 25, 50].map((r) => `<button class="${S.radius === r ? 'on' : ''}" aria-pressed="${S.radius === r}" data-action="radius" data-v="${r}">${r} mi</button>`).join('')}</div>
    <div class="chips">${CATS.map((c) => `<button class="chip ${S.category === c ? 'on' : ''}" aria-pressed="${S.category === c}" data-action="cat" data-v="${esc(c)}">${CAT_LABEL[c] || c}</button>`).join('')}</div></div>`
  if (!S.coords) {
    const finding = S.feedState === 'locating'
    const message = finding ? 'Finding your location…' : S.feedState === 'denied' ? 'GPS permission is off. Enter a ZIP code or city instead.' : S.feedState === 'error' ? esc(S.placesError || 'Could not determine your location.') : 'Use GPS or enter a ZIP code/city to find real nearby venues.'
    el.innerHTML = `${head}<p class="lede">${message}</p>${locationBlock()}${finding ? '<div class="list" aria-busy="true"><div class="skel"></div><div class="skel"></div></div>' : ''}`
    return
  }
  const loading = S.feedState === 'loading' || S.feedState === 'locating'
  const { list, e } = rankedVenues()
  const status = loading
    ? 'Loading real places…'
    : S.feedState === 'error'
      ? esc(S.placesError || 'Places unavailable')
      : `${list.length} real place${list.length === 1 ? '' : 's'}${S.placesWarning ? ' · ' + esc(S.placesWarning) : ''}`
  const tonightNote = S.when === 'tonight' ? `<p class="tiny faint" style="margin:-4px 0 12px">Tonight puts venue-posted events and specials first, then nightlife spots. Plans are intent — not a guarantee anyone will be there.</p>` : ''
  el.innerHTML = `${head}${locationBlock()}<button class="btn alt block" data-action="savedPlaces">Saved places</button><button class="link" data-action="settings">Settings & privacy</button>${askBlock()}<form class="inline-form" data-submit="venueSearch"><input class="input" name="venue" maxlength="100" value="${esc(S.venueQuery || '')}" placeholder="Search loaded venues by name" aria-label="Search loaded venue names"><button class="btn sm" type="submit">Search</button></form>${S.venueQuery ? '<button class="link" data-action="clearVenueSearch">Clear venue search</button>' : ''}${filters}${tonightNote}
    <p class="status-line">${loading ? '' : icon('pin', 'i-sm')}${status}${S.feedState === 'error' ? ' <button class="link" data-action="reloadPlaces">Retry</button>' : ''}</p>
    <div class="list">${
      loading && !list.length
        ? '<div class="skel"></div><div class="skel"></div><div class="skel"></div><div class="skel"></div>'
        : list.length
          ? list.slice(0, shown).map((v) => card(v, e[v.id])).join('')
          : S.feedState === 'error'
            ? `<div class="empty-card">${icon('pin', 'i-lg')}<div>Nearby places couldn’t load. Try again or enter another location above.</div><button class="btn sm alt" data-action="reloadPlaces">Retry</button></div>`
          : loading ? '' : `<div class="empty-card">${icon('search', 'i-lg')}<div>${S.venueQuery ? 'No loaded venues match ' + esc(S.venueQuery) + '. ' : ''}No ${S.category === 'All' ? '' : esc((CAT_LABEL[S.category] || S.category).toLowerCase()) + ' '}places within ${Math.min(S.radius, S.coverageMiles || S.radius).toFixed(1).replace(/\.0$/, '')} miles.</div><button class="btn sm alt" data-action="cat" data-v="All">Show all categories</button></div>`
    }</div>
    ${list.length > shown ? `<button class="btn ghost block" style="margin-top:12px" data-action="more">Show more (${list.length - shown})</button>` : ''}`
}

// Offline fallback for Ask LIT: simple category matching over real venues.
function keywordPicks(q, pool) {
  const map = [
    [/drink|cocktail|bar|beer|wine|pub/i, ['Bars']],
    [/date|dinner|eat|food|restaurant|brunch|taco|pizza|sushi/i, ['Food']],
    [/dance|club|party|dj/i, ['Party']],
    [/music|concert|band|jazz|live/i, ['Live Music']],
    [/comedy|laugh|stand.?up/i, ['Comedy']],
    [/movie|bowling|arcade|game|fun/i, ['Entertainment']],
  ]
  const hit = map.find(([re]) => re.test(q))
  return pool
    .filter((v) => !hit || hit[1].includes(v.category))
    .slice(0, 3)
    .map((v) => ({ id: v.id, reason: `${v.category} · ${v.miles} mi away · ${v.videos ? v.videos + ' fresh clip(s)' : 'No fresh LIT activity'}` }))
}

actionsFor({
  venueSearch: (d, form) => { S.venueQuery = form.elements.namedItem("venue").value.trim().slice(0, 100); shown = 30; renderPick() },
  clearVenueSearch: () => { S.venueQuery = ""; shown = 30; renderPick() },
  locate: () => locate(),
  reloadPlaces: () => loadPlaces(),
  manualLocation: async (d, form) => {
    const q = form.elements.namedItem('location').value.trim()
    if (!q) return toast('Enter a ZIP code or city')
    try { await searchLocation(q) } catch (e) { toast(e.message) }
  },
  when: (d) => {
    S.when = d.v
    savePrefs()
    renderPick()
  },
  radius: (d) => {
    shown = 30
    setRadius(Number(d.v))
    renderPick()
  },
  cat: (d) => {
    S.category = d.v
    shown = 30
    savePrefs()
    renderPick()
  },
  more: () => {
    shown += 30
    renderPick()
  },
  ask: async (d, form) => {
    const q = form.q.value.trim()
    if (!q) return toast('Tell LIT what you’re in the mood for')
    if (!S.venues.length) return toast('Set your location first so LIT can find real places')
    const version = ++askVersion, coords = S.coords
    askController?.abort()
    const controller = askController = new AbortController()
    const timer = setTimeout(() => controller.abort(), 10000)
    ask = { q, state: 'loading', result: null }
    renderPick()
    const { list, e } = rankedVenues()
    const pool = (list.length ? list : S.venues).slice(0, 60).map((v) => ({
      id: v.id,
      name: v.name,
      category: v.category,
      cuisine: v.cuisine,
      miles: Number(v.mi?.toFixed(1)),
      status: e[v.id]?.p?.score?.status,
      score: e[v.id]?.score ?? undefined,
      videos: e[v.id]?.count || 0,
      specials: (e[v.id]?.promos || []).map((p) => p.title),
    }))
    try {
      const res = await fetch('/api/ask', { signal: controller.signal, method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ query: q, venues: pool }) })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      if (version !== askVersion || coords !== S.coords) return
      if (!Array.isArray(data.picks)) throw new Error('Invalid recommendation response')
      ask = { q, state: 'done', result: data }
    } catch (err) {
      if (version !== askVersion || coords !== S.coords) return
      const picks = keywordPicks(q, pool)
      ask = picks.length
        ? { q, state: 'done', result: { summary: 'Real nearby matches for your request (smart answers are unavailable right now).', picks } }
        : { q, state: 'error', result: 'No matching places nearby. Try another request or a larger radius.' }
    } finally { clearTimeout(timer) }
    if (S.screen === 'pick') renderPick()
  },
})

let askLocation = S.coords
on('places', () => {
  if (askLocation !== S.coords) { askLocation = S.coords; ++askVersion; askController?.abort(); ask = { q: '', state: 'idle', result: null }; S.venueQuery = ''; shown = 30 }
  if (S.screen === 'pick') renderPick()
})
on('feed', () => S.screen === 'pick' && renderPick())
on('go', () => S.screen === 'pick' && renderPick())

on('saved', () => S.screen === 'pick' && renderPick())
