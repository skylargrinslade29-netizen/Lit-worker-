import { S, on, emit, esc, icon, actionsFor, openSheet, safeWebUrl } from './core.js'
import { rpc } from './api.js'
import { isGoing } from './go.js'

// Busy state covers newly rendered buttons as well as the original click target.
function updateGoButtons() {
 document.querySelectorAll('[data-action="go"]').forEach(button => {
  const busy=!!S.goSaving, going=isGoing(button.dataset.pid)
  button.disabled=busy
  button.setAttribute('aria-busy',String(busy))
  button.setAttribute('aria-pressed',String(going))
  if(busy && button.textContent.trim()==='Saving…') return
  if(busy) button.innerHTML=`${icon('go')} Saving…`
  else if(button.closest('#go')) button.innerHTML='Cancel GO'
  else if(button.closest('#sheetBody')) button.innerHTML=`${icon(going?'check':'go')} ${going?'Going':'GO'}`
  else if(button.classList.contains('go-mini')) button.innerHTML=icon(going?'check':'go')
  else if(button.closest('.rail')) button.innerHTML=`<span>${icon(going?'check':'go')}</span>${going?'GOING':'GO'}`
 })
}
on('goSaving',updateGoButtons)
on('go',updateGoButtons)
on('feed',()=>{updateGoButtons();emit('activityTick')})
on('places',updateGoButtons)

// Only selected non-credential forms are retained, in this tab, for 24 hours.
const drafts=new Map(),allowed=new Set(['claimSubmit','bizProfile','promoSave','feedback','createCrew','createOuting'])
const prefix='lit-form-draft:'
const formKey=form=>`${prefix}${S.user?.id||'guest'}:${form.dataset.submit}:${JSON.stringify(form.dataset)}`
const safeField=field=>field.name && !['password','hidden','file'].includes(field.type) && !/password|token|secret|payment/i.test(field.name)
function saveDraft(form){
 if(!allowed.has(form?.dataset.submit))return
 const values={}
 for(const field of form.elements)if(safeField(field))values[field.name]=field.type==='checkbox'?field.checked:field.value
 const data={at:Date.now(),values};drafts.set(formKey(form),data)
 try{sessionStorage.setItem(formKey(form),JSON.stringify(data))}catch{}
}
function restoreDraft(form){
 if(!allowed.has(form.dataset.submit)||form.dataset.draftRestored)return
 form.dataset.draftRestored='true'
 // Exclude this implementation marker from the draft identity.
 const marker=form.dataset.draftRestored;delete form.dataset.draftRestored
 const key=formKey(form);form.dataset.draftRestored=marker
 let data=drafts.get(key)
 try{data ||= JSON.parse(sessionStorage.getItem(key)||'null')}catch{}
 if(!data||Date.now()-data.at>86400000)return
 for(const field of form.elements)if(safeField(field)&&Object.hasOwn(data.values,field.name)){
  if(field.type==='checkbox')field.checked=!!data.values[field.name]
  else field.value=data.values[field.name]
 }
}
// Stable identity ignores the restore marker.
const originalKey=formKey
function keyFor(form){const marker=form.dataset.draftRestored;delete form.dataset.draftRestored;const key=originalKey(form);if(marker)form.dataset.draftRestored=marker;return key}
function record(event){const form=event.target.closest('form[data-submit]');if(!form)return;const marker=form.dataset.draftRestored;delete form.dataset.draftRestored;saveDraft(form);if(marker)form.dataset.draftRestored=marker}
document.addEventListener('input',record)
document.addEventListener('change',record)
on('draftSaved',form=>{if(!form)return;const key=keyFor(form);drafts.delete(key);try{sessionStorage.removeItem(key)}catch{}})
on('auth',()=>{drafts.clear();try{const actor=S.user?.id||'guest';if(sessionStorage.getItem('lit-draft-account')!==actor){for(const key of Object.keys(sessionStorage))if(key.startsWith(prefix))sessionStorage.removeItem(key)}sessionStorage.setItem('lit-draft-account',actor)}catch{}})
const observer=new MutationObserver(()=>{
 document.querySelectorAll('form[data-submit]').forEach(restoreDraft)
 // Only DOM additions need busy-state refresh; attribute updates aren't observed.
 if(S.goSaving)updateGoButtons()
})
observer.observe(document.body,{childList:true,subtree:true})

function viewport(){
 const v=window.visualViewport
 document.documentElement.style.setProperty('--lit-visible-height',`${v?.height||innerHeight}px`)
 document.documentElement.style.setProperty('--lit-visible-top',`${v?.offsetTop||0}px`)
}
window.visualViewport?.addEventListener('resize',viewport)
window.visualViewport?.addEventListener('scroll',viewport)
window.addEventListener('resize',viewport)
viewport()

async function launchChecklist(){
 const user=S.user?.id
 const access=await rpc('lit_safety_access')
 if(!access.is_owner)throw new Error('Only the LIT owner can open the launch checklist.')
 const rows=[]
 const probe=async(label,name,args={},describe=()=> 'Connected')=>{
  try{const value=await rpc(name,args);rows.push({label,ok:name!=='lit_operator_status'||value.worker_online,text:describe(value)})}
  catch(error){rows.push({label,ok:false,text:error.message})}
 }
 await probe('GO destinations','lit_my_go')
 await probe('Venue feed & migration chain','lit_nearby_feed',{p_places:[]})
 await probe('Crew','lit_my_crews')
 await probe('Business verification','lit_review_access')
 await probe('Video processing & account deletion','lit_operator_status',{},v=>v.worker_online?'Worker online': 'Worker offline — start the included worker before enabling uploads or deletion')
 const links=window.LIT_CONFIG?.links||{}
 const missing=['terms','privacy','support'].filter(key=>!safeWebUrl(links[key]))
 rows.push({label:'Support & policy links',ok:!missing.length,text:missing.length ? `Still needed: ${missing.join(', ')}. Add your published URLs in public/lit-config.js.` : 'URLs configured — confirm the pages are published and accurate'})
 if(user!==S.user?.id)return
 openSheet('Owner launch checklist',`<div class="stack"><p class="small muted">Checked now against your backend. These checks do not replace a real recording or deletion test.</p>${rows.map(r=>`<div class="card stack-sm"><strong>${esc(r.label)}</strong><p class="small ${r.ok?'muted':'err'}">${esc(r.text)}</p></div>`).join('')}<div class="card stack-sm"><strong>Before inviting the public</strong><p class="small muted">Test on a real phone, confirm support and policy links, and configure backups and monitoring. Payments, a verified live score and full business analytics are not connected.</p></div><button class="btn alt" data-action="launchChecklist">Check again</button></div>`)
}
actionsFor({launchChecklist})

on('rpcSaved',({name,args})=>{
 const submit={lit_save_business_profile:'bizProfile',lit_save_promotion:'promoSave',lit_create_crew:'createCrew',lit_create_outing:'createOuting'}[name]
 if(!submit)return
 document.querySelectorAll(`form[data-submit="${submit}"]`).forEach(form=>emit('draftSaved',form))
})

on('clearDrafts',()=>drafts.clear())
