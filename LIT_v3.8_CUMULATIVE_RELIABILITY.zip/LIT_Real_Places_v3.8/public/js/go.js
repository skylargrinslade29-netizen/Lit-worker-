import { activityMarkup } from './activity.js'
// GO → ARRIVE → VERIFY
import { S, $, esc, icon, on, emit, actionsFor, toast, fmtMiles, litBadge, ago, savePrefs, getPosition, distKm, miles } from './core.js'
import { rpc } from './api.js'
import { venue, ensurePlaceId } from './places.js'

export function isGoing(pid) {
  return !!S.user && S.go?.pid === pid && (!S.go.expires_at || Date.parse(S.go.expires_at) > Date.now())
}

let goVersion = 0
let goOperation = null
export async function loadGo() {
  if (goOperation) return
  const version = ++goVersion, user = S.user?.id
  if (!user) { S.go = null; S.localGo = null; savePrefs(); S.goError = null; emit('go'); return }
  const current = () => version === goVersion && user === S.user?.id
  try {
    let go = await rpc('lit_my_go')
    if (!current()) return
    const changed=JSON.stringify(S.go)!==JSON.stringify(go) || !!S.goError
    S.go = go; S.goError = null
    if (!changed) return
    if (go) { S.localGo = null; savePrefs() }
  } catch (error) { if (!current()) return; S.goError = error.message }
  if (current()) emit('go')
}

export async function toggleGo(pid, candidate = null) {
  if (!S.user) {
    const { requireAuth } = await import('./account.js')
    const intended = venue(pid) || candidate
    if (!requireAuth('Sign in to save your GO destination.', async () => {
      const user = S.user?.id
      const { openSharedVenue } = await import('./venue.js')
      await openSharedVenue(pid,{lat:intended?.lat,lon:intended?.lon})
      if(user===S.user?.id) await toggleGo(pid,intended)
    })) return
  }
  const v = venue(pid) || (S.go?.pid === pid ? S.go : null) || (S.localGo?.pid === pid ? S.localGo : null) || candidate
  if (!v) return toast('Choose a real venue first')
  const going = !isGoing(pid)
  if (goOperation) return toast('Saving your GO…')
  const token = goOperation = Symbol(), user = S.user.id
  S.goSaving = true; emit('goSaving')
  ++goVersion
  try {
    const id = going ? await ensurePlaceId(pid, v) : S.go?.place_id || S.places[pid]?.place_id || v.place_id
    if (user !== S.user?.id || token !== goOperation) return
    if (!id) throw new Error('Venue could not be saved')
    const go = await rpc('lit_set_go', { p_place: id, p_going: going })
    if (user !== S.user?.id || token !== goOperation) return
    S.go = go; S.goError = null; S.goSaving = false; emit('go');
    goOperation = null
    toast(going ? `Going to ${v.name}` : 'GO cancelled')
    const { loadFeed } = await import('./places.js')
    if (user === S.user?.id) await loadFeed()

  } catch (error) { if (user === S.user?.id) { S.goError = error.message; emit('go'); toast(error.message) } }
  finally { if (goOperation === token) { goOperation = null; S.goSaving = false; emit('goSaving') } }
}

function dest() {
  if (S.user && S.go && isGoing(S.go.pid)) return { ...S.go, local: false }
  return null
}

let feedbackDraft = { accuracy: null, vibe: null }

export function renderGo() {
  const el = $('go')
  const d = dest()
  if (!d) {
    el.innerHTML = `<div class="eyebrow">GO</div><h1 class="title">Make your move.</h1>
      <p class="lede">Pick a real place from WATCH or PICK and tap GO. LIT keeps your destination, directions and Crew plan in one place.</p>
      <div class="steps" aria-hidden="true"><div class="step now"><i></i>GO</div><div class="step"><i></i>ARRIVE</div><div class="step"><i></i>FEEDBACK</div></div>
      ${S.goError ? `<p class="small muted" role="status">${esc(S.goError)}</p><button class="btn sm alt" data-action="goRetry">Retry loading GO</button>` : ''}<div class="empty-card">${icon('go', 'i-lg')}<div>${S.goError ? 'Your destination could not be loaded.' : 'No destination yet.'}</div><div class="btn-row" style="width:100%"><button class="btn" data-action="nav" data-to="pick">Pick a place</button><button class="btn alt" data-action="nav" data-to="watch">Watch what’s live</button></div></div>`
    return
  }
  const v = S.byPid[d.pid]
  const mi = S.coords ? miles(distKm(S.coords.lat, S.coords.lon, d.lat, d.lon)) : null
  const place = S.places[d.pid]
  const arrived = !!d.arrival
  const done = d.arrival?.feedback_done
  const stage = done ? 3 : arrived ? 2 : 1
  const cls = (n) => (n < stage ? 'done' : n === stage ? 'now' : '')
  el.innerHTML = `<div class="eyebrow">GO</div><h1 class="title">You’re going out.</h1>
    <div class="steps"><div class="step ${cls(1)}"><i></i>GO</div><div class="step ${cls(2)}"><i></i>ARRIVE</div><div class="step ${cls(3)}"><i></i>FEEDBACK</div></div>
    <div class="card glow dest stack">
      <div class="row between"><span class="tag hot">${icon('check', 'i-sm')} Going</span>${litBadge(place?.score)}</div>
      <div><h2>${esc(d.name)}</h2><div class="small muted">${esc(d.category || '')}${mi != null ? ` · ${fmtMiles(mi)} away` : ''}${d.since ? ` · GO since ${ago(d.since)}` : ''}</div>
      ${d.expires_at ? `<div class="tiny faint" style="margin-top:6px">GO expires ${esc(new Date(d.expires_at).toLocaleString([], { hour:'numeric',minute:'2-digit' }))} · intent, not attendance</div>` : ''}</div>
      ${activityMarkup(place, { pid: d.pid })}
      <button class="btn block" data-action="directions" data-pid="${esc(d.pid)}">${icon('route')} Directions</button>
      <div class="btn-row">
        <button class="btn alt" data-action="invite" data-pid="${esc(d.pid)}">${icon('crew')} Invite Crew</button>
        <button class="btn alt" data-action="share" data-pid="${esc(d.pid)}">${icon('share')} Share</button>
        ${v ? `<button class="btn alt" data-action="venue" data-pid="${esc(d.pid)}">${icon('store')} Venue</button>` : ''}
      </div>
      <button class="btn ghost block" data-action="go" data-pid="${esc(d.pid)}">Cancel GO</button>
    </div>
    ${arrivePanel(d, arrived, done)}`
}

function arrivePanel(d, arrived, done) {
  if (d.local) return `<h2 class="sec">Arrive</h2><div class="card stack-sm"><p class="small muted" style="margin:0">Sign in to confirm arrival and help keep LIT accurate.</p><button class="btn alt" data-action="account">Log in or sign up</button></div>`
  if (done)
    return `<h2 class="sec">Feedback received</h2><div class="card stack-sm"><strong>Thanks — your feedback makes LIT more accurate.</strong>
      <p class="small muted" style="margin:0">Show everyone what it’s like right now with a fresh clip.</p>
      <button class="btn" data-action="post" data-pid="${esc(d.pid)}">${icon('camera')} Post a fresh clip</button></div>`
  if (!arrived)
    return `<h2 class="sec">Arrive</h2><div class="card stack-sm"><strong>Here already?</strong>
      <p class="small muted" style="margin:0">Optional. LIT uses a fresh GPS check against the venue. Your position is not shown to your Crew. LIT stores the check distance and accuracy, not your GPS coordinates. This device check does not prove attendance.</p>
      <button class="btn" data-action="arrive" data-place="${esc(d.place_id)}">${icon('pin')} I’m here</button></div>`
  const acc = [
    ['accurate', 'LIT was accurate'],
    ['busier', 'Busier than LIT showed'],
    ['quieter', 'Quieter than LIT showed'],
    ['inaccurate', 'Not accurate at all'],
    ['not_shown', 'No activity information to compare'],
  ]
  return `<h2 class="sec">Feedback</h2><form class="card stack" data-submit="feedback" data-arrival="${esc(d.arrival.id)}">
    <div><strong>How did LIT compare to reality?</strong><div class="tiny faint">One response per visit. Businesses see grouped results after at least 3 guests respond. Your account identity is not included.</div></div>
    <div class="choice-grid">${acc.map(([k, l]) => `<button type="button" class="choice ${feedbackDraft.accuracy === k ? 'on' : ''}" data-action="fbAccuracy" data-v="${k}">${l}</button>`).join('')}</div>
    <div><div class="small muted" style="margin-bottom:6px">Vibe right now</div><div class="vibe">${[1, 2, 3, 4, 5].map((n) => `<button type="button" class="${feedbackDraft.vibe === n ? 'on' : ''}" data-action="fbVibe" data-v="${n}" aria-label="Vibe ${n} of 5">${n}</button>`).join('')}</div></div>
    <label class="field">Anything else? (optional)<textarea name="note" maxlength="280" placeholder="Line out the door, live band started at 10…"></textarea></label>
    <label class="check"><input type="checkbox" name="shareNote"> Share my note with the venue when grouped feedback is available. Avoid names and personal details.</label>
    <button class="btn block" type="submit">Send feedback</button><p class="form-msg" role="status"></p></form>`
}

actionsFor({
  goRetry: () => loadGo(),
  go: (d) => toggleGo(d.pid),
  arrive: async (d, btn) => {
    btn.disabled = true
    btn.textContent = 'Checking location…'
    try {
      const p = await getPosition({ fresh: true })
      await rpc('lit_confirm_arrival', { p_place: d.place, p_lat: p.lat, p_lon: p.lon, p_accuracy: p.accuracy })
      await loadGo()
      toast('Location check completed')
    } catch (e) {
      toast(e.message)
      btn.disabled = false
      btn.innerHTML = `${icon('pin')} I’m here`
    }
  },
  fbAccuracy: (d, btn) => {
    feedbackDraft.accuracy = d.v
    btn.parentElement.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === btn))
  },
  fbVibe: (d, btn) => {
    feedbackDraft.vibe = Number(d.v)
    btn.parentElement.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === btn))
  },
  feedback: async (d, form) => {
    const msg = form.querySelector('.form-msg')
    if (!feedbackDraft.accuracy) {
      msg.textContent = 'Choose how accurate LIT was.'
      msg.classList.add('err')
      return
    }
    const button=form.querySelector('button[type=submit]');button.disabled=true
    try {
      await rpc('lit_submit_feedback', { p_arrival: d.arrival, p_accuracy: feedbackDraft.accuracy, p_vibe: feedbackDraft.vibe, p_note: form.note.value, p_share_note: form.shareNote.checked })
      emit('draftSaved',form)
      feedbackDraft = { accuracy: null, vibe: null }
      await loadGo()
      toast('Feedback sent — thank you')
    } catch (e) {
      msg.textContent = e.message
      msg.classList.add('err')
      button.disabled=false
    }
  },
})

on('auth', () => { goOperation = null;S.goSaving = false;emit('goSaving');feedbackDraft={accuracy:null,vibe:null}; loadGo() })
let draftDestination=null
on('go',()=>{const destination=S.go?.arrival?.id || (S.go ? `${S.go.pid}:${S.go.since}` : null);if(destination!==draftDestination){draftDestination=destination;feedbackDraft={accuracy:null,vibe:null}}})

on('go', () => S.screen === 'go' && renderGo())
