// Retry only the same session-owned object upload, never the publish transaction.
export async function uploadRecording(bucket, path, blob, options, current = () => true) {
  for (let attempt = 0; attempt < 2; attempt++) {
    if (!current()) throw new Error('Recording closed. Upload cancelled.')
    let result
    try { result = await bucket.upload(path, blob, options) } catch { result = { error: { message: 'Upload connection failed', status: 503 } } }
    if (!current()) throw new Error('Recording closed. Upload cancelled.')
    if (!result?.error) return result
    const error = result.error, status = Number(error.statusCode || error.status)
    const transient = status === 408 || status === 429 || status >= 500 && status <= 599 || /network|fetch failed|connection|timed? out/i.test(error.message || '')
    if (!transient || attempt === 1) return result
    await new Promise(resolve => setTimeout(resolve, 400))
  }
}
