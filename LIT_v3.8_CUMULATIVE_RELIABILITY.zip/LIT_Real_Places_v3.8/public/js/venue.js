import { isSaved } from './saved.js'
import { activityMarkup } from './activity.js'
import { hidePost } from './safety.js'
// Venue details sheet + shared venue actions (directions, share, report).
import { S, esc, icon, actionsFor, openSheet, closeSheet, toast, ago, fmtMiles, litBadge, fmtWhen, fmtTime, directionsUrl, emit, on, safeWebUrl } from './core.js'
import { rpc, track, signedUrls } from './api.js'
import { venue, ensurePlaceId, resolveSharedVenue } from './places.js'
import { isGoing } from './go.js'
import { requireAuth } from './account.js'

const COMPONENTS = [
  ['video', 'Fresh video', 'Independent people posting live clips here in the last 3 hours'],
  ['engagement', 'Engagement', 'Unique people watching 3s+ or sharing those clips'],
  ['intent', 'GO + Crew intent', 'People who tapped GO or said “I’m in” to a Crew plan (intent, not attendance)'],
  ['arrival', 'Directions + arrivals', 'Unique directions requests and device location checks, which do not prove attendance'],
  ['momentum', 'Momentum', 'Whether activity in the last hour is rising or falling'],
]

export function scoreExplainer(score, { detailed = false } = {}) {
  if (!score) return `<p class="small muted">No verified live score is available for this venue yet.</p>`
  const none = score.score == null || !Number.isFinite(Number(score.score))
  const bars = COMPONENTS.map(([k, label, help]) => {
    const c = score.components?.[k] || {}
    const known = c.weight != null && c.points != null && Number.isFinite(Number(c.weight)) && Number.isFinite(Number(c.points))
    const weight = Number.isFinite(Number(c.weight)) ? Math.max(0, Number(c.weight)) : 0
    const points = Number.isFinite(Number(c.points)) ? Math.max(0, Number(c.points)) : 0
    const pct = weight ? Math.min(100, points / weight * 100) : 0
    return `<div class="bar" title="${esc(help)}"><span>${label} <span class="faint">${known ? weight + '%' : '—'}</span></span><span class="track"><i style="width:${pct.toFixed(1)}%"></i></span><span class="pts">${known ? points.toFixed(1) : '—'}</span></div>
      ${detailed ? `<div class="tiny faint" style="margin:-4px 0 4px">${esc(help)}</div>` : ''}`
  }).join('')
  const conf = { high: 'High confidence', medium: 'Medium confidence', low: 'Low confidence', none: 'No confidence' }[score.confidence] || ''
  const trend = { rising: '↑ Rising', falling: '↓ Falling', steady: '→ Steady', flat: 'No recent change' }[score.trend] || ''
  return `<div class="score-hero">
      <div class="score-num ${none ? 'none' : ''}">${none ? 'NO FRESH<br>PROOF' : Math.min(100, Math.max(0, Number(score.score)))}</div>
      <div class="stack-sm"><div>${litBadge(score)}</div>
        <div class="small muted">${none ? 'Not enough recent independent evidence to score this venue. LIT never estimates activity.' : `${conf} · ${trend}`}</div>
        <div class="tiny faint">${score.last_post_at ? `Last fresh video ${ago(score.last_post_at)}` : 'Recent video timing unavailable'} · ${score.fresh_videos_24h != null && Number.isFinite(Number(score.fresh_videos_24h)) ? Math.max(0, Math.floor(Number(score.fresh_videos_24h))) : '—'} in 24h</div>
      </div></div>
    <div class="bars">${bars}</div>
    ${score.capped_at ? `<p class="tiny faint" style="margin:10px 0 0">Capped at ${esc(score.capped_at)}: higher statuses need more independent people posting.</p>` : ''}`
}

export async function openVenue(pid, { promo } = {}) {
  const v = venue(pid)
  if (!v) return toast('This venue is no longer in your area')
  const place = S.places[pid]
  const posts = S.posts.filter((p) => p.pid === pid)
  await signedUrls(posts.map((p) => p.video_path))
  const going = isGoing(pid)
  const promos = place?.promos || []
  const body = openSheet(
    v.name,
    `<div class="stack">
      <div class="small muted">${esc(v.category)}${v.cuisine ? ' · ' + esc(v.cuisine) : ''} · ${fmtMiles(v.mi)} away${place?.claimed ? ' · <span class="tag ok">Verified venue</span>' : ''}</div>
      <div class="btn-row">
        <button class="btn alt" data-action="saveVenue" data-pid="${esc(pid)}" aria-pressed="${isSaved(pid)}">${isSaved(pid) ? 'Saved ✓' : 'Save place'}</button>
        <button class="btn" data-action="go" data-pid="${esc(pid)}" aria-pressed="${going}">${icon(going ? 'check' : 'go')} ${going ? 'Going' : 'GO'}</button>
        <button class="btn alt" data-action="invite" data-pid="${esc(pid)}">${icon('crew')} Invite Crew</button>
        <button class="btn alt" data-action="directions" data-pid="${esc(pid)}">${icon('route')} Directions</button>
        <button class="btn alt" data-action="share" data-pid="${esc(pid)}">${icon('share')} Share</button>
      </div>
      <div class="card">${activityMarkup(place, { pid })}</div>
      <div class="card">${scoreExplainer(place?.score)}</div>
      ${promos.length ? `<div class="stack-sm"><h3>From the venue</h3>${promos.map((p) => `<div class="promo-card" data-promo-view="${esc(p.id)}"><div class="tiny">${esc(p.kind)}${p.starts_at && new Date(p.starts_at) > new Date() ? ' · ' + fmtWhen(p.starts_at) : ''}</div><strong>${esc(p.title)}</strong>${p.details ? `<div class="small muted">${esc(p.details)}</div>` : ''}<div class="tiny faint" style="margin-top:4px">Posted by the venue · does not affect the LIT Score</div></div>`).join('')}</div>` : ''}
      <div class="stack-sm"><div class="row between"><h3>Live clips</h3><span class="tiny faint">Last 24 hours</span></div>
        ${S.feedError ? `<div class="card stack-sm" role="status"><p class="small muted">Fresh videos and counts could not refresh. Your GO destination is saved separately.</p><button class="btn alt" data-action="retryVenueFeed" data-pid="${esc(pid)}">Retry venue data</button></div>` : ''}
        ${posts.length ? `<div class="clips">${posts.map((p) => `<button class="clip" data-action="watchPost" data-post="${esc(p.id)}" aria-label="Watch clip from ${ago(p.created_at)}">${S.urls[p.video_path] ? `<video muted playsinline preload="metadata" src="${esc(S.urls[p.video_path])}#t=0.5"></video>` : ''}<span>${ago(p.created_at)}</span></button>`).join('')}</div>` : `<div class="empty-card">${icon('camera', 'i-lg')}<div>No fresh clips here in the last 24 hours.</div></div>`}
        <button class="btn ghost block" data-action="post" data-pid="${esc(pid)}">${icon('camera')} Post a fresh clip here</button>
      </div>
      <div class="card stack-sm" id="venueAbout"><h3>About</h3><dl class="kv">
        ${v.address ? `<dt>Address</dt><dd>${esc(v.address)} <button class="link" data-action="copyVenueAddress" data-pid="${esc(pid)}">Copy address</button></dd>` : ''}
        ${v.hours ? `<dt>Hours</dt><dd>${esc(v.hours)} <span class="faint tiny">(OpenStreetMap)</span></dd>` : ''}
        ${safeWebUrl(v.website) ? `<dt>Website</dt><dd><a href="${esc(safeWebUrl(v.website))}" target="_blank" rel="noopener noreferrer">${esc(v.website.replace(/^https?:\/\//, ''))}</a></dd>` : ''}
        <dt>Source</dt><dd>OpenStreetMap contributors</dd></dl></div>
      <button class="link" data-action="claimVenue" data-pid="${esc(pid)}">Own or manage this venue? Claim it</button>
    </div>`,
    { eyebrow: 'Venue' },
  )
  if (place?.place_id) {
    track(place.place_id, 'venue_open')
    for (const p of promos) track(place.place_id, 'promo_view', { promo: p.id })
    if (promo) track(place.place_id, 'promo_tap', { promo })
    rpc('lit_place_details', { p_place: place.place_id })
      .then((d) => {
        const prof = d?.profile
        if (!prof || !body.isConnected) return
        const about = body.querySelector('#venueAbout .kv')
        about.insertAdjacentHTML(
          'afterbegin',
          `${prof.description ? `<dt>From venue</dt><dd>${esc(prof.description)}</dd>` : ''}${prof.hours ? `<dt>Venue hours</dt><dd>${esc(prof.hours)}</dd>` : ''}${prof.phone ? `<dt>Phone</dt><dd><a href="tel:${esc(prof.phone)}">${esc(prof.phone)}</a></dd>` : ''}${safeWebUrl(prof.website) ? `<dt>Venue site</dt><dd><a href="${esc(safeWebUrl(prof.website))}" target="_blank" rel="noopener noreferrer">${esc(prof.website.replace(/^https?:\/\//, ''))}</a></dd>` : ''}`,
        )
      })
      .catch(() => {})
  }
}

export async function directions(pid) {
  const v = venue(pid) || (S.go?.pid === pid ? S.go : null) || (S.localGo?.pid === pid ? S.localGo : null)
  if (!v) return toast('Select a real venue first')
  window.open(directionsUrl(v), '_blank', 'noopener,noreferrer')
  const id = S.places[pid]?.place_id || (S.go?.pid === pid ? S.go.place_id : null)
  if (id) track(id, 'directions')
}

export async function share(pid, postId) {
  const v = venue(pid) || (S.go?.pid === pid ? S.go : null) || (S.localGo?.pid === pid ? S.localGo : null)
  if (!v) return
  const params = new URLSearchParams({ venue: pid })
  if (Number.isFinite(v.lat) && Number.isFinite(v.lon)) {
    params.set('vlat',v.lat.toFixed(5)); params.set('vlon',v.lon.toFixed(5))
  }
  const url = `${location.origin}/?${params}`
  const text = `${v.name} on LIT — see what's happening right now`
  try {
    if (navigator.share) await navigator.share({ title: v.name, text, url })
    else if (navigator.clipboard) {
      await navigator.clipboard.writeText(url)
      toast('Link copied')
    } else openSheet('Share venue', `<input class="input" value="${esc(url)}" readonly onclick="this.select()">`)
    const id = S.places[pid]?.place_id
    if (id) track(id, 'share', { post: postId || null })
  } catch (e) {
    if (e.name !== 'AbortError') toast('Sharing is unavailable')
  }
}

export async function openSharedVenue(pid, hints = {}) {
  const account = S.authVersion
  try {
    const v = await resolveSharedVenue(pid,hints)
    if (account !== S.authVersion) return
    {
      try {
        const data = await rpc('lit_nearby_feed',{p_places:[{id:v.id}]})
        if (data.places?.[0]) S.places[pid] = data.places[0]
        S.posts = [...S.posts.filter(p => p.pid !== pid),...(data.posts || [])]
      } catch { /* The real venue remains usable if video is temporarily unavailable. */ }
    }
    if (account !== S.authVersion) return
    await openVenue(pid)
  } catch(error) {
    if (account !== S.authVersion) return
    openSheet('Venue link',`<div class="stack"><p role="status">${esc(error.message)}</p><button class="btn" data-action="retryVenueLink" data-pid="${esc(pid)}" data-lat="${esc(hints.lat ?? '')}" data-lon="${esc(hints.lon ?? '')}">Try again</button><button class="btn alt" data-action="location">Browse nearby places</button></div>`)
  }
}

function postMenu(postId) {
  const post = S.posts.find((p) => p.id === postId)
  if (!post) return
  openSheet(
    'Video options',
    `<div class="stack">
      <p class="small muted" style="margin:0">Recorded live at ${esc(venue(post.pid)?.name || 'this venue')} · ${ago(post.created_at)} (server time). Live until ${fmtTime(post.expires_at)}.</p>
      <button class="btn alt block" data-action="venue" data-pid="${esc(post.pid)}">${icon('store')} Venue details</button>
      ${post.mine ? `<button class="btn danger block" data-action="deletePost" data-post="${esc(post.id)}">${icon('trash')} Remove my video</button>` : ''}
      <button class="btn alt block" data-action="hidePost" data-post="${esc(post.id)}">Hide this video on this device</button>
      ${window.LIT_CONFIG?.features?.accountBlocking && !post.mine ? `<button class="btn alt block" data-action="blockAuthor" data-post="${esc(post.id)}">Block this creator</button>` : ''}
      <button class="btn ghost block" data-action="report" data-post="${esc(post.id)}">${icon('flag')} Report this video</button>
      <p class="tiny faint" style="margin:0">${icon('shield', 'i-sm')} Venues can’t remove or hide community videos. Use Report to submit safety or content concerns to LIT.</p>
    </div>`,
  )
}

const REASONS = [
  ['not_fresh', 'Not recorded live / old footage'],
  ['wrong_venue', 'Wrong venue'],
  ['inappropriate', 'Inappropriate content'],
  ['spam', 'Spam or promotion'],
  ['safety', 'Safety or privacy concern'],
  ['other', 'Something else'],
]
function reportSheet(postId) {
  if (!requireAuth('Sign in to report a video')) return
  openSheet(
    'Report video',
    `<form class="stack" data-submit="submitReport" data-post="${esc(postId)}">
      <div class="stack-sm" role="radiogroup">${REASONS.map(([k, l], i) => `<label class="check"><input type="radio" name="reason" value="${k}" ${i === 0 ? 'checked' : ''}> ${l}</label>`).join('')}</div>
      <label class="field">Details (optional)<textarea name="details" maxlength="500" placeholder="What should moderators know?"></textarea></label>
      <button class="btn block" type="submit">Send report</button><p class="form-msg" role="status"></p></form>`,
  )
}

actionsFor({
  retryVenueFeed: async d => { const { loadFeed } = await import('./places.js'); await loadFeed(); await openVenue(d.pid) },
  copyVenueAddress: async d => {
    const v=venue(d.pid)
    if(!v?.address)return
    try {if(!navigator.clipboard)throw new Error();await navigator.clipboard.writeText(v.address);toast('Address copied')}
    catch {openSheet('Venue address',`<label class="field">Copy this address<input class="input" readonly value="${esc(v.address)}" onclick="this.select()"></label>`)}
  },
  retryVenueLink: d => openSharedVenue(d.pid, { lat: d.lat !== '' ? Number(d.lat) : null, lon: d.lon !== '' ? Number(d.lon) : null }),
  hidePost: (d) => { if (hidePost(d.post)) { closeSheet(); toast("Video hidden on this device. No report was sent.") } },
  venue: (d) => openVenue(d.pid, { promo: d.promo }),
  directions: (d) => directions(d.pid),
  share: (d) => share(d.pid, d.post),
  postMenu: (d) => postMenu(d.post),
  report: (d) => reportSheet(d.post),
  watchPost: async (d) => {
    closeSheet()
    emit('navigate', 'watch')
    const { scrollToPost } = await import('./watch.js')
    setTimeout(() => scrollToPost(d.post), 50)
  },
  deletePost: async (d) => {
    if (!confirm('Remove your video from LIT? This cannot be undone.')) return
    try {
      await rpc('lit_delete_my_post', { p_post: d.post })
      S.posts = S.posts.filter((p) => p.id !== d.post)
      closeSheet()
      emit('feed')
      toast('Your video was removed')
    } catch (e) {
      toast(e.message)
    }
  },
  submitReport: async (d, form) => {
    const msg = form.querySelector('.form-msg')
    const btn = form.querySelector('button[type=submit]')
    btn.disabled = true
    try {
      await rpc('lit_report_post', { p_post: d.post, p_reason: form.reason.value, p_details: form.details.value })
      closeSheet()
      toast('Report submitted — thank you')
    } catch (e) {
      msg.textContent = e.message
      msg.classList.add('err')
      btn.disabled = false
    }
  },
  claimVenue: (d) => {
    closeSheet()
    emit('claim', d.pid)
  },
})

export { ensurePlaceId }

// Update the open venue sheet without replacing its content or scroll position.
on('go', () => {
  document.querySelectorAll('#sheetBody [data-action="go"][data-pid]').forEach(button => {
    const going = isGoing(button.dataset.pid)
    button.setAttribute('aria-pressed', String(going))
    button.innerHTML = `${icon(going ? 'check' : 'go')} ${going ? 'Going' : 'GO'}`
  })
})
