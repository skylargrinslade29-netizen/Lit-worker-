import './reliability.js'
import './deletion.js'
import './moderation.js'
import { updateConnectionNotice } from './connectivity.js'
// App entry: navigation, screen rendering and boot.
import { S, $, on, actionsFor, closeSheet } from './core.js'
import { initSupabase } from './api.js'
import { restoreCache, locate, loadPlaces, loadFeed, updateLocationLabel, pruneExpiredPosts, refreshActivity } from './places.js'
import { renderWatch, pauseWatch, resumeWatch } from './watch.js'
import { renderPick } from './pick.js'
import { renderCrew, handleJoinLink, refreshCrewsQuietly } from './crew.js'
import { renderGo, loadGo } from './go.js'
import { renderBusiness, refreshBusinessQuietly } from './business.js'
import { renderVerification, refreshReviewAccess } from './verification.js'
import { maybeWelcome } from './account.js'
import { openSharedVenue } from './venue.js'
import './capture.js'

const RENDER = { watch: renderWatch, pick: renderPick, crew: renderCrew, go: renderGo, business: renderBusiness, verification: renderVerification }

function show(id) {
  closeSheet()
  if (!RENDER[id]) id = 'watch'
  if (S.screen === 'watch' && id !== 'watch') pauseWatch()
  S.screen = id
  document.body.classList.toggle('on-watch', id === 'watch')
  document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('active', s.id === id))
  document.querySelectorAll('#tabbar button').forEach((b) => {
    const on = b.dataset.to === id
    b.classList.toggle('active', on)
    on ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current')
  })
  if (id !== 'watch') window.scrollTo(0, 0)
  RENDER[id]()
  if (id === 'watch') resumeWatch()
}

actionsFor({
  nav: (d) => show(d.to),
  location: () => {
    show('pick')
    setTimeout(() => document.querySelector('#pick input[name=location]')?.focus(), 50)
  },
  search: () => {
    show('pick')
    setTimeout(() => document.querySelector('#pick input[name=venue]')?.focus(), 50)
  },
})

on('navigate', show)
on('feed', () => {
  updateLocationLabel()
  if (S.screen === 'watch') renderWatch()
})
on('places', updateLocationLabel)
on('backend', () => S.screen !== 'watch' && RENDER[S.screen]())
on('auth', () => {
  if (S.coords) loadFeed()
  if (S.screen !== 'watch') RENDER[S.screen]()
})

async function boot() {
  const cached = restoreCache()
  updateLocationLabel()
  updateConnectionNotice()
  show('watch')
  const authReady = initSupabase().catch(() => { S.backend = 'offline' })
  if (cached) loadPlaces({ keepArea: true })
  else if (navigator.permissions) {
    try {
      const st = await navigator.permissions.query({ name: 'geolocation' })
      if (st.state === 'granted') locate({ silent: true })
    } catch {}
  }
  await authReady
  handleJoinLink()
  const linkParams = new URLSearchParams(location.search)
  const venueParam = linkParams.get('venue')
  if (venueParam) {
    history.replaceState(null, '', location.pathname)
    const hints = { lat: linkParams.get('vlat')?.trim() ? Number(linkParams.get('vlat')) : null, lon: linkParams.get('vlon')?.trim() ? Number(linkParams.get('vlon')) : null }
    await openSharedVenue(venueParam,hints)
  }
  maybeWelcome()
  $('main')?.removeAttribute('aria-busy')
}

setInterval(pruneExpiredPosts, 60000)
function refreshVisibleData() {
  if (document.hidden) return
  pruneExpiredPosts()
  Promise.allSettled([refreshActivity(),refreshCrewsQuietly(),refreshBusinessQuietly(),refreshReviewAccess(),S.user ? loadGo() : Promise.resolve()])
}
setInterval(refreshVisibleData,45000)
document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshVisibleData() })
boot()
