// Local hiding is a device preference; it does not submit a report or remove content globally.
import { S, emit } from './core.js'
const KEY = 'lit-hidden-posts'
let hidden = new Set()
try { const value = JSON.parse(localStorage.getItem(KEY) || '[]'); if (Array.isArray(value)) hidden = new Set(value.filter((x) => typeof x === 'string').slice(-500)) } catch {}
export const visiblePosts = (posts) => posts.filter((p) => !hidden.has(p.id))
export function hidePost(id) {
  if (typeof id !== 'string' || !S.posts.some((p) => p.id === id)) return false
  hidden.delete(id); hidden.add(id)
  if (hidden.size > 500) hidden.delete(hidden.values().next().value)
  try { localStorage.setItem(KEY, JSON.stringify([...hidden])) } catch {}
  S.posts = visiblePosts(S.posts); emit('feed'); emit('places'); return true
}
export function clearHiddenPosts() { hidden.clear(); try { localStorage.removeItem(KEY) } catch {} }
