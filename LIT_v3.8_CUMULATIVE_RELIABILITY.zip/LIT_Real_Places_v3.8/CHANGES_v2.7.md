# v3.2 changes and validation

## Problem and fix
Previously one failed Geoapify category search produced partial results without invoking the backup for that category. This could leave a thin nightclub/bar list even while other categories worked. The function now requests only failed categories from OSM, retains successful managed results, normalizes and deduplicates the combined records, and warns if backup coverage is smaller than the requested radius or recovery fails.

Successful empty categories remain empty, avoiding extra provider load. Normal searches still make four Geoapify calls; only failures add up to two bounded backup attempts. Geoapify and OSM share source data, so this improves failure recovery, not underlying listing coverage. No Google data or unverified venue names are inserted.

## Validation
Run `node scripts/check.mjs`. Added mocked checks for nightclub HTTP 429 recovery, preserved bars, targeted query excluding food, wider-radius warnings, and backup HTTP 503 preserving successful results. Existing server/client/account/media checks pass. No live Netlify, provider credential, database or hardware verification was performed.

## Deploy once
Follow DEPLOY_README.md for the existing glowing-crepe-8a40b0 project. Keep GEOAPIFY_API_KEY in the Production Functions environment. The source package requires functions deployment, not a public-only static upload. Check the places response header X-LIT-Discovery-Version: 3.2 after deployment.
