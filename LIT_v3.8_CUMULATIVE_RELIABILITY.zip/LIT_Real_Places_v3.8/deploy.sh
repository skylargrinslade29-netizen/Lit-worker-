#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
node scripts/check.mjs
printf '%s\n' 'Deploying LIT v3.7 to existing Netlify project glowing-crepe-8a40b0. Run the applicable v3.7 SQL migration first.'
npx --yes netlify-cli@latest login
npx --yes netlify-cli@latest deploy --site glowing-crepe-8a40b0 --context production --prod --dir public --functions netlify/functions --no-build --skip-functions-cache --message 'LIT v3.7 video processing, moderation, blocking and account deletion'
