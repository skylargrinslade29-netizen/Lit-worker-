# LIT v3.7.1

Fixes the open venue button: GO changes to Going after a successful save, and returns to GO after cancellation. The sheet stays open. All v3.7 features are retained.

Deploy this cumulative package through the same Netlify workflow used for v3.7. If the v3.7 migration and missing-v3.6 repair already ran successfully, no further SQL is needed for this button fix. The repair SQL is included for reference. Worker hosting is still required for video processing and account deletion.
