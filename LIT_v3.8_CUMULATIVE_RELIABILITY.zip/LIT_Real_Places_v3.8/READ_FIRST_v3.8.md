# LIT v3.8 cumulative reliability batch

Deploy this entire package using the same Netlify workflow that deployed v3.7. This batch needs no additional SQL if v3.7 and the missing-v3.6 repair already succeeded. The repair file is included for reference; avoid rerunning unrelated setup scripts.

Included: GO saving state across screens, duplicate-tap protection, live venue GO/Going/cancel label, return to the intended venue after sign-in, clearer business claim states and next steps, venue-data retry, connection recovery, selected form drafts, mobile keyboard viewport sizing and an owner-only launch checklist in Settings.

Drafts cover claim requests, business profiles, promotions, feedback text/consent and Crew/plan forms. They stay in the current tab's session storage for up to 24 hours. Passwords, tokens, file uploads and hidden fields are excluded. Successful supported submissions clear their drafts; switching accounts or clearing device data removes them. A draft does not mean a server submission succeeded. Closing the tab ends session-storage persistence. Feedback choice buttons still use their existing in-memory draft behavior.

The owner checklist makes read-only RPC checks. A successful check means the endpoint answered, not that every production workflow was verified. Worker offline remains a setup requirement. Policy/support links, physical-device testing, backups and monitoring still need operator attention. This package does not host the worker or add payments, a verified live score or full analytics.

After deploying once, refresh the app and test GO, cancel, sign-in continuation, a claim draft, Settings -> Owner launch checklist, and a form with the phone keyboard open.
