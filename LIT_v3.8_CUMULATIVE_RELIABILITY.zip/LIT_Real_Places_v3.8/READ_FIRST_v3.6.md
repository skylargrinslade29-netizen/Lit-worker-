# LIT v3.6 — arrivals, private feedback and venue promotions

All v3.5 files and features are retained: owner-controlled verification and delegated reviewers, business profiles, authenticated GO, private Crews, planning, saved places and shared links.

## Install once

If you ran the complete v3.5 SQL, run **SUPABASE_v3.6_ARRIVAL_PROMOTIONS.sql** in your existing Supabase SQL Editor. Then deploy this entire app folder to your existing Netlify project once, including its Functions. This deploy activates the server variables you recently saved. No additional API keys are needed.

If the v3.5 backend was never installed, run **SUPABASE_COMPLETE_v3.6.sql** instead. Only run SUPABASE_OWNER_SETUP.sql if the platform owner has not been configured; it still uses Nickmccrae11@gmail.com and refuses to replace a different owner. The owner must have a confirmed LIT account.

Do not reinstall an older migration by itself afterward: that would restore older dashboard/feed definitions. The complete v3.6 script runs the migrations in order and preserves existing records on rerun. Keep deployment files and production database definitions at the same release.

Netlify still needs SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY (the legacy service_role JWT, kept server-side), and GEOAPIFY_API_KEY available to Production Functions. The service-role key must never be placed in public/lit-config.js or shared in screenshots. Its value is not included in this ZIP.

## New features

- Signed-in, email-confirmed guests with an active GO destination can tap **I'm here**. A fresh device position must be within 200 metres, with reported accuracy no worse than 150 metres. This optional location check does not prove attendance; client GPS can be spoofed. Raw GPS coordinates are not stored in the arrival table or shared with Crews/businesses. The check time, distance and accuracy are stored privately.
- A guest can give one feedback response per visit within 24 hours. A new location check at the same venue has a six-hour cooldown. Retries of the same check/submission are safe. Daily account limits restrict repeated checks.
- Businesses see grouped feedback only after three distinct guests responded in the last 30 days. Each person contributes their latest response. Account IDs/emails and exact submission times are omitted. Only notes explicitly opted into sharing appear; choose wording that avoids names and personal details. This reduces disclosure, but free-text notes can still identify their author. Verified representatives are excluded from guest feedback for their own venue, including results after later approval.
- The business dashboard shows a distinct-account location-check total for the last 24 hours. It is separate from GO/planning and is not an attendance count. Do not add these overlapping totals together.
- Verified venue representatives can create, edit and end specials, event announcements and promotions. Concurrent edits require the current revision; stale edits cannot overwrite newer changes. Creation retries use the same ID.
- Active specials/promotions and upcoming event announcements appear on public venue pages and WATCH. Future specials/promotions appear only after their start. Ended/archived items disappear from subsequent public responses automatically. Revoking the business claim stops its editing access and hides promotions if no verified claim remains for the venue.
- These are event announcements, not a full event ticketing or event-specific RSVP system. Promotions cannot buy or change the LIT Score. View/tap analytics are explicitly unavailable, not invented zeroes.
- Venue-saving failures now include a short reference so you can find the matching safe error in Netlify Function logs. Logs identify the failing stage without logging keys, account tokens or GPS coordinates.

Promotion limits: 20 active/scheduled entries per venue, 30 creations per account/venue per day; start within 90 days, duration at most 30 days; title 2–80 characters, details at most 300. Arrival checks: at most 20 per account per day. Expired records are retained; this release does not add automatic record deletion or account deletion.

## After the one deployment

1. Use a guest account with GPS enabled, select a real venue as GO, and test I'm here at that venue. Confirm feedback can be submitted and cancellation still works.
2. Try arrival from outside the venue and as a signed-out visitor: the server must reject the action.
3. Submit feedback using three separate guest accounts. Check the verified business dashboard: grouped results appear, unshared notes and account identities do not.
4. Publish a special, edit it, open the shared venue link while signed out, and end it. Refresh to confirm it disappears.
5. Confirm business verification/reviewer controls, Crew plans and saved places still work.

The local database and browser checks are documented in VALIDATION_v3.6.md. Production Supabase/Netlify were not changed by preparation of this package. Physical iPhone/Android GPS acceptance remains necessary.

## If venue saving still fails

Use the short Reference displayed in LIT to find the matching `venue_registration_failed` record in Netlify's register-place Function logs. REG_CONFIGURATION means missing/invalid server setup; REG_ACCOUNT means the account/auth check failed; REG_DATABASE identifies a failed database lookup or quota function; REG_QUOTA means wait before another lookup; REG_PROVIDER means provider lookup failed; REG_SAVE means database insertion failed; REG_CONNECTION means the operation could not finish. The stage, HTTP status and safe backend code help distinguish setup, schema, permissions and provider failures. Never paste your service key into chat.

## Remaining backend work

Server-enforced video capture/processing/expiry and global moderation, trusted activity scoring, full Events/RSVP and ticket flows, account deletion/blocking, genuine promotion analytics, production monitoring and real-device acceptance. Existing interfaces/worker files remain included; this release does not connect those unfinished services.
