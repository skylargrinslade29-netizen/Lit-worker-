## v3.8 current release

See READ_FIRST_v3.8.md for the cumulative reliability batch. No further SQL is needed after successful v3.7 and the missing-v3.6 repair. This package has not been deployed by this assistant; worker hosting remains separate. Older sections below describe earlier versions.

## v3.7 update

Video processing, reporting, owner-delegated moderation, blocking and confirmed account deletion now have source implementations and local fixture validation. This release has not been deployed here. Processing and deletion require the included trusted worker to run continuously. See READ_FIRST_v3.7.md and WORKER_SETUP_v3.7.md; older sections below describe prior releases.

# v3.6 cumulative update

Arrival location checks, private grouped guest feedback, verified venue promotions and venue-saving diagnostics are implemented and locally tested in this release. All previous files remain. See READ_FIRST_v3.6.md. Location checks do not prove attendance. Event announcements do not implement full Events/RSVP or ticketing. Video server enforcement, global moderation, trusted scores, account deletion/blocking and full analytics remain outstanding. Historical statements below about missing arrival/feedback or promotion backend functions are superseded by v3.6 source. This package has not been deployed or applied to production.

# v3.5 update

Private Crew membership, invitations, planning, RSVP, cancellation, link rotation and anonymous planning totals are now implemented in source and tested locally. See READ_FIRST_v3.5.md for installation and live acceptance. Production has not been updated. Historical claims below that full Crew is missing are superseded by v3.5; video, Events, arrivals/feedback, scoring, moderation and account deletion remain outstanding.

# v3.3 update

The combined migration and client now implement owner-controlled business verification, business profiles, GO expiry and anonymous totals, registration permissions/quotas, shared links and recovery. Install the migration, seed your sole owner account, configure Netlify server variables and deploy once; then complete the live acceptance check. See READ_FIRST_v3.3.md and VALIDATION_v3.3.md. Video, full Crew/Events/RSVP, scoring, moderation, account deletion and operator policies remain outstanding. Historical statements below about missing business/GO functions are superseded by this batch's source, not claims of live deployment.

# v3.2 integration status (historical)

Frontend upload/playback recovery is implemented. Account blocking/moderation interfaces and FFmpeg worker are prepared with explicit contracts, but need backend connection and production verification. Real counts still require the existing feed aggregate fields. Supabase remains deferred. See VIDEO_PIPELINE_SETUP.md and SAFETY_BACKEND_CONTRACT.md. All prior launch gaps remain below unless explicitly completed.

# v3.2 added activity UI

Anonymous GO/planning and numeric score display is implemented. ACTIVITY_BACKEND_CONTRACT.md explains the missing live backend response fields and trusted aggregation helper. Supabase integration remains deferred. Public count totals must not be inferred from local GO, invitations, video counts or score points.

# v3.2 additional completed work

Saved places, video autoplay/preloading preferences, offline/reconnect guidance, home-screen metadata, expiration pruning and configurable genuine support/policy links are now included. All v2.9 source files remain. OPERATOR_SETUP.md explains configuration and the boundaries of device-local controls.

# Remaining work after v3.2

## Completed in source
Fresh-GPS/manual location flow; provider category budgets and targeted failure recovery; name search of loaded listings; bounded Ask fallback and location races; expired Tonight promotion exclusion; device-local video hiding; Help & Safety; account-response isolation, camera cleanup/proximity safeguards, signed URL renewal, GO directions and modal focus. Regression tests use mocks, not production services.

## Deferred at the user's request
Supabase contract/RLS review; server video metadata/duration/session enforcement; authoritative anti-fraud scoring; backend deletion/blocking/moderation controls; Events/RSVP schema and lifecycle. Do not claim these are implemented by frontend additions.

## Requires service access or operator information
Verify missing venues in Tampa/Lakeland/Orlando and select/configure an additional licensed provider if needed. Existing providers share OSM source data and cannot guarantee exhaustive clubs. Production Netlify logs/config/auth redirect verification needs account access. Legal documents require actual operator identity/contact, age rules, retention/deletion practices and review; support requires a real monitored contact. No fictional contacts or policies were published.

## Device and operational checks
Physical iPhone Safari/Android Chrome GPS/camera/playback tests; two-account permissions and privacy tests; a functioning moderation review/removal process; monitored provider quota/error rates and distributed rate limiting; supported account deletion process. Local hiding is not global moderation or account blocking. In-memory discovery caching is not distributed abuse control.
