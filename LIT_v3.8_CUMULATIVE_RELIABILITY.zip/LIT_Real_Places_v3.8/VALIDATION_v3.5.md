# v3.5 validation

## Automated results

- `npm test` passed the existing syntax/import/API routes, provider, auth/account isolation, GO and registration regression suite.
- `checks/crew-database.mjs` passed against actual PostgreSQL in PGlite: migration/rerun, private table/helper denial, anonymous Crew RPC denial, unrelated-account denial, limited invitation disclosure, owner-only membership/link management, acceptance/decline, code expiry/rotation and persisted failed-attempt quotas, plan lifecycle, RSVP validation, member removal, organizer departure, unique anonymous planning counts, time windows, confirmed-account requirement, 30-member and 20-Crew capacity checks, and cascading Crew deletion.
- The complete ordered migration was rerun with existing Crew records and preserved them.
- `checks/business-database.mjs` passed the business/owner verification, GO and registration database regressions. Its fixture substitutes a test owner email without changing the real owner setup.
- Real Chromium at 390 px and 1280 px passed Crew creation, invitation, member acceptance, owner-only UI controls, venue plan creation, RSVP, explicit link-join consent, verified business planning totals, draft-preserving dashboard refresh, cancellation, invite rotation and deletion. Neither layout overflowed horizontally.

- The existing mobile/desktop business browser suite also passed against the new combined backend: claim submission, reviewer delegation/approval/revocation, signed-out GO gating, GO/cancel business totals, profile drafts and edits, shared links and business privilege revocation.

## Reproduce locally

Install the optional PGlite package outside the deployment folder, then set `LIT_PGLITE_MODULE` to its `dist/index.js` path. Run `node checks/crew-database.mjs` and `node checks/business-database.mjs`.

For browser checks, install Python Playwright and Chromium, start `checks/browser-server.mjs` with `LIT_TEST_PORT=8767`, and run `python checks/browser_crew.py`. Set `LIT_BROWSER_WIDTH=1280` for desktop. To run the business suite against the same server, set `LIT_TEST_BASE=http://127.0.0.1:8767` and run `python checks/browser_business.py`. The server is local test infrastructure, not a Netlify function.

## Boundaries

Tests use local authenticated fixtures and provider fixtures, not production Supabase/Netlify. PGlite does not simulate multi-connection production load. Membership changes use transaction/advisory locks; actual load/concurrency acceptance still belongs in staging. Physical iPhone/Android checks and live production acceptance remain pending. No deployment or production SQL execution performed. Other remaining backend features are listed in READ_FIRST_v3.5.md.
