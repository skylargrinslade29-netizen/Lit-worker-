-- READ-ONLY Supabase readiness inventory. No schema/data changes.
-- Run in your project's SQL editor; it returns metadata, not user records.
-- Compare argument names/types with BACKEND_CONTRACTS.json.
with expected(name) as (select unnest(array[
    'lit_add_crew_member',
    'lit_archive_promotion',
    'lit_begin_capture',
    'lit_business_dashboard',
    'lit_confirm_arrival',
    'lit_create_crew',
    'lit_create_outing',
    'lit_delete_my_post',
    'lit_join_crew',
    'lit_leave_crew',
    'lit_my_business',
    'lit_my_crews',
    'lit_my_go',
    'lit_my_profile',
    'lit_nearby_feed',
    'lit_place_details',
    'lit_publish_capture',
    'lit_report_post',
    'lit_request_claim',
    'lit_respond_crew_invite',
    'lit_respond_outing',
    'lit_save_business_profile',
    'lit_save_profile',
    'lit_save_promotion',
    'lit_set_go',
    'lit_submit_feedback',
    'lit_track'
]))
select e.name as expected_rpc, p.oid is not null as exists_in_public,
  pg_get_function_identity_arguments(p.oid) as arguments,
  pg_get_function_result(p.oid) as result_type,
  p.prosecdef as security_definer, p.proconfig as configuration,
  case when p.oid is not null then has_function_privilege('anon',p.oid,'EXECUTE') end as anon_execute,
  case when p.oid is not null then has_function_privilege('authenticated',p.oid,'EXECUTE') end as authenticated_execute
from expected e
left join pg_namespace n on n.nspname='public'
left join pg_proc p on p.pronamespace=n.oid and p.proname=e.name
order by e.name;

select n.nspname as schema, c.relname as table_name,
 c.relrowsecurity as rls_enabled, c.relforcerowsecurity as rls_forced
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname in ('public','storage') and c.relkind in ('r','p')
order by n.nspname,c.relname;

select schemaname,tablename,policyname,permissive,roles,cmd
from pg_policies where schemaname in ('public','storage')
order by schemaname,tablename,policyname;

select id,name,public,file_size_limit,allowed_mime_types
from storage.buckets where id='lit-fresh-videos';
