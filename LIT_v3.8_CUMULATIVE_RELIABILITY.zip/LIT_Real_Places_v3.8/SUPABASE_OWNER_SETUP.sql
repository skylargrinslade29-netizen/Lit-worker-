-- Run ONCE in the Supabase SQL Editor after the v3.3 migration.
-- Owner email configured for Nickmccrae11@gmail.com; this must be an existing confirmed LIT account.
-- There is no public/client bootstrap endpoint. This needs database administrator access.
begin;
do $$
declare owner_email text:='Nickmccrae11@gmail.com'; target uuid; existing uuid;
begin
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:owner-bootstrap',0));
  select id into target from auth.users where lower(email)=lower(btrim(owner_email)) and email_confirmed_at is not null;
  if target is null then raise exception 'Enter your existing confirmed LIT account email in owner_email.'; end if;
  select user_id into existing from lit_private.owner_config where singleton=true for update;
  if existing is not null and existing<>target then raise exception 'An owner is already configured. This script will not replace them.'; end if;
  insert into lit_private.owner_config(singleton,user_id) values(true,target) on conflict(singleton) do nothing;
end $$;
commit;
