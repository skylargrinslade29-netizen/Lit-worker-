"""Real Chromium/mobile UI with local PostgreSQL RPCs. Requires browser-server.mjs."""
import asyncio, json, os
from pathlib import Path
from playwright.async_api import async_playwright

BASE=os.environ.get('LIT_TEST_BASE','http://127.0.0.1:8765')
IDS={'owner':'11111111-1111-4111-8111-111111111111','reviewer':'22222222-2222-4222-8222-222222222222','applicant':'33333333-3333-4333-8333-333333333333','outsider':'44444444-4444-4444-8444-444444444444','customer':'55555555-5555-4555-8555-555555555555'}
OUT=Path(os.environ.get('LIT_BROWSER_OUTPUT','/workspace/lit-validation/previews'));OUT.mkdir(parents=True,exist_ok=True)

async def main():
  errors=[]
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    api=await p.request.new_context();await api.post(BASE+'/__test/reset');await api.dispose()
    async def page_for(actor=None,desktop=False):
      ctx=await browser.new_context(viewport={'width':1280 if desktop else 390,'height':900 if desktop else 844})
      user={'id':IDS[actor],'email':actor+'@example.test'} if actor else None
      await ctx.add_init_script('localStorage.setItem("lit-v2-welcomed","1");localStorage.setItem("__lit_test_user",'+json.dumps(json.dumps(user))+');')
      sdk=await ctx.request.get(BASE+'/__test/sdk.js');sdk_body=await sdk.text()
      await ctx.route('**/supabase.min.js',lambda route: route.fulfill(status=200,content_type='text/javascript',body=sdk_body))
      await ctx.route('https://fonts.googleapis.com/**',lambda route:route.abort())
      await ctx.route('https://fonts.gstatic.com/**',lambda route:route.abort())
      page=await ctx.new_page();page.on('pageerror',lambda error:errors.append(str(error)))
      page.on('dialog',lambda dialog:dialog.accept())
      await page.goto(BASE,wait_until='networkidle')
      return page
    async def discover(page):
      await page.locator('[data-action="location"]').first.click()
      await page.locator('input[name="location"]').fill('Test City')
      await page.locator('[data-submit="manualLocation"] button[type="submit"]').click()
      await page.get_by_text('Harbor Social',exact=True).first.wait_for()
    async def account_action(page,action):
      await page.locator('#avatarBtn').click()
      await page.locator('[data-action="'+action+'"]').click()

    # A real applicant creates a pending claim through the actual form.
    applicant=await page_for('applicant');await discover(applicant)
    await applicant.locator('[data-action="venue"][data-pid="geoapify:browser-club"]').first.click()
    await applicant.locator('[data-action="claimVenue"]').click()
    claim_form=applicant.locator('[data-submit="claimSubmit"]')
    await claim_form.locator('[name="email"]').fill('manager@harborsocial.example')
    await claim_form.locator('[name="phone"]').fill('555-0100')
    await claim_form.locator('[name="evidence"]').fill('https://harborsocial.example')
    await claim_form.locator('[name="note"]').fill('General manager; call the official business number to verify me.')
    await claim_form.locator('button[type="submit"]').click()
    await applicant.get_by_text('Pending review',exact=True).wait_for()

    owner=await page_for('owner',True);await account_action(owner,'openVerification')
    await owner.get_by_role('button',name='Review request',exact=True).wait_for()
    await owner.screenshot(path=str(OUT/'verification-desktop.png'),full_page=True)
    # Owner delegates review access. The reviewer cannot grant other reviewers.
    grant=owner.locator('[data-submit="reviewerGrant"]');await grant.locator('[name="email"]').fill('reviewer@example.test')
    await grant.locator('button[type="submit"]').click()
    await owner.get_by_text('reviewer@example.test',exact=True).wait_for()
    reviewer=await page_for('reviewer');await account_action(reviewer,'openVerification')
    assert await reviewer.locator('[data-submit="reviewerGrant"]').count()==0
    await reviewer.get_by_role('button',name='Review request',exact=True).click()
    form=reviewer.locator('[data-submit="reviewDecision"]')
    await form.locator('[name="method"]').select_option('public_phone')
    await form.locator('[name="source"]').fill('Official public business listing; called the published number.')
    await form.locator('[name="note"]').fill('The business confirmed this person is the general manager.')
    await form.locator('[name="checked"]').check()
    await reviewer.screenshot(path=str(OUT/'verification-mobile-review.png'),full_page=True)
    await form.locator('button[type="submit"]').click()
    await reviewer.get_by_text('No requests in this queue.',exact=True).wait_for()

    # Supported drafts survive sheet replacement, but successful save clears them.
    await owner.evaluate("import('/js/core.js').then(m=>m.openSheet('Draft test','<form data-submit=claimSubmit data-pid=test><input name=email><textarea name=note></textarea></form>'))")
    await owner.locator('#sheetBody textarea').fill('Unsent verification draft')
    await owner.evaluate("import('/js/core.js').then(m=>m.openSheet('Draft test','<form data-submit=claimSubmit data-pid=test><input name=email><textarea name=note></textarea></form>'))")
    await owner.wait_for_function("document.querySelector('#sheetBody textarea')?.value==='Unsent verification draft'")
    await owner.evaluate("import('/js/core.js').then(m=>m.emit('draftSaved',document.querySelector('#sheetBody form')))")
    await owner.evaluate("import('/js/core.js').then(m=>m.openSheet('Draft test','<form data-submit=claimSubmit data-pid=test><input name=email><textarea name=note></textarea></form>'))")
    assert await owner.locator('#sheetBody textarea').input_value()==''
    await owner.evaluate("import('/js/core.js').then(m=>m.closeSheet())")
    await owner.evaluate("import('/js/core.js').then(m=>m.actionsFor) ")
    await owner.evaluate("import('/js/core.js').then(m=>m.openSheet('Launch','<button data-action=launchChecklist>Check</button>'))")
    await owner.locator('[data-action=launchChecklist]').click()
    await owner.locator('#sheetTitle').filter(has_text='Owner launch checklist').wait_for()
    await owner.get_by_text('Worker offline',exact=False).wait_for()
    await owner.evaluate("import('/js/core.js').then(m=>m.closeSheet())")
    await owner.evaluate("window.dispatchEvent(new Event('online'))")
    await owner.locator('[data-action=retryConnection]').wait_for()
    # Signed-out GO asks for authentication and does not save local intent.
    customer=await page_for();await discover(customer)
    await customer.locator('[data-action="go"][data-pid="geoapify:browser-club"]').first.click()
    await customer.get_by_text('Sign in to save your GO destination.',exact=True).wait_for()
    assert await customer.evaluate('JSON.parse(localStorage.getItem("lit-v2-prefs")||"{}").localGo') is None
    login=customer.locator('[data-submit="auth"]')
    await login.locator('[name="email"]').fill('customer@example.test');await login.locator('[name="password"]').fill('test-password')
    await login.locator('button[type="submit"]').click()
    await customer.locator('#sheetTitle').filter(has_text='Harbor Social').wait_for()
    await customer.wait_for_function("document.querySelector('#sheetBody [data-action=go]')?.textContent.trim()==='Going'")
    await customer.evaluate("import('/js/core.js').then(m=>m.closeSheet())")
    await customer.locator('#tabbar [data-to="go"]').click()
    await customer.locator('#go .tag').filter(has_text='Going').wait_for()

    await applicant.locator('[data-action="bizRefresh"]').first.click()
    await applicant.locator('#bizGoCount').wait_for()
    assert await applicant.locator('#bizGoCount').inner_text()=='1'
    # Quiet refresh does not erase an in-progress business profile edit.
    await applicant.locator('[data-submit="bizProfile"] [name="description"]').fill('Draft description')
    await customer.locator('#go [data-action="go"]').click()
    await customer.get_by_text('No destination yet.',exact=True).wait_for()
    await applicant.evaluate('import("/js/business.js").then(m=>m.refreshBusinessQuietly())')
    assert await applicant.locator('#bizGoCount').inner_text()=='0'
    assert await applicant.locator('[data-submit="bizProfile"] [name="description"]').input_value()=='Draft description'
    # The venue sheet stays open and reflects every saved GO/cancel state.
    await customer.evaluate("import('/js/venue.js').then(m=>m.openVenue('geoapify:browser-club'))")
    button=customer.locator('#sheetBody [data-action="go"]')
    for _ in range(2):
      await button.filter(has_text='GO').wait_for()
      await button.click()
      await customer.wait_for_function("document.querySelector('#sheetBody [data-action=go]')?.textContent.trim()==='Going'")
      assert await button.get_attribute('aria-pressed')=='true'
      await customer.get_by_text('Going to Harbor Social',exact=True).wait_for()
      await button.click()
      await customer.wait_for_function("document.querySelector('#sheetBody [data-action=go]')?.textContent.trim()==='GO'")
      assert await button.get_attribute('aria-pressed')=='false'
      await customer.get_by_text('GO cancelled',exact=True).wait_for()
    await customer.evaluate("import('/js/core.js').then(m=>m.closeSheet())")

    await applicant.locator('[data-submit="bizProfile"] button[type="submit"]').click()
    await applicant.get_by_text('Business profile saved',exact=True).wait_for()

    # A registered shared venue opens without loading a nearby list.
    shared=await page_for()
    await shared.goto(BASE+'/?venue=geoapify%3Abrowser-club',wait_until='networkidle')
    await shared.locator('#sheetTitle').filter(has_text='Harbor Social').wait_for()
    await shared.get_by_text('Draft description',exact=True).wait_for()
    assert await shared.evaluate('import("/js/core.js").then(m=>m.S.coords)') is None

    # Reviewer access revocation is enforced on the next request.
    await owner.locator('[data-action="reviewRefresh"]').click()
    await owner.locator('[data-action="reviewerRevoke"]').click()
    await owner.get_by_text('Access revoked',exact=True).wait_for()
    await reviewer.locator('[data-action="reviewRefresh"]').click()
    await reviewer.get_by_text('Review queue unavailable',exact=True).wait_for()
    assert await reviewer.get_by_role('button',name='Review request',exact=True).count()==0
    outsider=await page_for('outsider')
    await outsider.locator('#avatarBtn').click()
    assert await outsider.locator('[data-action="openVerification"]').count()==0
    await outsider.evaluate('import("/js/core.js").then(m=>m.emit("navigate","verification"))')
    await outsider.get_by_text('Review queue unavailable',exact=True).wait_for()

    # Revoke business access using the owner and confirm dashboard removal.
    await owner.locator('[data-action="reviewFilter"][data-status="verified"]').click()
    await owner.get_by_role('button',name='View record',exact=True).click()
    revoke=owner.locator('[data-submit="reviewDecision"]')
    await revoke.locator('[name="note"]').fill('Business authorization withdrawn.')
    await revoke.locator('[name="message"]').fill('Your venue access was revoked. Contact the review team to resolve this.')
    await revoke.locator('button[type="submit"]').click()
    await owner.get_by_text('No requests in this queue.',exact=True).wait_for()
    await applicant.locator('[data-action="bizRefresh"]').first.click()
    await applicant.get_by_text('Rejected',exact=True).wait_for()
    assert await applicant.locator('#bizGoCount').count()==0

    mobile_owner=await page_for('owner');await account_action(mobile_owner,'openVerification')
    await mobile_owner.locator('[data-action="reviewFilter"][data-status="rejected"]').click()
    await mobile_owner.get_by_role('button',name='View record',exact=True).wait_for()
    assert await mobile_owner.evaluate('document.documentElement.scrollWidth<=innerWidth'), 'Mobile horizontal overflow'
    await mobile_owner.screenshot(path=str(OUT/'verification-mobile-queue.png'),full_page=True)
    # An authorized response arriving after an account switch must not reveal old claims.
    waiting=asyncio.Event();release=asyncio.Event()
    async def delayed_queue(route):
      body=route.request.post_data_json
      if body.get('name')=='lit_verification_queue':
        response=await route.fetch();waiting.set();await release.wait();await route.fulfill(response=response)
      else:await route.continue_()
    await mobile_owner.route('**/__test/rpc',delayed_queue)
    click=asyncio.create_task(mobile_owner.locator('[data-action="reviewRefresh"]').click())
    await asyncio.wait_for(waiting.wait(),10)
    await mobile_owner.evaluate('window.__litChangeUser('+json.dumps({'id':IDS['outsider'],'email':'outsider@example.test'})+')')
    release.set();await click
    await mobile_owner.get_by_text('Review queue unavailable',exact=True).wait_for()
    assert await mobile_owner.get_by_text('manager@harborsocial.example',exact=True).count()==0
    # Expired authentication clears private state and asks for a new login.
    await outsider.evaluate('''async()=>{const api=await import('/js/api.js');api.sb.rpc=async()=>({data:null,error:{code:'PGRST301',message:'JWT expired'}});try{await api.rpc('lit_review_access')}catch{}}''')
    await outsider.get_by_text('Your session expired. Sign in again to continue.',exact=True).wait_for()
    assert await outsider.evaluate('import("/js/core.js").then(m=>m.S.user)') is None
    assert not errors,errors
    print('PASS: real mobile/desktop Chromium + PostgreSQL: claim submission, owner delegation, reviewer approval, signed-out auth gate, GO/cancel owner counts, draft-preserving refresh, business profile, out-of-radius shared link, reviewer revocation, unauthorized access denial and business access revocation')
    await browser.close()

asyncio.run(main())
