import asyncio,json,os
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.environ.get('LIT_TEST_BASE','http://127.0.0.1:8769')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':390,'height':844})
  await context.add_init_script('localStorage.setItem("lit-v2-welcomed","1");localStorage.setItem("__lit_test_user",'+json.dumps(json.dumps({'id':'11111111-1111-4111-8111-111111111111','email':'owner@example.test'}))+');')
  sdk=await(await context.request.get(BASE+'/__test/sdk.js')).text()
  await context.route('**/supabase.min.js',lambda r:r.fulfill(status=200,content_type='text/javascript',body=sdk))
  async def delay(route):
   if route.request.post_data_json.get('name')=='lit_set_go':await asyncio.sleep(.7)
   await route.continue_()
  await context.route('**/__test/rpc',delay)
  page=await context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/?venue=geoapify%3Abrowser-club',wait_until='networkidle')
  button=page.locator('#sheetBody [data-action=go]');await button.wait_for()
  going=await button.get_attribute('aria-pressed')=='true'
  await button.click();await page.wait_for_function("document.querySelector('#sheetBody [data-action=go]')?.textContent.trim()==='Saving…'")
  assert await button.is_disabled()
  await page.wait_for_function("document.querySelector('#sheetBody [data-action=go]')?.getAttribute('aria-busy')==='false'")
  assert await button.get_attribute('aria-pressed')==str(not going).lower()
  assert await button.inner_text()==('GO' if going else 'Going')
  await button.click();await page.wait_for_function("document.querySelector('#sheetBody [data-action=go]')?.getAttribute('aria-busy')==='false'")
  assert await button.get_attribute('aria-pressed')==str(going).lower()
  await page.evaluate("import('/js/core.js').then(m=>m.openSheet('Launch','<button data-action=launchChecklist>Check</button>'))")
  await page.locator('[data-action=launchChecklist]').click();await page.get_by_text('Support & policy links',exact=True).wait_for()
  assert 'Worker offline' in await page.locator('#sheetBody').inner_text()
  assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  out=Path('/workspace/lit-validation/previews');out.mkdir(exist_ok=True,parents=True)
  await page.wait_for_timeout(450)
  await page.screenshot(path=str(out/'owner-launch-390.png'),full_page=True)
  assert not errors,errors
  await browser.close();print('PASS: delayed GO saving/disabled state, saved and cancelled labels, mobile owner checklist and no browser errors')
asyncio.run(main())
