import assert from 'node:assert/strict'
import {readFileSync} from 'node:fs'
const {PGlite}=await import(process.env.LIT_PGLITE_MODULE || '@electric-sql/pglite')
const db=new PGlite()
const fixture=readFileSync(new URL('./business-database.mjs',import.meta.url),'utf8').match(/const fixture=`([\s\S]*?)`/)[1]
const ids={owner:'11111111-1111-4111-8111-111111111111',member:'22222222-2222-4222-8222-222222222222',invitee:'33333333-3333-4333-8333-333333333333',outsider:'44444444-4444-4444-8444-444444444444',other:'55555555-5555-4555-8555-555555555555'}
const sql=readFileSync(new URL('../SUPABASE_v3.5_CREW_BACKEND.sql',import.meta.url),'utf8')
const call=async(name,args=[]) => (await db.query(`select public.${name}(${args.map((_,i)=>'$'+(i+1)).join(',')}) as result`,args)).rows[0].result
async function actor(name,role='authenticated'){await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[ids[name]||'']);await db.exec(`set role ${role}`)}
async function admin(text,args=[]){await db.exec('reset role');return db.query(text,args)}
const denied=async(fn,pattern=/permission|unavailable|Sign in|Only|invitation|Choose|ended|cancelled|limit/)=>assert.rejects(fn,pattern)
try{
 await db.exec(fixture)
 for(const [name,id]of Object.entries(ids))await db.query('insert into auth.users values($1,$2,now())',[id,name+'@example.test'])
 await db.exec(readFileSync(new URL('../SUPABASE_v3.3_BUSINESS_SYSTEM.sql',import.meta.url),'utf8'));await db.exec(sql);await db.exec(sql)
 await actor('owner');await call('lit_save_profile',['Crew Owner','crewowner'])
 await actor('member');await call('lit_save_profile',['Crew Member','crewmember'])
 await actor('invitee');await call('lit_save_profile',['Crew Invitee','crewinvitee'])
 await actor('outsider');await call('lit_save_profile',['Outsider','outsider'])
 await actor('other');await call('lit_save_profile',['Other Member','othermember'])
 await actor('owner','service_role');const place=(await call('lit_register_verified_place',[ids.owner,{id:'geoapify:crew-place',name:'Crew venue',lat:40,lon:-74,category:'Bars'}])).place_id
 await actor('owner');const crew=await call('lit_create_crew',['Friday Crew']);let c=(await call('lit_my_crews'))[0];assert.equal(c.members.length,1);assert.equal(c.my_role,'owner');assert.equal(c.invite_code.length,32);const code=c.invite_code
 await denied(()=>call('lit_create_crew',[' '.repeat(5)]),/name/)
 await actor('outsider');assert.deepEqual(await call('lit_my_crews'),[]);await denied(()=>db.query('select * from lit_private.crews'));await denied(()=>call('lit_create_outing',[crew,place,new Date(Date.now()+3600000).toISOString(),'Private']))
 await denied(()=>call('lit_add_crew_member',[crew,'crewmember']));await denied(()=>call('lit_rotate_crew_invite',[crew]));await denied(()=>call('lit_leave_crew',[crew,ids.owner]));
 await actor('owner');assert.equal((await call('lit_add_crew_member',[crew,'@crewmember'])).sent,true);assert.equal((await call('lit_add_crew_member',[crew,'missing'])).error,'No confirmed LIT account has that username.')
 const outing=await call('lit_create_outing',[crew,place,new Date(Date.now()+3600000).toISOString(),'Meet at 9']);assert.equal((await call('lit_my_crews'))[0].outings[0].responses.length,1)
 await actor('member');c=(await call('lit_my_crews'))[0];assert.equal(c.my_status,'invited');assert.equal(c.invite_code,null);assert.deepEqual(c.outings,[]);await denied(()=>call('lit_respond_outing',[outing,'in']));await call('lit_respond_crew_invite',[crew,true]);c=(await call('lit_my_crews'))[0];assert.equal(c.members.length,2);assert.equal(c.outings[0].responses.length,2);assert.equal(c.outings[0].can_cancel,false)
 await denied(()=>call('lit_add_crew_member',[crew,'crewinvitee']));await denied(()=>call('lit_cancel_outing',[outing]));await call('lit_respond_outing',[outing,'in']);await denied(()=>call('lit_respond_outing',[outing,'spoof']))
 await actor(null,'anon');await denied(()=>call('lit_my_crews'));let totals=await call('lit_activity_counts',[[place]]);assert.equal(totals[0].activity.planning_count,2);assert.ok(!JSON.stringify(totals).includes(ids.member));assert.ok(!JSON.stringify(totals).includes('Friday Crew'))
 await actor('owner');const outing2=await call('lit_create_outing',[crew,place,new Date(Date.now()+7200000).toISOString(),'Second plan']);
 await actor('member');await call('lit_respond_outing',[outing2,'in']);await actor(null,'anon');assert.equal((await call('lit_activity_counts',[[place]]))[0].activity.planning_count,2)
 await actor('member');await call('lit_respond_outing',[outing,'pass']);await call('lit_respond_outing',[outing2,'maybe']);await actor(null,'anon');assert.equal((await call('lit_activity_counts',[[place]]))[0].activity.planning_count,1)
 await actor('invitee');assert.equal((await call('lit_join_crew',[code.toLowerCase()])).crew_id,crew);assert.equal((await call('lit_my_crews'))[0].outings[0].responses.length,3)
 await actor('owner');await call('lit_rotate_crew_invite',[crew]);await actor('other');assert.ok((await call('lit_join_crew',[code])).error);for(let i=0;i<20;i++)await call('lit_join_crew',['bad']);assert.match((await call('lit_join_crew',[code])).error,/Too many/)
 await admin("update lit_private.crew_request_limits set window_start=now()-interval '2 hours' where user_id=$1",[ids.other]);await actor('owner');let newCode=(await call('lit_my_crews'))[0].invite_code;await actor('other');assert.equal((await call('lit_join_crew',[newCode])).crew_id,crew)
 await actor('member');const memberPlan=await call('lit_create_outing',[crew,place,new Date(Date.now()+3600000).toISOString(),'Member plan']);await call('lit_respond_outing',[outing,'in']);await actor('owner');await call('lit_leave_crew',[crew,ids.member]);await actor('member');assert.deepEqual(await call('lit_my_crews'),[]);await denied(()=>call('lit_respond_outing',[outing,'in']));await actor('owner');assert.ok(!(await call('lit_my_crews'))[0].outings.some(x=>x.id===memberPlan))
 await call('lit_cancel_outing',[outing]);await actor('invitee');await denied(()=>call('lit_respond_outing',[outing,'in']));await actor('owner');await call('lit_cancel_outing',[outing2]);await actor(null,'anon');assert.equal((await call('lit_activity_counts',[[place]]))[0].activity.planning_count,0)
 await actor('owner');await denied(()=>call('lit_create_outing',[crew,place,new Date(Date.now()-60000).toISOString(),'']),/time/);await denied(()=>call('lit_create_outing',[crew,place,new Date(Date.now()+31*86400000).toISOString(),'']),/time/)
 const far=await call('lit_create_outing',[crew,place,new Date(Date.now()+86400000).toISOString(),'Tomorrow']);await actor(null,'anon');assert.equal((await call('lit_activity_counts',[[place]]))[0].activity.planning_count,0)
 await admin("update lit_private.crew_outings set starts_at=now()-interval '7 hours',ends_at=now()-interval '1 hour' where id=$1",[far]);await actor('owner');assert.ok(!(await call('lit_my_crews'))[0].outings.some(x=>x.id===far));await denied(()=>call('lit_respond_outing',[far,'in']))
 await admin("update lit_private.crews set invite_expires_at=now()-interval '1 second' where id=$1",[crew]);await actor('outsider');assert.match((await call('lit_join_crew',[newCode])).error,/expired/)
 await actor('owner');await call('lit_add_crew_member',[crew,'outsider']);await actor('outsider');await call('lit_respond_crew_invite',[crew,false]);assert.deepEqual(await call('lit_my_crews'),[])
 await actor('owner');await db.exec('reset role');await db.exec(readFileSync(new URL('../SUPABASE_COMPLETE_v3.5.sql',import.meta.url),'utf8'));await actor('owner');assert.equal((await call('lit_my_crews'))[0].id,crew);await call('lit_leave_crew',[crew,null]);assert.deepEqual(await call('lit_my_crews'),[]);await actor('invitee');assert.deepEqual(await call('lit_my_crews'),[])
 // Capacity and confirmed-account requirements are enforced on the server.
 await actor('owner');const capacityCrew=await call('lit_create_crew',['Capacity Crew'])
 await admin('update auth.users set email_confirmed_at=null where id=$1',[ids.other]);await actor('other');await denied(()=>call('lit_create_crew',['Unconfirmed']),/Confirm/);await admin('update auth.users set email_confirmed_at=now() where id=$1',[ids.other])
 const generated=[]
 for(let i=0;i<29;i++){const id='aaaaaaaa-aaaa-4aaa-8aaa-'+String(i).padStart(12,'0');generated.push(id);await admin('insert into auth.users values($1,$2,now())',[id,'capacity'+i+'@example.test']);await admin("insert into lit_private.crew_members(crew_id,user_id,status) values($1,$2,'joined')",[capacityCrew,id])}
 await actor('owner');assert.match((await call('lit_add_crew_member',[capacityCrew,'outsider'])).error,/30-member/)
 const capacityCode=(await call('lit_my_crews'))[0].invite_code;await actor('outsider');assert.match((await call('lit_join_crew',[capacityCode])).error,/30-member/)
 await actor('owner');await call('lit_leave_crew',[capacityCrew,null])
 await admin("delete from lit_private.crew_request_limits where user_id=$1 and kind='create'",[ids.owner]);await actor('owner')
 for(let i=0;i<20;i++)await call('lit_create_crew',['Limit '+i]);await denied(()=>call('lit_create_crew',['Overflow']),/limit|Too many/)
 console.log('PASS: private Crew access, invited-only disclosure, owner-only membership and links, join quota/expiry/rotation, plan creation/RSVP/cancellation, member removal, organizer departure, intent deduplication/windows, anonymous totals, migration rerun and cascading deletion.')
}finally{await db.close()}
