"""Chromium arrival/feedback/promotions against the real local PostgreSQL fixture."""
import asyncio,json,os
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.environ.get('LIT_TEST_BASE','http://127.0.0.1:8768')
WIDTH=int(os.environ.get('LIT_BROWSER_WIDTH','390'))
IDS={'owner':'11111111-1111-4111-8111-111111111111','reviewer':'22222222-2222-4222-8222-222222222222','applicant':'33333333-3333-4333-8333-333333333333','outsider':'44444444-4444-4444-8444-444444444444','customer':'55555555-5555-4555-8555-555555555555'}
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);api=await p.request.new_context();errors=[]
  async def rpc(actor,name,args={}):
   res=await api.post(BASE+'/__test/rpc',headers={'Authorization':'Bearer '+IDS[actor] if actor else ''},data={'name':name,'args':args});value=await res.json();assert not value.get('error'),value;return value['data']
  await api.post(BASE+'/__test/reset')
  for name in IDS:await rpc(name,'lit_save_profile',{'p_display_name':name.title(),'p_username':name+'handle'})
  place=(await rpc(None,'lit_public_place',{'p_pid':'geoapify:browser-club'}))['place']['place_id']
  claim=await rpc('reviewer','lit_request_claim',{'p_place':place,'p_role':'Owner','p_email':'reviewer@example.test','p_phone':'','p_note':'Owner','p_evidence_url':'https://example.test'})
  queue=await rpc('owner','lit_verification_queue');c=next(x for x in queue['claims'] if x['id']==claim['claim_id'])
  await rpc('owner','lit_review_claim',{'p_claim':c['id'],'p_version':c['version'],'p_decision':'approve','p_method':'public_phone','p_source':'Independent public source','p_note':'Confirmed business authority','p_message':'','p_checked':True,'p_allow_shared':False})
  sdk=await (await api.get(BASE+'/__test/sdk.js')).text()
  async def page_for(actor=None):
   ctx=await browser.new_context(viewport={'width':WIDTH,'height':900},geolocation={'latitude':40,'longitude':-74,'accuracy':20},permissions=['geolocation'])
   user={'id':IDS[actor],'email':actor+'@example.test'} if actor else None
   await ctx.add_init_script('localStorage.setItem("lit-v2-welcomed","1");localStorage.setItem("__lit_test_user",'+json.dumps(json.dumps(user))+');')
   await ctx.route('**/supabase.min.js',lambda r:r.fulfill(status=200,content_type='text/javascript',body=sdk));await ctx.route('https://fonts.googleapis.com/**',lambda r:r.abort());await ctx.route('https://fonts.gstatic.com/**',lambda r:r.abort())
   page=await ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());await page.goto(BASE,wait_until='networkidle');return page
  business=await page_for('reviewer');await business.evaluate("import('/js/core.js').then(m=>m.emit('navigate','business'))");await business.locator('#bizArrivalCount').wait_for();assert await business.locator('#bizArrivalCount').inner_text()=='0'
  for index,guest in enumerate(['applicant','outsider','customer']):
   await rpc(guest,'lit_set_go',{'p_place':place,'p_going':True});page=await page_for(guest);await page.locator('#tabbar [data-to=go]').click();await page.locator('[data-action=arrive]').click();form=page.locator('[data-submit=feedback]');await form.wait_for()
   await form.locator('[data-action=fbAccuracy][data-v=not_shown]').click();await form.locator('[data-action=fbVibe][data-v="4"]').click();await form.locator('[name=note]').fill('Shared guest note' if index==0 else 'Private guest note')
   if index==0:await form.locator('[name=shareNote]').check()
   await page.evaluate("import('/js/go.js').then(m=>m.loadGo())");assert await form.locator('[name=note]').input_value()==('Shared guest note' if index==0 else 'Private guest note');assert 'on' in await form.locator('[data-action=fbAccuracy][data-v=not_shown]').get_attribute('class')
   if index==0:
    out=Path(os.environ.get('LIT_BROWSER_OUTPUT','/workspace/lit-validation/previews'));out.mkdir(parents=True,exist_ok=True);await page.screenshot(path=str(out/('feedback-'+str(WIDTH)+'.png')),full_page=True)
   await form.locator('button[type=submit]').click();await page.get_by_text('Feedback received',exact=True).wait_for()
   if index==0:
    await business.locator('[data-action=bizRefresh]').first.click();await business.locator('#bizArrivalCount').wait_for();assert await business.locator('#bizArrivalCount').inner_text()=='1';assert 'different guests respond' in await business.locator('#business').inner_text();assert 'Shared guest note' not in await business.locator('#business').inner_text()
  await business.locator('[data-action=bizRefresh]').first.click();await business.get_by_text('3 guests · 30 days',exact=True).wait_for();assert 'Shared guest note' in await business.locator('#business').inner_text();assert 'Private guest note' not in await business.locator('#business').inner_text()
  promo=business.locator('[data-submit=promoSave]');await promo.locator('[name=title]').fill('Happy hour');await promo.locator('[name=details]').fill('Patio specials');await promo.locator('button[type=submit]').click();await business.get_by_text('Happy hour',exact=True).wait_for();assert (await rpc(None,'lit_public_place',{'p_pid':'geoapify:browser-club'}))['place']['promos'][0]['title']=='Happy hour'
  await business.locator('[data-action=promoEdit]').first.click();edit=business.locator('#sheetBody [data-submit=promoSave]');await edit.locator('[name=title]').fill('Updated happy hour');await edit.locator('button[type=submit]').click();await business.get_by_text('Updated happy hour',exact=True).wait_for();assert (await rpc(None,'lit_public_place',{'p_pid':'geoapify:browser-club'}))['place']['promos'][0]['title']=='Updated happy hour'
  await business.screenshot(path=str(out/('business-engagement-'+str(WIDTH)+'.png')),full_page=True)
  public=await page_for();await public.goto(BASE+'/?venue=geoapify%3Abrowser-club',wait_until='networkidle');await public.get_by_text('Updated happy hour',exact=True).wait_for()
  await business.locator('[data-action=promoArchive]').first.click();await business.get_by_text('Ended by venue',exact=False).wait_for();assert (await rpc(None,'lit_public_place',{'p_pid':'geoapify:browser-club'}))['place']['promos']==[]
  for page in [business,public]:assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  assert not errors,errors;await browser.close();await api.dispose();print('PASS: GPS check, feedback draft preservation/submission/consent/privacy, business aggregates, promotion create/edit/public/archive and responsive UI.')
asyncio.run(main())
