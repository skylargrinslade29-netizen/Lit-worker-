"""Saved-place portability and mobile UI checks against a local static server on 8766."""
import asyncio,json
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':390,'height':844})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.route('**/js/main.js',lambda r:r.fulfill(status=200,body=''))
  await page.route('https://**',lambda r:r.abort())
  await page.goto('http://127.0.0.1:8766')
  await page.evaluate('''async()=>{const {S,actionsFor}=await import('/js/core.js');const m=await import('/js/saved.js');S.sharedVenues['geoapify:test']={id:'geoapify:test',name:'Harbor <Social>',lat:28,lon:-81,address:'Main Street',category:'Bars'};m.toggleSaved('geoapify:test');const b=document.createElement('button');b.dataset.action='savedPlaces';document.body.append(b);b.click()}''')
  assert await page.locator('#savedRows strong').inner_text()=='Harbor <Social>'
  await page.locator('[name=savedQuery]').fill('missing');assert await page.locator('#savedRows').inner_text()=='No saved places match your search.'
  await page.locator('[name=savedQuery]').fill('Main');assert await page.locator('#savedRows strong').count()==1
  async with page.expect_download() as info: await page.locator('[data-action=exportSaved]').click()
  download=await info.value;payload=json.loads(open(await download.path()).read());assert payload['format']=='lit-saved-places' and len(payload['places'])==1 and 'user' not in payload
  await page.locator('[name=savedImport]').set_input_files({'name':'invalid.json','mimeType':'application/json','buffer':b'{"places":[]}'})
  await page.wait_for_function("document.querySelector('#savedImportStatus').textContent.includes('not a valid')")
  payload['places'].append({'id':'geoapify:second','name':'Night Garden','lat':29,'lon':-82,'category':'Food','address':'Park Lane'})
  await page.locator('[name=savedImport]').set_input_files({'name':'backup.json','mimeType':'application/json','buffer':json.dumps(payload).encode()})
  await page.wait_for_function("document.querySelector('#savedImportStatus').textContent.includes('Imported 1')")
  await page.locator('[name=savedQuery]').fill('');assert await page.locator('#savedRows strong').count()==2
  await page.locator('[name=savedSort]').select_option('name');assert await page.locator('#savedRows strong').first.inner_text()=='Harbor <Social>'
  await page.locator('[data-action=removeSaved]').first.click();assert await page.locator('#savedRows strong').count()==1
  assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  # A locally cached real venue can reopen without changing current discovery coordinates.
  await page.evaluate('''async()=>{const {S}=await import('/js/core.js');S.sharedVenues['geoapify:second']={id:'geoapify:second',name:'Night Garden',lat:29,lon:-82,address:'Park Lane',category:'Food'};S.coords=null}''')
  await page.locator('[data-action=openSaved]').click();await page.wait_for_function("document.querySelector('#sheetTitle').textContent==='Night Garden'")
  assert await page.evaluate("import('/js/core.js').then(m=>m.S.coords===null)")
  await page.locator('[data-action=saveVenue]').click();assert await page.locator('[data-action=saveVenue]').inner_text()=='Save place'
  assert not errors,errors
  await browser.close();print('PASS: mobile bookmark search, escaped text, export/import validation, merge deduplication, sorting, removal, shared venue reopening and Save toggle.')
asyncio.run(main())
