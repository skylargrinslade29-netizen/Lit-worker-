import assert from 'node:assert/strict'
import handler from '../netlify/functions/delete-account.mjs'
const oldFetch=globalThis.fetch,names=['SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY'],old=Object.fromEntries(names.map(n=>[n,process.env[n]]))
const request=(body,auth='Bearer user-token')=>new Request('https://example.test/api/delete-account',{method:'POST',headers:{Authorization:auth,'Content-Type':'application/json'},body:JSON.stringify(body)})
let mode='ok',queued=0
try{
 process.env.SUPABASE_URL='https://example.supabase.co';process.env.SUPABASE_SERVICE_ROLE_KEY='test-secret-only'
 globalThis.fetch=async(input,options)=>{
  const url=new URL(input)
  if(url.pathname==='/auth/v1/user'){assert.equal(options.headers.Authorization,'Bearer user-token');return Response.json({id:'derived-user',email:'real@example.test'})}
  if(url.pathname==='/auth/v1/token'){const body=JSON.parse(options.body);assert.equal(body.email,'real@example.test');assert.equal(body.password,'current-password');return mode==='wrong' ? Response.json({message:'private'}, {status:400}) : Response.json({user:{id:mode==='mismatch'?'wrong-user':'derived-user'},access_token:'private-auth-token',refresh_token:'private-refresh'})}
  if(url.pathname==='/rest/v1/rpc/lit_request_account_deletion'){queued++;assert.equal(options.headers.Authorization,'Bearer test-secret-only');assert.deepEqual(JSON.parse(options.body),{p_actor:'derived-user',p_confirmation:'DELETE'});return mode==='owner' ? Response.json({message:'The platform owner cannot delete this account.'},{status:403}) : Response.json({requested:true,receipt:'random-private-receipt',state:'pending'})}
  throw new Error('Unexpected request')
 }
 assert.equal((await handler(request({},''))).status,401);assert.equal((await handler(request({confirmation:'no',password:'current-password'}))).status,400)
 mode='wrong';assert.equal((await handler(request({confirmation:'DELETE',password:'current-password'}))).status,401);assert.equal(queued,0)
 mode='mismatch';assert.equal((await handler(request({confirmation:'DELETE',password:'current-password'}))).status,401);assert.equal(queued,0)
 mode='ok';let response=await handler(request({confirmation:'DELETE',password:'current-password',p_actor:'forged-user'}));assert.equal(response.status,200);let body=await response.json();assert.equal(body.requested,true);assert.ok(!JSON.stringify(body).includes('private-auth-token'));assert.ok(!JSON.stringify(body).includes('current-password'));assert.equal(queued,1)
 mode='owner';assert.equal((await handler(request({confirmation:'DELETE',password:'current-password'}))).status,403)
 console.log('PASS: deletion session/password re-authentication, wrong-password/mismatched-account refusal, server-derived identity, owner protection and secret-free responses.')
}finally{globalThis.fetch=oldFetch;for(const name of names){if(old[name]===undefined)delete process.env[name];else process.env[name]=old[name]}}
