"""Exercise worker job leases/results, cleanup/deletion order and private failure logs."""
import sys,importlib.util,io,contextlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'workers'))
import lit_worker as module
class Fake(module.Worker):
 def __init__(self):self.calls=[];self.fail=None
 def request(self,path,method='GET',body=None,content_type='application/json',missing_ok=False,destination=None):
  self.calls.append((path,method,body))
  if self.fail and self.fail in path:raise module.ServiceError('SECRET AUTH BODY')
  if destination:Path(destination).write_bytes(b'local fixture')
  return {'published':False} if 'lit_worker_result_status' in path else {'saved':True}
worker=Fake();job={'kind':'cleanup','id':'task','lease':'lease','bucket':'lit-fresh-videos','path':'author/clip.mp4'}
worker.process(job);assert worker.calls[0][0]=='/storage/v1/object/lit-fresh-videos';assert worker.calls[0][2]=={'prefixes':['author/clip.mp4']};assert worker.calls[1][2]['p_ok'] is True
worker.calls=[];job={'kind':'deletion','id':'task','lease':'lease','user_id':'account'};worker.process(job);assert '/lit_worker_purge_account' in worker.calls[0][0];assert '/auth/v1/admin/users/account'==worker.calls[1][0];assert worker.calls[2][2]['p_ok'] is True
worker.calls=[];worker.fail='purge';out=io.StringIO()
with contextlib.redirect_stdout(out):worker.process(job)
assert not any('/auth/v1/admin/' in p for p,_,_ in worker.calls);assert 'SECRET' not in out.getvalue();assert worker.calls[-1][2]['p_ok'] is False
# An upload whose publication lease is rejected is physically cleaned, never advertised as ready.
original=module.prepare
try:
 module.prepare=lambda source,output:(Path(output).write_bytes(b'prepared') and {'duration_seconds':11,'bytes':8,'width':320,'height':240,'content_type':'video/mp4'})
 worker=Fake();worker.fail='lit_worker_result';original_request=worker.request
 def request(path,*args,**kwargs):
  if 'lit_worker_result_status' in path:return {'published':False}
  return original_request(path,*args,**kwargs)
 worker.request=request;job={'kind':'video','id':'task','lease':'lease','bucket':'lit-video-quarantine','path':'author/source.webm','output_path':'author/session/lease.mp4','declared_ms':11000}
 with contextlib.redirect_stdout(out):worker.process(job)
 assert any(method=='DELETE' and body=={'prefixes':[job['output_path']]} for _,method,body in worker.calls)
 assert 'SECRET' not in out.getvalue()
 worker=Fake();worker.fail='lit_worker_result';original_request=worker.request
 def committed(path,*args,**kwargs):
  if 'lit_worker_result_status' in path:return {'published':True}
  return original_request(path,*args,**kwargs)
 worker.request=committed
 with contextlib.redirect_stdout(out):worker.process(job)
 assert not any(method=='DELETE' for _,method,_ in worker.calls)
 assert 'worker_publication_confirmed' in out.getvalue()
finally:module.prepare=original
print('PASS: worker cleanup/deletion sequencing, purge refusal, failed-lease output removal and secret-free logging.')
