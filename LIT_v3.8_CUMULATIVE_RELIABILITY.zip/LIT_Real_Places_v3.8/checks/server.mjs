import assert from 'node:assert/strict'
import places from '../netlify/functions/places.mjs'
import geocode from '../netlify/functions/geocode.mjs'
import ask from '../netlify/functions/ask.mjs'
import { providerJson } from '../netlify/functions/lib/provider.mjs'
const logs=[]
console.info=console.warn=(message)=>logs.push(message)
let calls=[], sequence=0
const request=(query='lat=40&lon=-74&radius=5')=>new Request(`https://example.test/api/places?${query}`)
const feature=(id,name,lat=40,lon=-74,categories=['catering.bar'])=>({properties:{place_id:id,name,categories},geometry:{coordinates:[lon,lat]}})
function mock(responses,key=true){ calls=[];let managedCalls=0,managedResponse; if(key)process.env.GEOAPIFY_API_KEY=`test-secret-${++sequence}`;else delete process.env.GEOAPIFY_API_KEY
 globalThis.fetch=async(url,options)=>{calls.push({url:String(url),options});const isPlaces=new URL(url).pathname==='/v2/places';let next;if(isPlaces){if(managedCalls++===0)managedResponse=responses.shift();next=managedResponse}else next=responses.shift();assert.ok(next,'Unexpected additional provider request');if(next instanceof Error)throw next;return Response.json(next.body,{status:next.status||200})}
}
mock([])
for(const q of ['lat=40%26lon=-74%26radius=5','lat=&lon=0','lat=91&lon=0','lat=0&lon=181','lat=0&lon=0&radius=3','lat=0&lon=0&radius=','lat=40&lat=41&lon=0'])assert.equal((await places(request(q))).status,400)
assert.equal(calls.length,0)
assert.equal((await places(new Request('https://example.test/api/places',{method:'POST'}))).status,405)
mock([{body:{features:[feature('1','Bar'),feature('2','Club',40,-74,['adult.nightclub']),feature('3','Outside',0,0),feature('4',''),feature('duplicate','Bar'),{properties:{name:'missing ID'},geometry:{coordinates:[-74,40]}}]}}])
let r=await places(request()),d=await r.json()
assert.equal(r.status,200);assert.equal(r.headers.get('X-LIT-Discovery-Version'),'3.2');assert.equal(d.venues.length,2);assert.equal(d.venues[1].category,'Party')
let u=new URL(calls[0].url);assert.equal(u.searchParams.get('filter'),'circle:-74,40,8047');const cats=calls.flatMap((c)=>new URL(c.url).searchParams.get('categories').split(','));assert.equal(calls.length,4);for(const call of calls)assert.equal(new URL(call.url).searchParams.get('limit'),'100');assert.ok(cats.includes('adult.nightclub'));for(const bad of ['entertainment.nightclub','entertainment.theatre','entertainment.music_venue'])assert.ok(!cats.includes(bad))
// Warm success cache prevents another provider call.
r=await places(request());assert.equal(r.status,200);assert.equal(calls.length,4)
// Brief provider outages may reuse recent real results, explicitly labeled.
const realNow=Date.now;Date.now=()=>realNow()+95000;calls=[]
const failures=[400,400,400,400,503,429];globalThis.fetch=async(url)=>{calls.push(url);return Response.json({}, {status:failures.shift()})}
r=await places(request());d=await r.json();assert.equal(r.status,200);assert.equal(d.venues.length,2);assert.ok(d.warning.includes('last 15 minutes'));assert.equal(calls.length,6);Date.now=realNow
mock([{body:{features:[]}}]);d=await(await places(request())).json();assert.deepEqual(d.venues,[]);assert.equal(calls.length,4)
mock([{status:401,body:{error:'test-secret'}},{status:503,body:{}},{body:{elements:[{type:'node',id:1,lat:40,lon:-74,tags:{name:'Real OSM record',amenity:'pub'}}]}}]);d=await(await places(request('lat=40&lon=-74&radius=25'))).json();assert.equal(d.provider,'openstreetmap');assert.ok(d.coverage_miles<25);assert.ok(d.warning.includes('7.5'));assert.equal(calls.length,6)
mock([{status:400,body:{}},{status:503,body:{}},{status:429,body:{}}]);r=await places(request());assert.equal(r.status,503);assert.equal(r.headers.get('Cache-Control'),'no-store');d=await r.json();assert.equal(d.code,'PLACES_UNAVAILABLE');assert.ok(d.request_id);assert.equal(r.headers.get('X-LIT-Request-ID'),d.request_id)
mock([{body:{features:{}}},{body:{elements:[],remark:'runtime error'}},{body:{elements:[]}}]);assert.equal((await places(request())).status,200);assert.equal(calls.length,6)
mock([{body:{elements:[]}}],false);assert.equal((await places(request())).status,200);assert.equal(calls.length,1)
// Concurrent identical requests coalesce into one upstream call.
process.env.GEOAPIFY_API_KEY='coalescing-secret';let completions=[];calls=[]
globalThis.fetch=async(url)=>{calls.push(url);return new Promise(resolve=>{completions.push(()=>resolve(Response.json({features:[]})))})}
const a=places(request('lat=41&lon=-74&radius=5')),b=places(request('lat=41&lon=-74&radius=5'));assert.equal(calls.length,4);for(const complete of completions)complete();assert.equal((await a).status,200);assert.equal((await b).status,200)
// Food density cannot remove a separately retrieved club; category failures stay honest.
process.env.GEOAPIFY_API_KEY='balanced-secret';calls=[]
globalThis.fetch=async(url)=>{calls.push(url);const category=new URL(url).searchParams.get('categories');return Response.json({features: category==='adult.nightclub' ? [feature('club','Actual club',40.01,-74,['adult.nightclub'])] : category.startsWith('catering.restaurant') ? Array.from({length:100},(_,i)=>feature(`food-${i}`,`Food ${i}`,40,-74,['catering.restaurant'])) : []})}
d=await(await places(request('lat=40&lon=-74&radius=10'))).json();assert.ok(d.venues.some(v=>v.name==='Actual club'&&v.category==='Party'));assert.equal(d.venues.filter(v=>v.category==='Food').length,100);assert.equal(calls.length,4)
process.env.GEOAPIFY_API_KEY='partial-secret';globalThis.fetch=async(url)=>{const category=new URL(url).searchParams.get('categories');return category.startsWith('catering.restaurant') ? Response.json({}, {status:503}) : Response.json({features: category==='adult.nightclub' ? [feature('club','Club',40,-74,['adult.nightclub'])] : []})}
d=await(await places(request())).json();assert.equal(d.venues.length,1);assert.ok(d.warning.includes('categories'))
// Repair failed nightclub searches without discarding successful bars or querying food again.
process.env.GEOAPIFY_API_KEY='club-recovery-secret';calls=[]
globalThis.fetch=async(url,options)=>{
 calls.push({url:String(url),options})
 if(new URL(url).pathname==='/v2/places') {
  const category=new URL(url).searchParams.get('categories')
  return category==='adult.nightclub' ? Response.json({}, {status:429}) : Response.json({features:category==='catering.bar,catering.pub'?[feature('bar','Successful bar')]:[]})
 }
 const query=options.body.get('data');assert.ok(query.includes('amenity=nightclub'));assert.ok(!query.includes('restaurant'));assert.ok(!query.includes('biergarten'))
 return Response.json({elements:[{type:'node',id:72,lat:40,lon:-74,tags:{name:'Recovered nightclub',amenity:'nightclub'}}]})
}
d=await(await places(request())).json();assert.equal(d.provider,'geoapify+openstreetmap');assert.equal(d.warning,null);assert.ok(d.venues.some(v=>v.name==='Successful bar'));assert.ok(d.venues.some(v=>v.name==='Recovered nightclub'&&v.category==='Party'));assert.equal(calls.length,5)
process.env.GEOAPIFY_API_KEY='club-recovery-wide-secret'
d=await(await places(request('lat=40&lon=-74&radius=25'))).json();assert.ok(d.warning.includes('7.5'));assert.equal(d.coverage_miles,25)
// A second provider outage must still retain the successful categories.
process.env.GEOAPIFY_API_KEY='club-recovery-failed-secret';const recoveryFetch=globalThis.fetch
 globalThis.fetch=async(url,options)=>new URL(url).pathname==='/v2/places'?recoveryFetch(url,options):Response.json({}, {status:503})
d=await(await places(request())).json();assert.equal(d.provider,'geoapify');assert.equal(d.venues.length,1);assert.ok(d.warning.includes('categories'))
for(const q of ['10001','New York, NY','A & B','London']){mock([{body:{results:[{lat:40,lon:-74,city:'New York',state:'New York'}]}}]);d=await(await geocode(new Request(`https://example.test/api/geocode?${new URLSearchParams({q})}`))).json();assert.equal(d.lat,40);u=new URL(calls[0].url);assert.equal(u.searchParams.get('text'),q);assert.equal(u.searchParams.has('filter'),q==='10001');assert.equal(d.area,'New York, New York')}
mock([{status:403,body:{}},{body:[{lat:'40',lon:'-74',address:{city:'NY'}}]}]);d=await(await geocode(new Request('https://example.test/api/geocode?q=10001'))).json();assert.equal(d.provider,'openstreetmap')
mock([{body:{results:[]}}]);assert.equal((await geocode(new Request('https://example.test/api/geocode?q=10001'))).status,404);assert.equal(calls.length,1)
mock([{body:{results:[{lat:null,lon:null}]}},{body:[{lat:'40',lon:'-74'}]}]);assert.equal((await geocode(new Request('https://example.test/api/geocode?q=10001'))).status,200);assert.equal(calls.length,2)
mock([{status:401,body:{}},{status:503,body:{}}]);assert.equal((await geocode(new Request('https://example.test/api/geocode?q=10001'))).status,503)
assert.equal((await geocode(new Request('https://example.test/api/geocode?q=a'))).status,400)
let firstSignal;globalThis.fetch=(url,{signal})=>{firstSignal=signal;return new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(new Error('abort'))))}
await assert.rejects(providerJson('slow','https://example.test',{timeout:5,trace:(x)=>logs.push(JSON.stringify(x))}));assert.equal(firstSignal.aborted,true)
globalThis.fetch=async(url,{signal})=>{assert.equal(signal.aborted,false);return Response.json({ok:true})};assert.deepEqual(await providerJson('fallback','https://example.test'),{ok:true})
assert.ok(logs.some(x=>x.includes('"status":401')));assert.ok(logs.some(x=>x.includes('"reason":"timeout"')));assert.ok(logs.some(x=>x.includes('invalid_or_partial_response')));assert.ok(!logs.join('').includes('test-secret'));assert.ok(!logs.join('').includes('coalescing-secret'));assert.ok(!logs.join('').includes('apiKey'))
r=await ask(new Request('https://example.test/api/ask',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({query:'bars',venues:[{id:'osm:node:1',name:'Real input',category:'Bars',miles:1}]})}));assert.equal(r.status,200);assert.equal((await r.json()).picks[0].id,'osm:node:1')
r=await ask(new Request('https://example.test/api/ask',{method:'POST',body:'null'}));assert.equal(r.status,400)
r=await ask(new Request('https://example.test/api/ask',{method:'POST',body:'x'.repeat(65537)}));assert.equal(r.status,413)
r=await ask(new Request('https://example.test/api/ask',{method:'POST',body:JSON.stringify({query:'bars',venues:[null,{id:'osm:node:1',name:'At your location',category:'Bars',miles:0},{id:'osm:node:2',name:'Farther venue',category:'Bars',miles:1}]})}));assert.equal((await r.json()).picks[0].id,'osm:node:1')
process.stdout.write('PASS: provider categories, methods, invalid queries, normalization, empty results, fallbacks, coverage, cache/coalescing, geocoding, timeout isolation, safe logs, Ask API\n')

const {aggregateIntent}=await import('../netlify/functions/lib/intent-aggregate.mjs')
const aggregateNow=Date.now(), iso=(offset)=>new Date(aggregateNow+offset).toISOString()
const goRow={place_id:'venue-a',user_id:'private-a',active:true,created_at:iso(-60000),expires_at:iso(3600000)}
const planRow={place_id:'venue-a',user_id:'private-a',response:'in',status:'active',member_active:true,starts_at:iso(1800000)}
const totals=aggregateIntent({placeId:'venue-a',windowStart:iso(-3600000),windowEnd:iso(3600000),now:aggregateNow,goRows:[goRow,goRow,{...goRow,user_id:'private-b'},{...goRow,user_id:'expired',expires_at:iso(-1)},{...goRow,user_id:'cancelled',active:false},{...goRow,user_id:'outside',place_id:'venue-b'}],planRows:[planRow,planRow,{...planRow,user_id:'private-c'},{...planRow,user_id:'maybe',response:'maybe'},{...planRow,user_id:'cancelled',status:'cancelled'},{...planRow,user_id:'removed',member_active:false}]})
assert.equal(totals.going_count,2);assert.equal(totals.planning_count,2);assert.ok(!JSON.stringify(totals).includes('private'));assert.equal(Object.keys(totals).length,5)
assert.throws(()=>aggregateIntent({placeId:'venue-a',windowStart:iso(1),windowEnd:iso(3600000),now:aggregateNow}),/Invalid/)
process.stdout.write('PASS: server aggregate deduplication, cancellations, expired GO, revoked membership, separate intent metrics and identity-free output\n')
