import assert from 'node:assert/strict'
const storage=()=>{const map=new Map();return {getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k),get length(){return map.size},key:i=>[...map.keys()][i]}}
globalThis.localStorage=storage();globalThis.sessionStorage=storage();localStorage.setItem('lit-v2-prefs','null')
const elements=new Map(),listeners={}
const classes={add(){},remove(){},toggle(){}}
function element(id){if(!elements.has(id)){const e={_html:'',get innerHTML(){return this._html},set innerHTML(x){this._html=x},get children(){return this._html?[{}]:[]},textContent:'',style:{},classList:classes,dataset:{},disabled:false,querySelectorAll:()=>[],querySelector:()=>null,addEventListener(){},setAttribute(){},focus(){document.activeElement=this},setSelectionRange(){},play:async()=>{},pause(){},getClientRects:()=>[{}]};elements.set(id,e)}return elements.get(id)}
globalThis.document={getElementById:element,addEventListener:(k,f)=>(listeners[k]||=[]).push(f),querySelectorAll:()=>[],activeElement:{},hidden:false}
globalThis.window={addEventListener(){},LIT_CONFIG:{supabaseUrl:'https://example.test',supabaseAnonKey:'public-test'},isSecureContext:true,open:(url)=>opened.push(url)}
globalThis.IntersectionObserver=class{observe(){} disconnect(){}}
globalThis.CSS={escape:value=>String(value)}
globalThis.confirm=()=>true;globalThis.location={origin:'https://example.test',search:'',pathname:'/'};let opened=[]
let gps=[],streamRequests=[]
Object.defineProperty(globalThis,'navigator',{value:{geolocation:{getCurrentPosition:(ok,fail)=>gps.push({ok,fail})},mediaDevices:{getUserMedia:()=>new Promise(resolve=>streamRequests.push(resolve))},platform:'Linux',userAgent:'test'},configurable:true})
let time=0;Object.defineProperty(globalThis,'performance',{value:{now:()=>time},configurable:true})
class Recorder {static isTypeSupported(){return true}constructor(){this.state='inactive';this.mimeType='video/mp4';Recorder.last=this}start(){this.state='recording';Recorder.starts++}stop(){this.state='inactive';this.onstop?.()}}Recorder.starts=0;globalThis.MediaRecorder=window.MediaRecorder=Recorder
const core=await import('../public/js/core.js'),{S}=core
assert.equal(S.radius,10)
S.screen='test'
const api=await import('../public/js/api.js')
const account=await import('../public/js/account.js')
const go=await import('../public/js/go.js')
const crew=await import('../public/js/crew.js')
const business=await import('../public/js/business.js')
const venue=await import('../public/js/venue.js')
const capture=await import('../public/js/capture.js')
const settle=()=>new Promise(resolve=>setImmediate(resolve))
function action(name,data={},el=element(name)){el.dataset={action:name,...data};el.disabled=false;for(const fn of listeners.click||[])fn({target:{closest:()=>el},preventDefault(){}});return el}
let authChanged,held=new Map(),finished=new Map(),setGoCount=0
const defaultData=(name)=>name==='lit_my_profile'?{username:S.user?.id,display_name:S.user?.id}:name==='lit_my_crews'?[{id:S.user?.id,name:S.user?.id,members:[],outings:[]}]:name==='lit_my_business'?[]:name==='lit_my_go'?null:name==='lit_begin_capture'?{session_id:'capture',upload_path:'capture.mp4',mime_type:'video/mp4'}:name==='lit_set_go'?{pid:'go-target',name:'Saved destination',lat:40,lon:-74}:{}
const client={auth:{getSession:async()=>({data:{session:{user:{id:'A',email:'a@example.test'}}}}),onAuthStateChange:fn=>{authChanged=fn}},rpc:async(name,args)=>{if(name==='lit_set_go')setGoCount++;if(S.user?.id==='A'&&held.has(name))return new Promise(resolve=>finished.set(name,()=>resolve({data:held.get(name),error:null})));return {data:defaultData(name),error:null}},storage:{from:()=>({createSignedUrls:async paths=>({data:paths.map(path=>({path,signedUrl:`https://example.test/${path}`}))})})}}
window.supabase={createClient:()=>client};await api.initSupabase();await settle()
held.set('lit_my_profile',{username:'old-private'});held.set('lit_my_crews',[{id:'old-private',members:[],outings:[]}]);held.set('lit_my_go',{pid:'old-private'});held.set('lit_my_business',[{place_id:'old-private',status:'verified'}])
const pending=[account.loadProfile(),crew.loadCrews(),go.loadGo(),business.loadBusiness()]
assert.equal(finished.size,4)
authChanged('SIGNED_IN',{user:{id:'B',email:'b@example.test'}});await settle();await business.loadBusiness();for(const finish of finished.values())finish();await Promise.all(pending)
assert.equal(S.profile.username,'B');assert.equal(S.crews[0].id,'B');assert.ok(!S.go||S.go.pid!=='old-private');S.screen='business';business.renderBusiness();assert.ok(!element('business').innerHTML.includes('old-private'));S.screen='test'
// Signed media must renew before expiration and never reappear after an account switch.
let signatures=0;client.storage.from=()=>({createSignedUrls:async paths=>{signatures++;return {data:paths.map(path=>({path,signedUrl:`https://example.test/${path}?n=${signatures}`}))}}})
await api.signedUrls(['clip']);await api.signedUrls(['clip']);assert.equal(signatures,1);S.urlExpires.clip=0;await api.signedUrls(['clip']);assert.equal(signatures,2)
let finishSigned;client.storage.from=()=>({createSignedUrls:async()=>new Promise(resolve=>{finishSigned=()=>resolve({data:[{path:'private',signedUrl:'https://example.test/private'}]})})});const privateUrl=api.signedUrls(['private']);authChanged('SIGNED_IN',{user:{id:'C',email:'c@example.test'}});await settle();finishSigned();await privateUrl;assert.equal(S.urls.private,undefined)
assert.equal(core.safeWebUrl('javascript:alert(1)'),null);assert.equal(core.safeWebUrl('data:text/html,test'),null);assert.equal(core.safeWebUrl(' https://example.test '),'https://example.test/');assert.ok(!core.litBadge({score:'<script>oops</script>'}).includes('<script>'))
S.go=null;S.byPid={};S.localGo={pid:'local',name:'Real saved venue',lat:40,lon:-74};await venue.directions('local');assert.ok(opened[0].includes('40%2C-74'));S.localGo=null
// Repeated GO saves serialize.
S.byPid={'go-target':{id:'go-target',name:'Destination',lat:40,lon:-74}};S.places={'go-target':{place_id:'server-place'}}
let finishGo;const normalRpc=client.rpc;client.rpc=async(name,args)=>{if(name==='lit_set_go'){setGoCount++;return new Promise(resolve=>{finishGo=()=>resolve({data:{pid:'go-target',name:'Destination'},error:null})})}return normalRpc(name,args)}
const count=setGoCount,pendingGo=go.toggleGo('go-target');await go.toggleGo('go-target');assert.equal(setGoCount,count+1);finishGo();await pendingGo;client.rpc=normalRpc
// Late camera permission results must release their own stream.
let stopped=0;const stream=()=>({getTracks:()=>[{stop(){stopped++}}]})
let opening=capture.openCapture();action('capClose');streamRequests.shift()(stream());await opening;assert.equal(stopped,1);assert.equal(element('captureRoot').innerHTML,'')
// A GPS denial during recording preparation must allow a retry.
opening=capture.openCapture();streamRequests.shift()(stream());await opening;gps.at(-1).fail({code:1});await settle();action('capShutter');gps.at(-1).fail({code:1});await settle();assert.equal(element('shutter').disabled,false)
action('capShutter');gps.at(-1).ok({coords:{latitude:40,longitude:-74,accuracy:5}});await settle();assert.equal(Recorder.starts,1);assert.equal(Recorder.last.state,'recording')
// Backgrounding an incomplete clip must not publish a short preview as fresh.
Recorder.last.ondataavailable({data:new Blob(['video'])});time=1000;document.hidden=true;for(const fn of listeners.visibilitychange||[])fn();document.hidden=false;assert.equal(element('captureRoot').innerHTML,'')
// Old GPS results must not attach to a newly opened camera.
opening=capture.openCapture();const oldGps=gps.at(-1);streamRequests.shift()(stream());await opening;action('capClose');opening=capture.openCapture();const newGps=gps.at(-1);streamRequests.shift()(stream());await opening;oldGps.ok({coords:{latitude:9,longitude:9,accuracy:5}});await settle();let beginLat;client.rpc=async(name,args)=>{if(name==='lit_begin_capture')beginLat=args.p_lat;return normalRpc(name,args)};action('capShutter');await settle();assert.equal(beginLat,undefined);gps.at(-1).ok({coords:{latitude:41,longitude:-73,accuracy:5}});await settle();assert.equal(beginLat,41);action('capClose');client.rpc=normalRpc
// Capture's GPS venue lookup must not move the user's manually selected discovery area.
S.coords={lat:12,lon:13};S.area='Manual browsing area';S.venues=[];S.byPid={};S.places={};S.feedState='ready'
opening=capture.openCapture();streamRequests.shift()(stream());await opening;gps.at(-1).ok({coords:{latitude:40,longitude:-74,accuracy:5}});await settle();action('capShutter');await settle();Recorder.last.ondataavailable({data:new Blob(['recorded video'],{type:'video/mp4'})});time+=11000;action('capShutter');await settle();assert.ok(element('captureRoot').innerHTML.includes('Review your video'))
globalThis.fetch=async()=>Response.json({venues:[{id:'geoapify:capture',name:'GPS venue',lat:40,lon:-74,category:'Bars'}]})
action('capNext');gps.at(-1).ok({coords:{latitude:40,longitude:-74,accuracy:5}});await settle();assert.equal(S.coords.lat,12);assert.equal(S.area,'Manual browsing area');assert.ok(element('capPanel').innerHTML.includes('GPS venue'))
let uploaded=0,published
client.storage.from=()=>({upload:async()=>{uploaded++;return {error:null}}})
client.rpc=async(name,args)=>{if(name==='lit_nearby_feed')return {data:{places:[{pid:'geoapify:capture',place_id:'capture-db'}]},error:null};if(name==='lit_publish_capture'){published=args;return {data:{post_id:'new-post'},error:null}}return normalRpc(name,args)}
action('capPublish');await settle();gps.at(-1).fail({code:1});await settle();assert.equal(uploaded,0);assert.equal(published,undefined)
action('capPublish');await settle();gps.at(-1).ok({coords:{latitude:40,longitude:-74,accuracy:5}});await settle();assert.equal(uploaded,1);assert.equal(published.p_place,'capture-db');assert.equal(published.p_lat,40);assert.ok(published.p_duration_ms>=10000);assert.equal(element('captureRoot').innerHTML,'');client.rpc=normalRpc
// Keyboard focus cycles inside the active dialog and background controls are inert.
const first=element('focus-first'),last=element('focus-last'),dialog={querySelectorAll:()=>[first,last],contains:x=>x===first||x===last,focus(){}}
element('sheetRoot').innerHTML='dialog';element('sheetRoot').querySelector=()=>dialog;core.syncModalState();assert.equal(element('main').inert,true);document.activeElement=last;let prevented=false;for(const fn of listeners.keydown||[])fn({key:'Tab',shiftKey:false,preventDefault(){prevented=true}});assert.equal(document.activeElement,first);assert.ok(prevented);document.activeElement=first;for(const fn of listeners.keydown||[])fn({key:'Tab',shiftKey:true,preventDefault(){}});assert.equal(document.activeElement,last);element('sheetRoot').innerHTML='';core.syncModalState();assert.equal(element('main').inert,false)
// Device clear removes caches from every discovery version.
for(const key of ['lit-v2-places','lit-v2.4-places','lit-v2.5-places'])sessionStorage.setItem(key,'cache');action('clearLocal');await settle();for(const key of ['lit-v2-places','lit-v2.4-places','lit-v2.5-places'])assert.equal(sessionStorage.getItem(key),null)
// Playback recovery refreshes signed media without crossing accounts.
let renewed=0;client.storage.from=()=>({createSignedUrls:async paths=>{renewed++;return {data:paths.map(path=>({path,signedUrl:`https://example.test/${path}?refresh=${renewed}`}))}}})
S.posts=[{id:'recover',pid:'recover-venue',video_path:'recover.mp4'}];S.urls['recover.mp4']='https://example.test/expired'
let played=0,loaded=0;const retryMedia={load(){loaded++},play:async()=>{played++}}
const retrySlide={dataset:{post:'recover'},querySelector:()=>retryMedia};const retryButton={closest:()=>retrySlide,dataset:{},setAttribute(){},innerHTML:''}
const watch=await import('../public/js/watch.js');await watch.retryVideo(retryButton);assert.equal(renewed,1);assert.equal(loaded,1);assert.equal(played,1);assert.equal(retryButton.dataset.action,'togglePlay');assert.ok(retryMedia.src.includes('refresh=1'))
// Moderation must require an explicit server authorization result; deny block acknowledgments.
const moderation=await import('../public/js/moderation.js');client.rpc=async(name,args)=>name==='lit_moderation_queue'?{data:{authorized:false,reports:[{id:'secret-report'}]},error:null}:normalRpc(name,args)
await assert.rejects(moderation.reviewQueue(),/access is unavailable/);assert.ok(!element('sheetRoot').innerHTML.includes('secret-report'))
element('sheetRoot').firstElementChild={addEventListener(){},querySelector:()=>null,isConnected:false}
client.rpc=async(name,args)=>name==='lit_moderation_queue'?{data:{authorized:true,reports:[{id:'test-report',reason:'Spam',details:'<script>unsafe</script>'}]},error:null}:normalRpc(name,args)
await moderation.reviewQueue();assert.ok(element('sheetRoot').innerHTML.includes('Report review'));assert.ok(element('sheetRoot').innerHTML.includes('&lt;script&gt;'));assert.ok(!element('sheetRoot').innerHTML.includes('<script>'));core.closeSheet()
S.posts=[{id:'block-target'}];client.rpc=async(name,args)=>name==='lit_block_post_author'?{data:{blocked:false},error:null}:normalRpc(name,args)
await assert.rejects(moderation.blockPostAuthor('block-target'),/could not be confirmed/);assert.equal(S.posts.length,1)
client.rpc=normalRpc
// Signed-out GO must open authentication without saving device intent or calling GO.
// Newly discovered venues use authenticated server registration; errors remain visible.
S.user={id:'registration-user'};
const discovery=await import('../public/js/places.js');
S.byPid={'geoapify:new':{id:'geoapify:new',name:'New venue',lat:40,lon:-74}};S.places={};
const originalSession=client.auth.getSession,originalFetch=globalThis.fetch;
client.auth.getSession=async()=>({data:{session:{access_token:'user-token'}}});
client.rpc=async(name,args)=>name==='lit_nearby_feed'?{data:{places:[],posts:[]},error:null}:normalRpc(name,args);
globalThis.fetch=async(url,options)=>{
  assert.equal(url,'/api/register-place');assert.equal(options.headers.Authorization,'Bearer user-token');
  assert.equal(JSON.parse(options.body).id,'geoapify:new');
  return Response.json({place:{pid:'geoapify:new',place_id:'registered-id'}});
};
assert.equal(await discovery.ensurePlaceId('geoapify:new'),'registered-id');
assert.equal(S.places['geoapify:new'].place_id,'registered-id');
S.places={};globalThis.fetch=async()=>Response.json({error:'Provider verification failed'},{status:422});
await assert.rejects(discovery.ensurePlaceId('geoapify:new'),/Provider verification failed/);
client.auth.getSession=originalSession;globalThis.fetch=originalFetch;client.rpc=normalRpc;
// Saved GO toggles to Going, cancellation clears it, and owner totals render without a score.
S.screen='business';S.venues=[];S.go=null;
S.byPid={'geoapify:new':{id:'geoapify:new',name:'New venue',lat:40,lon:-74}};
S.places={'geoapify:new':{place_id:'registered-id'}};
let goTotal=0;
client.rpc=async(name,args)=>{
  if(name==='lit_set_go'){
    goTotal=args.p_going?1:0;
    return {data:args.p_going?{pid:'geoapify:new',place_id:'registered-id',name:'New venue'}:null,error:null};
  }
  if(name==='lit_my_business')return {data:[{place_id:'registered-id',status:'verified',name:'New venue'}],error:null};
  if(name==='lit_business_dashboard')return {data:{place:{name:'New venue'},generated_at:new Date().toISOString(),
    go:{current_count:goTotal,updated_at:new Date().toISOString()},score:null,
    capabilities:{full_analytics:false,promotions:false,business_profile:false}},error:null};
  return normalRpc(name,args);
};
await go.toggleGo('geoapify:new');assert.equal(go.isGoing('geoapify:new'),true);
await business.loadBusiness();assert.ok(element('business').innerHTML.includes('Current GO intent'));
assert.ok(element('business').innerHTML.includes('font-size:32px">1</strong>'));
await go.toggleGo('geoapify:new');assert.equal(go.isGoing('geoapify:new'),false);
await business.loadBusiness();assert.ok(element('business').innerHTML.includes('font-size:32px">0</strong>'));
client.rpc=normalRpc;S.screen='test';
S.user=null;S.go=null;S.localGo={pid:'go-target'};
const savesBeforeLogin=setGoCount;
await go.toggleGo('go-target');
assert.equal(setGoCount,savesBeforeLogin);
assert.equal(go.isGoing('go-target'),false);
assert.ok(element('sheetRoot').innerHTML.includes('Sign in to save your GO destination.'));
await go.loadGo();assert.equal(S.localGo,null);
process.stdout.write('PASS: account isolation, private response races, signed URL renewal, safe links/scores, saved GO directions, duplicate GO, camera cleanup/GPS retry/short recordings, modal focus, device cache cleanup\n')
