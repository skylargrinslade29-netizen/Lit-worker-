"""Real mobile Chromium with the private Crew PostgreSQL backend. Local test server only."""
import asyncio,json,os
from pathlib import Path
from playwright.async_api import async_playwright
WIDTH=int(os.environ.get('LIT_BROWSER_WIDTH','390'))
BASE=os.environ.get('LIT_TEST_BASE','http://127.0.0.1:8767')
IDS={'owner':'11111111-1111-4111-8111-111111111111','reviewer':'22222222-2222-4222-8222-222222222222','applicant':'33333333-3333-4333-8333-333333333333','outsider':'44444444-4444-4444-8444-444444444444','customer':'55555555-5555-4555-8555-555555555555'}
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  api=await p.request.new_context()
  async def rpc(actor,name,args={}):
   r=await api.post(BASE+'/__test/rpc',headers={'Authorization':'Bearer '+IDS[actor] if actor else ''},data={'name':name,'args':args});value=await r.json();assert not value.get('error'),value;return value['data']
  await api.post(BASE+'/__test/reset')
  for name in IDS:await rpc(name,'lit_save_profile',{'p_display_name':name.title(),'p_username':name+'handle'})
  sdk=await (await api.get(BASE+'/__test/sdk.js')).text();errors=[]
  async def page_for(actor=None,url='/'):
   ctx=await browser.new_context(viewport={'width':WIDTH,'height':844})
   user={'id':IDS[actor],'email':actor+'@example.test'} if actor else None
   await ctx.add_init_script('localStorage.setItem("lit-v2-welcomed","1");localStorage.setItem("__lit_test_user",'+json.dumps(json.dumps(user))+');')
   await ctx.route('**/supabase.min.js',lambda r:r.fulfill(status=200,content_type='text/javascript',body=sdk))
   await ctx.route('https://fonts.googleapis.com/**',lambda r:r.abort());await ctx.route('https://fonts.gstatic.com/**',lambda r:r.abort())
   page=await ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());await page.goto(BASE+url,wait_until='networkidle');return page
  owner=await page_for('owner');await owner.locator('[data-to=crew]').first.click()
  await owner.locator('[data-submit=createCrew] input').fill('Friday Crew');await owner.locator('[data-submit=createCrew] button').click()
  await owner.wait_for_selector('[data-submit=addMember]')
  await owner.locator('[data-submit=addMember] input').fill('applicanthandle');await owner.locator('[data-submit=addMember] button').click()
  await owner.wait_for_function("document.querySelector('#crew').textContent.includes('Invited')")
  crews=await rpc('owner','lit_my_crews');crew=crews[0]['id'];code=crews[0]['invite_code']
  member=await page_for('applicant');await member.locator('[data-to=crew]').first.click();await member.wait_for_selector('[data-action=crewInvite][data-v="1"]')
  assert await member.locator('[data-submit=addMember]').count()==0
  await member.locator('[data-action=crewInvite][data-v="1"]').click();await member.wait_for_selector('[data-action=toggleCrew]');await member.locator('[data-action=toggleCrew]').click()
  assert await member.locator('[data-submit=addMember]').count()==0;assert await member.locator('[data-action=shareCode]').count()==0
  await owner.locator('[data-action=location]').first.click();await owner.locator('input[name=location]').fill('Test City');await owner.locator('[data-submit=manualLocation] button').click()
  await owner.wait_for_selector('[data-action=venue]');await owner.locator('[data-action=venue]').first.click();await owner.locator('#sheetBody [data-action=invite]').click()
  await owner.wait_for_selector('[data-submit=createOuting]');await owner.locator('[name=note]').fill('Meet at the entrance');await owner.locator('[data-submit=createOuting] button[type=submit]').click()
  await owner.wait_for_selector('[data-action=cancelOuting]');assert 'Meet at the entrance' in await owner.locator('#crew').inner_text()
  await member.locator('[data-action=crewRetry]').click();await member.wait_for_selector('[data-action=rsvp][data-v=in]');await member.locator('[data-action=rsvp][data-v=in]').click()
  await member.wait_for_function("document.querySelector('[data-action=rsvp][data-v=in]').getAttribute('aria-pressed')==='true'")
  assert await member.locator('[data-action=cancelOuting]').count()==0
  outings=(await rpc('owner','lit_my_crews'))[0]['outings'];place=outings[0]['place_id'];assert (await rpc(None,'lit_activity_counts',{'p_places':[place]}))[0]['activity']['planning_count']==2
  await owner.locator('[data-action=crewRetry]').click();await owner.wait_for_selector('[data-action=cancelOuting]')
  preview=Path(os.environ.get('LIT_BROWSER_OUTPUT','/workspace/lit-validation/previews'));preview.mkdir(parents=True,exist_ok=True);await owner.screenshot(path=str(preview/('crew-'+str(WIDTH)+'.png')),full_page=True)
  outsider=await page_for('outsider');await outsider.locator('[data-to=crew]').first.click();assert 'Friday Crew' not in await outsider.locator('#crew').inner_text()
  # Opening an invite link does not join until the person explicitly clicks Join.
  link=await page_for('customer','/?join='+code);await link.wait_for_selector('[data-action=confirmJoinCode]');assert await rpc('customer','lit_my_crews')==[]
  await link.locator('[data-action=confirmJoinCode]').click();await link.wait_for_selector('[data-action=toggleCrew]');assert len(await rpc('customer','lit_my_crews'))==1
  # Verified business sees exactly the same anonymous planning total.
  claim=await rpc('owner','lit_request_claim',{'p_place':place,'p_role':'Owner','p_email':'owner@example.test','p_phone':'555-0100','p_note':'Business owner','p_evidence_url':'https://example.test'})
  await rpc('owner','lit_manage_reviewer',{'p_email':'reviewer@example.test','p_enabled':True})
  q=await rpc('reviewer','lit_verification_queue');c=next(x for x in q['claims'] if x['id']==claim['claim_id'])
  await rpc('reviewer','lit_review_claim',{'p_claim':c['id'],'p_version':c['version'],'p_decision':'approve','p_method':'public_phone','p_source':'Independent public source','p_note':'Confirmed ownership by published number','p_message':'','p_checked':True,'p_allow_shared':False})
  await owner.evaluate("import('/js/core.js').then(m=>m.emit('navigate','business'))")
  await owner.wait_for_selector('#bizPlanningCount');assert await owner.locator('#bizPlanningCount').inner_text()=='2'
  # Quiet refresh does not replace a business profile draft.
  await owner.locator('textarea[name=description]').fill('Unsaved profile draft')
  await member.locator('[data-action=rsvp][data-v=pass]').click()
  await owner.evaluate("import('/js/business.js').then(m=>m.refreshBusinessQuietly())")
  assert await owner.locator('#bizPlanningCount').inner_text()=='1';assert await owner.locator('textarea[name=description]').input_value()=='Unsaved profile draft'
  await owner.evaluate("import('/js/core.js').then(m=>m.emit('navigate','crew'))");await owner.locator('[data-action=cancelOuting]').click();await owner.wait_for_function("!document.querySelector('[data-action=cancelOuting]')")
  assert (await rpc(None,'lit_activity_counts',{'p_places':[place]}))[0]['activity']['planning_count']==0
  if not await owner.locator('[data-action=rotateCrewInvite]').count():await owner.locator('[data-action=toggleCrew]').click()
  await owner.wait_for_selector('[data-action=rotateCrewInvite]');await owner.locator('[data-action=rotateCrewInvite]').click()
  for _ in range(50):
   if (await rpc('owner','lit_my_crews'))[0]['invite_code']!=code:break
   await asyncio.sleep(.1)
  else:raise AssertionError('Crew invite rotation did not complete')
  # Owner-only delete immediately removes Crew access from every member.
  await owner.locator('[data-action=leaveCrew]').click();await owner.wait_for_function("!document.querySelector('[data-action=toggleCrew]')")
  assert await rpc('applicant','lit_my_crews')==[];assert await rpc('customer','lit_my_crews')==[]
  assert await owner.evaluate('document.documentElement.scrollWidth<=innerWidth');assert not errors,errors
  await browser.close();await api.dispose();print('PASS: Crew create/invite/join, owner-only controls, venue plan creation, RSVP, anonymous business totals, draft-preserving refresh, explicit link consent, cancellation, rotation and deletion.')
asyncio.run(main())
