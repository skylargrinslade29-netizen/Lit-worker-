import assert from 'node:assert/strict'
const storage=()=>{const map=new Map();return {getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k)}}
globalThis.localStorage=storage();globalThis.sessionStorage=storage()
const elements=new Map(),listeners={}
const element=(id)=>{if(!elements.has(id))elements.set(id,{innerHTML:'',textContent:'',children:[],classList:{add(){},remove(){},toggle(){}},querySelectorAll:()=>[],querySelector:()=>null});return elements.get(id)}
globalThis.document={getElementById:element,addEventListener:(name,fn)=>(listeners[name]||=[]).push(fn),querySelectorAll:()=>[],activeElement:{},hidden:false}
globalThis.window={addEventListener(){},LIT_CONFIG:{}}
globalThis.IntersectionObserver=class {observe(){} disconnect(){}}
let gpsSuccess,gpsFailure,gpsOptions
Object.defineProperty(globalThis,'navigator',{value:{geolocation:{getCurrentPosition:(a,b,options)=>{gpsSuccess=a;gpsFailure=b;gpsOptions=options}},platform:'Linux',userAgent:'test'},configurable:true})
const {S}=await import('../public/js/core.js')
const api=await import('../public/js/api.js')
const discovery=await import('../public/js/places.js')
const {renderPick,rankedVenues,tonightPromo}=await import('../public/js/pick.js')
const {renderWatch}=await import('../public/js/watch.js')
S.screen='test';let calls=[]
const record=(id='osm:node:1',name='Fixture venue',lat=40,lon=-74)=>({id,name,lat,lon,category:'Bars',address:''})
function mock(rows){calls=[];globalThis.fetch=async(url,options)=>{calls.push({url:String(url),options});const r=rows.shift();assert.ok(r,'Unexpected client request');return r instanceof Response?r:Response.json(r)}}
const settled=()=>new Promise(resolve=>setImmediate(resolve))
const gps=discovery.locate();gpsFailure({code:1});await gps;assert.equal(S.feedState,'denied');renderPick();assert.ok(element('pick').innerHTML.includes('manualLocation'));assert.ok(element('pick').innerHTML.includes('GPS permission is off'))
mock([{lat:40,lon:-74,area:'A & B'},{venues:[record()],provider:'geoapify',coverage_miles:10}]);await discovery.searchLocation('A & B');assert.equal(S.feedState,'ready');assert.equal(S.venues.length,1);assert.equal(new URL(calls[0].url,'https://example.test').searchParams.get('q'),'A & B');let p=new URL(calls[1].url,'https://example.test').searchParams;assert.equal(p.size,3);assert.equal(p.get('lat'),'40.00000');assert.equal(p.get('lon'),'-74.00000');assert.equal(S.area,'A & B');assert.ok(S.feedError);renderPick();assert.ok(element('pick').innerHTML.includes('Fixture venue'));assert.ok(element('pick').innerHTML.includes('manualLocation'));renderWatch();assert.ok(element('feed').innerHTML.includes('Real places are ready.'));assert.ok(!element('feed').innerHTML.includes('Nobody has posted'))
mock([Response.json({error:'Temporary outage'},{status:503})]);await discovery.loadPlaces();assert.equal(S.feedState,'ready');assert.equal(S.venues.length,1);assert.ok(S.placesWarning.includes('previously loaded'));
mock([{venues:[],provider:'geoapify',coverage_miles:10}]);await discovery.loadPlaces();assert.equal(S.feedState,'ready');assert.deepEqual(S.venues,[])
mock([Response.json({error:'Provider unavailable'},{status:503})]);await discovery.loadPlaces();assert.equal(S.feedState,'error');renderPick();assert.ok(element('pick').innerHTML.includes('Nearby places couldn’t load'));assert.ok(!element('pick').innerHTML.includes('No places within'))
mock([new Response('<html>Wrong route</html>',{headers:{'content-type':'text/html'}})]);await discovery.loadPlaces();assert.ok(S.placesError.includes('invalid response'))
// An old geocode result must not win, even if fetch ignores cancellation.
let finishOld;calls=[];globalThis.fetch=async(url)=>{calls.push(url);const u=new URL(url,'https://example.test');if(u.searchParams.get('q')==='Old city')return new Promise(resolve=>{finishOld=()=>resolve(Response.json({lat:41,lon:-75,area:'Old'}))});if(u.pathname==='/api/geocode')return Response.json({lat:40,lon:-74,area:'New'});return Response.json({venues:[record('osm:node:new','New venue')],provider:'geoapify'})}
const old=discovery.searchLocation('Old city');await discovery.searchLocation('New city');finishOld();await old;assert.equal(S.area,'New');assert.equal(S.venues[0].name,'New venue');assert.equal(calls.filter(x=>x.startsWith('/api/places')).length,1)
// A late GPS answer must not replace a manually selected city.
const oldGps=discovery.locate();mock([{lat:40,lon:-74,area:'Manual city'},{venues:[record()],provider:'geoapify'}]);await discovery.searchLocation('Manual city');gpsSuccess({coords:{latitude:42,longitude:-76,accuracy:10}});await oldGps;assert.equal(S.area,'Manual city');assert.equal(S.locationSource,'manual')
// Old radius requests must not replace the newest list.
let finishRadius;globalThis.fetch=async(url)=>{const radius=new URL(url,'https://example.test').searchParams.get('radius');if(radius==='10')return new Promise(resolve=>{finishRadius=()=>resolve(Response.json({venues:[record('osm:node:old','Old radius')]}))});return Response.json({venues:[record('osm:node:new','New radius')],warning:'Showing real places within about 7.5 miles.',provider:'openstreetmap',coverage_miles:7.456})}
S.radius=10;const oldRadius=discovery.loadPlaces();await discovery.setRadius(25);finishRadius();await oldRadius;assert.equal(S.venues[0].name,'New radius');assert.equal(S.radius,25)
S.coords=null;S.venues=[];assert.equal(discovery.restoreCache(),true);assert.equal(S.placesProvider,'openstreetmap');assert.ok(S.placesWarning.includes('7.5'));assert.equal(S.venues[0].name,'New radius')
// New venues render while the separate live-feed RPC is still pending.
let finishFeed;let feedCalls=[];const client={auth:{getSession:async()=>({data:{session:null}}),onAuthStateChange(){}},rpc:async(name,args)=>{feedCalls.push(args);if(args.p_places?.[0]?.id==='osm:node:slow')return new Promise(resolve=>{finishFeed=()=>resolve({data:{places:[{pid:'osm:node:slow',score:{score:99}}],posts:[]},error:null})});return {data:{places:[],posts:[]},error:null}}}
window.LIT_CONFIG={supabaseUrl:'https://example.test',supabaseAnonKey:'public-test'};window.supabase={createClient:()=>client};await api.initSupabase()
mock([{venues:[record('osm:node:slow','Slow feed venue')],provider:'geoapify'}]);const slow=discovery.loadPlaces();await settled();assert.equal(S.feedState,'ready');renderPick();assert.ok(element('pick').innerHTML.includes('Slow feed venue'))
mock([{lat:40,lon:-74,area:'Latest city'},{venues:[record('osm:node:latest','Latest venue')],provider:'geoapify'}]);await discovery.searchLocation('Latest city');finishFeed();await slow;assert.equal(S.venues[0].name,'Latest venue');assert.ok(!S.places['osm:node:slow']);assert.equal(S.area,'Latest city')
// Submit uses the location field rather than Ask LIT's q input.
mock([{lat:40,lon:-74,area:'Submitted'},{venues:[record()],provider:'geoapify'}]);const form={dataset:{submit:'manualLocation'},elements:{namedItem:name=>({value:'10001'})},closest(){return this}};for(const callback of listeners.submit||[])callback({target:form,preventDefault(){}});await settled();assert.equal(new URL(calls[0].url,'https://example.test').searchParams.get('q'),'10001');assert.equal(S.area,'Submitted')
// Explicit current-location action requests fresh GPS and replaces manual search.
mock([{venues:[record('gps-club','GPS club',27.96,-82.44)],provider:'geoapify'}])
const currentGps=discovery.locate();assert.equal(gpsOptions.maximumAge,0);assert.equal(gpsOptions.enableHighAccuracy,true)
gpsSuccess({coords:{latitude:27.96,longitude:-82.44,accuracy:20}});await currentGps
assert.equal(S.locationSource,'gps');assert.equal(S.area,'Near you');assert.equal(S.coords.lat,27.96)
assert.equal(new URL(calls[0].url,'https://example.test').searchParams.get('lat'),'27.96000')
// Denial retains useful results, instead of clearing the user's current search.
const retryGps=discovery.locate();gpsFailure({code:1});await retryGps
assert.equal(S.coords.lat,27.96);assert.equal(S.venues[0].id,'gps-club');assert.equal(S.feedState,'ready');assert.ok(S.locationError.includes('browser settings'));renderPick();assert.ok(element('pick').innerHTML.includes('Use my current location'));assert.ok(element('pick').innerHTML.includes('Keeping your previous'))
const core=await import('../public/js/core.js')
window.isSecureContext=false;await assert.rejects(core.getPosition(),/HTTPS/);delete window.isSecureContext
const malformed=core.getPosition();gpsSuccess({coords:{latitude:NaN,longitude:0}});await assert.rejects(malformed,/could not get a location/)
const hung=core.getPosition({timeout:1});await assert.rejects(hung,/timed out/)
// All mixes category ties without pushing stronger genuine evidence down.
S.radius=10;S.category='All';S.when='now';S.places={};S.posts=[]
S.venues=Array.from({length:100},(_,i)=>({...record(`food-${i}`,`Food ${i}`),category:'Food',mi:0.1+i/100})).concat([{...record('club','Club'),category:'Party',mi:2},{...record('bar','Bar'),category:'Bars',mi:3}]);S.byPid=Object.fromEntries(S.venues.map(v=>[v.id,v]));let ranked=rankedVenues().list;assert.ok(ranked.slice(0,30).some(v=>v.id==='club'));renderPick();assert.ok(element('pick').innerHTML.includes('Nightclubs'))
// Feed registration also reserves space across categories.
const previousVenues=S.venues, previousByPid=S.byPid
S.venues=['Food','Bars','Entertainment'].flatMap(category=>Array.from({length:100},(_,i)=>({...record(`${category}-${i}`,`${category} ${i}`),category,mi:1}))).concat([{...record('club-proof','Club with potential proof'),category:'Party',mi:8}]);S.byPid=Object.fromEntries(S.venues.map(v=>[v.id,v]));await discovery.loadFeed();assert.equal(feedCalls.at(-1).p_places.length,250);assert.ok(feedCalls.at(-1).p_places.some(v=>v.id==='club-proof'));S.venues=previousVenues;S.byPid=previousByPid
S.places['food-0']={score:{score:90}};ranked=rankedVenues().list;assert.equal(ranked[0].id,'food-0');S.category='Party';assert.deepEqual(rankedVenues().list.map(v=>v.id),['club'])
const now=Date.now();assert.equal(tonightPromo([{starts_at:new Date(now-7200000).toISOString(),ends_at:new Date(now-3600000).toISOString()}]),undefined);assert.ok(tonightPromo([{title:'Active',starts_at:new Date(now-1000).toISOString(),ends_at:new Date(now+3600000).toISOString()}]));assert.equal(tonightPromo([{starts_at:'invalid',ends_at:'invalid'}]),undefined)
// Name search finds loaded venues without inventing provider records.
S.category='All';S.venueQuery='Club';assert.deepEqual(rankedVenues().list.map(v=>v.id),['club']);S.venueQuery='missing';assert.equal(rankedVenues().list.length,0);S.venueQuery=''
// Local hiding stays separate from reporting and filters fresh feed results too.
const safety=await import('../public/js/safety.js');S.posts=[{id:'hidden-clip'},{id:'visible-clip'}]
assert.equal(safety.hidePost('missing'),false);assert.equal(safety.hidePost('hidden-clip'),true);assert.deepEqual(S.posts.map(p=>p.id),['visible-clip']);assert.deepEqual(safety.visiblePosts([{id:'hidden-clip'},{id:'visible-clip'}]).map(p=>p.id),['visible-clip']);safety.clearHiddenPosts();assert.equal(safety.visiblePosts([{id:'hidden-clip'}]).length,1)
// Ask responses from a previous location must not reappear at the new location.
S.posts=[];let finishAsk;globalThis.fetch=async()=>new Promise(resolve=>{finishAsk=()=>resolve(Response.json({summary:'OLD CITY ANSWER',picks:[]}))})
const askForm={dataset:{submit:'ask'},q:{value:'clubs'},closest(){return this}}
for(const callback of listeners.submit||[])callback({target:askForm,preventDefault(){}})
await settled();assert.ok(finishAsk);S.coords={lat:28,lon:-82};core.emit('places');finishAsk();await settled();renderPick();assert.ok(!element('pick').innerHTML.includes('OLD CITY ANSWER'))
// Device-local bookmarks accept loaded venues only and do not mutate GO.
const saved=await import('../public/js/saved.js');const originalGo=S.localGo
assert.equal(saved.toggleSaved('club'),true);assert.equal(saved.isSaved('club'),true);assert.equal(saved.savedVenues()[0].name,'Club');assert.equal(S.localGo,originalGo)
const copied=saved.savedVenues();copied[0].name='Changed';assert.equal(saved.savedVenues()[0].name,'Club');assert.throws(()=>saved.toggleSaved('unknown'),/loaded real venue/);assert.equal(saved.toggleSaved('club'),false);saved.clearSavedVenues();assert.equal(saved.savedVenues().length,0)
const connectivity=await import('../public/js/connectivity.js');navigator.onLine=false;connectivity.updateConnectionNotice();assert.equal(element('connectionNotice').hidden,false);assert.ok(element('connectionNotice').innerHTML.includes('offline'));navigator.onLine=true;connectivity.updateConnectionNotice(true);assert.ok(element('connectionNotice').innerHTML.includes('Refresh connection'));connectivity.updateConnectionNotice();assert.equal(element('connectionNotice').hidden,true)
const currentTime=Date.now();const timestamp=(offset)=>new Date(currentTime+offset).toISOString()
const expirationFixtures=[{id:'fresh',created_at:timestamp(-1000)},{id:'expired',created_at:timestamp(-1000),expires_at:timestamp(-1)},{id:'old',created_at:timestamp(-25*3600000)},{id:'invalid',created_at:'invalid'},{id:'future',created_at:timestamp(120000)}]
assert.deepEqual(discovery.freshPosts(expirationFixtures,currentTime).map(p=>p.id),['fresh']);S.posts=expirationFixtures;assert.equal(discovery.pruneExpiredPosts(),true);assert.equal(S.posts.length,1);assert.equal(discovery.pruneExpiredPosts(),false)
// Autoplay/data-saver settings persist as booleans without removing filters.
S.autoplay=false;S.dataSaver=true;core.savePrefs();const storedPrefs=JSON.parse(localStorage.getItem('lit-v2-prefs'));assert.equal(storedPrefs.autoplay,false);assert.equal(storedPrefs.dataSaver,true);assert.equal(storedPrefs.radius,S.radius)
const resources=await import('../public/js/resources.js');window.LIT_CONFIG.links={terms:'https://example.test/terms',privacy:'javascript:alert(1)',support:'https://example.test/support'};const links=resources.resourceLinks();assert.ok(links.includes('Contact support'));assert.ok(links.includes('Terms'));assert.ok(!links.includes('javascript'));assert.ok(!links.includes('Privacy policy'));delete window.LIT_CONFIG.links
S.coords={lat:40,lon:-74};S.feedState='ready';S.byPid={fixture:record('fixture','Playback venue')};S.places={};S.urls={'fixture.mp4':'https://example.test/fixture.mp4'};S.posts=[{id:'playback',pid:'fixture',video_path:'fixture.mp4',created_at:new Date().toISOString()}];S.dataSaver=true;renderWatch();assert.ok(element('feed').innerHTML.includes('preload="none"'));S.dataSaver=false;renderWatch();assert.ok(element('feed').innerHTML.includes('preload="auto"'))
// Anonymous aggregates show zero honestly, reject invalid/stale counts and never render identities.
const activity=await import('../public/js/activity.js');const activityNow=Date.now()
const serverActivity={going_count:50,planning_count:75,updated_at:new Date(activityNow-60000).toISOString(),window_start:new Date(activityNow-3600000).toISOString(),window_end:new Date(activityNow+3600000).toISOString(),names:['SECRET NAME'],user_ids:['SECRET ID']}
const activityPlace={activity:serverActivity,score:{score:84},pid:'fixture'}
let publicNumbers=activity.publicActivity(activityPlace,activityNow);assert.equal(publicNumbers.going,50);assert.equal(publicNumbers.planning,75)
let html=activity.activityMarkup(activityPlace,{now:activityNow});assert.ok(html.includes('<strong>50</strong> going'));assert.ok(html.includes('<strong>75</strong> planning to go'));assert.ok(html.includes('84/100'));assert.ok(!html.includes('SECRET'));assert.ok(html.includes('not attendance'))
assert.equal(activity.publicActivity({activity:{...serverActivity,going_count:0}},activityNow).going,0)
for(const bad of [-1,1.5,'50',null,true,Infinity,Number.MAX_SAFE_INTEGER+1])assert.equal(activity.publicActivity({activity:{...serverActivity,going_count:bad}},activityNow).going,null)
assert.equal(activity.publicActivity({activity:{...serverActivity,updated_at:new Date(activityNow-16*60000).toISOString()}},activityNow).going,null)
assert.equal(activity.publicActivity({activity:{...serverActivity,window_end:new Date(activityNow-1).toISOString()}},activityNow).going,null)
assert.equal(activity.publicActivity({},activityNow).going,null);assert.ok(activity.activityMarkup({}).includes('unavailable'));assert.ok(!activity.activityMarkup({score:{score:null}}).includes('0/100'))
S.category='All';S.venueQuery='';S.venues=[record('fixture','Count venue')];S.byPid={fixture:S.venues[0]};S.places={fixture:activityPlace};renderPick();assert.ok(element('pick').innerHTML.includes('<strong>50</strong> going'));renderWatch();assert.ok(element('feed').innerHTML.includes('84/100'))
// Upload retries are bounded and preserve the same non-overwriting session object.
const uploads=await import('../public/js/upload.js');let uploadCalls=[]
const options={upsert:false,contentType:'video/mp4'};const uploadBucket={upload:async(...args)=>{uploadCalls.push(args);return uploadCalls.length===1?{error:{statusCode:503,message:'Temporary'}}:{error:null}}}
assert.equal((await uploads.uploadRecording(uploadBucket,'owned/session.mp4',new Blob(['video']),options)).error,null);assert.equal(uploadCalls.length,2);assert.equal(uploadCalls[0][0],uploadCalls[1][0]);assert.equal(uploadCalls[1][2].upsert,false)
let denied=0;await uploads.uploadRecording({upload:async()=>{denied++;return{error:{statusCode:403,message:'Denied'}}}},'same',new Blob(['v']),options);assert.equal(denied,1)
let failed=0;await uploads.uploadRecording({upload:async()=>{failed++;return{error:{statusCode:503}}}},'same',new Blob(['v']),options);assert.equal(failed,2)
await assert.rejects(uploads.uploadRecording(uploadBucket,'same',new Blob(['v']),options,()=>false),/cancelled/)
process.stdout.write('PASS: GPS denial, manual query encoding, persistent search form, venues without feed backend, HTML/503 handling, geocode/GPS/radius/feed race protection, cache metadata, form submission\n')
