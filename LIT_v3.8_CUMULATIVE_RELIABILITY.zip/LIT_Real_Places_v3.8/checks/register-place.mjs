import assert from 'node:assert/strict'
import register from '../netlify/functions/register-place.mjs'
const originalFetch=globalThis.fetch
const old=Object.fromEntries(['SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY','GEOAPIFY_API_KEY'].map(name=>[name,process.env[name]]))
const originalWarn=console.warn,logs=[]
console.warn=message=>logs.push(JSON.parse(message))
const request=(body,token='Bearer test-user')=>new Request('https://example.test/api/register-place',{
  method:'POST',headers:{Authorization:token,'Content-Type':'application/json'},body:JSON.stringify(body)
})
try {
  assert.equal((await register(request({},''))).status,401)
  delete process.env.SUPABASE_URL;delete process.env.SUPABASE_SERVICE_ROLE_KEY
  const missing=await register(request({}));assert.equal(missing.status,503);const problem=await missing.json();assert.equal(problem.code,'REG_CONFIGURATION');assert.match(problem.reference,/^[a-f0-9-]{36}$/)
  process.env.SUPABASE_URL='https://example.supabase.co'
  process.env.SUPABASE_SERVICE_ROLE_KEY='server-only-test'
  process.env.GEOAPIFY_API_KEY='test-provider'
  let inserted=null,providerCalls=0
  globalThis.fetch=async (input,options={})=>{
    const url=new URL(String(input))
    if(url.pathname==='/auth/v1/user'){
      assert.equal(options.headers.Authorization,'Bearer test-user')
      return Response.json({id:'user-test'})
    }
    if(url.hostname==='api.geoapify.com'){
      providerCalls++
      return Response.json({features:[{geometry:{coordinates:[-74,40]},properties:{place_id:'trusted-venue',name:'Provider name',categories:['catering.bar'],formatted:'Provider address'}}]})
    }
    if(url.pathname.startsWith('/rest/v1/rpc/')){
      assert.equal(options.headers.Authorization,'Bearer server-only-test')
      const body=JSON.parse(options.body)
      if(url.pathname.endsWith('/lit_public_place'))return Response.json(null)
      assert.equal(body.p_actor,'user-test')
      if(url.pathname.endsWith('/lit_reserve_place_lookup'))return Response.json({allowed:true})
      if(url.pathname.endsWith('/lit_register_verified_place')){
        inserted=body.p_place;return Response.json({pid:inserted.id,place_id:'database-venue',provider_verified:true})
      }
    }
    throw new Error('Unexpected request')
  }
  assert.equal((await register(request({id:'geoapify:trusted-venue',lat:100,lon:0}))).status,400)
  const response=await register(request({id:'geoapify:trusted-venue',lat:40,lon:-74,name:'Forged name'}))
  assert.equal(response.status,200)
  assert.deepEqual((await response.json()).place,{pid:'geoapify:trusted-venue',place_id:'database-venue',provider_verified:true})
  assert.ok(providerCalls>0)
  assert.equal(inserted.name,'Provider name')
  assert.equal(inserted.id,'geoapify:trusted-venue')
  assert.equal(inserted.lat,40)
  inserted=null
  assert.equal((await register(request({id:'geoapify:missing',lat:40,lon:-74}))).status,422)
  assert.equal(inserted,null)
  globalThis.fetch=async()=>Response.json({error:'expired'},{status:401})
  assert.equal((await register(request({id:'geoapify:trusted-venue',lat:40,lon:-74}))).status,401)
  globalThis.fetch=async(input)=>String(input).includes('/auth/v1/user') ? Response.json({id:'user-test'}) : Response.json({code:'PGRST202',message:'server-only-test sensitive backend detail'},{status:404})
  const broken=await register(request({id:'geoapify:trusted-venue',lat:40,lon:-74}));const safe=await broken.json();assert.equal(safe.code,'REG_DATABASE');assert.ok(!JSON.stringify(safe).includes('sensitive backend detail'));assert.ok(!JSON.stringify(logs).includes('server-only-test'));assert.equal(logs.at(-1).stage,'venue_lookup');assert.equal(logs.at(-1).backend_code,'PGRST202');assert.equal(logs.at(-1).reference,safe.reference)
  console.log('PASS: registration authentication, configuration, input bounds, provider verification, trusted record insertion, missing venue rejection')
} finally {
  globalThis.fetch=originalFetch;console.warn=originalWarn
  for(const name of ['SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY','GEOAPIFY_API_KEY']){
    if(old[name]===undefined)delete process.env[name];else process.env[name]=old[name]
  }
}
