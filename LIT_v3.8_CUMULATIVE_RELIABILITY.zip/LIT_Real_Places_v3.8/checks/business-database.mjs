// Runs real PostgreSQL in PGlite against a fixture matching the supplied inventory.
// Keep this optional dependency outside the deployed app; see VALIDATION_v3.3.md.
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
const { PGlite } = await import(process.env.LIT_PGLITE_MODULE || '@electric-sql/pglite')
const db = new PGlite()
const ids={owner:'11111111-1111-4111-8111-111111111111',reviewer:'22222222-2222-4222-8222-222222222222',applicant:'33333333-3333-4333-8333-333333333333',outsider:'44444444-4444-4444-8444-444444444444',customer:'55555555-5555-4555-8555-555555555555'}
const fixture=`
create role anon; create role authenticated; create role service_role bypassrls;
create schema auth;
create table auth.users(id uuid primary key,email text unique,email_confirmed_at timestamptz);
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
grant usage on schema auth to anon,authenticated,service_role;
grant execute on function auth.uid() to anon,authenticated,service_role;
create table public.profiles(id uuid primary key references auth.users(id),username text unique,display_name text,account_type text not null default 'consumer' check(account_type in ('consumer','business','admin')),avatar_url text);
create table public.lit_places_v2(id uuid primary key default gen_random_uuid(),name text not null,address text,latitude double precision check(latitude between -90 and 90),longitude double precision check(longitude between -180 and 180),category text,provider text,provider_place_id text,created_at timestamptz not null default now(),unique(provider,provider_place_id));
create table public.lit_business_claims_v2(id uuid primary key default gen_random_uuid(),place_id uuid not null references public.lit_places_v2(id),claimant_id uuid not null references auth.users(id),status text not null default 'pending' check(status in ('pending','verified','rejected')),created_at timestamptz not null default now(),unique(place_id,claimant_id));
create table public.lit_go_intents_v2(user_id uuid not null references auth.users(id),place_id uuid not null references public.lit_places_v2(id),created_at timestamptz not null default now(),primary key(user_id,place_id));
create table public.lit_venue_posts_v2(id uuid primary key default gen_random_uuid(),place_id uuid not null references public.lit_places_v2(id),author_id uuid not null references auth.users(id),video_path text not null,post_type text not null default 'community',created_at timestamptz not null default now(),expires_at timestamptz not null default now()+interval '24 hours',deleted_at timestamptz);
grant usage on schema public to anon,authenticated,service_role;
grant all on all tables in schema public to anon,authenticated,service_role;
alter table public.profiles enable row level security;
create policy profile_read on public.profiles for select using(true);
create policy profile_update on public.profiles for update using(auth.uid()=id);
alter table public.lit_places_v2 enable row level security;
create policy place_read on public.lit_places_v2 for select using(true);
create policy place_insert on public.lit_places_v2 for insert to authenticated with check(auth.uid() is not null);
alter table public.lit_business_claims_v2 enable row level security;
create policy claim_read on public.lit_business_claims_v2 for select to authenticated using(claimant_id=auth.uid());
create policy claim_insert on public.lit_business_claims_v2 for insert to authenticated with check(claimant_id=auth.uid() and status='pending');
alter table public.lit_go_intents_v2 enable row level security;
create policy go_own on public.lit_go_intents_v2 for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
alter table public.lit_venue_posts_v2 enable row level security;
create policy posts_read on public.lit_venue_posts_v2 for select to authenticated using(deleted_at is null and expires_at>now());
`
async function actor(who,role='authenticated'){
  await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[who?ids[who]:'']);await db.exec(`set role ${role}`)
}
async function call(name,args=[]){
  const placeholders=args.map((_,i)=>`$${i+1}`).join(',')
  return (await db.query(`select public.${name}(${placeholders}) as result`,args)).rows[0].result
}
async function admin(sql,args=[]){await db.exec('reset role');return db.query(sql,args)}
async function denied(work,pattern=/permission denied|required|Sign in|owner|own business claim/){await assert.rejects(work,pattern)}
try {
  await db.exec(fixture)
  for(const [name,id] of Object.entries(ids))await db.query('insert into auth.users values($1,$2,now())',[id,`${name}@example.test`])
  const migration=readFileSync(new URL('../SUPABASE_v3.3_BUSINESS_SYSTEM.sql',import.meta.url),'utf8')
  await db.exec(migration)
  await db.exec(migration) // Existing data and owner grants must survive reruns.
  await actor('applicant');assert.deepEqual(await call('lit_review_access'),{can_review:false,is_owner:false})
  await denied(()=>call('lit_manage_reviewer',['reviewer@example.test',true]))
  await denied(()=>db.query('insert into lit_private.owner_config(user_id) values($1)',[ids.applicant]))
  const bootstrap=readFileSync(new URL('../SUPABASE_OWNER_SETUP.sql',import.meta.url),'utf8').replace(/owner_email text:='[^']*'/,"owner_email text:='owner@example.test'")
  await db.exec('reset role');await db.exec(bootstrap);await db.exec(bootstrap)
  await actor('owner');assert.deepEqual(await call('lit_review_access'),{can_review:true,is_owner:true})
  await call('lit_manage_reviewer',['reviewer@example.test',true])
  await actor('reviewer');assert.deepEqual(await call('lit_review_access'),{can_review:true,is_owner:false})
  await denied(()=>call('lit_manage_reviewer',['outsider@example.test',true]))
  await actor('customer','service_role');await call('lit_reserve_place_lookup',[ids.customer])
  const place=await call('lit_register_verified_place',[ids.customer,{id:'geoapify:real-venue',name:'Real venue',lat:40,lon:-74,category:'Bars',address:'Public address'}])
  const second=await call('lit_register_verified_place',[ids.customer,{id:'osm:node:42',name:'Second venue',lat:40,lon:-74,category:'Bars'}])
  assert.equal((await call('lit_register_verified_place',[ids.customer,{id:'geoapify:real-venue',name:'Real venue',lat:40,lon:-74}])).place_id,place.place_id)
  await actor('applicant')
  await denied(()=>call('lit_register_verified_place',[ids.applicant,{id:'geoapify:forged',name:'Fake',lat:0,lon:0}]))
  await denied(()=>db.query('insert into public.lit_places_v2(name) values($1)',['Forged venue']))
  const submitted=await call('lit_request_claim',[place.place_id,'Owner','business@example.test','555-0100','I run this business.','https://example.test/business'])
  assert.equal(submitted.status,'pending')
  await denied(()=>db.query("update public.lit_business_claims_v2 set status='verified' where id=$1",[submitted.claim_id]))
  await denied(()=>call('lit_business_dashboard',[place.place_id]))
  await denied(()=>call('lit_verification_queue'))
  await actor('reviewer')
  let claim=(await call('lit_verification_queue')).claims[0]
  assert.equal(claim.id,submitted.claim_id);assert.equal(claim.account_email,'applicant@example.test')
  const review=(decision,version=claim.version,checked=true,shared=false)=>call('lit_review_claim',[claim.id,version,decision,'public_phone','Independent public listing','Called the published business number.','',checked,shared])
  await denied(()=>review('approve',claim.version,false),/independent verification/)
  await review('approve')
  await denied(()=>review('approve'),/changed|pending/)
  assert.ok((await call('lit_claim_audit',[claim.id])).some(x=>x.action==='claim_approve'))
  await actor('applicant')
  assert.equal((await call('lit_my_business'))[0].status,'verified')
  assert.equal((await call('lit_my_business'))[0].reviewer_note,undefined)
  await call('lit_save_business_profile',[place.place_id,'Venue description','https://example.test','555-0100','Daily 5–11pm'])
  await denied(()=>call('lit_save_business_profile',[place.place_id,'Venue description','javascript:alert(1)','','']),/HTTP/)
  await actor('outsider')
  await denied(()=>call('lit_business_dashboard',[place.place_id]))
  await denied(()=>call('lit_save_business_profile',[place.place_id,'Spoof','','','']))
  await denied(()=>db.query('select reviewer_note from public.lit_business_claims_v2'))
  await actor('customer')
  const go=await call('lit_set_go',[place.place_id,true]);assert.equal(go.pid,'geoapify:real-venue')
  assert.ok(Date.parse(go.expires_at)>Date.now()+11*3600000)
  assert.equal((await call('lit_nearby_feed',[[{id:'geoapify:real-venue',name:'Fake input',lat:1,lon:1}]] )).places[0].name,'Real venue')
  await actor('applicant');assert.equal((await call('lit_business_dashboard',[place.place_id])).go.current_count,1)
  await actor('customer');await call('lit_set_go',[place.place_id,false]);assert.equal(await call('lit_my_go'),null)
  await actor('applicant');assert.equal((await call('lit_business_dashboard',[place.place_id])).go.current_count,0)
  await actor('customer');await call('lit_set_go',[place.place_id,true]);await call('lit_set_go',[second.place_id,true])
  await actor('applicant');assert.equal((await call('lit_business_dashboard',[place.place_id])).go.current_count,0)
  await admin("update public.lit_go_intents_v2 set expires_at=now()-interval '1 second' where user_id=$1",[ids.customer])
  await actor('customer');assert.equal(await call('lit_my_go'),null)
  await denied(()=>db.query('insert into public.lit_go_intents_v2(user_id,place_id) values($1,$2)',[ids.customer,place.place_id]))
  await actor(null,'anon')
  const publicVenue=await call('lit_public_place',['geoapify:real-venue']);assert.equal(publicVenue.venue.name,'Real venue')
  assert.equal((await call('lit_place_details',[place.place_id])).profile.description,'Venue description')
  const feed=await call('lit_nearby_feed',[[{id:'geoapify:real-venue'}]])
  assert.equal(feed.places[0].claimed,true);assert.equal(feed.places[0].activity.going_count,0)
  assert.equal(feed.places[0].activity.planning_count,null);assert.deepEqual(feed.posts,[])
  await denied(()=>call('lit_set_go',[place.place_id,true]));await denied(()=>call('lit_verification_queue'))
  await actor('owner');await call('lit_manage_reviewer',['reviewer@example.test',false])
  await actor('reviewer');await denied(()=>call('lit_verification_queue'));await denied(()=>call('lit_claim_audit',[claim.id]))
  await actor('owner')
  const verified=(await call('lit_verification_queue',['verified'])).claims[0]
  await call('lit_review_claim',[verified.id,verified.version,'revoke','','','Business no longer authorized.','Your venue access was revoked.',false,false])
  await actor('applicant');await denied(()=>call('lit_business_dashboard',[place.place_id]));await denied(()=>call('lit_save_business_profile',[place.place_id,'Edit','','','']))
  await actor(null,'anon');assert.equal((await call('lit_place_details',[place.place_id])).profile,null)
  await admin('insert into public.profiles(id,account_type) values($1,$2)',[ids.outsider,'admin'])
  await actor('outsider');assert.equal((await call('lit_review_access')).can_review,false)
  await denied(()=>db.query('select * from lit_private.verification_audit'))
  await denied(()=>db.query('select * from lit_private.reviewers'))
  // Owner bootstrap cannot silently transfer control to a different account.
  await db.exec('reset role')
  await assert.rejects(()=>db.exec(bootstrap.replace('owner@example.test','outsider@example.test')),/already configured/)
  await db.exec('rollback')
  await actor('owner');await call('lit_manage_reviewer',['reviewer@example.test',true])
  await actor('reviewer')
  const selfClaim=await call('lit_request_claim',[second.place_id,'Staff (authorised)','reviewer@example.test','','Authorized staff.'])
  let pending=(await call('lit_verification_queue')).claims.find(c=>c.id===selfClaim.claim_id)
  await denied(()=>call('lit_review_claim',[pending.id,pending.version,'approve','public_phone','Public listing','Confirmed through official number.','',true,false]),/own business claim/)
  // Request information, resubmit, reject stale review, then approve explicitly.
  await actor('applicant')
  const followup=await call('lit_request_claim',[second.place_id,'Owner','applicant@example.test','','I own this venue.'])
  await actor('reviewer');pending=(await call('lit_verification_queue')).claims.find(c=>c.id===followup.claim_id)
  const beforeResubmit=pending.version
  await call('lit_review_claim',[pending.id,pending.version,'request_info','','','Need business authorization proof.','Please provide your official business page.',false,false])
  await actor('applicant')
  let own=(await call('lit_my_business')).find(c=>c.id===followup.claim_id)
  assert.equal(own.needs_information,true);assert.equal(own.reviewer_note,undefined)
  assert.equal(own.message,'Please provide your official business page.')
  await admin("update public.lit_business_claims_v2 set updated_at=now()-interval '31 seconds' where id=$1",[followup.claim_id])
  await actor('applicant');await call('lit_request_claim',[second.place_id,'Owner','applicant@example.test','','See our official page.','https://example.test/official'])
  own=(await call('lit_my_business')).find(c=>c.id===followup.claim_id);assert.equal(own.needs_information,false)
  await actor('reviewer')
  await denied(()=>call('lit_review_claim',[followup.claim_id,beforeResubmit,'approve','public_phone','Public listing','Confirmed authorization.','',true,false]),/changed/)
  pending=(await call('lit_verification_queue')).claims.find(c=>c.id===followup.claim_id)
  await call('lit_review_claim',[pending.id,pending.version,'approve','public_phone','Public listing','Confirmed authorization.','',true,false])
  // An additional account requires a specific authorization acknowledgment.
  await actor('outsider')
  const extra=await call('lit_request_claim',[second.place_id,'General manager','outsider@example.test','','Authorized manager.'])
  await actor('reviewer');pending=(await call('lit_verification_queue')).claims.find(c=>c.id===extra.claim_id)
  assert.equal(pending.other_verified_accounts,1)
  await denied(()=>call('lit_review_claim',[pending.id,pending.version,'approve','public_phone','Public listing','Confirmed manager.','',true,false]),/already has verified access/)
  await call('lit_review_claim',[pending.id,pending.version,'approve','public_phone','Public listing','Confirmed manager.','',true,true])
  // Cursor paging must not skip tied timestamps or duplicate rows.
  await actor('customer');const paginationClaim=await call('lit_request_claim',[place.place_id,'Owner','customer@example.test','','Claim for test pagination.'])
  await admin("update public.lit_business_claims_v2 set updated_at='2026-01-01T00:00:00Z' where status='pending'")
  await actor('reviewer')
  const first=await call('lit_verification_queue',['pending',null,1]);assert.equal(first.has_more,true)
  const next=await call('lit_verification_queue',['pending',first.next_cursor,1])
  assert.notEqual(first.claims[0].id,next.claims[0].id)
  const customerClaim=[...first.claims,...next.claims].find(c=>c.id===paginationClaim.claim_id)
  assert.ok(customerClaim)
  await denied(()=>call('lit_review_claim',[customerClaim.id,customerClaim.version,'reject','','','Invalid authorization.','',false,false]),/message/)
  // Existing provider identities are reverified without changing their UUIDs.
  const legacy=(await admin("insert into public.lit_places_v2(name,provider,provider_place_id,latitude,longitude) values('Legacy venue','openstreetmap','node:99',40,-74) returning id")).rows[0].id
  await actor('customer');await denied(()=>call('lit_set_go',[legacy,true]),/provider verification/)
  await actor('customer','service_role')
  assert.equal((await call('lit_register_verified_place',[ids.customer,{id:'osm:node:99',name:'Verified legacy venue',lat:40,lon:-74}])).place_id,legacy)
  // Rate limits persist in the database, independent of function instances.
  await actor('customer','service_role');for(let i=0;i<11;i++)await call('lit_reserve_place_lookup',[ids.customer])
  await denied(()=>call('lit_reserve_place_lookup',[ids.customer]),/wait a minute/)
  await admin('update lit_private.place_lookup_limits set daily_count=200 where user_id=$1',[ids.customer])
  await actor('customer','service_role');await denied(()=>call('lit_reserve_place_lookup',[ids.customer]),/Daily/)
  await db.exec('reset role');await db.exec(migration)
  await actor('owner');assert.equal((await call('lit_review_access')).is_owner,true)
  console.log('PASS: real PostgreSQL migration/rerun, private owner bootstrap, delegated review/revocation, denied self-escalation/direct writes, verified-only business access, private audit, GO/cancel/switch/expiry, anonymous aggregates, provider registration and quotas')
} finally {await db.close()}
