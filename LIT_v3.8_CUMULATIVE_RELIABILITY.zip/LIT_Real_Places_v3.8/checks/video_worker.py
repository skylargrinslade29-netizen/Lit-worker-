import importlib.util
from pathlib import Path
import subprocess
import tempfile
import shutil

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('video_prepare', root / 'workers/video_prepare.py')
worker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(worker)
if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
    raise SystemExit('FFmpeg/FFprobe required for video worker integration checks.')
with tempfile.TemporaryDirectory(prefix='lit-worker-test-') as temporary:
    directory = Path(temporary)
    def clip(name, duration):
        path = directory / name
        subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-f', 'lavfi', '-i', f'color=c=black:s=320x240:r=15:d={duration}', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', '-metadata', 'location=private-gps', str(path)], check=True)
        return path
    valid = clip('input.mp4', 11)
    output = directory / 'prepared.mp4'
    result = worker.prepare(valid, output)
    assert result['codec'] == 'h264' and result['content_type'] == 'video/mp4'
    assert 10 <= result['duration_seconds'] <= 30.1
    assert valid.exists()
    assert 'private-gps' not in worker.run(['ffprobe','-v','error','-show_format','-of','json',str(output)],30)
    for source, destination in [(clip('short.mp4', 2), directory / 'short-output.mp4'), (clip('long.mp4', 31), directory / 'long-output.mp4'), (valid, output)]:
        try:
            worker.prepare(source, destination)
            raise AssertionError('Invalid video or overwrite was accepted')
        except ValueError:
            pass
    # Streaming/WebM output has no container Duration, as with Chrome MediaRecorder.
    browser_webm = directory / 'browser.webm'
    subprocess.run(['ffmpeg','-nostdin','-v','error','-f','lavfi','-i','color=c=black:s=320x240:r=15:d=11','-c:v','libvpx','-deadline','realtime','-f','webm','-live','1',str(browser_webm)],check=True)
    browser_result = worker.prepare(browser_webm, directory / 'browser-prepared.mp4')
    assert 10 <= browser_result['duration_seconds'] <= 30.1
    bad = directory / 'broken.mp4'; bad.write_text('not a video')
    try:
        worker.prepare(bad, directory / 'bad-output.mp4')
        raise AssertionError('Malformed media was accepted')
    except ValueError:
        pass
print('PASS: real FFmpeg conversion, duration measurement, malformed/short/long rejection and overwrite prevention')
