// LOCAL TEST SERVER ONLY. Never used by Netlify or shipped as an API function.
import { createServer } from 'node:http'
import { readFileSync, existsSync } from 'node:fs'
import { resolve, extname } from 'node:path'
const { PGlite } = await import(process.env.LIT_PGLITE_MODULE || '@electric-sql/pglite')
const root=resolve(new URL('../',import.meta.url).pathname),db=new PGlite()
const fixture=readFileSync(resolve(root,'checks/business-database.mjs'),'utf8').match(/const fixture=`([\s\S]*?)`/)[1]
await db.exec(fixture)
await db.exec(readFileSync(resolve(root,'checks/video-safety-database.mjs'),'utf8').match(/const storage=`([\s\S]*?)`/)[1])
const users={owner:'11111111-1111-4111-8111-111111111111',reviewer:'22222222-2222-4222-8222-222222222222',applicant:'33333333-3333-4333-8333-333333333333',outsider:'44444444-4444-4444-8444-444444444444',customer:'55555555-5555-4555-8555-555555555555'}
for(const [name,id] of Object.entries(users))await db.query('insert into auth.users values($1,$2,now())',[id,`${name}@example.test`])
await db.exec(readFileSync(resolve(root,'SUPABASE_v3.3_BUSINESS_SYSTEM.sql'),'utf8'))
await db.exec(readFileSync(resolve(root,'SUPABASE_v3.5_CREW_BACKEND.sql'),'utf8'))
await db.exec(readFileSync(resolve(root,'SUPABASE_v3.6_ARRIVAL_PROMOTIONS.sql'),'utf8'))
await db.exec(readFileSync(resolve(root,'SUPABASE_v3.7_VIDEO_SAFETY.sql'),'utf8'))
await db.exec(readFileSync(resolve(root,'SUPABASE_OWNER_SETUP.sql'),'utf8').replace(/owner_email text:='[^']*'/,"owner_email text:='owner@example.test'"))
const venues=[{id:'geoapify:browser-club',name:'Harbor Social',lat:40,lon:-74,category:'Bars',address:'120 Harbor Street'},
  {id:'osm:node:42',name:'Night Garden',lat:40.01,lon:-74.01,category:'Party',address:'42 Garden Avenue'}]
for(const venue of venues)await db.query('select public.lit_register_verified_place($1,$2)',[users.customer,venue])
let dbChain=Promise.resolve()
function dbTask(fn){const run=dbChain.then(fn);dbChain=run.catch(()=>{});return run}
const json=(res,value,status=200)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value))}
const fakeSDK=`
window.supabase={createClient:()=>{
  let user=JSON.parse(localStorage.getItem('__lit_test_user')||'null');const listeners=[];
  const change=(next,event='SIGNED_IN')=>{user=next;localStorage.setItem('__lit_test_user',JSON.stringify(next));for(const fn of listeners)fn(event,next?{user:next,access_token:next.id}:null)};
  const session=()=>user?{user,access_token:user.id}:null;
  window.__litChangeUser=change;
  return {auth:{getSession:async()=>({data:{session:session()},error:null}),onAuthStateChange:fn=>listeners.push(fn),
    signInWithPassword:async({email})=>{const response=await fetch('/__test/login',{method:'POST',body:JSON.stringify({email})});const result=await response.json();if(result.user){change(result.user);return {data:{user:result.user,session:session()},error:null}}return {error:{message:'Unknown test account'}}},
    signOut:async()=>{change(null,'SIGNED_OUT');return {error:null}},resetPasswordForEmail:async()=>({error:null})},
    rpc:async(name,args={})=>{try{const response=await fetch('/__test/rpc',{method:'POST',headers:{'Content-Type':'application/json',Authorization:user?'Bearer '+user.id:''},body:JSON.stringify({name,args})});return await response.json()}catch{return {data:null,error:{message:'Failed to fetch'}}}},
    storage:{from:bucket=>({upload:async(path,blob)=>{const response=await fetch('/__test/upload',{method:'POST',headers:{'Content-Type':'application/json',Authorization:user?'Bearer '+user.id:''},body:JSON.stringify({bucket,path,size:blob.size})});return await response.json()},createSignedUrls:async(paths)=>({data:paths.map(path=>({path,signedUrl:'/__test/clip.mp4'})),error:null}),createSignedUrl:async()=>({data:{signedUrl:'/__test/clip.mp4'},error:null})})}}
}};
`
const server=createServer(async(req,res)=>{
  try {
    const url=new URL(req.url,'http://127.0.0.1')
    if(url.pathname==='/__test/sdk.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end(fakeSDK);return}
    if(url.pathname==='/__test/reset'){
      await dbTask(async()=>{await db.exec('reset role');await db.exec('delete from storage.objects; delete from lit_private.video_sessions; delete from lit_private.reports; delete from lit_private.blocks; delete from lit_private.moderators; delete from lit_private.deletion_requests; delete from lit_private.media_cleanup; delete from public.lit_venue_posts_v2; delete from lit_private.guest_feedback; delete from lit_private.arrivals; delete from lit_private.promotions; delete from lit_private.crews; delete from lit_private.crew_request_limits; delete from public.lit_business_profiles_v3; delete from public.lit_go_intents_v2; delete from public.lit_business_claims_v2; delete from lit_private.reviewers; delete from lit_private.verification_audit;');for(const [name,id]of Object.entries(users))await db.query('insert into auth.users(id,email,email_confirmed_at) values($1,$2,now()) on conflict(id) do update set email_confirmed_at=now()',[id,name+'@example.test'])})
      json(res,{reset:true});return
    }
    if(url.pathname==='/__test/worker'){
      let result=null;await dbTask(async()=>{await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub','',false)");await db.exec('set role service_role');
       for(let i=0;i<30;i++){const job=(await db.query('select public.lit_worker_claim() result')).rows[0].result;if(!job)break;
        await db.exec('reset role');
        if(job.kind==='cleanup')await db.query('delete from storage.objects where bucket_id=$1 and name=$2',[job.bucket,job.path]);
        else if(job.kind==='video')await db.query('insert into storage.objects(bucket_id,name,metadata) values($1,$2,$3)',['lit-fresh-videos',job.output_path,{size:5000}]);
        else if(job.kind==='deletion'){await db.query('select public.lit_worker_purge_account($1,$2)',[job.id,job.lease]);await db.query('delete from auth.users where id=$1',[job.user_id]);}
        await db.exec('set role service_role');await db.query('select public.lit_worker_result($1,$2,$3,true,$4)',[job.kind,job.id,job.lease,job.kind==='video'?{duration_ms:job.declared_ms,bytes:5000,width:320,height:240,content_type:'video/mp4'}:{}]);result=job;
       }await db.exec('reset role');});json(res,{job:result});return;
    }
    if(url.pathname==='/__test/upload'){
      let body='';for await(const part of req)body+=part;const input=JSON.parse(body),actor=req.headers.authorization?.replace(/^Bearer /,'');
      await dbTask(async()=>{await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[Object.values(users).includes(actor)?actor:'']);await db.exec('set role authenticated');
       try{await db.query('insert into storage.objects(bucket_id,name,metadata,owner_id) values($1,$2,$3,$4)',[input.bucket,input.path,{size:input.size},actor]);json(res,{data:{path:input.path},error:null})}catch(e){json(res,{error:{message:e.message}},400)}finally{await db.exec('reset role')}});return;
    }
    if(url.pathname==='/api/delete-account'){
      let body='';for await(const part of req)body+=part;const input=JSON.parse(body),actor=req.headers.authorization?.replace(/^Bearer /,'');if(!Object.values(users).includes(actor) || input.password!=='test-password'){json(res,{error:'Password could not be confirmed.'},401);return;}
      await dbTask(async()=>{await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub','',false)");await db.exec('set role service_role');try{const row=await db.query('select public.lit_request_account_deletion($1,$2) result',[actor,input.confirmation]);json(res,row.rows[0].result)}catch(e){json(res,{error:e.message},400)}finally{await db.exec('reset role')}});return;
    }
    if(url.pathname==='/api/places'){json(res,{venues,provider:'test-provider',coverage_miles:5});return}
    if(url.pathname==='/api/geocode'){json(res,{lat:40,lon:-74,area:'Test City'});return}
    if(url.pathname==='/__test/login'){
      let body='';for await(const part of req)body+=part;const email=JSON.parse(body).email;const name=email?.split('@')[0];
      json(res,{user:users[name]?{id:users[name],email:`${name}@example.test`}:null});return
    }
    if(url.pathname==='/__test/rpc'){
      let body='';for await(const part of req)body+=part;const input=JSON.parse(body)
      if(!/^lit_[a-z0-9_]+$/.test(input.name)||Object.keys(input.args).some(k=>!/^p_[a-z0-9_]+$/.test(k)))throw new Error('Invalid test RPC')
      const token=req.headers.authorization?.replace(/^Bearer /,'');const actor=Object.values(users).includes(token)?token:''
      const keys=Object.keys(input.args),args=keys.map(k=>input.args[k])
      const named=keys.map((k,i)=>`${k} => $${i+1}`).join(',')
      await dbTask(async()=>{
        await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[actor]);await db.exec(`set role ${actor?'authenticated':'anon'}`)
        try {const result=await db.query(`select public.${input.name}(${named}) as result`,args);json(res,{data:result.rows[0].result,error:null})}
        catch(error){json(res,{data:null,error:{message:error.message,code:error.code}},400)}
        finally{await db.exec('reset role')}
      });return
    }
    const path=resolve(root,'public',url.pathname==='/'?'index.html':'.'+url.pathname)
    if(!path.startsWith(resolve(root,'public')+'/')||!existsSync(path)){res.writeHead(404);res.end();return}
    const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'}
    res.writeHead(200,{'Content-Type':mime[extname(path)]||'application/octet-stream'});res.end(readFileSync(path))
  }catch(error){json(res,{error:error.message},500)}
})
const port=Number(process.env.LIT_TEST_PORT || 8765)
server.listen(port,'127.0.0.1',()=>console.log('LIT local browser test server ready at http://127.0.0.1:'+port))
