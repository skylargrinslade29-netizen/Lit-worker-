-- Complete ordered installation for LIT v3.5. Owner setup is separate.
-- LIT v3.3 cumulative migration for the schema inventoried in this chat.
-- Run once in the existing project's SQL Editor; safe to rerun.
-- Supersedes batches 1, 2 and 3. Bootstrap the owner separately afterward.
begin;

create schema if not exists lit_private;
revoke all on schema lit_private from public,anon,authenticated;

create table if not exists lit_private.owner_config (
  singleton boolean primary key default true check (singleton),
  user_id uuid not null unique references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);
create table if not exists lit_private.reviewers (
  user_id uuid primary key references auth.users(id) on delete cascade,
  granted_by uuid not null references auth.users(id),
  granted_at timestamptz not null default now(),
  revoked_at timestamptz
);
create table if not exists lit_private.verification_audit (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  claim_id uuid,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create table if not exists lit_private.place_lookup_limits (
  user_id uuid primary key references auth.users(id) on delete cascade,
  day date not null default current_date,
  daily_count integer not null default 0,
  minute timestamptz not null default date_trunc('minute',now()),
  minute_count integer not null default 0
);
alter table lit_private.owner_config enable row level security;
alter table lit_private.reviewers enable row level security;
alter table lit_private.verification_audit enable row level security;
alter table lit_private.place_lookup_limits enable row level security;

alter table public.lit_business_claims_v2
  add column if not exists business_role text,
  add column if not exists business_email text,
  add column if not exists business_phone text,
  add column if not exists applicant_note text,
  add column if not exists evidence_url text,
  add column if not exists applicant_message text,
  add column if not exists reviewed_by uuid references auth.users(id) on delete set null,
  add column if not exists reviewed_at timestamptz,
  add column if not exists verification_method text,
  add column if not exists verification_source text,
  add column if not exists reviewer_note text,
  add column if not exists review_version integer not null default 1,
  add column if not exists updated_at timestamptz not null default now();
alter table public.lit_places_v2
  add column if not exists provider_verified boolean not null default false,
  add column if not exists provider_verified_at timestamptz;
alter table public.lit_go_intents_v2 add column if not exists expires_at timestamptz;
update public.lit_go_intents_v2 set expires_at=created_at+interval '12 hours' where expires_at is null;
alter table public.lit_go_intents_v2 alter column expires_at set default (now()+interval '12 hours');
alter table public.lit_go_intents_v2 alter column expires_at set not null;
create index if not exists lit_go_place_expiry_v3 on public.lit_go_intents_v2(place_id,expires_at);
create index if not exists lit_claim_review_v3 on public.lit_business_claims_v2(status,updated_at desc,id desc);
create index if not exists lit_claim_audit_v3 on lit_private.verification_audit(claim_id,id desc);

create table if not exists public.lit_business_profiles_v3 (
  place_id uuid primary key references public.lit_places_v2(id) on delete cascade,
  description text not null default '' check (length(description)<=600),
  hours text not null default '' check (length(hours)<=200),
  phone text not null default '' check (length(phone)<=40),
  website text not null default '' check (website='' or (length(website)<=200 and website ~* '^https?://[^[:space:]]+$')),
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);
alter table public.lit_business_profiles_v3 enable row level security;
-- Functions below are the only client write/read paths for privileged claim fields.
revoke all on public.lit_business_claims_v2,public.lit_business_profiles_v3 from public,anon,authenticated;
revoke insert,update,delete,truncate,references,trigger on public.lit_places_v2,public.lit_go_intents_v2 from public,anon,authenticated;

create or replace function lit_private.is_owner()
returns boolean language sql stable security definer set search_path='' as $$
  select exists(select 1 from lit_private.owner_config where user_id=auth.uid());
$$;
create or replace function lit_private.can_review()
returns boolean language sql stable security definer set search_path='' as $$
  select lit_private.is_owner() or exists(
    select 1 from lit_private.reviewers where user_id=auth.uid() and revoked_at is null
  );
$$;
create or replace function lit_private.require_reviewer()
returns void language plpgsql security definer set search_path='' as $$
begin
  perform 1 from lit_private.owner_config where user_id=auth.uid() for share;
  if found then return; end if;
  perform 1 from lit_private.reviewers where user_id=auth.uid() and revoked_at is null for share;
  if not found then raise exception 'Business review access is required.' using errcode='42501'; end if;
end $$;
create or replace function lit_private.require_owner()
returns void language plpgsql security definer set search_path='' as $$
begin
  if not lit_private.is_owner() then raise exception 'Only the LIT owner can manage reviewers.' using errcode='42501'; end if;
end $$;
create or replace function lit_private.require_business(p_place uuid)
returns void language plpgsql security definer set search_path='' as $$
begin
  perform 1 from public.lit_business_claims_v2
  where place_id=p_place and claimant_id=auth.uid() and status='verified' for share;
  if not found then raise exception 'A verified claim for this venue is required.' using errcode='42501'; end if;
end $$;
create or replace function lit_private.pid(p_provider text,p_id text)
returns text language sql immutable set search_path='' as $$
  select case when p_id like 'geoapify:%' or p_id like 'osm:%' then p_id
    when p_provider='geoapify' then 'geoapify:'||p_id
    when p_provider in ('osm','openstreetmap') then 'osm:'||p_id
    else p_provider||':'||p_id end;
$$;
create or replace function lit_private.activity(p_place uuid)
returns jsonb language sql stable security definer set search_path='' as $$
  select jsonb_build_object('going_count',count(*),'planning_count',null,
    'updated_at',now(),'window_start',now()-interval '12 hours','window_end',now()+interval '12 hours')
  from (select distinct on (user_id) user_id,place_id from public.lit_go_intents_v2
    where expires_at>now() order by user_id,created_at desc,place_id) current_go
  where place_id=p_place;
$$;

create or replace function public.lit_review_access()
returns jsonb language sql stable security definer set search_path='' as $$
  select jsonb_build_object('can_review',lit_private.can_review(),'is_owner',lit_private.is_owner());
$$;
create or replace function public.lit_list_reviewers()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  perform lit_private.require_owner();
  select coalesce(jsonb_agg(jsonb_build_object('user_id',r.user_id,'email',u.email,
    'granted_at',r.granted_at,'active',r.revoked_at is null) order by r.granted_at desc),'[]'::jsonb)
    into result from lit_private.reviewers r join auth.users u on u.id=r.user_id;
  return result;
end $$;
create or replace function public.lit_manage_reviewer(p_email text,p_enabled boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare target uuid; normalized text:=lower(btrim(p_email));
begin
  perform lit_private.require_owner();
  if p_enabled is null or normalized is null or length(normalized)>254 then raise exception 'Enter a valid account email.'; end if;
  select id into target from auth.users where lower(email)=normalized and email_confirmed_at is not null;
  if target is null then raise exception 'This person must create a LIT account and confirm their email first.'; end if;
  if target=auth.uid() then raise exception 'The owner account cannot be changed through reviewer controls.'; end if;
  insert into lit_private.reviewers(user_id,granted_by,revoked_at)
    values(target,auth.uid(),case when p_enabled then null else now() end)
    on conflict(user_id) do update set granted_by=auth.uid(),granted_at=now(),revoked_at=excluded.revoked_at;
  insert into lit_private.verification_audit(actor_id,action,details)
    values(auth.uid(),case when p_enabled then 'reviewer_granted' else 'reviewer_revoked' end,jsonb_build_object('user_id',target));
  return jsonb_build_object('saved',true,'enabled',p_enabled);
end $$;

create or replace function public.lit_request_claim(p_place uuid,p_role text,p_email text,p_phone text,p_note text,p_evidence_url text default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); old public.lit_business_claims_v2%rowtype; new_id uuid;
  email text:=lower(btrim(p_email)); evidence text:=nullif(btrim(p_evidence_url),'');
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  if p_role is null or p_role not in ('Owner','General manager','Marketing / social','Staff (authorised)') then raise exception 'Choose your business role.'; end if;
  if email is null or length(email)>254 or email !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' then raise exception 'Enter a valid business email.'; end if;
  if length(coalesce(p_phone,''))>40 or length(coalesce(p_note,''))>600 then raise exception 'Contact details or note are too long.'; end if;
  if evidence is not null and (length(evidence)>500 or evidence !~* '^https://[^[:space:]]+$') then raise exception 'Use an HTTPS link to your official business page.'; end if;
  if not exists(select 1 from public.lit_places_v2 where id=p_place and provider_verified) then raise exception 'Refresh this venue so its provider identity can be verified first.'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:claim:'||u::text,0));
  select * into old from public.lit_business_claims_v2 where claimant_id=u and place_id=p_place for update;
  if old.status='verified' then raise exception 'This account already has verified access to this venue.'; end if;
  if old.updated_at>now()-interval '30 seconds' then raise exception 'Please wait a moment before resubmitting.'; end if;
  if old.id is null and (select count(*) from public.lit_business_claims_v2 where claimant_id=u and created_at>now()-interval '24 hours')>=10 then raise exception 'Daily claim limit reached. Try again tomorrow.'; end if;
  insert into public.lit_business_claims_v2(place_id,claimant_id,status,business_role,business_email,business_phone,applicant_note,evidence_url)
    values(p_place,u,'pending',p_role,email,btrim(coalesce(p_phone,'')),btrim(coalesce(p_note,'')),evidence)
    on conflict(place_id,claimant_id) do update set status='pending',business_role=excluded.business_role,
      business_email=excluded.business_email,business_phone=excluded.business_phone,applicant_note=excluded.applicant_note,
      evidence_url=excluded.evidence_url,applicant_message=null,reviewed_by=null,reviewed_at=null,
      verification_method=null,verification_source=null,reviewer_note=null,
      review_version=public.lit_business_claims_v2.review_version+1,updated_at=now()
    returning id into new_id;
  insert into lit_private.verification_audit(actor_id,claim_id,action)
    values(u,new_id,case when old.id is null then 'claim_requested' else 'claim_resubmitted' end);
  return jsonb_build_object('submitted',true,'claim_id',new_id,'status','pending');
end $$;
create or replace function public.lit_my_business()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',c.id,'place_id',c.place_id,'status',c.status,
    'name',p.name,'pid',lit_private.pid(p.provider,p.provider_place_id),'lat',p.latitude,'lon',p.longitude,'requested_at',c.created_at,
    'updated_at',c.updated_at,'message',c.applicant_message,'business_role',c.business_role,
    'business_email',c.business_email,'business_phone',c.business_phone,
    'note',c.applicant_note,'evidence_url',c.evidence_url,
    'needs_information',c.status='pending' and c.applicant_message is not null and c.reviewed_at is not null) order by c.updated_at desc,c.id),'[]'::jsonb)
    into result from public.lit_business_claims_v2 c join public.lit_places_v2 p on p.id=c.place_id where c.claimant_id=auth.uid();
  return result;
end $$;
create or replace function public.lit_verification_queue(p_status text default 'pending',p_cursor jsonb default null,p_limit integer default 25)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb; cursor_at timestamptz; cursor_id uuid; has_more boolean; next_cursor jsonb;
begin
  perform lit_private.require_reviewer();
  if p_status is null or p_status not in ('pending','verified','rejected') or p_limit is null or p_limit not between 1 and 50 then raise exception 'Invalid review filter.'; end if;
  if p_cursor is not null then cursor_at:=(p_cursor->>'at')::timestamptz; cursor_id:=(p_cursor->>'id')::uuid;
    if cursor_at is null or cursor_id is null then raise exception 'Invalid review cursor.'; end if; end if;
  with selected as (
    select c.*,p.name,p.address,p.latitude,p.longitude,p.provider,p.provider_place_id,u.email as account_email,
      u.email_confirmed_at is not null as account_email_confirmed,
      (select count(*) from public.lit_business_claims_v2 other where other.place_id=c.place_id and other.status='verified' and other.id<>c.id) as other_verified_accounts
    from public.lit_business_claims_v2 c join public.lit_places_v2 p on p.id=c.place_id join auth.users u on u.id=c.claimant_id
    where c.status=p_status and (cursor_at is null or (c.updated_at,c.id)<(cursor_at,cursor_id))
    order by c.updated_at desc,c.id desc limit p_limit+1
  ), page as (select * from selected order by updated_at desc,id desc limit p_limit)
  select coalesce((select jsonb_agg(jsonb_build_object(
    'id',id,'place_id',place_id,'name',name,'address',address,'lat',latitude,'lon',longitude,
    'pid',lit_private.pid(provider,provider_place_id),'status',status,'version',review_version,
    'requested_at',created_at,'updated_at',updated_at,'business_role',business_role,
    'business_email',business_email,'business_phone',business_phone,'note',applicant_note,
    'evidence_url',evidence_url,'account_email',account_email,'account_email_confirmed',account_email_confirmed,
    'message',applicant_message,'other_verified_accounts',other_verified_accounts,
    'reviewed_at',reviewed_at,'verification_method',verification_method,
    'verification_source',verification_source,'reviewer_note',reviewer_note
  ) order by updated_at desc,id desc) from page),'[]'::jsonb),
    (select count(*)>p_limit from selected),
    (select jsonb_build_object('at',updated_at,'id',id) from page order by updated_at,id limit 1)
  into result,has_more,next_cursor;
  return jsonb_build_object('claims',result,'has_more',has_more,'next_cursor',case when has_more then next_cursor else null end,
    'summary',jsonb_build_object(
      'pending',(select count(*) from public.lit_business_claims_v2 where status='pending'),
      'verified',(select count(*) from public.lit_business_claims_v2 where status='verified'),
      'rejected',(select count(*) from public.lit_business_claims_v2 where status='rejected')));
end $$;
create or replace function public.lit_review_claim(p_claim uuid,p_version integer,p_decision text,p_method text,p_source text,p_note text,p_message text,p_checked boolean,p_allow_shared boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$
declare c public.lit_business_claims_v2%rowtype; next_status text; internal_note text:=btrim(p_note); customer_message text:=btrim(coalesce(p_message,''));
begin
  perform lit_private.require_reviewer();
  if p_decision is null or p_decision not in ('approve','reject','request_info','revoke') then raise exception 'Choose a review decision.'; end if;
  if internal_note is null or length(internal_note) not between 3 and 1000 or length(customer_message)>600 then raise exception 'Add a review note (3–1000 characters).'; end if;
  -- Lock a venue before the claim to serialize competing approvals for the same place.
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:verify-place:'||(select place_id::text from public.lit_business_claims_v2 where id=p_claim),0));
  select * into c from public.lit_business_claims_v2 where id=p_claim for update;
  if c.id is null then raise exception 'Claim not found.'; end if;
  if c.claimant_id=auth.uid() then raise exception 'You cannot review your own business claim. Ask another authorized reviewer.' using errcode='42501'; end if;
  if p_version is null or c.review_version<>p_version then raise exception 'This claim changed. Refresh before reviewing it.'; end if;
  if p_decision='revoke' and c.status<>'verified' then raise exception 'Only verified access can be revoked.'; end if;
  if p_decision<>'revoke' and c.status<>'pending' then raise exception 'Only pending claims can be reviewed.'; end if;
  if p_decision='approve' then
    if p_checked is distinct from true or p_method is null or p_method not in ('public_phone','business_email','official_website','in_person','business_documents')
      or length(btrim(coalesce(p_source,''))) not between 3 and 500 then raise exception 'Confirm an independent verification method and source before approving.'; end if;
    if exists(select 1 from public.lit_business_claims_v2 where place_id=c.place_id and status='verified' and id<>c.id) and p_allow_shared is distinct from true then
      raise exception 'This venue already has verified access. Confirm the additional person is authorized before approving.';
    end if;
  elsif customer_message='' then raise exception 'Add a message explaining the decision to the applicant.';
  end if;
  next_status:=case when p_decision='approve' then 'verified' when p_decision='request_info' then 'pending' else 'rejected' end;
  update public.lit_business_claims_v2 set status=next_status,reviewed_by=auth.uid(),reviewed_at=now(),
    verification_method=case when p_decision='approve' then p_method else verification_method end,
    verification_source=case when p_decision='approve' then btrim(p_source) else verification_source end,
    reviewer_note=internal_note,applicant_message=case when customer_message='' then 'Your venue access has been verified.' else customer_message end,
    review_version=review_version+1,updated_at=now() where id=c.id;
  insert into lit_private.verification_audit(actor_id,claim_id,action,details)
    values(auth.uid(),c.id,'claim_'||p_decision,jsonb_build_object('previous_status',c.status,'status',next_status,
      'method',p_method,'source',p_source,'note',internal_note,'message',customer_message,'shared_access_acknowledged',p_allow_shared));
  return jsonb_build_object('saved',true,'status',next_status);
end $$;
create or replace function public.lit_claim_audit(p_claim uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  perform lit_private.require_reviewer();
  select coalesce(jsonb_agg(jsonb_build_object('id',a.id,'action',a.action,'at',a.created_at,
    'reviewer',u.email,'details',a.details) order by a.id desc),'[]'::jsonb) into result
    from (select * from lit_private.verification_audit where claim_id=p_claim order by id desc limit 100) a left join auth.users u on u.id=a.actor_id;
  return result;
end $$;

create or replace function public.lit_save_business_profile(p_place uuid,p_description text,p_website text,p_phone text,p_hours text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb; site text:=btrim(coalesce(p_website,''));
begin
  perform lit_private.require_business(p_place);
  if length(coalesce(p_description,''))>600 or length(coalesce(p_hours,''))>200 or length(coalesce(p_phone,''))>40
    or length(site)>200 or (site<>'' and site !~* '^https?://[^[:space:]]+$') then raise exception 'Check field lengths and use an HTTP or HTTPS website link.'; end if;
  insert into public.lit_business_profiles_v3(place_id,description,website,phone,hours,updated_by)
    values(p_place,btrim(coalesce(p_description,'')),site,btrim(coalesce(p_phone,'')),btrim(coalesce(p_hours,'')),auth.uid())
    on conflict(place_id) do update set description=excluded.description,website=excluded.website,phone=excluded.phone,hours=excluded.hours,updated_by=auth.uid(),updated_at=now();
  select jsonb_build_object('description',description,'website',website,'phone',phone,'hours',hours,'updated_at',updated_at)
    into result from public.lit_business_profiles_v3 where place_id=p_place;
  return result;
end $$;
create or replace function public.lit_place_details(p_place uuid)
returns jsonb language sql stable security definer set search_path='' as $$
  select jsonb_build_object('profile',case when exists(select 1 from public.lit_business_claims_v2 where place_id=p_place and status='verified')
    then (select jsonb_build_object('description',description,'website',website,'phone',phone,'hours',hours) from public.lit_business_profiles_v3 where place_id=p_place) else null end);
$$;
create or replace function public.lit_business_dashboard(p_place uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare place_data jsonb;
begin
  perform lit_private.require_business(p_place);
  select jsonb_build_object('place_id',id,'name',name,'pid',lit_private.pid(provider,provider_place_id)) into place_data from public.lit_places_v2 where id=p_place;
  return jsonb_build_object('generated_at',now(),'place',place_data,
    'go',jsonb_build_object('current_count',(lit_private.activity(p_place)->>'going_count')::bigint,'updated_at',now(),'expires_after_hours',12),
    'score',null,'history','[]'::jsonb,'totals','{}'::jsonb,'hourly','[]'::jsonb,'daily','[]'::jsonb,'videos','[]'::jsonb,
    'feedback',jsonb_build_object('accuracy','{}'::jsonb,'recent','[]'::jsonb),'promotions','[]'::jsonb,
    'profile',(public.lit_place_details(p_place)->'profile'),
    'capabilities',jsonb_build_object('go_totals',true,'full_analytics',false,'business_profile',true,'promotions',false));
end $$;

create or replace function public.lit_my_profile()
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); result jsonb;
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  insert into public.profiles(id,account_type) values(u,'consumer') on conflict(id) do nothing;
  select jsonb_build_object('id',id,'username',username,'display_name',display_name,'account_type',account_type,'avatar_url',avatar_url)
    into result from public.profiles where id=u;
  return result;
end $$;
create or replace function public.lit_save_profile(p_display_name text,p_username text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); display text:=btrim(p_display_name); handle text:=lower(btrim(p_username));
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  if display is null or length(display) not between 1 and 40 then raise exception 'Display name must be 1–40 characters.'; end if;
  if handle is null or handle !~ '^[a-z0-9_.]{3,24}$' then raise exception 'Username must be 3–24 letters, numbers, underscores or dots.'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:username:'||handle,0));
  if exists(select 1 from public.profiles where lower(username)=handle and id<>u) then raise exception 'That username is already taken.'; end if;
  insert into public.profiles(id,display_name,username,account_type) values(u,display,handle,'consumer')
    on conflict(id) do update set display_name=excluded.display_name,username=excluded.username;
  return public.lit_my_profile();
end $$;
create or replace function public.lit_my_go()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  select jsonb_build_object('place_id',p.id,'pid',lit_private.pid(p.provider,p.provider_place_id),
    'name',p.name,'lat',p.latitude,'lon',p.longitude,'category',p.category,'since',g.created_at,'expires_at',g.expires_at,'arrival',null)
    into result from public.lit_go_intents_v2 g join public.lit_places_v2 p on p.id=g.place_id
    where g.user_id=auth.uid() and g.expires_at>now() order by g.created_at desc,g.place_id limit 1;
  return result;
end $$;
create or replace function public.lit_set_go(p_place uuid,p_going boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  if p_place is null or p_going is null then raise exception 'Choose a venue and GO state.'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:go:'||u::text,0));
  if p_going then
    if not exists(select 1 from public.lit_places_v2 where id=p_place and provider_verified and latitude is not null and longitude is not null) then
      raise exception 'This venue needs provider verification. Refresh and try again.';
    end if;
    delete from public.lit_go_intents_v2 where user_id=u and place_id<>p_place;
    insert into public.lit_go_intents_v2(user_id,place_id,expires_at) values(u,p_place,now()+interval '12 hours')
      on conflict(user_id,place_id) do update set created_at=now(),expires_at=now()+interval '12 hours'
      where public.lit_go_intents_v2.expires_at<=now();
  else delete from public.lit_go_intents_v2 where user_id=u and place_id=p_place;
  end if;
  return public.lit_my_go();
end $$;
create or replace function public.lit_nearby_feed(p_places jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result_places jsonb; result_posts jsonb:='[]'::jsonb;
begin
  if p_places is null or jsonb_typeof(p_places)<>'array' then raise exception 'Expected a list of places.'; end if;
  if jsonb_array_length(p_places)>250 or octet_length(p_places::text)>250000 then raise exception 'Too many places in one request.'; end if;
  with requested as (select distinct item->>'id' as pid from jsonb_array_elements(p_places) items(item)
    where jsonb_typeof(item)='object' and length(item->>'id') between 1 and 512),
  matched as (select distinct on (r.pid) r.pid,p.* from requested r join public.lit_places_v2 p
    on r.pid=lit_private.pid(p.provider,p.provider_place_id) order by r.pid,p.created_at,p.id)
  select coalesce(jsonb_agg(jsonb_build_object('pid',pid,'place_id',id,'name',name,'lat',latitude,'lon',longitude,
    'category',category,'address',address,'provider_verified',provider_verified,'score',null,
    'activity',case when provider_verified then lit_private.activity(id) else null end,
    'claimed',exists(select 1 from public.lit_business_claims_v2 where place_id=m.id and status='verified'),
    'promos','[]'::jsonb) order by pid),'[]'::jsonb) into result_places from matched m;
  if auth.uid() is not null then
    select coalesce(jsonb_agg(row_data order by created_at desc,id),'[]'::jsonb) into result_posts from (
      select post.id,post.created_at,jsonb_build_object('id',post.id,'place_id',post.place_id,'pid',place->>'pid',
        'video_path',post.video_path,'post_type',post.post_type,'created_at',post.created_at,'expires_at',post.expires_at) row_data
      from public.lit_venue_posts_v2 post join jsonb_array_elements(result_places) places(place) on (place->>'place_id')::uuid=post.place_id
      where post.deleted_at is null and post.expires_at>now() and post.created_at>now()-interval '24 hours' and post.created_at<=now()
      order by post.created_at desc,post.id limit 250) active_posts;
  end if;
  return jsonb_build_object('server_time',now(),'places',result_places,'posts',result_posts);
end $$;
create or replace function public.lit_public_place(p_pid text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare p public.lit_places_v2%rowtype;
begin
  if p_pid is null or length(p_pid)>512 then raise exception 'Invalid venue link.'; end if;
  select * into p from public.lit_places_v2 where lit_private.pid(provider,provider_place_id)=p_pid order by created_at,id limit 1;
  if p.id is null or not p.provider_verified then return null; end if;
  return jsonb_build_object('venue',jsonb_build_object('id',p_pid,'name',p.name,'lat',p.latitude,'lon',p.longitude,'category',p.category,'address',p.address),
    'place',jsonb_build_object('pid',p_pid,'place_id',p.id,'provider_verified',true,'score',null,'activity',lit_private.activity(p.id),
      'claimed',exists(select 1 from public.lit_business_claims_v2 where place_id=p.id and status='verified'),'promos','[]'::jsonb));
end $$;

create or replace function public.lit_activity_counts(p_places uuid[])
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  if p_places is null or cardinality(p_places)>250 then raise exception 'Choose at most 250 venues.'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('place_id',p.id,'activity',lit_private.activity(p.id),
    'claimed',exists(select 1 from public.lit_business_claims_v2 c where c.place_id=p.id and c.status='verified'))),'[]'::jsonb)
    into result from public.lit_places_v2 p where p.id=any(p_places) and p.provider_verified;
  return result;
end $$;

-- Only trusted server code using the service_role key can verify provider records.
create or replace function public.lit_reserve_place_lookup(p_actor uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare limits lit_private.place_lookup_limits%rowtype;
begin
  if not exists(select 1 from auth.users where id=p_actor) then raise exception 'Account not found.'; end if;
  insert into lit_private.place_lookup_limits(user_id) values(p_actor) on conflict(user_id) do nothing;
  select * into limits from lit_private.place_lookup_limits where user_id=p_actor for update;
  if limits.day=current_date and limits.daily_count>=200 then raise exception 'Daily venue lookup limit reached.'; end if;
  if limits.minute=date_trunc('minute',now()) and limits.minute_count>=12 then raise exception 'Please wait a minute before registering more venues.'; end if;
  update lit_private.place_lookup_limits set day=current_date,
    daily_count=case when day=current_date then daily_count+1 else 1 end,
    minute=date_trunc('minute',now()),minute_count=case when minute=date_trunc('minute',now()) then minute_count+1 else 1 end where user_id=p_actor;
  return jsonb_build_object('allowed',true);
end $$;
create or replace function public.lit_register_verified_place(p_actor uuid,p_place jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare pid text:=p_place->>'id'; provider text; provider_id text; existing uuid; registered uuid;
begin
  if not exists(select 1 from auth.users where id=p_actor) then raise exception 'Account not found.'; end if;
  if pid is null or length(pid)>512 or pid !~ '^(geoapify:.+|osm:(node|way|relation):[0-9]+)$'
    or jsonb_typeof(p_place->'lat') is distinct from 'number' or jsonb_typeof(p_place->'lon') is distinct from 'number'
    or (p_place->>'lat')::double precision not between -90 and 90 or (p_place->>'lon')::double precision not between -180 and 180
    or length(btrim(coalesce(p_place->>'name',''))) not between 1 and 300 then raise exception 'Invalid provider record.'; end if;
  provider:=split_part(pid,':',1); provider_id:=substr(pid,length(provider)+2);
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:provider-place:'||pid,0));
  select id into existing from public.lit_places_v2 p where lit_private.pid(p.provider,p.provider_place_id)=pid order by created_at,id limit 1;
  if existing is null then
    insert into public.lit_places_v2(provider,provider_place_id,name,latitude,longitude,category,address,provider_verified,provider_verified_at)
      values(provider,provider_id,btrim(p_place->>'name'),(p_place->>'lat')::double precision,(p_place->>'lon')::double precision,
        left(p_place->>'category',80),left(p_place->>'address',1000),true,now()) returning id into registered;
  else
    update public.lit_places_v2 set name=btrim(p_place->>'name'),latitude=(p_place->>'lat')::double precision,longitude=(p_place->>'lon')::double precision,
      category=left(p_place->>'category',80),address=left(p_place->>'address',1000),provider_verified=true,provider_verified_at=now() where id=existing returning id into registered;
  end if;
  return jsonb_build_object('pid',pid,'place_id',registered,'provider_verified',true);
end $$;

revoke all on all tables in schema lit_private from public,anon,authenticated;
revoke all on all sequences in schema lit_private from public,anon,authenticated;
revoke all on all functions in schema lit_private from public,anon,authenticated;
-- Reset all new/updated API function grants without affecting unrelated functions.
do $$
declare f record;
begin
  for f in select p.oid::regprocedure as signature from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname=any(array[
      'lit_review_access','lit_list_reviewers','lit_manage_reviewer','lit_request_claim','lit_my_business',
      'lit_verification_queue','lit_review_claim','lit_claim_audit','lit_save_business_profile','lit_business_dashboard',
      'lit_my_profile','lit_save_profile','lit_my_go','lit_set_go','lit_nearby_feed','lit_public_place','lit_place_details','lit_activity_counts',
      'lit_reserve_place_lookup','lit_register_verified_place'])
  loop execute format('revoke all on function %s from public,anon,authenticated',f.signature); end loop;
end $$;
grant execute on function public.lit_review_access(),public.lit_list_reviewers(),public.lit_manage_reviewer(text,boolean),
  public.lit_request_claim(uuid,text,text,text,text,text),public.lit_my_business(),public.lit_verification_queue(text,jsonb,integer),
  public.lit_review_claim(uuid,integer,text,text,text,text,text,boolean,boolean),public.lit_claim_audit(uuid),
  public.lit_save_business_profile(uuid,text,text,text,text),public.lit_business_dashboard(uuid),
  public.lit_my_profile(),public.lit_save_profile(text,text),public.lit_my_go(),public.lit_set_go(uuid,boolean) to authenticated;
grant execute on function public.lit_nearby_feed(jsonb),public.lit_public_place(text),public.lit_place_details(uuid),public.lit_activity_counts(uuid[]) to anon,authenticated,service_role;
grant execute on function public.lit_reserve_place_lookup(uuid),public.lit_register_verified_place(uuid,jsonb) to service_role;
notify pgrst,'reload schema';
commit;

-- Run after SUPABASE_v3.3_BUSINESS_SYSTEM.sql. Private Crew backend; existing legacy tables remain intact.
begin;
create table if not exists lit_private.crews (
 id uuid primary key default gen_random_uuid(),name text not null check(length(btrim(name)) between 1 and 60),
 owner_id uuid not null references auth.users(id) on delete cascade,
 invite_code text not null unique default upper(replace(gen_random_uuid()::text,'-','')),
 invite_expires_at timestamptz not null default now()+interval '7 days',created_at timestamptz not null default now()
);
create table if not exists lit_private.crew_members (
 crew_id uuid not null references lit_private.crews(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 status text not null check(status in ('joined','invited')),created_at timestamptz not null default now(),primary key(crew_id,user_id)
);
create table if not exists lit_private.crew_outings (
 id uuid primary key default gen_random_uuid(),crew_id uuid not null references lit_private.crews(id) on delete cascade,
 organizer_id uuid not null references auth.users(id) on delete cascade,place_id uuid not null references public.lit_places_v2(id) on delete cascade,
 starts_at timestamptz not null,ends_at timestamptz not null,note text not null default '' check(length(note)<=200),
 cancelled_at timestamptz,created_at timestamptz not null default now(),check(ends_at>starts_at)
);
create table if not exists lit_private.outing_responses (
 outing_id uuid not null references lit_private.crew_outings(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,response text not null default 'waiting' check(response in ('waiting','in','maybe','pass')),
 updated_at timestamptz not null default now(),primary key(outing_id,user_id)
);
create table if not exists lit_private.crew_request_limits (
 user_id uuid not null references auth.users(id) on delete cascade,kind text not null,window_start timestamptz not null,
 attempts integer not null check(attempts>0),primary key(user_id,kind)
);
create index if not exists crew_members_user_v5 on lit_private.crew_members(user_id,crew_id);
create index if not exists crew_outings_place_v5 on lit_private.crew_outings(place_id,starts_at,ends_at) where cancelled_at is null;
create index if not exists crew_outings_crew_v5 on lit_private.crew_outings(crew_id,starts_at) where cancelled_at is null;
alter table lit_private.crews enable row level security;
alter table lit_private.crew_members enable row level security;
alter table lit_private.crew_outings enable row level security;
alter table lit_private.outing_responses enable row level security;
alter table lit_private.crew_request_limits enable row level security;

create or replace function lit_private.crew_user() returns uuid language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();
begin
 if u is null then raise exception 'Sign in first.' using errcode='42501';end if;
 if not exists(select 1 from auth.users where id=u and email_confirmed_at is not null) then raise exception 'Confirm your account email first.';end if;
 if not exists(select 1 from public.profiles where id=u and username is not null) then raise exception 'Choose your LIT username first.';end if;
 return u;
end $$;
create or replace function lit_private.crew_quota(p_kind text,p_limit integer) returns boolean language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user(); n integer;
begin
 insert into lit_private.crew_request_limits as q(user_id,kind,window_start,attempts) values(u,p_kind,now(),1)
 on conflict(user_id,kind) do update set
 attempts=case when q.window_start<=now()-interval '1 hour' then 1 else least(q.attempts+1,p_limit+1) end,
 window_start=case when q.window_start<=now()-interval '1 hour' then now() else q.window_start end returning attempts into n;
 return n<=p_limit;
end $$;
create or replace function lit_private.lock_crew(p_crew uuid,p_owner boolean default false) returns lit_private.crews language plpgsql security definer set search_path='' as $$
declare c lit_private.crews; u uuid:=lit_private.crew_user();
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 select * into c from lit_private.crews where id=p_crew for update;
 if c.id is null or not exists(select 1 from lit_private.crew_members where crew_id=p_crew and user_id=u and status='joined')
 or (p_owner and c.owner_id<>u) then raise exception 'This Crew is unavailable or you do not have permission.' using errcode='42501';end if;
 return c;
end $$;
create or replace function lit_private.join_member(p_crew uuid,p_user uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if (select count(*) from lit_private.crew_members where crew_id=p_crew)>=30 and not exists(select 1 from lit_private.crew_members where crew_id=p_crew and user_id=p_user) then raise exception 'This Crew has reached its 30-member limit.';end if;
 if (select count(*) from lit_private.crew_members where user_id=p_user)>=20 and not exists(select 1 from lit_private.crew_members where crew_id=p_crew and user_id=p_user) then raise exception 'The account has reached its 20-Crew limit.';end if;
 insert into lit_private.crew_members(crew_id,user_id,status) values(p_crew,p_user,'joined') on conflict(crew_id,user_id) do update set status='joined';
 insert into lit_private.outing_responses(outing_id,user_id) select id,p_user from lit_private.crew_outings where crew_id=p_crew and cancelled_at is null and ends_at>now() on conflict do nothing;
end $$;
create or replace function public.lit_create_crew(p_name text) returns uuid language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user(); id uuid;
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 if p_name is null or length(btrim(p_name)) not between 1 and 60 then raise exception 'Crew name must be 1–60 characters.';end if;
 if not lit_private.crew_quota('create',20) then raise exception 'Too many Crew creations. Try again in an hour.';end if;
 if (select count(*) from lit_private.crew_members where user_id=u)>=20 then raise exception 'You have reached the 20-Crew limit.';end if;
 insert into lit_private.crews(name,owner_id) values(btrim(p_name),u) returning crews.id into id;
 perform lit_private.join_member(id,u);return id;
end $$;
-- JSON response lets failed code attempts commit their quota counter instead of rolling it back.
create or replace function public.lit_join_crew(p_code text) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user();c lit_private.crews; code text:=upper(btrim(p_code));
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 if not lit_private.crew_quota('join',20) then return jsonb_build_object('error','Too many join attempts. Try again in an hour.');end if;
 if code is null or code !~ '^[A-F0-9]{32}$' then return jsonb_build_object('error','This invite is invalid or expired. Ask the owner for a new link.');end if;
 select * into c from lit_private.crews where invite_code=code for update;
 if c.id is null or c.invite_expires_at<=now() then return jsonb_build_object('error','This invite is invalid or expired. Ask the owner for a new link.');end if;
 if (select count(*) from lit_private.crew_members where crew_id=c.id)>=30 and not exists(select 1 from lit_private.crew_members where crew_id=c.id and user_id=u) then return jsonb_build_object('error','This Crew has reached its 30-member limit.');end if;
 if (select count(*) from lit_private.crew_members where user_id=u)>=20 and not exists(select 1 from lit_private.crew_members where crew_id=c.id and user_id=u) then return jsonb_build_object('error','You have reached the 20-Crew limit.');end if;
 perform lit_private.join_member(c.id,u);return jsonb_build_object('crew_id',c.id);
end $$;
create or replace function public.lit_add_crew_member(p_crew uuid,p_username text) returns jsonb language plpgsql security definer set search_path='' as $$
declare c lit_private.crews; target uuid;u uuid:=lit_private.crew_user();
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 c:=lit_private.lock_crew(p_crew,true);
 if not lit_private.crew_quota('invite',60) then return jsonb_build_object('error','Too many invitations. Try again in an hour.');end if;
 select p.id into target from public.profiles p join auth.users a on a.id=p.id where lower(p.username)=lower(ltrim(btrim(p_username),'@')) and a.email_confirmed_at is not null;
 if target is null then return jsonb_build_object('error','No confirmed LIT account has that username.');end if;
 if target=u then return jsonb_build_object('error','You are already the Crew owner.');end if;
 if exists(select 1 from lit_private.crew_members where crew_id=p_crew and user_id=target) then return jsonb_build_object('sent',false,'already_member',true);end if;
 if (select count(*) from lit_private.crew_members where crew_id=p_crew)>=30 then return jsonb_build_object('error','This Crew has reached its 30-member limit.');end if;
 -- Membership mutation lock also serializes per-account capacity checks.
 if (select count(*) from lit_private.crew_members where user_id=target)>=20 then return jsonb_build_object('error','This account cannot receive another Crew invitation.');end if;
 insert into lit_private.crew_members(crew_id,user_id,status) values(p_crew,target,'invited');return jsonb_build_object('sent',true);
end $$;
create or replace function public.lit_respond_crew_invite(p_crew uuid,p_accept boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user();c lit_private.crews;
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 select * into c from lit_private.crews where id=p_crew for update;
 if c.id is null or not exists(select 1 from lit_private.crew_members where crew_id=p_crew and user_id=u and status='invited') then raise exception 'This invitation is no longer available.';end if;
 if p_accept is null then raise exception 'Choose Join or Decline.';end if;
 if p_accept then perform lit_private.join_member(p_crew,u);else delete from lit_private.crew_members where crew_id=p_crew and user_id=u;end if;
 return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_leave_crew(p_crew uuid,p_user uuid default null) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user();target uuid:=coalesce(p_user,u);c lit_private.crews;
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 c:=lit_private.lock_crew(p_crew,target<>u);
 if target=c.owner_id then
  if u<>c.owner_id then raise exception 'Only the owner can delete this Crew.';end if;
  delete from lit_private.crews where id=p_crew;
 else
  delete from lit_private.outing_responses r using lit_private.crew_outings o where r.outing_id=o.id and o.crew_id=p_crew and r.user_id=target;
  update lit_private.crew_outings set cancelled_at=now() where crew_id=p_crew and organizer_id=target and cancelled_at is null;
  delete from lit_private.crew_members where crew_id=p_crew and user_id=target;
 end if;
 return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_rotate_crew_invite(p_crew uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare c lit_private.crews;
begin
 c:=lit_private.lock_crew(p_crew,true);
 update lit_private.crews set invite_code=upper(replace(gen_random_uuid()::text,'-','')),invite_expires_at=now()+interval '7 days' where id=p_crew;
 return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_create_outing(p_crew uuid,p_place uuid,p_starts_at timestamptz,p_note text default '') returns uuid language plpgsql security definer set search_path='' as $$
declare c lit_private.crews;u uuid:=lit_private.crew_user(); outing uuid;
begin
 c:=lit_private.lock_crew(p_crew);
 if not lit_private.crew_quota('plan',60) then raise exception 'Too many plans. Try again in an hour.';end if;
 if p_starts_at is null or p_starts_at<now() or p_starts_at>now()+interval '30 days' then raise exception 'Choose a start time within the next 30 days.';end if;
 if length(coalesce(p_note,''))>200 then raise exception 'Plan notes must be at most 200 characters.';end if;
 if not exists(select 1 from public.lit_places_v2 where id=p_place and provider_verified) then raise exception 'Choose a registered real venue.';end if;
 if (select count(*) from lit_private.crew_outings where crew_id=p_crew and cancelled_at is null and ends_at>now())>=50 then raise exception 'This Crew has reached its 50-active-plan limit.';end if;
 insert into lit_private.crew_outings(crew_id,organizer_id,place_id,starts_at,ends_at,note) values(p_crew,u,p_place,p_starts_at,p_starts_at+interval '6 hours',btrim(coalesce(p_note,''))) returning id into outing;
 insert into lit_private.outing_responses(outing_id,user_id,response) select outing,user_id,case when user_id=u then 'in' else 'waiting' end from lit_private.crew_members where crew_id=p_crew and status='joined';return outing;
end $$;
create or replace function public.lit_respond_outing(p_outing uuid,p_response text) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user();o lit_private.crew_outings;c lit_private.crews;
begin
 select * into o from lit_private.crew_outings where id=p_outing;
 c:=lit_private.lock_crew(o.crew_id);
 select * into o from lit_private.crew_outings where id=p_outing for update;
 if o.id is null or o.cancelled_at is not null or o.ends_at<=now() then raise exception 'This plan has ended or was cancelled.';end if;
 if p_response is null or p_response not in ('in','maybe','pass') then raise exception 'Choose In, Maybe or Pass.';end if;
 insert into lit_private.outing_responses(outing_id,user_id,response) values(p_outing,u,p_response) on conflict(outing_id,user_id) do update set response=excluded.response,updated_at=now();
 return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_cancel_outing(p_outing uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare o lit_private.crew_outings;c lit_private.crews;u uuid:=lit_private.crew_user();
begin
 select * into o from lit_private.crew_outings where id=p_outing;c:=lit_private.lock_crew(o.crew_id);
 if o.organizer_id<>u and c.owner_id<>u then raise exception 'Only the organizer or Crew owner can cancel this plan.' using errcode='42501';end if;
 update lit_private.crew_outings set cancelled_at=coalesce(cancelled_at,now()) where id=p_outing;return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_my_crews() returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user();result jsonb;
begin
 select coalesce(jsonb_agg(jsonb_build_object('id',c.id,'name',c.name,'my_status',mine.status,'my_role',case when c.owner_id=u then 'owner' else 'member' end,
 'invite_code',case when c.owner_id=u then c.invite_code else null end,'invite_expires_at',case when c.owner_id=u then c.invite_expires_at else null end,
 'members',(select coalesce(jsonb_agg(jsonb_build_object('user_id',m.user_id,'name',coalesce(p.display_name,p.username,'LIT member'),'username',p.username,'me',m.user_id=u,'role',case when m.user_id=c.owner_id then 'owner' else 'member' end,'status',m.status) order by (m.user_id=c.owner_id) desc,m.created_at,m.user_id),'[]'::jsonb)
 from lit_private.crew_members m left join public.profiles p on p.id=m.user_id where m.crew_id=c.id and (mine.status='joined' or m.user_id in (u,c.owner_id))),
 'outings',case when mine.status='joined' then (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'pid',lit_private.pid(p.provider,p.provider_place_id),'place_id',p.id,'place_name',p.name,'lat',p.latitude,'lon',p.longitude,'category',p.category,'starts_at',o.starts_at,'ends_at',o.ends_at,'note',o.note,'can_cancel',o.organizer_id=u or c.owner_id=u,
 'responses',(select coalesce(jsonb_agg(jsonb_build_object('user_id',r.user_id,'name',coalesce(pr.display_name,pr.username,'LIT member'),'me',r.user_id=u,'response',r.response) order by r.user_id),'[]'::jsonb) from lit_private.outing_responses r join lit_private.crew_members mm on mm.crew_id=c.id and mm.user_id=r.user_id and mm.status='joined' left join public.profiles pr on pr.id=r.user_id where r.outing_id=o.id)) order by o.starts_at,o.id),'[]'::jsonb)
 from lit_private.crew_outings o join public.lit_places_v2 p on p.id=o.place_id where o.crew_id=c.id and o.cancelled_at is null and o.ends_at>now()) else '[]'::jsonb end) order by c.created_at,c.id),'[]'::jsonb) into result
 from lit_private.crews c join lit_private.crew_members mine on mine.crew_id=c.id and mine.user_id=u;
 return result;
end $$;
create or replace function lit_private.activity(p_place uuid) returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('going_count',(select count(*) from (select distinct on(user_id) user_id,place_id from public.lit_go_intents_v2 where expires_at>now() order by user_id,created_at desc,place_id) g where g.place_id=p_place),
 'planning_count',(select count(distinct r.user_id) from lit_private.crew_outings o join lit_private.outing_responses r on r.outing_id=o.id join lit_private.crew_members m on m.crew_id=o.crew_id and m.user_id=r.user_id and m.status='joined' where o.place_id=p_place and o.cancelled_at is null and o.ends_at>now() and o.starts_at>=now()-interval '12 hours' and o.starts_at<now()+interval '12 hours' and r.response='in'),
 'updated_at',now(),'window_start',now()-interval '12 hours','window_end',now()+interval '12 hours');
$$;
create or replace function public.lit_business_dashboard(p_place uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare place_data jsonb;
begin
  perform lit_private.require_business(p_place);
  select jsonb_build_object('place_id',id,'name',name,'pid',lit_private.pid(provider,provider_place_id)) into place_data from public.lit_places_v2 where id=p_place;
  return jsonb_build_object('generated_at',now(),'place',place_data,
    'go',jsonb_build_object('current_count',(lit_private.activity(p_place)->>'going_count')::bigint,'updated_at',now(),'expires_after_hours',12),
    'crew',jsonb_build_object('planning_count',(lit_private.activity(p_place)->>'planning_count')::bigint,'updated_at',now()),
    'score',null,'history','[]'::jsonb,'totals','{}'::jsonb,'hourly','[]'::jsonb,'daily','[]'::jsonb,'videos','[]'::jsonb,
    'feedback',jsonb_build_object('accuracy','{}'::jsonb,'recent','[]'::jsonb),'promotions','[]'::jsonb,
    'profile',(public.lit_place_details(p_place)->'profile'),
    'capabilities',jsonb_build_object('go_totals',true,'crew_totals',true,'full_analytics',false,'business_profile',true,'promotions',false));
end $$;

-- Private schema is inaccessible to browsers, including all new tables/helpers.
revoke all on all tables in schema lit_private from public,anon,authenticated;
revoke all on all functions in schema lit_private from public,anon,authenticated;
revoke all on function public.lit_create_crew(text),public.lit_join_crew(text),public.lit_add_crew_member(uuid,text),public.lit_respond_crew_invite(uuid,boolean),public.lit_leave_crew(uuid,uuid),public.lit_rotate_crew_invite(uuid),public.lit_create_outing(uuid,uuid,timestamptz,text),public.lit_respond_outing(uuid,text),public.lit_cancel_outing(uuid),public.lit_my_crews() from public,anon,authenticated;
grant execute on function public.lit_create_crew(text),public.lit_join_crew(text),public.lit_add_crew_member(uuid,text),public.lit_respond_crew_invite(uuid,boolean),public.lit_leave_crew(uuid,uuid),public.lit_rotate_crew_invite(uuid),public.lit_create_outing(uuid,uuid,timestamptz,text),public.lit_respond_outing(uuid,text),public.lit_cancel_outing(uuid),public.lit_my_crews() to authenticated;
notify pgrst,'reload schema';
commit;


-- Run after the v3.5 complete migration. Keeps earlier features and records.
begin;
create table if not exists lit_private.arrivals (
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,
 place_id uuid not null references public.lit_places_v2(id) on delete cascade,go_started_at timestamptz not null,
 checked_at timestamptz not null default now(),distance_m double precision not null check(distance_m between 0 and 200),
 accuracy_m double precision not null check(accuracy_m>0 and accuracy_m<=150),unique(user_id,place_id,go_started_at)
);
create table if not exists lit_private.guest_feedback (
 arrival_id uuid primary key references lit_private.arrivals(id) on delete cascade,
 accuracy text not null check(accuracy in ('accurate','busier','quieter','inaccurate','not_shown')),
 vibe integer check(vibe between 1 and 5),note text not null default '' check(length(note)<=280),
 share_note boolean not null default false,submitted_at timestamptz not null default now()
);
create table if not exists lit_private.promotions (
 id uuid primary key default gen_random_uuid(),place_id uuid not null references public.lit_places_v2(id) on delete cascade,
 kind text not null check(kind in ('special','event','promotion')),title text not null check(length(btrim(title)) between 2 and 80),
 details text not null default '' check(length(details)<=300),starts_at timestamptz not null,ends_at timestamptz not null,
 created_by uuid references auth.users(id) on delete set null,updated_by uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now(),updated_at timestamptz not null default now(),revision integer not null default 1,
 archived_at timestamptz,check(ends_at>starts_at and ends_at<=starts_at+interval '30 days')
);
alter table lit_private.arrivals enable row level security;
alter table lit_private.guest_feedback enable row level security;
alter table lit_private.promotions enable row level security;
create index if not exists lit_arrivals_user_place_v6 on lit_private.arrivals(user_id,place_id,checked_at desc);
create index if not exists lit_arrivals_place_v6 on lit_private.arrivals(place_id,checked_at desc);
create index if not exists lit_promotions_live_v6 on lit_private.promotions(place_id,ends_at,starts_at) where archived_at is null;

create or replace function public.lit_confirm_arrival(p_place uuid,p_lat double precision,p_lon double precision,p_accuracy double precision default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();g public.lit_go_intents_v2;v public.lit_places_v2;a lit_private.arrivals;distance double precision;
begin
 if u is null then raise exception 'Sign in first.' using errcode='42501';end if;
 if not exists(select 1 from auth.users where id=u and email_confirmed_at is not null) then raise exception 'Confirm your account email first.';end if;
 if p_lat is null or p_lon is null or p_lat not between -90 and 90 or p_lon not between -180 and 180 then raise exception 'Your device did not return a valid location. Try again.';end if;
 if p_accuracy is null or p_accuracy<=0 or p_accuracy>150 then raise exception 'Location is not precise enough. Try outdoors with precise location enabled.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:go:'||u::text,0));
 select * into g from public.lit_go_intents_v2 where user_id=u and place_id=p_place and expires_at>now();
 if g.user_id is null then raise exception 'Save this venue as your current GO destination first.';end if;
 select * into v from public.lit_places_v2 where id=p_place and provider_verified and latitude is not null and longitude is not null;
 if v.id is null then raise exception 'This venue needs provider verification first.';end if;
 distance:=6371000*acos(greatest(-1.0,least(1.0,sin(radians(p_lat))*sin(radians(v.latitude))+cos(radians(p_lat))*cos(radians(v.latitude))*cos(radians(p_lon-v.longitude)))));
 if distance>200 then raise exception 'You need to be within 200 metres of the venue to check your location.';end if;
 select * into a from lit_private.arrivals where user_id=u and place_id=p_place and go_started_at=g.created_at;
 if a.id is not null then return jsonb_build_object('id',a.id,'checked_at',a.checked_at,'feedback_done',exists(select 1 from lit_private.guest_feedback where arrival_id=a.id));end if;
 if exists(select 1 from lit_private.arrivals where user_id=u and place_id=p_place and checked_at>now()-interval '6 hours') then raise exception 'You already checked your location at this venue within the last 6 hours.';end if;
 if (select count(*) from lit_private.arrivals where user_id=u and checked_at>now()-interval '24 hours')>=20 then raise exception 'Daily location-check limit reached. Try again tomorrow.';end if;
 insert into lit_private.arrivals(user_id,place_id,go_started_at,distance_m,accuracy_m) values(u,p_place,g.created_at,distance,p_accuracy) returning * into a;
 return jsonb_build_object('id',a.id,'checked_at',a.checked_at,'feedback_done',false);
end $$;
create or replace function public.lit_submit_feedback(p_arrival uuid,p_accuracy text,p_vibe integer,p_note text,p_share_note boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$
declare a lit_private.arrivals;u uuid:=auth.uid();old lit_private.guest_feedback;
begin
 if u is null then raise exception 'Sign in first.' using errcode='42501';end if;
 select * into a from lit_private.arrivals where id=p_arrival and user_id=u for update;
 if a.id is null then raise exception 'This location check is unavailable for your account.' using errcode='42501';end if;
 if p_accuracy is null or p_accuracy not in ('accurate','busier','quieter','inaccurate','not_shown') or (p_vibe is not null and p_vibe not between 1 and 5) or length(coalesce(p_note,''))>280 or p_share_note is null then raise exception 'Check your feedback choices and keep the note within 280 characters.';end if;
 select * into old from lit_private.guest_feedback where arrival_id=p_arrival;
 if old.arrival_id is not null then
  if old.accuracy=p_accuracy and old.vibe is not distinct from p_vibe and old.note=btrim(coalesce(p_note,'')) and old.share_note=p_share_note then return jsonb_build_object('saved',true,'already_submitted',true);end if;
  raise exception 'Feedback was already submitted for this visit.';
 end if;
 if a.checked_at<now()-interval '24 hours' then raise exception 'Feedback must be sent within 24 hours of your location check.';end if;
 if exists(select 1 from public.lit_business_claims_v2 where place_id=a.place_id and claimant_id=u and status='verified') then raise exception 'Verified representatives cannot submit guest feedback for their own venue.';end if;
 insert into lit_private.guest_feedback(arrival_id,accuracy,vibe,note,share_note) values(p_arrival,p_accuracy,p_vibe,btrim(coalesce(p_note,'')),p_share_note);
 return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_my_go()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 if auth.uid() is null then raise exception 'Sign in first.' using errcode='42501';end if;
 select jsonb_build_object('place_id',p.id,'pid',lit_private.pid(p.provider,p.provider_place_id),'name',p.name,'lat',p.latitude,'lon',p.longitude,'category',p.category,'since',g.created_at,'expires_at',g.expires_at,
 'arrival',(select jsonb_build_object('id',a.id,'checked_at',a.checked_at,'feedback_done',exists(select 1 from lit_private.guest_feedback where arrival_id=a.id)) from lit_private.arrivals a where a.user_id=g.user_id and a.place_id=g.place_id and a.go_started_at=g.created_at))
 into result from public.lit_go_intents_v2 g join public.lit_places_v2 p on p.id=g.place_id where g.user_id=auth.uid() and g.expires_at>now() order by g.created_at desc,g.place_id limit 1;
 return result;
end $$;
create or replace function lit_private.feedback_summary(p_place uuid)
returns jsonb language plpgsql stable security definer set search_path='' as $$
declare participants bigint;result jsonb;
begin
 select count(distinct a.user_id) into participants from lit_private.guest_feedback f join lit_private.arrivals a on a.id=f.arrival_id where a.place_id=p_place and f.submitted_at>now()-interval '30 days' and not exists(select 1 from public.lit_business_claims_v2 c where c.place_id=a.place_id and c.claimant_id=a.user_id and c.status='verified');
 if participants<3 then return jsonb_build_object('privacy_threshold',3,'suppressed',true,'accuracy','{}'::jsonb,'recent','[]'::jsonb,'count_30d',null,'avg_vibe',null);end if;
 with latest as(select distinct on(a.user_id) f.* from lit_private.guest_feedback f join lit_private.arrivals a on a.id=f.arrival_id where a.place_id=p_place and f.submitted_at>now()-interval '30 days' and not exists(select 1 from public.lit_business_claims_v2 c where c.place_id=a.place_id and c.claimant_id=a.user_id and c.status='verified') order by a.user_id,f.submitted_at desc,f.arrival_id),
 counts as(select accuracy,count(*) n from latest group by accuracy)
 select jsonb_build_object('privacy_threshold',3,'suppressed',false,'accuracy',coalesce((select jsonb_object_agg(accuracy,n) from counts),'{}'::jsonb),'count_30d',participants,'avg_vibe',(select round(avg(vibe),1) from latest),'recent',coalesce((select jsonb_agg(jsonb_build_object('at',date_trunc('day',submitted_at),'accuracy',accuracy,'vibe',vibe,'note',note) order by submitted_at desc,arrival_id) from (select * from latest where share_note and note<>'' order by submitted_at desc,arrival_id limit 6) notes),'[]'::jsonb)) into result;
 return result;
end $$;
create or replace function public.lit_save_promotion(p_place uuid,p_id uuid,p_kind text,p_title text,p_details text,p_starts_at timestamptz,p_ends_at timestamptz,p_version integer default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();promo lit_private.promotions;start_time timestamptz:=coalesce(p_starts_at,now());title_text text:=btrim(p_title);details_text text:=btrim(coalesce(p_details,''));new_id uuid:=coalesce(p_id,gen_random_uuid());
begin
 perform lit_private.require_business(p_place);
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:promotions:'||p_place::text,0));
 if p_kind is null or p_kind not in ('special','event','promotion') or title_text is null or length(title_text) not between 2 and 80 or length(details_text)>300 then raise exception 'Choose a promotion type, a 2–80 character title and details within 300 characters.';end if;
 if p_ends_at is null or p_ends_at<=now() or p_ends_at<=start_time or p_ends_at>start_time+interval '30 days' or start_time>now()+interval '90 days' then raise exception 'Choose an end after the start, within 30 days. Starts must be within 90 days.';end if;
 select * into promo from lit_private.promotions where id=new_id for update;
 if promo.id is not null then
  if promo.place_id<>p_place then raise exception 'This promotion belongs to another venue.' using errcode='42501';end if;
  if p_version is null then
   if promo.archived_at is null and promo.kind=p_kind and promo.title=title_text and promo.details=details_text and promo.starts_at=start_time and promo.ends_at=p_ends_at then return jsonb_build_object('saved',true,'id',promo.id,'version',promo.revision);end if;
   raise exception 'This promotion already exists. Refresh before editing it.';
  end if;
  if promo.revision<>p_version or promo.archived_at is not null then raise exception 'This promotion changed or was ended. Refresh before editing.';end if;
  update lit_private.promotions set kind=p_kind,title=title_text,details=details_text,starts_at=start_time,ends_at=p_ends_at,updated_by=u,updated_at=now(),revision=revision+1 where id=new_id returning * into promo;
 else
  if p_version is not null then raise exception 'This promotion is no longer available.';end if;
  if (select count(*) from lit_private.promotions where place_id=p_place and created_by=u and created_at>now()-interval '24 hours')>=30 then raise exception 'Daily promotion creation limit reached.';end if;
  if (select count(*) from lit_private.promotions where place_id=p_place and archived_at is null and ends_at>now())>=20 then raise exception 'This venue has 20 active or scheduled promotions. End one first.';end if;
  insert into lit_private.promotions(id,place_id,kind,title,details,starts_at,ends_at,created_by,updated_by) values(new_id,p_place,p_kind,title_text,details_text,start_time,p_ends_at,u,u) returning * into promo;
 end if;
 return jsonb_build_object('saved',true,'id',promo.id,'version',promo.revision);
end $$;
create or replace function public.lit_archive_promotion(p_id uuid,p_version integer default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare promo lit_private.promotions;
begin
 select * into promo from lit_private.promotions where id=p_id;
 if promo.id is null then raise exception 'Promotion not found.';end if;
 perform lit_private.require_business(promo.place_id);
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:promotions:'||promo.place_id::text,0));
 select * into promo from lit_private.promotions where id=p_id for update;
 if promo.archived_at is not null then return jsonb_build_object('saved',true);end if;
 if p_version is not null and p_version<>promo.revision then raise exception 'This promotion changed. Refresh before ending it.';end if;
 update lit_private.promotions set archived_at=now(),updated_by=auth.uid(),updated_at=now(),revision=revision+1 where id=p_id;
 return jsonb_build_object('saved',true);
end $$;
create or replace function lit_private.public_promotions(p_place uuid)
returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'kind',kind,'title',title,'details',details,'starts_at',starts_at,'ends_at',ends_at,'active',starts_at<=now()) order by starts_at,id),'[]'::jsonb) from lit_private.promotions where place_id=p_place and archived_at is null and ends_at>now() and (starts_at<=now() or kind='event') and exists(select 1 from public.lit_business_claims_v2 where place_id=p_place and status='verified');
$$;

create or replace function lit_private.feed_base_v6(p_places jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result_places jsonb; result_posts jsonb:='[]'::jsonb;
begin
  if p_places is null or jsonb_typeof(p_places)<>'array' then raise exception 'Expected a list of places.'; end if;
  if jsonb_array_length(p_places)>250 or octet_length(p_places::text)>250000 then raise exception 'Too many places in one request.'; end if;
  with requested as (select distinct item->>'id' as pid from jsonb_array_elements(p_places) items(item)
    where jsonb_typeof(item)='object' and length(item->>'id') between 1 and 512),
  matched as (select distinct on (r.pid) r.pid,p.* from requested r join public.lit_places_v2 p
    on r.pid=lit_private.pid(p.provider,p.provider_place_id) order by r.pid,p.created_at,p.id)
  select coalesce(jsonb_agg(jsonb_build_object('pid',pid,'place_id',id,'name',name,'lat',latitude,'lon',longitude,
    'category',category,'address',address,'provider_verified',provider_verified,'score',null,
    'activity',case when provider_verified then lit_private.activity(id) else null end,
    'claimed',exists(select 1 from public.lit_business_claims_v2 where place_id=m.id and status='verified'),
    'promos','[]'::jsonb) order by pid),'[]'::jsonb) into result_places from matched m;
  if auth.uid() is not null then
    select coalesce(jsonb_agg(row_data order by created_at desc,id),'[]'::jsonb) into result_posts from (
      select post.id,post.created_at,jsonb_build_object('id',post.id,'place_id',post.place_id,'pid',place->>'pid',
        'video_path',post.video_path,'post_type',post.post_type,'created_at',post.created_at,'expires_at',post.expires_at) row_data
      from public.lit_venue_posts_v2 post join jsonb_array_elements(result_places) places(place) on (place->>'place_id')::uuid=post.place_id
      where post.deleted_at is null and post.expires_at>now() and post.created_at>now()-interval '24 hours' and post.created_at<=now()
      order by post.created_at desc,post.id limit 250) active_posts;
  end if;
  return jsonb_build_object('server_time',now(),'places',result_places,'posts',result_posts);
end $$;

create or replace function lit_private.place_base_v6(p_pid text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare p public.lit_places_v2%rowtype;
begin
  if p_pid is null or length(p_pid)>512 then raise exception 'Invalid venue link.'; end if;
  select * into p from public.lit_places_v2 where lit_private.pid(provider,provider_place_id)=p_pid order by created_at,id limit 1;
  if p.id is null or not p.provider_verified then return null; end if;
  return jsonb_build_object('venue',jsonb_build_object('id',p_pid,'name',p.name,'lat',p.latitude,'lon',p.longitude,'category',p.category,'address',p.address),
    'place',jsonb_build_object('pid',p_pid,'place_id',p.id,'provider_verified',true,'score',null,'activity',lit_private.activity(p.id),
      'claimed',exists(select 1 from public.lit_business_claims_v2 where place_id=p.id and status='verified'),'promos','[]'::jsonb));
end $$;

create or replace function public.lit_nearby_feed(p_places jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;places jsonb;
begin
 result:=lit_private.feed_base_v6(p_places);
 select coalesce(jsonb_agg(p||jsonb_build_object('promos',lit_private.public_promotions((p->>'place_id')::uuid)) order by p->>'pid'),'[]'::jsonb) into places from jsonb_array_elements(result->'places') x(p);
 return jsonb_set(result,'{places}',places);
end $$;
create or replace function public.lit_public_place(p_pid text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 result:=lit_private.place_base_v6(p_pid);if result is null then return null;end if;
 return jsonb_set(result,'{place,promos}',lit_private.public_promotions((result->'place'->>'place_id')::uuid));
end $$;
create or replace function public.lit_business_dashboard(p_place uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare place_data jsonb;promos jsonb;checks bigint;
begin
 perform lit_private.require_business(p_place);
 select jsonb_build_object('place_id',id,'name',name,'pid',lit_private.pid(provider,provider_place_id)) into place_data from public.lit_places_v2 where id=p_place;
 select count(distinct user_id) into checks from lit_private.arrivals where place_id=p_place and checked_at>now()-interval '24 hours';
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'kind',kind,'title',title,'details',details,'starts_at',starts_at,'ends_at',ends_at,'active',archived_at is null and starts_at<=now() and ends_at>now(),'archived',archived_at is not null,'version',revision,'views',null,'taps',null) order by created_at desc,id),'[]'::jsonb) into promos from (select * from lit_private.promotions where place_id=p_place and (created_at>now()-interval '30 days' or ends_at>now()) order by created_at desc,id limit 50) p;
 return jsonb_build_object('generated_at',now(),'place',place_data,'go',jsonb_build_object('current_count',(lit_private.activity(p_place)->>'going_count')::bigint,'updated_at',now(),'expires_after_hours',12),'crew',jsonb_build_object('planning_count',(lit_private.activity(p_place)->>'planning_count')::bigint,'updated_at',now()),'arrivals',jsonb_build_object('count_24h',checks,'method','client_location_check'),'score',null,'history','[]'::jsonb,'totals','{}'::jsonb,'hourly','[]'::jsonb,'daily','[]'::jsonb,'videos','[]'::jsonb,'feedback',lit_private.feedback_summary(p_place),'promotions',promos,'profile',(public.lit_place_details(p_place)->'profile'),'capabilities',jsonb_build_object('go_totals',true,'crew_totals',true,'arrival_feedback',true,'full_analytics',false,'business_profile',true,'promotions',true));
end $$;
revoke all on all tables in schema lit_private from public,anon,authenticated;
revoke all on all functions in schema lit_private from public,anon,authenticated;
revoke all on function public.lit_confirm_arrival(uuid,double precision,double precision,double precision),public.lit_submit_feedback(uuid,text,integer,text,boolean),public.lit_save_promotion(uuid,uuid,text,text,text,timestamptz,timestamptz,integer),public.lit_archive_promotion(uuid,integer) from public,anon,authenticated;
grant execute on function public.lit_confirm_arrival(uuid,double precision,double precision,double precision),public.lit_submit_feedback(uuid,text,integer,text,boolean),public.lit_save_promotion(uuid,uuid,text,text,text,timestamptz,timestamptz,integer),public.lit_archive_promotion(uuid,integer) to authenticated;
notify pgrst,'reload schema';
commit;


-- LIT v3.7. Run after the complete v3.6 migration. No existing videos are deleted by installation.
begin;
create table if not exists lit_private.worker_health(singleton boolean primary key default true check(singleton),seen_at timestamptz not null);
create table if not exists lit_private.video_sessions(
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,
 upload_path text not null unique,mime text not null,started_at timestamptz not null default now(),expires_at timestamptz not null default now()+interval '10 minutes',
 start_lat double precision,start_lon double precision,state text not null default 'recording' check(state in('recording','pending','processing','ready','failed','removed')),
 place_id uuid references public.lit_places_v2(id) on delete cascade,post_id uuid not null unique default gen_random_uuid(),declared_ms integer,
 lease uuid,lease_until timestamptz,attempts integer not null default 0,next_attempt timestamptz not null default now(),output_path text,error_code text,
 measured_ms integer,bytes bigint,width integer,height integer
);
create table if not exists lit_private.moderators(user_id uuid primary key references auth.users(id) on delete cascade,granted_at timestamptz not null default now());
create table if not exists lit_private.reports(
 id uuid primary key default gen_random_uuid(),post_id uuid references public.lit_venue_posts_v2(id) on delete set null,
 reporter_id uuid references auth.users(id) on delete set null,reason text not null,details text not null default '',created_at timestamptz not null default now(),
 resolved_at timestamptz,decision text,reviewer_id uuid references auth.users(id) on delete set null,review_note text,unique(post_id,reporter_id)
);
create table if not exists lit_private.blocks(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,author_id uuid not null references auth.users(id) on delete cascade,created_at timestamptz not null default now(),unique(user_id,author_id),check(user_id<>author_id));
create table if not exists lit_private.media_cleanup(
 id uuid primary key default gen_random_uuid(),bucket text not null,path text not null,created_at timestamptz not null default now(),done_at timestamptz,
 lease uuid,lease_until timestamptz,attempts integer not null default 0,next_attempt timestamptz not null default now(),unique(bucket,path)
);
-- No FK: this minimal receipt survives Auth deletion. No email/password/notes are retained here.
create table if not exists lit_private.deletion_requests(id uuid primary key default gen_random_uuid(),user_id uuid not null unique,requested_at timestamptz not null default now(),finished_at timestamptz,lease uuid,lease_until timestamptz,attempts integer not null default 0,next_attempt timestamptz not null default now());
create index if not exists lit_video_work_v7 on lit_private.video_sessions(state,next_attempt);
create index if not exists lit_report_queue_v7 on lit_private.reports(created_at) where resolved_at is null;
create index if not exists lit_cleanup_queue_v7 on lit_private.media_cleanup(next_attempt) where done_at is null;
create index if not exists lit_posts_author_v7 on public.lit_venue_posts_v2(author_id);
create index if not exists lit_posts_video_path_v7 on public.lit_venue_posts_v2(video_path);
do $$declare t text;begin foreach t in array array['worker_health','video_sessions','moderators','reports','blocks','media_cleanup','deletion_requests'] loop execute format('alter table lit_private.%I enable row level security',t);end loop;end $$;

create or replace function lit_private.require_active()
returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not exists(select 1 from auth.users where id=auth.uid()) then raise exception 'Sign in with an active LIT account.' using errcode='42501';end if;
 perform pg_catalog.pg_advisory_xact_lock_shared(pg_catalog.hashtextextended('lit:account:'||auth.uid()::text,0));
 if exists(select 1 from lit_private.deletion_requests where user_id=auth.uid()) then raise exception 'Account deletion is in progress. This account cannot make further changes.' using errcode='42501';end if;
end $$;
create or replace function lit_private.require_worker_online()
returns void language plpgsql security definer set search_path='' as $$
begin if not exists(select 1 from lit_private.worker_health where seen_at>now()-interval '5 minutes') then raise exception 'The processing service is offline. Please try again later.';end if;end $$;
create or replace function lit_private.can_moderate()
returns boolean language sql stable security definer set search_path='' as $$select lit_private.is_owner() or exists(select 1 from lit_private.moderators where user_id=auth.uid());$$;
create or replace function lit_private.require_moderator()
returns void language plpgsql security definer set search_path='' as $$
begin perform lit_private.require_active();perform 1 from lit_private.owner_config where user_id=auth.uid() for share;if found then return;end if;perform 1 from lit_private.moderators where user_id=auth.uid() for share;if not found then raise exception 'Content moderator access is required.' using errcode='42501';end if;end $$;
create or replace function public.lit_safety_access()
returns jsonb language plpgsql security definer set search_path='' as $$
begin perform lit_private.require_active();return jsonb_build_object('can_moderate',lit_private.can_moderate(),'is_owner',lit_private.is_owner());end $$;
create or replace function public.lit_manage_moderator(p_email text,p_enabled boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare target uuid;
begin perform lit_private.require_active();perform lit_private.require_owner();if p_enabled is null then raise exception 'Choose grant or revoke.';end if;
 select id into target from auth.users where lower(email)=lower(btrim(p_email)) and email_confirmed_at is not null;
 if target is null or exists(select 1 from lit_private.deletion_requests where user_id=target) then raise exception 'A confirmed active LIT account is required.';end if;
 if target=auth.uid() then raise exception 'You retain owner access.';end if;
 if p_enabled then insert into lit_private.moderators(user_id) values(target) on conflict(user_id) do nothing;else delete from lit_private.moderators where user_id=target;end if;
 insert into lit_private.verification_audit(actor_id,action,details) values(auth.uid(),case when p_enabled then 'moderator_grant' else 'moderator_revoke' end,jsonb_build_object('user_id',target));return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_list_moderators()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;begin perform lit_private.require_active();perform lit_private.require_owner();select coalesce(jsonb_agg(jsonb_build_object('email',u.email,'granted_at',m.granted_at) order by m.granted_at),'[]'::jsonb) into result from lit_private.moderators m join auth.users u on u.id=m.user_id;return result;end $$;
create or replace function public.lit_begin_capture(p_lat double precision,p_lon double precision,p_mime text,p_accuracy double precision default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();s lit_private.video_sessions;ext text;
begin perform lit_private.require_active();perform lit_private.require_worker_online();
 if not exists(select 1 from auth.users where id=u and email_confirmed_at is not null) then raise exception 'Confirm your account email first.';end if;
 if p_lat is null or p_lon is null or p_lat not between -90 and 90 or p_lon not between -180 and 180 or p_accuracy is null or p_accuracy<=0 or p_accuracy>150 then raise exception 'A fresh precise location is required. Try outdoors with precise location enabled.';end if;
 if p_mime is null or p_mime not in('video/mp4','video/webm','video/quicktime') then raise exception 'This recording format is unsupported.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:capture:'||u::text,0));
 if (select count(*) from lit_private.video_sessions where user_id=u and started_at>now()-interval '24 hours')>=20 then raise exception 'Daily recording limit reached.';end if;
 if (select count(*) from lit_private.video_sessions where user_id=u and ((state='recording' and expires_at>now()) or state in('pending','processing')))>=3 then raise exception 'Finish or discard an existing recording first.';end if;
 ext:=case p_mime when 'video/webm' then 'webm' when 'video/quicktime' then 'mov' else 'mp4' end;
 s.id:=gen_random_uuid();insert into lit_private.video_sessions(id,user_id,upload_path,mime,start_lat,start_lon) values(s.id,u,u::text||'/'||s.id::text||'.'||ext,p_mime,p_lat,p_lon) returning * into s;
 return jsonb_build_object('session_id',s.id,'upload_path',s.upload_path,'mime_type',s.mime,'bucket','lit-video-quarantine','expires_at',s.expires_at);
end $$;
create or replace function public.lit_publish_capture(p_session uuid,p_place uuid,p_duration_ms integer,p_lat double precision,p_lon double precision,p_accuracy double precision default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare s lit_private.video_sessions;v public.lit_places_v2;distance double precision;size_bytes bigint;
begin perform lit_private.require_active();select * into s from lit_private.video_sessions where id=p_session and user_id=auth.uid() for update;
 if s.id is null then raise exception 'Recording unavailable for this account.' using errcode='42501';end if;
 if s.state in('pending','processing','ready') then if s.place_id<>p_place then raise exception 'Recording was already submitted to another venue.';end if;return jsonb_build_object('post_id',s.post_id,'state',s.state);end if;
 if s.state<>'recording' or s.expires_at<=now() then raise exception 'This recording expired or was discarded. Record again.';end if;
 perform lit_private.require_worker_online();
 if now()<s.started_at+interval '10 seconds' or p_duration_ms is null or p_duration_ms not between 10000 and 30000 then raise exception 'Record a complete 10–30 second clip.';end if;
 if p_lat is null or p_lon is null or p_lat not between -90 and 90 or p_lon not between -180 and 180 or p_accuracy is null or p_accuracy<=0 or p_accuracy>150 then raise exception 'A fresh precise location is required.';end if;
 select * into v from public.lit_places_v2 where id=p_place and provider_verified and latitude is not null and longitude is not null;
 if v.id is null then raise exception 'Choose a provider-verified venue.';end if;
 distance:=6371000*acos(greatest(-1.0,least(1.0,sin(radians(p_lat))*sin(radians(v.latitude))+cos(radians(p_lat))*cos(radians(v.latitude))*cos(radians(p_lon-v.longitude)))));
 if distance>400 then raise exception 'You need to be within 400 metres of this venue.';end if;
 distance:=6371000*acos(greatest(-1.0,least(1.0,sin(radians(s.start_lat))*sin(radians(v.latitude))+cos(radians(s.start_lat))*cos(radians(v.latitude))*cos(radians(s.start_lon-v.longitude)))));
 if distance>400 then raise exception 'The recording must start near this venue.';end if;
 select case when (metadata->>'size') ~ '^[0-9]{1,12}$' then (metadata->>'size')::bigint else null end into size_bytes from storage.objects where bucket_id='lit-video-quarantine' and name=s.upload_path;
 if size_bytes is null or size_bytes<=0 or size_bytes>78643200 then raise exception 'Upload a valid recording within the 75 MiB limit first.';end if;
 update lit_private.video_sessions set place_id=p_place,declared_ms=p_duration_ms,state='pending',start_lat=null,start_lon=null where id=s.id;
 return jsonb_build_object('post_id',s.post_id,'state','pending');
end $$;
create or replace function public.lit_my_uploads()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;begin perform lit_private.require_active();select coalesce(jsonb_agg(jsonb_build_object('id',id,'post_id',post_id,'state',state,'created_at',started_at,'expires_at',started_at+interval '24 hours','error_code',error_code) order by started_at desc),'[]'::jsonb) into result from (select * from lit_private.video_sessions where user_id=auth.uid() and started_at>now()-interval '7 days' order by started_at desc limit 30) s;return result;end $$;
create or replace function public.lit_discard_capture(p_session uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare s lit_private.video_sessions;begin perform lit_private.require_active();select * into s from lit_private.video_sessions where id=p_session and user_id=auth.uid() for update;if s.id is null then raise exception 'Recording unavailable.';end if;
 update lit_private.video_sessions set state='removed',start_lat=null,start_lon=null where id=s.id;
 update public.lit_venue_posts_v2 set deleted_at=coalesce(deleted_at,now()) where id=s.post_id;
 insert into lit_private.media_cleanup(bucket,path) values('lit-video-quarantine',s.upload_path) on conflict(bucket,path) do nothing;
 if s.output_path is not null then insert into lit_private.media_cleanup(bucket,path) values('lit-fresh-videos',s.output_path) on conflict(bucket,path) do nothing;end if;
 return jsonb_build_object('removed',true);end $$;
create or replace function lit_private.visible_post(p_id uuid)
returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.lit_venue_posts_v2 p where p.id=p_id and p.deleted_at is null and p.expires_at>now() and p.created_at<=now() and not exists(select 1 from lit_private.deletion_requests d where d.user_id=p.author_id) and not exists(select 1 from lit_private.blocks b where b.user_id=auth.uid() and b.author_id=p.author_id));$$;
create or replace function public.lit_report_post(p_post uuid,p_reason text,p_details text)
returns jsonb language plpgsql security definer set search_path='' as $$
begin perform lit_private.require_active();if not lit_private.visible_post(p_post) then raise exception 'This video is no longer available.';end if;
 if p_reason is null or p_reason not in('not_fresh','wrong_venue','inappropriate','spam','safety','other') or length(coalesce(p_details,''))>500 then raise exception 'Choose a valid reason and details within 500 characters.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:report:'||auth.uid()::text,0));
 if exists(select 1 from lit_private.reports where post_id=p_post and reporter_id=auth.uid()) then return jsonb_build_object('reported',true);end if;
 if (select count(*) from lit_private.reports where reporter_id=auth.uid() and created_at>now()-interval '24 hours')>=20 then raise exception 'Daily reporting limit reached.';end if;
 insert into lit_private.reports(post_id,reporter_id,reason,details) values(p_post,auth.uid(),p_reason,btrim(coalesce(p_details,'')));return jsonb_build_object('reported',true);end $$;
create or replace function public.lit_moderation_queue(p_limit integer default 25)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;begin perform lit_private.require_moderator();
 select coalesce(jsonb_agg(jsonb_build_object('id',r.id,'post_id',r.post_id,'reason',r.reason,'details',r.details,'at',r.created_at,'venue',p.name,'unavailable',v.id is null or v.deleted_at is not null or v.expires_at<=now()) order by r.created_at),'[]'::jsonb) into result from (select * from lit_private.reports where resolved_at is null order by created_at,id limit greatest(1,least(coalesce(p_limit,25),25))) r left join public.lit_venue_posts_v2 v on v.id=r.post_id left join public.lit_places_v2 p on p.id=v.place_id;
 return jsonb_build_object('authorized',true,'reports',result);end $$;
-- Moderator preview is still private, expires quickly and does not reveal author/reporter identities.
create or replace function public.lit_moderation_preview(p_report uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare media_path text;begin perform lit_private.require_moderator();select p.video_path into media_path from lit_private.reports r join public.lit_venue_posts_v2 p on p.id=r.post_id where r.id=p_report and r.resolved_at is null and p.deleted_at is null and p.expires_at>now();if media_path is null then raise exception 'This clip is no longer available.';end if;return jsonb_build_object('path',media_path);end $$;
create or replace function public.lit_resolve_report(p_report uuid,p_decision text,p_note text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare r lit_private.reports;media_path text;
begin perform lit_private.require_moderator();if p_decision is null or p_decision not in('remove','dismiss') or p_note is null or length(btrim(p_note)) not between 3 and 500 then raise exception 'Choose a decision and a 3–500 character review note.';end if;
 select * into r from lit_private.reports where id=p_report for update;if r.id is null then raise exception 'Report unavailable.';end if;
 if r.resolved_at is not null then if r.decision=p_decision then return jsonb_build_object('resolved',true);end if;raise exception 'This report was already resolved. Refresh the queue.';end if;
 if p_decision='remove' and r.post_id is not null then
 update public.lit_venue_posts_v2 set deleted_at=coalesce(deleted_at,now()) where id=r.post_id returning video_path into media_path;
 update lit_private.video_sessions set state='removed' where post_id=r.post_id;
 if media_path is not null then insert into lit_private.media_cleanup(bucket,path) values('lit-fresh-videos',media_path) on conflict(bucket,path) do nothing;end if;
 end if;
 update lit_private.reports set resolved_at=now(),decision=p_decision,reviewer_id=auth.uid(),review_note=btrim(p_note) where id=p_report;
 insert into lit_private.verification_audit(actor_id,action,details) values(auth.uid(),'report_'||p_decision,jsonb_build_object('report_id',p_report,'post_id',r.post_id));return jsonb_build_object('resolved',true);end $$;
create or replace function public.lit_delete_my_post(p_post uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare media_path text;begin perform lit_private.require_active();select video_path into media_path from public.lit_venue_posts_v2 where id=p_post and author_id=auth.uid() for update;if media_path is null then raise exception 'This is not your video.' using errcode='42501';end if;
 update public.lit_venue_posts_v2 set deleted_at=coalesce(deleted_at,now()) where id=p_post;update lit_private.video_sessions set state='removed' where post_id=p_post;
 insert into lit_private.media_cleanup(bucket,path) values('lit-fresh-videos',media_path) on conflict(bucket,path) do nothing;return jsonb_build_object('removed',true);end $$;
create or replace function public.lit_block_post_author(p_post uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare author uuid;begin perform lit_private.require_active();select author_id into author from public.lit_venue_posts_v2 where id=p_post and deleted_at is null and expires_at>now();if author is null or author=auth.uid() then raise exception 'Choose another available creator.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:blocks:'||auth.uid()::text,0));
 if (select count(*) from lit_private.blocks where user_id=auth.uid())>=500 and not exists(select 1 from lit_private.blocks where user_id=auth.uid() and author_id=author) then raise exception 'Block limit reached. Unblock a creator first.';end if;
 insert into lit_private.blocks(user_id,author_id) values(auth.uid(),author) on conflict(user_id,author_id) do nothing;return jsonb_build_object('blocked',true);end $$;
create or replace function public.lit_my_blocks()
returns jsonb language plpgsql security definer set search_path='' as $$declare result jsonb;begin perform lit_private.require_active();select coalesce(jsonb_agg(jsonb_build_object('id',id) order by created_at),'[]'::jsonb) into result from lit_private.blocks where user_id=auth.uid();return result;end $$;
create or replace function public.lit_unblock_creator(p_block uuid)
returns jsonb language plpgsql security definer set search_path='' as $$begin perform lit_private.require_active();delete from lit_private.blocks where id=p_block and user_id=auth.uid();return jsonb_build_object('unblocked',true);end $$;

-- Re-authentication is performed by the server endpoint before this service-only request.
create or replace function public.lit_request_account_deletion(p_actor uuid,p_confirmation text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare receipt uuid;
begin
 if p_actor is null or p_confirmation is distinct from 'DELETE' then raise exception 'Type DELETE to confirm.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:account:'||p_actor::text,0));
 if exists(select 1 from lit_private.owner_config where user_id=p_actor) then raise exception 'The platform owner cannot delete this account. Transfer platform ownership through an operator procedure first.';end if;
 if not exists(select 1 from auth.users where id=p_actor) then raise exception 'Account unavailable.';end if;
 perform lit_private.require_worker_online();
 insert into lit_private.deletion_requests(user_id) values(p_actor) on conflict(user_id) do nothing;
 select id into receipt from lit_private.deletion_requests where user_id=p_actor;
 -- Remove access immediately; physical cleanup and Auth deletion run in the trusted worker.
 update public.lit_venue_posts_v2 set deleted_at=coalesce(deleted_at,now()) where author_id=p_actor;
 update lit_private.video_sessions set state='removed',start_lat=null,start_lon=null where user_id=p_actor;
 update public.profiles set username=null,display_name=null,avatar_url=null where id=p_actor;
 delete from public.lit_go_intents_v2 where user_id=p_actor;
 update public.lit_business_claims_v2 set status='rejected',review_version=review_version+1,updated_at=now() where claimant_id=p_actor;
 delete from lit_private.reviewers where user_id=p_actor;delete from lit_private.moderators where user_id=p_actor;
 delete from lit_private.crews where owner_id=p_actor;
 delete from lit_private.crew_outings where organizer_id=p_actor;
 delete from lit_private.crew_members where user_id=p_actor;
 delete from lit_private.outing_responses where user_id=p_actor;
 return jsonb_build_object('requested',true,'receipt',receipt,'state','pending');
end $$;
create or replace function public.lit_deletion_status(p_receipt uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;begin
 select jsonb_build_object('state',case when finished_at is not null then 'completed' when attempts>=5 then 'needs_operator' else 'pending' end,'requested_at',requested_at,'completed_at',finished_at) into result from lit_private.deletion_requests where id=p_receipt;
 if result is null then raise exception 'Deletion receipt unavailable.';end if;return result;end $$;
-- Service-only maintenance handles expiry, orphaned uploads and deletion receipts.
create or replace function public.lit_worker_claim()
returns jsonb language plpgsql security definer set search_path='' as $$
#variable_conflict use_column
declare c lit_private.media_cleanup;s lit_private.video_sessions;d lit_private.deletion_requests;token uuid;
begin
 insert into lit_private.worker_health(singleton,seen_at) values(true,now()) on conflict(singleton) do update set seen_at=now();
 update lit_private.video_sessions set state='failed',error_code='SESSION_EXPIRED',start_lat=null,start_lon=null where state='recording' and expires_at<=now();
 update lit_private.video_sessions set state='failed',error_code='PROCESSING_EXPIRED',start_lat=null,start_lon=null where state in('pending','processing') and started_at<now()-interval '24 hours';
 insert into lit_private.media_cleanup(bucket,path)
 select 'lit-video-quarantine',upload_path from lit_private.video_sessions where state in('failed','removed','ready')
 union select 'lit-fresh-videos',video_path from public.lit_venue_posts_v2 where deleted_at is not null or expires_at<=now()
 union select 'lit-fresh-videos',output_path from lit_private.video_sessions where state in('failed','removed') and output_path is not null
 union select o.bucket_id,o.name from storage.objects o where o.bucket_id='lit-fresh-videos' and o.name ~ '^[a-f0-9-]{36}/[a-f0-9-]{36}/[a-f0-9-]{36}\.mp4$' and o.created_at<now()-interval '15 minutes' and not exists(select 1 from public.lit_venue_posts_v2 p where p.video_path=o.name and p.deleted_at is null and p.expires_at>now()) and not exists(select 1 from lit_private.video_sessions s where s.output_path=o.name and s.state='processing' and s.lease_until>now())
 on conflict(bucket,path) do nothing;
 -- Queue all objects owned by a deleting account, including older buckets. Never delete provider venue records.
 insert into lit_private.media_cleanup(bucket,path)
 select o.bucket_id,o.name from storage.objects o join lit_private.deletion_requests d on d.finished_at is null and ((to_jsonb(o)->>'owner_id')=d.user_id::text or (to_jsonb(o)->>'owner')=d.user_id::text or (o.bucket_id in('lit-video-quarantine','lit-fresh-videos','lit-videos') and split_part(o.name,'/',1)=d.user_id::text))
 union select 'lit-fresh-videos',p.video_path from public.lit_venue_posts_v2 p join lit_private.deletion_requests d on d.user_id=p.author_id where d.finished_at is null
 on conflict(bucket,path) do nothing;
 select * into c from lit_private.media_cleanup where done_at is null and next_attempt<=now() and (lease_until is null or lease_until<now()) order by created_at,id for update skip locked limit 1;
 if c.id is not null then token:=gen_random_uuid();update lit_private.media_cleanup set lease=token,lease_until=now()+interval '5 minutes',attempts=attempts+1 where id=c.id;return jsonb_build_object('kind','cleanup','id',c.id,'lease',token,'bucket',c.bucket,'path',c.path);end if;
 select * into d from lit_private.deletion_requests where finished_at is null and next_attempt<=now() and (lease_until is null or lease_until<now()) and attempts<5 order by requested_at,id for update skip locked limit 1;
 if d.id is not null then
 if exists(select 1 from storage.objects o where (to_jsonb(o)->>'owner_id')=d.user_id::text or (to_jsonb(o)->>'owner')=d.user_id::text or (o.bucket_id in('lit-video-quarantine','lit-fresh-videos','lit-videos') and split_part(o.name,'/',1)=d.user_id::text)) or exists(select 1 from public.lit_venue_posts_v2 p join lit_private.media_cleanup c on c.bucket='lit-fresh-videos' and c.path=p.video_path where p.author_id=d.user_id and c.done_at is null) then
 update lit_private.deletion_requests set next_attempt=now()+interval '10 seconds' where id=d.id;
 else token:=gen_random_uuid();update lit_private.deletion_requests set lease=token,lease_until=now()+interval '5 minutes',attempts=attempts+1 where id=d.id;return jsonb_build_object('kind','deletion','id',d.id,'lease',token,'user_id',d.user_id);end if;
 end if;
 select * into s from lit_private.video_sessions where ((state='pending' and next_attempt<=now()) or (state='processing' and lease_until<now())) and attempts<3 and started_at>now()-interval '24 hours' and not exists(select 1 from lit_private.deletion_requests d where d.user_id=video_sessions.user_id) order by started_at,id for update skip locked limit 1;
 if s.id is not null then
 token:=gen_random_uuid();update lit_private.video_sessions set state='processing',lease=token,lease_until=now()+interval '10 minutes',attempts=attempts+1,output_path=user_id::text||'/'||id::text||'/'||token::text||'.mp4' where id=s.id returning * into s;
 return jsonb_build_object('kind','video','id',s.id,'lease',token,'bucket','lit-video-quarantine','path',s.upload_path,'output_path',s.output_path,'declared_ms',s.declared_ms);end if;
 update lit_private.video_sessions set state='failed',error_code='PROCESSING_FAILED' where state='processing' and lease_until<now() and attempts>=3;
 return null;
end $$;
create or replace function public.lit_worker_result(p_kind text,p_id uuid,p_lease uuid,p_ok boolean,p_metadata jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare s lit_private.video_sessions;ms integer;size_bytes bigint;w integer;h integer;u uuid;
begin
 if p_ok is null then raise exception 'Worker outcome required.';end if;
 if p_kind='cleanup' then
 update lit_private.media_cleanup set done_at=case when p_ok then now() else null end,lease_until=null,next_attempt=now()+interval '1 minute' where id=p_id and lease=p_lease and lease_until>now();if not found then raise exception 'Worker lease expired.';end if;
 elsif p_kind='deletion' then
 select user_id into u from lit_private.deletion_requests where id=p_id and lease=p_lease and lease_until>now() for update;if u is null then raise exception 'Worker lease expired.';end if;
 if p_ok and exists(select 1 from auth.users where id=u) then raise exception 'Auth deletion has not completed.';end if;
 update lit_private.deletion_requests set finished_at=case when p_ok then now() else null end,lease_until=null,next_attempt=now()+interval '1 minute' where id=p_id;
 elsif p_kind='video' then
 select * into s from lit_private.video_sessions where id=p_id and lease=p_lease and lease_until>now() and state='processing' for update;
 if s.id is null then raise exception 'Worker lease expired or recording was removed.';end if;
 if exists(select 1 from lit_private.deletion_requests where user_id=s.user_id) then raise exception 'Account deletion is in progress.';end if;
 if p_ok then
 ms:=(p_metadata->>'duration_ms')::integer;size_bytes:=(p_metadata->>'bytes')::bigint;w:=(p_metadata->>'width')::integer;h:=(p_metadata->>'height')::integer;
 if ms is null or ms not between 10000 and 30100 or abs(ms-s.declared_ms)>1000 or size_bytes is null or size_bytes<=0 or size_bytes>78643200 or w is null or h is null or w<2 or h<2 or w>1280 or h>1280 or p_metadata->>'content_type' is distinct from 'video/mp4' then raise exception 'Processed metadata failed validation.';end if;
 if not exists(select 1 from storage.objects where bucket_id='lit-fresh-videos' and name=s.output_path and (metadata->>'size')::bigint=size_bytes) then raise exception 'Processed object unavailable.';end if;
 if s.started_at<now()-interval '24 hours' then raise exception 'Recording freshness expired.';end if;
 insert into public.lit_venue_posts_v2(id,place_id,author_id,video_path,post_type,created_at,expires_at) values(s.post_id,s.place_id,s.user_id,s.output_path,case when exists(select 1 from public.lit_business_claims_v2 where place_id=s.place_id and claimant_id=s.user_id and status='verified') then 'business' else 'community' end,s.started_at,s.started_at+interval '24 hours') on conflict(id) do nothing;
 update lit_private.video_sessions set state='ready',measured_ms=ms,bytes=size_bytes,width=w,height=h,lease_until=null,error_code=null where id=s.id;
 else
 update lit_private.video_sessions set state=case when attempts>=3 or p_metadata->>'code'='MEDIA_INVALID' then 'failed' else 'pending' end,error_code=case when p_metadata->>'code'='MEDIA_INVALID' then 'MEDIA_INVALID' else 'PROCESSING_FAILED' end,lease_until=null,next_attempt=now()+interval '1 minute' where id=s.id;
 end if;
 else raise exception 'Unknown worker task.';end if;
 return jsonb_build_object('saved',true);
end $$;
-- Recover an uncertain publication response without deleting a successfully committed object.
create or replace function public.lit_worker_result_status(p_id uuid,p_lease uuid)
returns jsonb language sql stable security definer set search_path='' as $$select jsonb_build_object('published',state='ready' and lease=p_lease,'state',state) from lit_private.video_sessions where id=p_id;$$;
-- Purge known application rows before the worker calls the Supabase Auth Admin API.
create or replace function public.lit_worker_purge_account(p_id uuid,p_lease uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid;t record;idlist uuid[];
begin
 select user_id into u from lit_private.deletion_requests where id=p_id and lease=p_lease and lease_until>now() and finished_at is null for update;if u is null then raise exception 'Worker lease expired.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:account:'||u::text,0));
 if exists(select 1 from lit_private.owner_config where user_id=u) then raise exception 'Owner deletion is prohibited.';end if;
 if exists(select 1 from storage.objects o where (to_jsonb(o)->>'owner_id')=u::text or (to_jsonb(o)->>'owner')=u::text or (o.bucket_id in('lit-video-quarantine','lit-fresh-videos','lit-videos') and split_part(o.name,'/',1)=u::text)) then raise exception 'Storage cleanup is not complete.';end if;
 select array_agg(id) into idlist from public.lit_business_claims_v2 where claimant_id=u;
 delete from lit_private.verification_audit where claim_id=any(coalesce(idlist,'{}'::uuid[]));
 update lit_private.verification_audit set actor_id=null where actor_id=u;
 update lit_private.reports set reporter_id=null,details='' where reporter_id=u;
 update lit_private.reports set reviewer_id=null,review_note=null where reviewer_id=u;
 delete from lit_private.blocks where user_id=u or author_id=u;
 delete from lit_private.video_sessions where user_id=u;
 delete from lit_private.arrivals where user_id=u;
 delete from lit_private.crews where owner_id=u;delete from lit_private.crew_outings where organizer_id=u;delete from lit_private.crew_members where user_id=u;delete from lit_private.outing_responses where user_id=u;
 delete from lit_private.crew_request_limits where user_id=u;delete from lit_private.place_lookup_limits where user_id=u;delete from lit_private.reviewers where user_id=u;delete from lit_private.moderators where user_id=u;
 -- Optional legacy tables use the known inventory's user columns. Shared venues/events stay with owner/creator detached.
 for t in select * from (values('follows','user_id','delete'),('going_intents','user_id','delete'),('engagement_events','actor_id','delete'),('lit_engagement_events_v2','user_id','delete'),('lit_crew_members_v2','user_id','delete'),('lit_crew_members_v2','member_id','delete'),('lit_outing_invites_v2','invitee_id','delete'),('lit_outings_v2','organizer_id','delete'),('venues','owner_id','detach'),('posts','creator_id','delete'),('events','creator_id','detach')) x(tab,col,mode) loop
 if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t.tab and column_name=t.col) then
 if t.mode='delete' then execute format('delete from public.%I where %I=$1',t.tab,t.col) using u;else execute format('update public.%I set %I=null where %I=$1',t.tab,t.col,t.col) using u;end if;end if;end loop;
 delete from public.lit_go_intents_v2 where user_id=u;delete from public.lit_business_claims_v2 where claimant_id=u;delete from public.lit_venue_posts_v2 where author_id=u;delete from public.profiles where id=u;
 return jsonb_build_object('purged',true,'user_id',u);
end $$;

create or replace function public.lit_operator_status()
returns jsonb language plpgsql security definer set search_path='' as $$
begin perform lit_private.require_active();perform lit_private.require_owner();return jsonb_build_object('worker_seen_at',(select seen_at from lit_private.worker_health where singleton),'worker_online',exists(select 1 from lit_private.worker_health where seen_at>now()-interval '5 minutes'),'video_pending',(select count(*) from lit_private.video_sessions where state in('pending','processing')),'video_failed_7d',(select count(*) from lit_private.video_sessions where state='failed' and started_at>now()-interval '7 days'),'media_cleanup_pending',(select count(*) from lit_private.media_cleanup where done_at is null),'deletions_pending',(select count(*) from lit_private.deletion_requests where finished_at is null),'deletions_needing_attention',(select count(*) from lit_private.deletion_requests where finished_at is null and attempts>=5));end $$;
create or replace function public.lit_retry_deletions()
returns jsonb language plpgsql security definer set search_path='' as $$
begin perform lit_private.require_active();perform lit_private.require_owner();update lit_private.deletion_requests set attempts=0,next_attempt=now() where finished_at is null and attempts>=5 and (lease_until is null or lease_until<now());insert into lit_private.verification_audit(actor_id,action) values(auth.uid(),'deletion_retry');return jsonb_build_object('saved',true);end $$;

-- Delivery authorization: blocked/deleted/expired videos cannot receive fresh signed URLs.
revoke insert,update,delete,truncate,references,trigger on public.lit_venue_posts_v2 from public,anon,authenticated;
drop policy if exists lit_posts_read_v2 on public.lit_venue_posts_v2;
create policy lit_posts_read_v2 on public.lit_venue_posts_v2 for select to authenticated using(lit_private.visible_post(id));
-- Avoid recursive table policies by using the security-definer helper. Remove earlier broad read policy names.
drop policy if exists posts_read on public.lit_venue_posts_v2;
drop policy if exists lit_video_own_upload on storage.objects;
drop policy if exists lit_video_authenticated_read on storage.objects;
drop policy if exists lit_video_own_cleanup on storage.objects;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('lit-video-quarantine','lit-video-quarantine',false,78643200,array['video/webm','video/mp4','video/quicktime']) on conflict(id) do update set public=false,file_size_limit=78643200,allowed_mime_types=excluded.allowed_mime_types;
update storage.buckets set public=false where id='lit-fresh-videos';
drop policy if exists lit_quarantine_upload_v7 on storage.objects;
create policy lit_quarantine_upload_v7 on storage.objects for insert to authenticated with check(bucket_id='lit-video-quarantine' and exists(select 1 from lit_private.video_sessions s where s.user_id=auth.uid() and s.upload_path=name and s.state='recording' and s.expires_at>now()) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid()));
drop policy if exists lit_processed_read_v7 on storage.objects;
create policy lit_processed_read_v7 on storage.objects for select to authenticated using(bucket_id='lit-fresh-videos' and exists(select 1 from public.lit_venue_posts_v2 p where p.video_path=name and p.deleted_at is null and p.expires_at>now() and (lit_private.visible_post(p.id) or lit_private.can_moderate())) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid()));
-- Policies need carefully scoped public helpers, not access to private tables.
create or replace function public.lit_video_upload_allowed(p_path text)
returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from lit_private.video_sessions where user_id=auth.uid() and upload_path=p_path and state='recording' and expires_at>now()) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid());$$;
create or replace function public.lit_video_read_allowed(p_path text)
returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.lit_venue_posts_v2 p where video_path=p_path and deleted_at is null and expires_at>now() and (lit_private.visible_post(p.id) or lit_private.can_moderate())) and exists(select 1 from auth.users where id=auth.uid()) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid());$$;
drop policy lit_quarantine_upload_v7 on storage.objects;
create policy lit_quarantine_upload_v7 on storage.objects for insert to authenticated with check(bucket_id='lit-video-quarantine' and public.lit_video_upload_allowed(name));
drop policy lit_processed_read_v7 on storage.objects;
create policy lit_processed_read_v7 on storage.objects for select to authenticated using(bucket_id='lit-fresh-videos' and public.lit_video_read_allowed(name));
-- Direct post reads use a public boolean helper so no private-schema grants are required.
create or replace function public.lit_post_visible(p_id uuid)
returns boolean language sql stable security definer set search_path='' as $$select lit_private.visible_post(p_id) and exists(select 1 from auth.users where id=auth.uid()) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid());$$;
drop policy lit_posts_read_v2 on public.lit_venue_posts_v2;
create policy lit_posts_read_v2 on public.lit_venue_posts_v2 for select to authenticated using(public.lit_post_visible(id));

-- Restrictive guards also cover direct legacy table/storage API requests with an old token.
create or replace function public.lit_account_active()
returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from auth.users where id=auth.uid()) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid());$$;
drop policy if exists lit_active_storage_v7 on storage.objects;
create policy lit_active_storage_v7 on storage.objects as restrictive for all to authenticated using((select public.lit_account_active())) with check((select public.lit_account_active()));
do $$declare t record;begin for t in select c.relname from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r' and (c.relname like 'lit_%' or c.relname in('profiles','posts','follows','boosts','areas','engagement_events','venues','events','going_intents')) loop
 execute format('alter table public.%I enable row level security',t.relname);
 execute format('drop policy if exists lit_active_account_v7 on public.%I',t.relname);
 execute format('create policy lit_active_account_v7 on public.%I as restrictive for all to authenticated using((select public.lit_account_active())) with check((select public.lit_account_active()))',t.relname);
 end loop;end $$;

-- Copy the v3.6 feed and filter blocked/removed authors without changing any other fields.
create or replace function lit_private.feed_base_v7(p_places jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;places jsonb;
begin
 result:=lit_private.feed_base_v6(p_places);
 select coalesce(jsonb_agg(p||jsonb_build_object('promos',lit_private.public_promotions((p->>'place_id')::uuid)) order by p->>'pid'),'[]'::jsonb) into places from jsonb_array_elements(result->'places') x(p);
 return jsonb_set(result,'{places}',places);
end $$;
create or replace function public.lit_nearby_feed(p_places jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;posts jsonb;begin
 if auth.uid() is not null then perform lit_private.require_active();end if;
 result:=lit_private.feed_base_v7(p_places);
 select coalesce(jsonb_agg(p||jsonb_build_object('mine',v.author_id=auth.uid()) order by p->>'created_at' desc,p->>'id'),'[]'::jsonb) into posts from jsonb_array_elements(result->'posts') x(p) join public.lit_venue_posts_v2 v on v.id=(p->>'id')::uuid where lit_private.visible_post(v.id);
 return jsonb_set(result,'{posts}',posts);
end $$;
-- Guard previous mutating/read RPCs against stale tokens after a deletion request.
-- Uses only our existing public PL/pgSQL functions, retaining their signatures and permissions.
do $guard$
declare f record;definition text;body text;
begin
 for f in select p.oid,p.prosrc,p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace join pg_language l on l.oid=p.prolang where n.nspname='public' and l.lanname='plpgsql' and p.proname like 'lit_%' and p.prosecdef and p.proname not like 'lit_worker_%' and p.proname not in('lit_request_account_deletion','lit_deletion_status','lit_register_verified_place','lit_reserve_place_lookup') loop
 if position('lit_private.require_active()' in f.prosrc)=0 then
 body:=regexp_replace(f.prosrc,'\mbegin\M','begin if auth.uid() is not null then perform lit_private.require_active();end if;','i');
 if body=f.prosrc then raise exception 'Cannot guard function %',f.proname;end if;
 definition:=pg_get_functiondef(f.oid);execute replace(definition,f.prosrc,body);
 end if;
 end loop;
end $guard$;
revoke all on all tables in schema lit_private from public,anon,authenticated;
revoke all on all functions in schema lit_private from public,anon,authenticated;
do $$declare f record;begin for f in select p.oid::regprocedure name,p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname in('lit_operator_status','lit_retry_deletions','lit_account_active','lit_safety_access','lit_manage_moderator','lit_list_moderators','lit_begin_capture','lit_publish_capture','lit_my_uploads','lit_discard_capture','lit_report_post','lit_moderation_queue','lit_moderation_preview','lit_resolve_report','lit_delete_my_post','lit_block_post_author','lit_my_blocks','lit_unblock_creator','lit_video_upload_allowed','lit_video_read_allowed','lit_post_visible','lit_worker_claim','lit_worker_result_status','lit_worker_result','lit_worker_purge_account','lit_request_account_deletion','lit_deletion_status') loop
 execute format('revoke all on function %s from public,anon,authenticated',f.name);
 if f.proname like 'lit_worker_%' or f.proname='lit_request_account_deletion' then execute format('grant execute on function %s to service_role',f.name);
 elsif f.proname='lit_deletion_status' then execute format('grant execute on function %s to anon,authenticated',f.name);
 else execute format('grant execute on function %s to authenticated',f.name);end if;
 end loop;end $$;
notify pgrst,'reload schema';
commit;
