-- LIT v3.3 cumulative migration for the schema inventoried in this chat.
-- Run once in the existing project's SQL Editor; safe to rerun.
-- Supersedes batches 1, 2 and 3. Bootstrap the owner separately afterward.
begin;

create schema if not exists lit_private;
revoke all on schema lit_private from public,anon,authenticated;

create table if not exists lit_private.owner_config (
  singleton boolean primary key default true check (singleton),
  user_id uuid not null unique references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);
create table if not exists lit_private.reviewers (
  user_id uuid primary key references auth.users(id) on delete cascade,
  granted_by uuid not null references auth.users(id),
  granted_at timestamptz not null default now(),
  revoked_at timestamptz
);
create table if not exists lit_private.verification_audit (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  claim_id uuid,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create table if not exists lit_private.place_lookup_limits (
  user_id uuid primary key references auth.users(id) on delete cascade,
  day date not null default current_date,
  daily_count integer not null default 0,
  minute timestamptz not null default date_trunc('minute',now()),
  minute_count integer not null default 0
);
alter table lit_private.owner_config enable row level security;
alter table lit_private.reviewers enable row level security;
alter table lit_private.verification_audit enable row level security;
alter table lit_private.place_lookup_limits enable row level security;

alter table public.lit_business_claims_v2
  add column if not exists business_role text,
  add column if not exists business_email text,
  add column if not exists business_phone text,
  add column if not exists applicant_note text,
  add column if not exists evidence_url text,
  add column if not exists applicant_message text,
  add column if not exists reviewed_by uuid references auth.users(id) on delete set null,
  add column if not exists reviewed_at timestamptz,
  add column if not exists verification_method text,
  add column if not exists verification_source text,
  add column if not exists reviewer_note text,
  add column if not exists review_version integer not null default 1,
  add column if not exists updated_at timestamptz not null default now();
alter table public.lit_places_v2
  add column if not exists provider_verified boolean not null default false,
  add column if not exists provider_verified_at timestamptz;
alter table public.lit_go_intents_v2 add column if not exists expires_at timestamptz;
update public.lit_go_intents_v2 set expires_at=created_at+interval '12 hours' where expires_at is null;
alter table public.lit_go_intents_v2 alter column expires_at set default (now()+interval '12 hours');
alter table public.lit_go_intents_v2 alter column expires_at set not null;
create index if not exists lit_go_place_expiry_v3 on public.lit_go_intents_v2(place_id,expires_at);
create index if not exists lit_claim_review_v3 on public.lit_business_claims_v2(status,updated_at desc,id desc);
create index if not exists lit_claim_audit_v3 on lit_private.verification_audit(claim_id,id desc);

create table if not exists public.lit_business_profiles_v3 (
  place_id uuid primary key references public.lit_places_v2(id) on delete cascade,
  description text not null default '' check (length(description)<=600),
  hours text not null default '' check (length(hours)<=200),
  phone text not null default '' check (length(phone)<=40),
  website text not null default '' check (website='' or (length(website)<=200 and website ~* '^https?://[^[:space:]]+$')),
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);
alter table public.lit_business_profiles_v3 enable row level security;
-- Functions below are the only client write/read paths for privileged claim fields.
revoke all on public.lit_business_claims_v2,public.lit_business_profiles_v3 from public,anon,authenticated;
revoke insert,update,delete,truncate,references,trigger on public.lit_places_v2,public.lit_go_intents_v2 from public,anon,authenticated;

create or replace function lit_private.is_owner()
returns boolean language sql stable security definer set search_path='' as $$
  select exists(select 1 from lit_private.owner_config where user_id=auth.uid());
$$;
create or replace function lit_private.can_review()
returns boolean language sql stable security definer set search_path='' as $$
  select lit_private.is_owner() or exists(
    select 1 from lit_private.reviewers where user_id=auth.uid() and revoked_at is null
  );
$$;
create or replace function lit_private.require_reviewer()
returns void language plpgsql security definer set search_path='' as $$
begin
  perform 1 from lit_private.owner_config where user_id=auth.uid() for share;
  if found then return; end if;
  perform 1 from lit_private.reviewers where user_id=auth.uid() and revoked_at is null for share;
  if not found then raise exception 'Business review access is required.' using errcode='42501'; end if;
end $$;
create or replace function lit_private.require_owner()
returns void language plpgsql security definer set search_path='' as $$
begin
  if not lit_private.is_owner() then raise exception 'Only the LIT owner can manage reviewers.' using errcode='42501'; end if;
end $$;
create or replace function lit_private.require_business(p_place uuid)
returns void language plpgsql security definer set search_path='' as $$
begin
  perform 1 from public.lit_business_claims_v2
  where place_id=p_place and claimant_id=auth.uid() and status='verified' for share;
  if not found then raise exception 'A verified claim for this venue is required.' using errcode='42501'; end if;
end $$;
create or replace function lit_private.pid(p_provider text,p_id text)
returns text language sql immutable set search_path='' as $$
  select case when p_id like 'geoapify:%' or p_id like 'osm:%' then p_id
    when p_provider='geoapify' then 'geoapify:'||p_id
    when p_provider in ('osm','openstreetmap') then 'osm:'||p_id
    else p_provider||':'||p_id end;
$$;
create or replace function lit_private.activity(p_place uuid)
returns jsonb language sql stable security definer set search_path='' as $$
  select jsonb_build_object('going_count',count(*),'planning_count',null,
    'updated_at',now(),'window_start',now()-interval '12 hours','window_end',now()+interval '12 hours')
  from (select distinct on (user_id) user_id,place_id from public.lit_go_intents_v2
    where expires_at>now() order by user_id,created_at desc,place_id) current_go
  where place_id=p_place;
$$;

create or replace function public.lit_review_access()
returns jsonb language sql stable security definer set search_path='' as $$
  select jsonb_build_object('can_review',lit_private.can_review(),'is_owner',lit_private.is_owner());
$$;
create or replace function public.lit_list_reviewers()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  perform lit_private.require_owner();
  select coalesce(jsonb_agg(jsonb_build_object('user_id',r.user_id,'email',u.email,
    'granted_at',r.granted_at,'active',r.revoked_at is null) order by r.granted_at desc),'[]'::jsonb)
    into result from lit_private.reviewers r join auth.users u on u.id=r.user_id;
  return result;
end $$;
create or replace function public.lit_manage_reviewer(p_email text,p_enabled boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare target uuid; normalized text:=lower(btrim(p_email));
begin
  perform lit_private.require_owner();
  if p_enabled is null or normalized is null or length(normalized)>254 then raise exception 'Enter a valid account email.'; end if;
  select id into target from auth.users where lower(email)=normalized and email_confirmed_at is not null;
  if target is null then raise exception 'This person must create a LIT account and confirm their email first.'; end if;
  if target=auth.uid() then raise exception 'The owner account cannot be changed through reviewer controls.'; end if;
  insert into lit_private.reviewers(user_id,granted_by,revoked_at)
    values(target,auth.uid(),case when p_enabled then null else now() end)
    on conflict(user_id) do update set granted_by=auth.uid(),granted_at=now(),revoked_at=excluded.revoked_at;
  insert into lit_private.verification_audit(actor_id,action,details)
    values(auth.uid(),case when p_enabled then 'reviewer_granted' else 'reviewer_revoked' end,jsonb_build_object('user_id',target));
  return jsonb_build_object('saved',true,'enabled',p_enabled);
end $$;

create or replace function public.lit_request_claim(p_place uuid,p_role text,p_email text,p_phone text,p_note text,p_evidence_url text default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); old public.lit_business_claims_v2%rowtype; new_id uuid;
  email text:=lower(btrim(p_email)); evidence text:=nullif(btrim(p_evidence_url),'');
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  if p_role is null or p_role not in ('Owner','General manager','Marketing / social','Staff (authorised)') then raise exception 'Choose your business role.'; end if;
  if email is null or length(email)>254 or email !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' then raise exception 'Enter a valid business email.'; end if;
  if length(coalesce(p_phone,''))>40 or length(coalesce(p_note,''))>600 then raise exception 'Contact details or note are too long.'; end if;
  if evidence is not null and (length(evidence)>500 or evidence !~* '^https://[^[:space:]]+$') then raise exception 'Use an HTTPS link to your official business page.'; end if;
  if not exists(select 1 from public.lit_places_v2 where id=p_place and provider_verified) then raise exception 'Refresh this venue so its provider identity can be verified first.'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:claim:'||u::text,0));
  select * into old from public.lit_business_claims_v2 where claimant_id=u and place_id=p_place for update;
  if old.status='verified' then raise exception 'This account already has verified access to this venue.'; end if;
  if old.updated_at>now()-interval '30 seconds' then raise exception 'Please wait a moment before resubmitting.'; end if;
  if old.id is null and (select count(*) from public.lit_business_claims_v2 where claimant_id=u and created_at>now()-interval '24 hours')>=10 then raise exception 'Daily claim limit reached. Try again tomorrow.'; end if;
  insert into public.lit_business_claims_v2(place_id,claimant_id,status,business_role,business_email,business_phone,applicant_note,evidence_url)
    values(p_place,u,'pending',p_role,email,btrim(coalesce(p_phone,'')),btrim(coalesce(p_note,'')),evidence)
    on conflict(place_id,claimant_id) do update set status='pending',business_role=excluded.business_role,
      business_email=excluded.business_email,business_phone=excluded.business_phone,applicant_note=excluded.applicant_note,
      evidence_url=excluded.evidence_url,applicant_message=null,reviewed_by=null,reviewed_at=null,
      verification_method=null,verification_source=null,reviewer_note=null,
      review_version=public.lit_business_claims_v2.review_version+1,updated_at=now()
    returning id into new_id;
  insert into lit_private.verification_audit(actor_id,claim_id,action)
    values(u,new_id,case when old.id is null then 'claim_requested' else 'claim_resubmitted' end);
  return jsonb_build_object('submitted',true,'claim_id',new_id,'status','pending');
end $$;
create or replace function public.lit_my_business()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',c.id,'place_id',c.place_id,'status',c.status,
    'name',p.name,'pid',lit_private.pid(p.provider,p.provider_place_id),'lat',p.latitude,'lon',p.longitude,'requested_at',c.created_at,
    'updated_at',c.updated_at,'message',c.applicant_message,'business_role',c.business_role,
    'business_email',c.business_email,'business_phone',c.business_phone,
    'note',c.applicant_note,'evidence_url',c.evidence_url,
    'needs_information',c.status='pending' and c.applicant_message is not null and c.reviewed_at is not null) order by c.updated_at desc,c.id),'[]'::jsonb)
    into result from public.lit_business_claims_v2 c join public.lit_places_v2 p on p.id=c.place_id where c.claimant_id=auth.uid();
  return result;
end $$;
create or replace function public.lit_verification_queue(p_status text default 'pending',p_cursor jsonb default null,p_limit integer default 25)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb; cursor_at timestamptz; cursor_id uuid; has_more boolean; next_cursor jsonb;
begin
  perform lit_private.require_reviewer();
  if p_status is null or p_status not in ('pending','verified','rejected') or p_limit is null or p_limit not between 1 and 50 then raise exception 'Invalid review filter.'; end if;
  if p_cursor is not null then cursor_at:=(p_cursor->>'at')::timestamptz; cursor_id:=(p_cursor->>'id')::uuid;
    if cursor_at is null or cursor_id is null then raise exception 'Invalid review cursor.'; end if; end if;
  with selected as (
    select c.*,p.name,p.address,p.latitude,p.longitude,p.provider,p.provider_place_id,u.email as account_email,
      u.email_confirmed_at is not null as account_email_confirmed,
      (select count(*) from public.lit_business_claims_v2 other where other.place_id=c.place_id and other.status='verified' and other.id<>c.id) as other_verified_accounts
    from public.lit_business_claims_v2 c join public.lit_places_v2 p on p.id=c.place_id join auth.users u on u.id=c.claimant_id
    where c.status=p_status and (cursor_at is null or (c.updated_at,c.id)<(cursor_at,cursor_id))
    order by c.updated_at desc,c.id desc limit p_limit+1
  ), page as (select * from selected order by updated_at desc,id desc limit p_limit)
  select coalesce((select jsonb_agg(jsonb_build_object(
    'id',id,'place_id',place_id,'name',name,'address',address,'lat',latitude,'lon',longitude,
    'pid',lit_private.pid(provider,provider_place_id),'status',status,'version',review_version,
    'requested_at',created_at,'updated_at',updated_at,'business_role',business_role,
    'business_email',business_email,'business_phone',business_phone,'note',applicant_note,
    'evidence_url',evidence_url,'account_email',account_email,'account_email_confirmed',account_email_confirmed,
    'message',applicant_message,'other_verified_accounts',other_verified_accounts,
    'reviewed_at',reviewed_at,'verification_method',verification_method,
    'verification_source',verification_source,'reviewer_note',reviewer_note
  ) order by updated_at desc,id desc) from page),'[]'::jsonb),
    (select count(*)>p_limit from selected),
    (select jsonb_build_object('at',updated_at,'id',id) from page order by updated_at,id limit 1)
  into result,has_more,next_cursor;
  return jsonb_build_object('claims',result,'has_more',has_more,'next_cursor',case when has_more then next_cursor else null end,
    'summary',jsonb_build_object(
      'pending',(select count(*) from public.lit_business_claims_v2 where status='pending'),
      'verified',(select count(*) from public.lit_business_claims_v2 where status='verified'),
      'rejected',(select count(*) from public.lit_business_claims_v2 where status='rejected')));
end $$;
create or replace function public.lit_review_claim(p_claim uuid,p_version integer,p_decision text,p_method text,p_source text,p_note text,p_message text,p_checked boolean,p_allow_shared boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$
declare c public.lit_business_claims_v2%rowtype; next_status text; internal_note text:=btrim(p_note); customer_message text:=btrim(coalesce(p_message,''));
begin
  perform lit_private.require_reviewer();
  if p_decision is null or p_decision not in ('approve','reject','request_info','revoke') then raise exception 'Choose a review decision.'; end if;
  if internal_note is null or length(internal_note) not between 3 and 1000 or length(customer_message)>600 then raise exception 'Add a review note (3–1000 characters).'; end if;
  -- Lock a venue before the claim to serialize competing approvals for the same place.
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:verify-place:'||(select place_id::text from public.lit_business_claims_v2 where id=p_claim),0));
  select * into c from public.lit_business_claims_v2 where id=p_claim for update;
  if c.id is null then raise exception 'Claim not found.'; end if;
  if c.claimant_id=auth.uid() then raise exception 'You cannot review your own business claim. Ask another authorized reviewer.' using errcode='42501'; end if;
  if p_version is null or c.review_version<>p_version then raise exception 'This claim changed. Refresh before reviewing it.'; end if;
  if p_decision='revoke' and c.status<>'verified' then raise exception 'Only verified access can be revoked.'; end if;
  if p_decision<>'revoke' and c.status<>'pending' then raise exception 'Only pending claims can be reviewed.'; end if;
  if p_decision='approve' then
    if p_checked is distinct from true or p_method is null or p_method not in ('public_phone','business_email','official_website','in_person','business_documents')
      or length(btrim(coalesce(p_source,''))) not between 3 and 500 then raise exception 'Confirm an independent verification method and source before approving.'; end if;
    if exists(select 1 from public.lit_business_claims_v2 where place_id=c.place_id and status='verified' and id<>c.id) and p_allow_shared is distinct from true then
      raise exception 'This venue already has verified access. Confirm the additional person is authorized before approving.';
    end if;
  elsif customer_message='' then raise exception 'Add a message explaining the decision to the applicant.';
  end if;
  next_status:=case when p_decision='approve' then 'verified' when p_decision='request_info' then 'pending' else 'rejected' end;
  update public.lit_business_claims_v2 set status=next_status,reviewed_by=auth.uid(),reviewed_at=now(),
    verification_method=case when p_decision='approve' then p_method else verification_method end,
    verification_source=case when p_decision='approve' then btrim(p_source) else verification_source end,
    reviewer_note=internal_note,applicant_message=case when customer_message='' then 'Your venue access has been verified.' else customer_message end,
    review_version=review_version+1,updated_at=now() where id=c.id;
  insert into lit_private.verification_audit(actor_id,claim_id,action,details)
    values(auth.uid(),c.id,'claim_'||p_decision,jsonb_build_object('previous_status',c.status,'status',next_status,
      'method',p_method,'source',p_source,'note',internal_note,'message',customer_message,'shared_access_acknowledged',p_allow_shared));
  return jsonb_build_object('saved',true,'status',next_status);
end $$;
create or replace function public.lit_claim_audit(p_claim uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  perform lit_private.require_reviewer();
  select coalesce(jsonb_agg(jsonb_build_object('id',a.id,'action',a.action,'at',a.created_at,
    'reviewer',u.email,'details',a.details) order by a.id desc),'[]'::jsonb) into result
    from (select * from lit_private.verification_audit where claim_id=p_claim order by id desc limit 100) a left join auth.users u on u.id=a.actor_id;
  return result;
end $$;

create or replace function public.lit_save_business_profile(p_place uuid,p_description text,p_website text,p_phone text,p_hours text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb; site text:=btrim(coalesce(p_website,''));
begin
  perform lit_private.require_business(p_place);
  if length(coalesce(p_description,''))>600 or length(coalesce(p_hours,''))>200 or length(coalesce(p_phone,''))>40
    or length(site)>200 or (site<>'' and site !~* '^https?://[^[:space:]]+$') then raise exception 'Check field lengths and use an HTTP or HTTPS website link.'; end if;
  insert into public.lit_business_profiles_v3(place_id,description,website,phone,hours,updated_by)
    values(p_place,btrim(coalesce(p_description,'')),site,btrim(coalesce(p_phone,'')),btrim(coalesce(p_hours,'')),auth.uid())
    on conflict(place_id) do update set description=excluded.description,website=excluded.website,phone=excluded.phone,hours=excluded.hours,updated_by=auth.uid(),updated_at=now();
  select jsonb_build_object('description',description,'website',website,'phone',phone,'hours',hours,'updated_at',updated_at)
    into result from public.lit_business_profiles_v3 where place_id=p_place;
  return result;
end $$;
create or replace function public.lit_place_details(p_place uuid)
returns jsonb language sql stable security definer set search_path='' as $$
  select jsonb_build_object('profile',case when exists(select 1 from public.lit_business_claims_v2 where place_id=p_place and status='verified')
    then (select jsonb_build_object('description',description,'website',website,'phone',phone,'hours',hours) from public.lit_business_profiles_v3 where place_id=p_place) else null end);
$$;
create or replace function public.lit_business_dashboard(p_place uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare place_data jsonb;
begin
  perform lit_private.require_business(p_place);
  select jsonb_build_object('place_id',id,'name',name,'pid',lit_private.pid(provider,provider_place_id)) into place_data from public.lit_places_v2 where id=p_place;
  return jsonb_build_object('generated_at',now(),'place',place_data,
    'go',jsonb_build_object('current_count',(lit_private.activity(p_place)->>'going_count')::bigint,'updated_at',now(),'expires_after_hours',12),
    'score',null,'history','[]'::jsonb,'totals','{}'::jsonb,'hourly','[]'::jsonb,'daily','[]'::jsonb,'videos','[]'::jsonb,
    'feedback',jsonb_build_object('accuracy','{}'::jsonb,'recent','[]'::jsonb),'promotions','[]'::jsonb,
    'profile',(public.lit_place_details(p_place)->'profile'),
    'capabilities',jsonb_build_object('go_totals',true,'full_analytics',false,'business_profile',true,'promotions',false));
end $$;

create or replace function public.lit_my_profile()
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); result jsonb;
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  insert into public.profiles(id,account_type) values(u,'consumer') on conflict(id) do nothing;
  select jsonb_build_object('id',id,'username',username,'display_name',display_name,'account_type',account_type,'avatar_url',avatar_url)
    into result from public.profiles where id=u;
  return result;
end $$;
create or replace function public.lit_save_profile(p_display_name text,p_username text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); display text:=btrim(p_display_name); handle text:=lower(btrim(p_username));
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  if display is null or length(display) not between 1 and 40 then raise exception 'Display name must be 1–40 characters.'; end if;
  if handle is null or handle !~ '^[a-z0-9_.]{3,24}$' then raise exception 'Username must be 3–24 letters, numbers, underscores or dots.'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:username:'||handle,0));
  if exists(select 1 from public.profiles where lower(username)=handle and id<>u) then raise exception 'That username is already taken.'; end if;
  insert into public.profiles(id,display_name,username,account_type) values(u,display,handle,'consumer')
    on conflict(id) do update set display_name=excluded.display_name,username=excluded.username;
  return public.lit_my_profile();
end $$;
create or replace function public.lit_my_go()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  select jsonb_build_object('place_id',p.id,'pid',lit_private.pid(p.provider,p.provider_place_id),
    'name',p.name,'lat',p.latitude,'lon',p.longitude,'category',p.category,'since',g.created_at,'expires_at',g.expires_at,'arrival',null)
    into result from public.lit_go_intents_v2 g join public.lit_places_v2 p on p.id=g.place_id
    where g.user_id=auth.uid() and g.expires_at>now() order by g.created_at desc,g.place_id limit 1;
  return result;
end $$;
create or replace function public.lit_set_go(p_place uuid,p_going boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  if p_place is null or p_going is null then raise exception 'Choose a venue and GO state.'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:go:'||u::text,0));
  if p_going then
    if not exists(select 1 from public.lit_places_v2 where id=p_place and provider_verified and latitude is not null and longitude is not null) then
      raise exception 'This venue needs provider verification. Refresh and try again.';
    end if;
    delete from public.lit_go_intents_v2 where user_id=u and place_id<>p_place;
    insert into public.lit_go_intents_v2(user_id,place_id,expires_at) values(u,p_place,now()+interval '12 hours')
      on conflict(user_id,place_id) do update set created_at=now(),expires_at=now()+interval '12 hours'
      where public.lit_go_intents_v2.expires_at<=now();
  else delete from public.lit_go_intents_v2 where user_id=u and place_id=p_place;
  end if;
  return public.lit_my_go();
end $$;
create or replace function public.lit_nearby_feed(p_places jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result_places jsonb; result_posts jsonb:='[]'::jsonb;
begin
  if p_places is null or jsonb_typeof(p_places)<>'array' then raise exception 'Expected a list of places.'; end if;
  if jsonb_array_length(p_places)>250 or octet_length(p_places::text)>250000 then raise exception 'Too many places in one request.'; end if;
  with requested as (select distinct item->>'id' as pid from jsonb_array_elements(p_places) items(item)
    where jsonb_typeof(item)='object' and length(item->>'id') between 1 and 512),
  matched as (select distinct on (r.pid) r.pid,p.* from requested r join public.lit_places_v2 p
    on r.pid=lit_private.pid(p.provider,p.provider_place_id) order by r.pid,p.created_at,p.id)
  select coalesce(jsonb_agg(jsonb_build_object('pid',pid,'place_id',id,'name',name,'lat',latitude,'lon',longitude,
    'category',category,'address',address,'provider_verified',provider_verified,'score',null,
    'activity',case when provider_verified then lit_private.activity(id) else null end,
    'claimed',exists(select 1 from public.lit_business_claims_v2 where place_id=m.id and status='verified'),
    'promos','[]'::jsonb) order by pid),'[]'::jsonb) into result_places from matched m;
  if auth.uid() is not null then
    select coalesce(jsonb_agg(row_data order by created_at desc,id),'[]'::jsonb) into result_posts from (
      select post.id,post.created_at,jsonb_build_object('id',post.id,'place_id',post.place_id,'pid',place->>'pid',
        'video_path',post.video_path,'post_type',post.post_type,'created_at',post.created_at,'expires_at',post.expires_at) row_data
      from public.lit_venue_posts_v2 post join jsonb_array_elements(result_places) places(place) on (place->>'place_id')::uuid=post.place_id
      where post.deleted_at is null and post.expires_at>now() and post.created_at>now()-interval '24 hours' and post.created_at<=now()
      order by post.created_at desc,post.id limit 250) active_posts;
  end if;
  return jsonb_build_object('server_time',now(),'places',result_places,'posts',result_posts);
end $$;
create or replace function public.lit_public_place(p_pid text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare p public.lit_places_v2%rowtype;
begin
  if p_pid is null or length(p_pid)>512 then raise exception 'Invalid venue link.'; end if;
  select * into p from public.lit_places_v2 where lit_private.pid(provider,provider_place_id)=p_pid order by created_at,id limit 1;
  if p.id is null or not p.provider_verified then return null; end if;
  return jsonb_build_object('venue',jsonb_build_object('id',p_pid,'name',p.name,'lat',p.latitude,'lon',p.longitude,'category',p.category,'address',p.address),
    'place',jsonb_build_object('pid',p_pid,'place_id',p.id,'provider_verified',true,'score',null,'activity',lit_private.activity(p.id),
      'claimed',exists(select 1 from public.lit_business_claims_v2 where place_id=p.id and status='verified'),'promos','[]'::jsonb));
end $$;

create or replace function public.lit_activity_counts(p_places uuid[])
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
  if p_places is null or cardinality(p_places)>250 then raise exception 'Choose at most 250 venues.'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('place_id',p.id,'activity',lit_private.activity(p.id),
    'claimed',exists(select 1 from public.lit_business_claims_v2 c where c.place_id=p.id and c.status='verified'))),'[]'::jsonb)
    into result from public.lit_places_v2 p where p.id=any(p_places) and p.provider_verified;
  return result;
end $$;

-- Only trusted server code using the service_role key can verify provider records.
create or replace function public.lit_reserve_place_lookup(p_actor uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare limits lit_private.place_lookup_limits%rowtype;
begin
  if not exists(select 1 from auth.users where id=p_actor) then raise exception 'Account not found.'; end if;
  insert into lit_private.place_lookup_limits(user_id) values(p_actor) on conflict(user_id) do nothing;
  select * into limits from lit_private.place_lookup_limits where user_id=p_actor for update;
  if limits.day=current_date and limits.daily_count>=200 then raise exception 'Daily venue lookup limit reached.'; end if;
  if limits.minute=date_trunc('minute',now()) and limits.minute_count>=12 then raise exception 'Please wait a minute before registering more venues.'; end if;
  update lit_private.place_lookup_limits set day=current_date,
    daily_count=case when day=current_date then daily_count+1 else 1 end,
    minute=date_trunc('minute',now()),minute_count=case when minute=date_trunc('minute',now()) then minute_count+1 else 1 end where user_id=p_actor;
  return jsonb_build_object('allowed',true);
end $$;
create or replace function public.lit_register_verified_place(p_actor uuid,p_place jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare pid text:=p_place->>'id'; provider text; provider_id text; existing uuid; registered uuid;
begin
  if not exists(select 1 from auth.users where id=p_actor) then raise exception 'Account not found.'; end if;
  if pid is null or length(pid)>512 or pid !~ '^(geoapify:.+|osm:(node|way|relation):[0-9]+)$'
    or jsonb_typeof(p_place->'lat') is distinct from 'number' or jsonb_typeof(p_place->'lon') is distinct from 'number'
    or (p_place->>'lat')::double precision not between -90 and 90 or (p_place->>'lon')::double precision not between -180 and 180
    or length(btrim(coalesce(p_place->>'name',''))) not between 1 and 300 then raise exception 'Invalid provider record.'; end if;
  provider:=split_part(pid,':',1); provider_id:=substr(pid,length(provider)+2);
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:provider-place:'||pid,0));
  select id into existing from public.lit_places_v2 p where lit_private.pid(p.provider,p.provider_place_id)=pid order by created_at,id limit 1;
  if existing is null then
    insert into public.lit_places_v2(provider,provider_place_id,name,latitude,longitude,category,address,provider_verified,provider_verified_at)
      values(provider,provider_id,btrim(p_place->>'name'),(p_place->>'lat')::double precision,(p_place->>'lon')::double precision,
        left(p_place->>'category',80),left(p_place->>'address',1000),true,now()) returning id into registered;
  else
    update public.lit_places_v2 set name=btrim(p_place->>'name'),latitude=(p_place->>'lat')::double precision,longitude=(p_place->>'lon')::double precision,
      category=left(p_place->>'category',80),address=left(p_place->>'address',1000),provider_verified=true,provider_verified_at=now() where id=existing returning id into registered;
  end if;
  return jsonb_build_object('pid',pid,'place_id',registered,'provider_verified',true);
end $$;

revoke all on all tables in schema lit_private from public,anon,authenticated;
revoke all on all sequences in schema lit_private from public,anon,authenticated;
revoke all on all functions in schema lit_private from public,anon,authenticated;
-- Reset all new/updated API function grants without affecting unrelated functions.
do $$
declare f record;
begin
  for f in select p.oid::regprocedure as signature from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname=any(array[
      'lit_review_access','lit_list_reviewers','lit_manage_reviewer','lit_request_claim','lit_my_business',
      'lit_verification_queue','lit_review_claim','lit_claim_audit','lit_save_business_profile','lit_business_dashboard',
      'lit_my_profile','lit_save_profile','lit_my_go','lit_set_go','lit_nearby_feed','lit_public_place','lit_place_details','lit_activity_counts',
      'lit_reserve_place_lookup','lit_register_verified_place'])
  loop execute format('revoke all on function %s from public,anon,authenticated',f.signature); end loop;
end $$;
grant execute on function public.lit_review_access(),public.lit_list_reviewers(),public.lit_manage_reviewer(text,boolean),
  public.lit_request_claim(uuid,text,text,text,text,text),public.lit_my_business(),public.lit_verification_queue(text,jsonb,integer),
  public.lit_review_claim(uuid,integer,text,text,text,text,text,boolean,boolean),public.lit_claim_audit(uuid),
  public.lit_save_business_profile(uuid,text,text,text,text),public.lit_business_dashboard(uuid),
  public.lit_my_profile(),public.lit_save_profile(text,text),public.lit_my_go(),public.lit_set_go(uuid,boolean) to authenticated;
grant execute on function public.lit_nearby_feed(jsonb),public.lit_public_place(text),public.lit_place_details(uuid),public.lit_activity_counts(uuid[]) to anon,authenticated,service_role;
grant execute on function public.lit_reserve_place_lookup(uuid),public.lit_register_verified_place(uuid,jsonb) to service_role;
notify pgrst,'reload schema';
commit;
