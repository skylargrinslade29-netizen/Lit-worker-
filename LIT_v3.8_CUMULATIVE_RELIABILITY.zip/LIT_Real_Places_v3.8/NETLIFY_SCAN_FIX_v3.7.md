# Public Supabase URL scanning

The screenshots establish that Netlify's build compiled but secret scanning blocked deployment. They list the watched variable names, not the exact matching values/files. The release intentionally includes the Supabase project URL and publishable browser key in public/lit-config.js; those are public configuration.

netlify.toml now sets SECRETS_SCAN_OMIT_KEYS to SUPABASE_URL only. The service-role and Geoapify keys remain scanned; scanning is not disabled. Actual service credentials are obtained at runtime through process.env in Netlify Functions, or private environment variables in the trusted worker. No actual service-role/Geoapify key was found in the supplied source. Production environment values/repository history were not accessible, so they were not independently compared.

If Netlify still reports a real key value in a particular file or output after this change, remove that value from the listed file/output. If a real secret was exposed publicly, replace it in its provider and update server secret bindings. Do not add real keys to the omit list. Scope server credentials to Production Functions when the Netlify plan allows selecting scopes. A mistaken URL in SUPABASE_SERVICE_ROLE_KEY must be corrected to the actual key, not bypassed through scanning exclusions.

This ZIP has not been deployed, so no production build result is claimed. The exception is included in the cumulative package; no separate app deployment is necessary just to apply this file.
