import { readdirSync, readFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import assert from 'node:assert/strict'
const root = fileURLToPath(new URL('../', import.meta.url))
function files(dir) { return readdirSync(dir, { withFileTypes: true }).flatMap((x) => x.isDirectory() ? files(join(dir, x.name)) : [join(dir, x.name)]) }
for (const file of files(root).filter((x) => /\.(?:mjs|js)$/.test(x) && !x.includes('/node_modules/') && !x.includes('/.netlify/'))) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' })
  if (result.status) { process.stderr.write(result.stderr); process.exit(1) }
  // Every relative import must be present in the distributable.
  const source = readFileSync(file, 'utf8')
  for (const match of source.matchAll(/(?:from\s+|import\s*)['"](\.[^'"]+)['"]/g)) assert.ok(files(root).includes(resolve(file, '..', match[1])), `Missing import: ${file}: ${match[1]}`)
}
const redirects = readFileSync(join(root, 'public/_redirects'), 'utf8')
for (const fn of ['places', 'geocode', 'ask', 'register-place', 'delete-account']) assert.ok(redirects.includes(`/api/${fn}`) && redirects.includes(`/.netlify/functions/${fn}`))
assert.equal(readdirSync(join(root, 'netlify/functions')).filter((x) => x.endsWith('.mjs')).length, 5)
const manifest = JSON.parse(readFileSync(join(root, 'public/manifest.webmanifest'), 'utf8'))
assert.equal(manifest.start_url, '/')
for (const icon of manifest.icons) assert.ok(files(root).includes(join(root, 'public', icon.src.replace(/^\//, ''))))
assert.ok(readFileSync(join(root, 'public/index.html'), 'utf8').includes('/manifest.webmanifest'))
for (const test of ['server.mjs', 'client.mjs', 'readiness.mjs', 'register-place.mjs', 'delete-account.mjs']) {
  const result = spawnSync(process.execPath, [join(root, 'checks', test)], { stdio: 'inherit' })
  if (result.status) process.exit(result.status || 1)
}
console.log('Video worker integration is separate: python checks/video_worker.py (requires FFmpeg/FFprobe).')
console.log('PASS: syntax, local imports, API redirects, five function entries, server/client regression checks')
