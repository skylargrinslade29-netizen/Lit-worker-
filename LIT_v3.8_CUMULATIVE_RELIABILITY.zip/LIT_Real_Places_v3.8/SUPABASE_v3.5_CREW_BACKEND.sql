-- Run after SUPABASE_v3.3_BUSINESS_SYSTEM.sql. Private Crew backend; existing legacy tables remain intact.
begin;
create table if not exists lit_private.crews (
 id uuid primary key default gen_random_uuid(),name text not null check(length(btrim(name)) between 1 and 60),
 owner_id uuid not null references auth.users(id) on delete cascade,
 invite_code text not null unique default upper(replace(gen_random_uuid()::text,'-','')),
 invite_expires_at timestamptz not null default now()+interval '7 days',created_at timestamptz not null default now()
);
create table if not exists lit_private.crew_members (
 crew_id uuid not null references lit_private.crews(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 status text not null check(status in ('joined','invited')),created_at timestamptz not null default now(),primary key(crew_id,user_id)
);
create table if not exists lit_private.crew_outings (
 id uuid primary key default gen_random_uuid(),crew_id uuid not null references lit_private.crews(id) on delete cascade,
 organizer_id uuid not null references auth.users(id) on delete cascade,place_id uuid not null references public.lit_places_v2(id) on delete cascade,
 starts_at timestamptz not null,ends_at timestamptz not null,note text not null default '' check(length(note)<=200),
 cancelled_at timestamptz,created_at timestamptz not null default now(),check(ends_at>starts_at)
);
create table if not exists lit_private.outing_responses (
 outing_id uuid not null references lit_private.crew_outings(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,response text not null default 'waiting' check(response in ('waiting','in','maybe','pass')),
 updated_at timestamptz not null default now(),primary key(outing_id,user_id)
);
create table if not exists lit_private.crew_request_limits (
 user_id uuid not null references auth.users(id) on delete cascade,kind text not null,window_start timestamptz not null,
 attempts integer not null check(attempts>0),primary key(user_id,kind)
);
create index if not exists crew_members_user_v5 on lit_private.crew_members(user_id,crew_id);
create index if not exists crew_outings_place_v5 on lit_private.crew_outings(place_id,starts_at,ends_at) where cancelled_at is null;
create index if not exists crew_outings_crew_v5 on lit_private.crew_outings(crew_id,starts_at) where cancelled_at is null;
alter table lit_private.crews enable row level security;
alter table lit_private.crew_members enable row level security;
alter table lit_private.crew_outings enable row level security;
alter table lit_private.outing_responses enable row level security;
alter table lit_private.crew_request_limits enable row level security;

create or replace function lit_private.crew_user() returns uuid language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();
begin
 if u is null then raise exception 'Sign in first.' using errcode='42501';end if;
 if not exists(select 1 from auth.users where id=u and email_confirmed_at is not null) then raise exception 'Confirm your account email first.';end if;
 if not exists(select 1 from public.profiles where id=u and username is not null) then raise exception 'Choose your LIT username first.';end if;
 return u;
end $$;
create or replace function lit_private.crew_quota(p_kind text,p_limit integer) returns boolean language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user(); n integer;
begin
 insert into lit_private.crew_request_limits as q(user_id,kind,window_start,attempts) values(u,p_kind,now(),1)
 on conflict(user_id,kind) do update set
 attempts=case when q.window_start<=now()-interval '1 hour' then 1 else least(q.attempts+1,p_limit+1) end,
 window_start=case when q.window_start<=now()-interval '1 hour' then now() else q.window_start end returning attempts into n;
 return n<=p_limit;
end $$;
create or replace function lit_private.lock_crew(p_crew uuid,p_owner boolean default false) returns lit_private.crews language plpgsql security definer set search_path='' as $$
declare c lit_private.crews; u uuid:=lit_private.crew_user();
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 select * into c from lit_private.crews where id=p_crew for update;
 if c.id is null or not exists(select 1 from lit_private.crew_members where crew_id=p_crew and user_id=u and status='joined')
 or (p_owner and c.owner_id<>u) then raise exception 'This Crew is unavailable or you do not have permission.' using errcode='42501';end if;
 return c;
end $$;
create or replace function lit_private.join_member(p_crew uuid,p_user uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if (select count(*) from lit_private.crew_members where crew_id=p_crew)>=30 and not exists(select 1 from lit_private.crew_members where crew_id=p_crew and user_id=p_user) then raise exception 'This Crew has reached its 30-member limit.';end if;
 if (select count(*) from lit_private.crew_members where user_id=p_user)>=20 and not exists(select 1 from lit_private.crew_members where crew_id=p_crew and user_id=p_user) then raise exception 'The account has reached its 20-Crew limit.';end if;
 insert into lit_private.crew_members(crew_id,user_id,status) values(p_crew,p_user,'joined') on conflict(crew_id,user_id) do update set status='joined';
 insert into lit_private.outing_responses(outing_id,user_id) select id,p_user from lit_private.crew_outings where crew_id=p_crew and cancelled_at is null and ends_at>now() on conflict do nothing;
end $$;
create or replace function public.lit_create_crew(p_name text) returns uuid language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user(); id uuid;
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 if p_name is null or length(btrim(p_name)) not between 1 and 60 then raise exception 'Crew name must be 1–60 characters.';end if;
 if not lit_private.crew_quota('create',20) then raise exception 'Too many Crew creations. Try again in an hour.';end if;
 if (select count(*) from lit_private.crew_members where user_id=u)>=20 then raise exception 'You have reached the 20-Crew limit.';end if;
 insert into lit_private.crews(name,owner_id) values(btrim(p_name),u) returning crews.id into id;
 perform lit_private.join_member(id,u);return id;
end $$;
-- JSON response lets failed code attempts commit their quota counter instead of rolling it back.
create or replace function public.lit_join_crew(p_code text) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user();c lit_private.crews; code text:=upper(btrim(p_code));
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 if not lit_private.crew_quota('join',20) then return jsonb_build_object('error','Too many join attempts. Try again in an hour.');end if;
 if code is null or code !~ '^[A-F0-9]{32}$' then return jsonb_build_object('error','This invite is invalid or expired. Ask the owner for a new link.');end if;
 select * into c from lit_private.crews where invite_code=code for update;
 if c.id is null or c.invite_expires_at<=now() then return jsonb_build_object('error','This invite is invalid or expired. Ask the owner for a new link.');end if;
 if (select count(*) from lit_private.crew_members where crew_id=c.id)>=30 and not exists(select 1 from lit_private.crew_members where crew_id=c.id and user_id=u) then return jsonb_build_object('error','This Crew has reached its 30-member limit.');end if;
 if (select count(*) from lit_private.crew_members where user_id=u)>=20 and not exists(select 1 from lit_private.crew_members where crew_id=c.id and user_id=u) then return jsonb_build_object('error','You have reached the 20-Crew limit.');end if;
 perform lit_private.join_member(c.id,u);return jsonb_build_object('crew_id',c.id);
end $$;
create or replace function public.lit_add_crew_member(p_crew uuid,p_username text) returns jsonb language plpgsql security definer set search_path='' as $$
declare c lit_private.crews; target uuid;u uuid:=lit_private.crew_user();
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 c:=lit_private.lock_crew(p_crew,true);
 if not lit_private.crew_quota('invite',60) then return jsonb_build_object('error','Too many invitations. Try again in an hour.');end if;
 select p.id into target from public.profiles p join auth.users a on a.id=p.id where lower(p.username)=lower(ltrim(btrim(p_username),'@')) and a.email_confirmed_at is not null;
 if target is null then return jsonb_build_object('error','No confirmed LIT account has that username.');end if;
 if target=u then return jsonb_build_object('error','You are already the Crew owner.');end if;
 if exists(select 1 from lit_private.crew_members where crew_id=p_crew and user_id=target) then return jsonb_build_object('sent',false,'already_member',true);end if;
 if (select count(*) from lit_private.crew_members where crew_id=p_crew)>=30 then return jsonb_build_object('error','This Crew has reached its 30-member limit.');end if;
 -- Membership mutation lock also serializes per-account capacity checks.
 if (select count(*) from lit_private.crew_members where user_id=target)>=20 then return jsonb_build_object('error','This account cannot receive another Crew invitation.');end if;
 insert into lit_private.crew_members(crew_id,user_id,status) values(p_crew,target,'invited');return jsonb_build_object('sent',true);
end $$;
create or replace function public.lit_respond_crew_invite(p_crew uuid,p_accept boolean) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user();c lit_private.crews;
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 select * into c from lit_private.crews where id=p_crew for update;
 if c.id is null or not exists(select 1 from lit_private.crew_members where crew_id=p_crew and user_id=u and status='invited') then raise exception 'This invitation is no longer available.';end if;
 if p_accept is null then raise exception 'Choose Join or Decline.';end if;
 if p_accept then perform lit_private.join_member(p_crew,u);else delete from lit_private.crew_members where crew_id=p_crew and user_id=u;end if;
 return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_leave_crew(p_crew uuid,p_user uuid default null) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user();target uuid:=coalesce(p_user,u);c lit_private.crews;
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:crew-membership',0));
 c:=lit_private.lock_crew(p_crew,target<>u);
 if target=c.owner_id then
  if u<>c.owner_id then raise exception 'Only the owner can delete this Crew.';end if;
  delete from lit_private.crews where id=p_crew;
 else
  delete from lit_private.outing_responses r using lit_private.crew_outings o where r.outing_id=o.id and o.crew_id=p_crew and r.user_id=target;
  update lit_private.crew_outings set cancelled_at=now() where crew_id=p_crew and organizer_id=target and cancelled_at is null;
  delete from lit_private.crew_members where crew_id=p_crew and user_id=target;
 end if;
 return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_rotate_crew_invite(p_crew uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare c lit_private.crews;
begin
 c:=lit_private.lock_crew(p_crew,true);
 update lit_private.crews set invite_code=upper(replace(gen_random_uuid()::text,'-','')),invite_expires_at=now()+interval '7 days' where id=p_crew;
 return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_create_outing(p_crew uuid,p_place uuid,p_starts_at timestamptz,p_note text default '') returns uuid language plpgsql security definer set search_path='' as $$
declare c lit_private.crews;u uuid:=lit_private.crew_user(); outing uuid;
begin
 c:=lit_private.lock_crew(p_crew);
 if not lit_private.crew_quota('plan',60) then raise exception 'Too many plans. Try again in an hour.';end if;
 if p_starts_at is null or p_starts_at<now() or p_starts_at>now()+interval '30 days' then raise exception 'Choose a start time within the next 30 days.';end if;
 if length(coalesce(p_note,''))>200 then raise exception 'Plan notes must be at most 200 characters.';end if;
 if not exists(select 1 from public.lit_places_v2 where id=p_place and provider_verified) then raise exception 'Choose a registered real venue.';end if;
 if (select count(*) from lit_private.crew_outings where crew_id=p_crew and cancelled_at is null and ends_at>now())>=50 then raise exception 'This Crew has reached its 50-active-plan limit.';end if;
 insert into lit_private.crew_outings(crew_id,organizer_id,place_id,starts_at,ends_at,note) values(p_crew,u,p_place,p_starts_at,p_starts_at+interval '6 hours',btrim(coalesce(p_note,''))) returning id into outing;
 insert into lit_private.outing_responses(outing_id,user_id,response) select outing,user_id,case when user_id=u then 'in' else 'waiting' end from lit_private.crew_members where crew_id=p_crew and status='joined';return outing;
end $$;
create or replace function public.lit_respond_outing(p_outing uuid,p_response text) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user();o lit_private.crew_outings;c lit_private.crews;
begin
 select * into o from lit_private.crew_outings where id=p_outing;
 c:=lit_private.lock_crew(o.crew_id);
 select * into o from lit_private.crew_outings where id=p_outing for update;
 if o.id is null or o.cancelled_at is not null or o.ends_at<=now() then raise exception 'This plan has ended or was cancelled.';end if;
 if p_response is null or p_response not in ('in','maybe','pass') then raise exception 'Choose In, Maybe or Pass.';end if;
 insert into lit_private.outing_responses(outing_id,user_id,response) values(p_outing,u,p_response) on conflict(outing_id,user_id) do update set response=excluded.response,updated_at=now();
 return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_cancel_outing(p_outing uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare o lit_private.crew_outings;c lit_private.crews;u uuid:=lit_private.crew_user();
begin
 select * into o from lit_private.crew_outings where id=p_outing;c:=lit_private.lock_crew(o.crew_id);
 if o.organizer_id<>u and c.owner_id<>u then raise exception 'Only the organizer or Crew owner can cancel this plan.' using errcode='42501';end if;
 update lit_private.crew_outings set cancelled_at=coalesce(cancelled_at,now()) where id=p_outing;return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_my_crews() returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=lit_private.crew_user();result jsonb;
begin
 select coalesce(jsonb_agg(jsonb_build_object('id',c.id,'name',c.name,'my_status',mine.status,'my_role',case when c.owner_id=u then 'owner' else 'member' end,
 'invite_code',case when c.owner_id=u then c.invite_code else null end,'invite_expires_at',case when c.owner_id=u then c.invite_expires_at else null end,
 'members',(select coalesce(jsonb_agg(jsonb_build_object('user_id',m.user_id,'name',coalesce(p.display_name,p.username,'LIT member'),'username',p.username,'me',m.user_id=u,'role',case when m.user_id=c.owner_id then 'owner' else 'member' end,'status',m.status) order by (m.user_id=c.owner_id) desc,m.created_at,m.user_id),'[]'::jsonb)
 from lit_private.crew_members m left join public.profiles p on p.id=m.user_id where m.crew_id=c.id and (mine.status='joined' or m.user_id in (u,c.owner_id))),
 'outings',case when mine.status='joined' then (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'pid',lit_private.pid(p.provider,p.provider_place_id),'place_id',p.id,'place_name',p.name,'lat',p.latitude,'lon',p.longitude,'category',p.category,'starts_at',o.starts_at,'ends_at',o.ends_at,'note',o.note,'can_cancel',o.organizer_id=u or c.owner_id=u,
 'responses',(select coalesce(jsonb_agg(jsonb_build_object('user_id',r.user_id,'name',coalesce(pr.display_name,pr.username,'LIT member'),'me',r.user_id=u,'response',r.response) order by r.user_id),'[]'::jsonb) from lit_private.outing_responses r join lit_private.crew_members mm on mm.crew_id=c.id and mm.user_id=r.user_id and mm.status='joined' left join public.profiles pr on pr.id=r.user_id where r.outing_id=o.id)) order by o.starts_at,o.id),'[]'::jsonb)
 from lit_private.crew_outings o join public.lit_places_v2 p on p.id=o.place_id where o.crew_id=c.id and o.cancelled_at is null and o.ends_at>now()) else '[]'::jsonb end) order by c.created_at,c.id),'[]'::jsonb) into result
 from lit_private.crews c join lit_private.crew_members mine on mine.crew_id=c.id and mine.user_id=u;
 return result;
end $$;
create or replace function lit_private.activity(p_place uuid) returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('going_count',(select count(*) from (select distinct on(user_id) user_id,place_id from public.lit_go_intents_v2 where expires_at>now() order by user_id,created_at desc,place_id) g where g.place_id=p_place),
 'planning_count',(select count(distinct r.user_id) from lit_private.crew_outings o join lit_private.outing_responses r on r.outing_id=o.id join lit_private.crew_members m on m.crew_id=o.crew_id and m.user_id=r.user_id and m.status='joined' where o.place_id=p_place and o.cancelled_at is null and o.ends_at>now() and o.starts_at>=now()-interval '12 hours' and o.starts_at<now()+interval '12 hours' and r.response='in'),
 'updated_at',now(),'window_start',now()-interval '12 hours','window_end',now()+interval '12 hours');
$$;
create or replace function public.lit_business_dashboard(p_place uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare place_data jsonb;
begin
  perform lit_private.require_business(p_place);
  select jsonb_build_object('place_id',id,'name',name,'pid',lit_private.pid(provider,provider_place_id)) into place_data from public.lit_places_v2 where id=p_place;
  return jsonb_build_object('generated_at',now(),'place',place_data,
    'go',jsonb_build_object('current_count',(lit_private.activity(p_place)->>'going_count')::bigint,'updated_at',now(),'expires_after_hours',12),
    'crew',jsonb_build_object('planning_count',(lit_private.activity(p_place)->>'planning_count')::bigint,'updated_at',now()),
    'score',null,'history','[]'::jsonb,'totals','{}'::jsonb,'hourly','[]'::jsonb,'daily','[]'::jsonb,'videos','[]'::jsonb,
    'feedback',jsonb_build_object('accuracy','{}'::jsonb,'recent','[]'::jsonb),'promotions','[]'::jsonb,
    'profile',(public.lit_place_details(p_place)->'profile'),
    'capabilities',jsonb_build_object('go_totals',true,'crew_totals',true,'full_analytics',false,'business_profile',true,'promotions',false));
end $$;

-- Private schema is inaccessible to browsers, including all new tables/helpers.
revoke all on all tables in schema lit_private from public,anon,authenticated;
revoke all on all functions in schema lit_private from public,anon,authenticated;
revoke all on function public.lit_create_crew(text),public.lit_join_crew(text),public.lit_add_crew_member(uuid,text),public.lit_respond_crew_invite(uuid,boolean),public.lit_leave_crew(uuid,uuid),public.lit_rotate_crew_invite(uuid),public.lit_create_outing(uuid,uuid,timestamptz,text),public.lit_respond_outing(uuid,text),public.lit_cancel_outing(uuid),public.lit_my_crews() from public,anon,authenticated;
grant execute on function public.lit_create_crew(text),public.lit_join_crew(text),public.lit_add_crew_member(uuid,text),public.lit_respond_crew_invite(uuid,boolean),public.lit_leave_crew(uuid,uuid),public.lit_rotate_crew_invite(uuid),public.lit_create_outing(uuid,uuid,timestamptz,text),public.lit_respond_outing(uuid,text),public.lit_cancel_outing(uuid),public.lit_my_crews() to authenticated;
notify pgrst,'reload schema';
commit;
