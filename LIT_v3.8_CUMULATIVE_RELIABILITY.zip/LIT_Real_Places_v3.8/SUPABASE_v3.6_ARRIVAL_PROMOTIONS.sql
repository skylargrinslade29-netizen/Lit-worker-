-- Run after the v3.5 complete migration. Keeps earlier features and records.
begin;
create table if not exists lit_private.arrivals (
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,
 place_id uuid not null references public.lit_places_v2(id) on delete cascade,go_started_at timestamptz not null,
 checked_at timestamptz not null default now(),distance_m double precision not null check(distance_m between 0 and 200),
 accuracy_m double precision not null check(accuracy_m>0 and accuracy_m<=150),unique(user_id,place_id,go_started_at)
);
create table if not exists lit_private.guest_feedback (
 arrival_id uuid primary key references lit_private.arrivals(id) on delete cascade,
 accuracy text not null check(accuracy in ('accurate','busier','quieter','inaccurate','not_shown')),
 vibe integer check(vibe between 1 and 5),note text not null default '' check(length(note)<=280),
 share_note boolean not null default false,submitted_at timestamptz not null default now()
);
create table if not exists lit_private.promotions (
 id uuid primary key default gen_random_uuid(),place_id uuid not null references public.lit_places_v2(id) on delete cascade,
 kind text not null check(kind in ('special','event','promotion')),title text not null check(length(btrim(title)) between 2 and 80),
 details text not null default '' check(length(details)<=300),starts_at timestamptz not null,ends_at timestamptz not null,
 created_by uuid references auth.users(id) on delete set null,updated_by uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now(),updated_at timestamptz not null default now(),revision integer not null default 1,
 archived_at timestamptz,check(ends_at>starts_at and ends_at<=starts_at+interval '30 days')
);
alter table lit_private.arrivals enable row level security;
alter table lit_private.guest_feedback enable row level security;
alter table lit_private.promotions enable row level security;
create index if not exists lit_arrivals_user_place_v6 on lit_private.arrivals(user_id,place_id,checked_at desc);
create index if not exists lit_arrivals_place_v6 on lit_private.arrivals(place_id,checked_at desc);
create index if not exists lit_promotions_live_v6 on lit_private.promotions(place_id,ends_at,starts_at) where archived_at is null;

create or replace function public.lit_confirm_arrival(p_place uuid,p_lat double precision,p_lon double precision,p_accuracy double precision default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();g public.lit_go_intents_v2;v public.lit_places_v2;a lit_private.arrivals;distance double precision;
begin
 if u is null then raise exception 'Sign in first.' using errcode='42501';end if;
 if not exists(select 1 from auth.users where id=u and email_confirmed_at is not null) then raise exception 'Confirm your account email first.';end if;
 if p_lat is null or p_lon is null or p_lat not between -90 and 90 or p_lon not between -180 and 180 then raise exception 'Your device did not return a valid location. Try again.';end if;
 if p_accuracy is null or p_accuracy<=0 or p_accuracy>150 then raise exception 'Location is not precise enough. Try outdoors with precise location enabled.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:go:'||u::text,0));
 select * into g from public.lit_go_intents_v2 where user_id=u and place_id=p_place and expires_at>now();
 if g.user_id is null then raise exception 'Save this venue as your current GO destination first.';end if;
 select * into v from public.lit_places_v2 where id=p_place and provider_verified and latitude is not null and longitude is not null;
 if v.id is null then raise exception 'This venue needs provider verification first.';end if;
 distance:=6371000*acos(greatest(-1.0,least(1.0,sin(radians(p_lat))*sin(radians(v.latitude))+cos(radians(p_lat))*cos(radians(v.latitude))*cos(radians(p_lon-v.longitude)))));
 if distance>200 then raise exception 'You need to be within 200 metres of the venue to check your location.';end if;
 select * into a from lit_private.arrivals where user_id=u and place_id=p_place and go_started_at=g.created_at;
 if a.id is not null then return jsonb_build_object('id',a.id,'checked_at',a.checked_at,'feedback_done',exists(select 1 from lit_private.guest_feedback where arrival_id=a.id));end if;
 if exists(select 1 from lit_private.arrivals where user_id=u and place_id=p_place and checked_at>now()-interval '6 hours') then raise exception 'You already checked your location at this venue within the last 6 hours.';end if;
 if (select count(*) from lit_private.arrivals where user_id=u and checked_at>now()-interval '24 hours')>=20 then raise exception 'Daily location-check limit reached. Try again tomorrow.';end if;
 insert into lit_private.arrivals(user_id,place_id,go_started_at,distance_m,accuracy_m) values(u,p_place,g.created_at,distance,p_accuracy) returning * into a;
 return jsonb_build_object('id',a.id,'checked_at',a.checked_at,'feedback_done',false);
end $$;
create or replace function public.lit_submit_feedback(p_arrival uuid,p_accuracy text,p_vibe integer,p_note text,p_share_note boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$
declare a lit_private.arrivals;u uuid:=auth.uid();old lit_private.guest_feedback;
begin
 if u is null then raise exception 'Sign in first.' using errcode='42501';end if;
 select * into a from lit_private.arrivals where id=p_arrival and user_id=u for update;
 if a.id is null then raise exception 'This location check is unavailable for your account.' using errcode='42501';end if;
 if p_accuracy is null or p_accuracy not in ('accurate','busier','quieter','inaccurate','not_shown') or (p_vibe is not null and p_vibe not between 1 and 5) or length(coalesce(p_note,''))>280 or p_share_note is null then raise exception 'Check your feedback choices and keep the note within 280 characters.';end if;
 select * into old from lit_private.guest_feedback where arrival_id=p_arrival;
 if old.arrival_id is not null then
  if old.accuracy=p_accuracy and old.vibe is not distinct from p_vibe and old.note=btrim(coalesce(p_note,'')) and old.share_note=p_share_note then return jsonb_build_object('saved',true,'already_submitted',true);end if;
  raise exception 'Feedback was already submitted for this visit.';
 end if;
 if a.checked_at<now()-interval '24 hours' then raise exception 'Feedback must be sent within 24 hours of your location check.';end if;
 if exists(select 1 from public.lit_business_claims_v2 where place_id=a.place_id and claimant_id=u and status='verified') then raise exception 'Verified representatives cannot submit guest feedback for their own venue.';end if;
 insert into lit_private.guest_feedback(arrival_id,accuracy,vibe,note,share_note) values(p_arrival,p_accuracy,p_vibe,btrim(coalesce(p_note,'')),p_share_note);
 return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_my_go()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 if auth.uid() is null then raise exception 'Sign in first.' using errcode='42501';end if;
 select jsonb_build_object('place_id',p.id,'pid',lit_private.pid(p.provider,p.provider_place_id),'name',p.name,'lat',p.latitude,'lon',p.longitude,'category',p.category,'since',g.created_at,'expires_at',g.expires_at,
 'arrival',(select jsonb_build_object('id',a.id,'checked_at',a.checked_at,'feedback_done',exists(select 1 from lit_private.guest_feedback where arrival_id=a.id)) from lit_private.arrivals a where a.user_id=g.user_id and a.place_id=g.place_id and a.go_started_at=g.created_at))
 into result from public.lit_go_intents_v2 g join public.lit_places_v2 p on p.id=g.place_id where g.user_id=auth.uid() and g.expires_at>now() order by g.created_at desc,g.place_id limit 1;
 return result;
end $$;
create or replace function lit_private.feedback_summary(p_place uuid)
returns jsonb language plpgsql stable security definer set search_path='' as $$
declare participants bigint;result jsonb;
begin
 select count(distinct a.user_id) into participants from lit_private.guest_feedback f join lit_private.arrivals a on a.id=f.arrival_id where a.place_id=p_place and f.submitted_at>now()-interval '30 days' and not exists(select 1 from public.lit_business_claims_v2 c where c.place_id=a.place_id and c.claimant_id=a.user_id and c.status='verified');
 if participants<3 then return jsonb_build_object('privacy_threshold',3,'suppressed',true,'accuracy','{}'::jsonb,'recent','[]'::jsonb,'count_30d',null,'avg_vibe',null);end if;
 with latest as(select distinct on(a.user_id) f.* from lit_private.guest_feedback f join lit_private.arrivals a on a.id=f.arrival_id where a.place_id=p_place and f.submitted_at>now()-interval '30 days' and not exists(select 1 from public.lit_business_claims_v2 c where c.place_id=a.place_id and c.claimant_id=a.user_id and c.status='verified') order by a.user_id,f.submitted_at desc,f.arrival_id),
 counts as(select accuracy,count(*) n from latest group by accuracy)
 select jsonb_build_object('privacy_threshold',3,'suppressed',false,'accuracy',coalesce((select jsonb_object_agg(accuracy,n) from counts),'{}'::jsonb),'count_30d',participants,'avg_vibe',(select round(avg(vibe),1) from latest),'recent',coalesce((select jsonb_agg(jsonb_build_object('at',date_trunc('day',submitted_at),'accuracy',accuracy,'vibe',vibe,'note',note) order by submitted_at desc,arrival_id) from (select * from latest where share_note and note<>'' order by submitted_at desc,arrival_id limit 6) notes),'[]'::jsonb)) into result;
 return result;
end $$;
create or replace function public.lit_save_promotion(p_place uuid,p_id uuid,p_kind text,p_title text,p_details text,p_starts_at timestamptz,p_ends_at timestamptz,p_version integer default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();promo lit_private.promotions;start_time timestamptz:=coalesce(p_starts_at,now());title_text text:=btrim(p_title);details_text text:=btrim(coalesce(p_details,''));new_id uuid:=coalesce(p_id,gen_random_uuid());
begin
 perform lit_private.require_business(p_place);
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:promotions:'||p_place::text,0));
 if p_kind is null or p_kind not in ('special','event','promotion') or title_text is null or length(title_text) not between 2 and 80 or length(details_text)>300 then raise exception 'Choose a promotion type, a 2–80 character title and details within 300 characters.';end if;
 if p_ends_at is null or p_ends_at<=now() or p_ends_at<=start_time or p_ends_at>start_time+interval '30 days' or start_time>now()+interval '90 days' then raise exception 'Choose an end after the start, within 30 days. Starts must be within 90 days.';end if;
 select * into promo from lit_private.promotions where id=new_id for update;
 if promo.id is not null then
  if promo.place_id<>p_place then raise exception 'This promotion belongs to another venue.' using errcode='42501';end if;
  if p_version is null then
   if promo.archived_at is null and promo.kind=p_kind and promo.title=title_text and promo.details=details_text and promo.starts_at=start_time and promo.ends_at=p_ends_at then return jsonb_build_object('saved',true,'id',promo.id,'version',promo.revision);end if;
   raise exception 'This promotion already exists. Refresh before editing it.';
  end if;
  if promo.revision<>p_version or promo.archived_at is not null then raise exception 'This promotion changed or was ended. Refresh before editing.';end if;
  update lit_private.promotions set kind=p_kind,title=title_text,details=details_text,starts_at=start_time,ends_at=p_ends_at,updated_by=u,updated_at=now(),revision=revision+1 where id=new_id returning * into promo;
 else
  if p_version is not null then raise exception 'This promotion is no longer available.';end if;
  if (select count(*) from lit_private.promotions where place_id=p_place and created_by=u and created_at>now()-interval '24 hours')>=30 then raise exception 'Daily promotion creation limit reached.';end if;
  if (select count(*) from lit_private.promotions where place_id=p_place and archived_at is null and ends_at>now())>=20 then raise exception 'This venue has 20 active or scheduled promotions. End one first.';end if;
  insert into lit_private.promotions(id,place_id,kind,title,details,starts_at,ends_at,created_by,updated_by) values(new_id,p_place,p_kind,title_text,details_text,start_time,p_ends_at,u,u) returning * into promo;
 end if;
 return jsonb_build_object('saved',true,'id',promo.id,'version',promo.revision);
end $$;
create or replace function public.lit_archive_promotion(p_id uuid,p_version integer default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare promo lit_private.promotions;
begin
 select * into promo from lit_private.promotions where id=p_id;
 if promo.id is null then raise exception 'Promotion not found.';end if;
 perform lit_private.require_business(promo.place_id);
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:promotions:'||promo.place_id::text,0));
 select * into promo from lit_private.promotions where id=p_id for update;
 if promo.archived_at is not null then return jsonb_build_object('saved',true);end if;
 if p_version is not null and p_version<>promo.revision then raise exception 'This promotion changed. Refresh before ending it.';end if;
 update lit_private.promotions set archived_at=now(),updated_by=auth.uid(),updated_at=now(),revision=revision+1 where id=p_id;
 return jsonb_build_object('saved',true);
end $$;
create or replace function lit_private.public_promotions(p_place uuid)
returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'kind',kind,'title',title,'details',details,'starts_at',starts_at,'ends_at',ends_at,'active',starts_at<=now()) order by starts_at,id),'[]'::jsonb) from lit_private.promotions where place_id=p_place and archived_at is null and ends_at>now() and (starts_at<=now() or kind='event') and exists(select 1 from public.lit_business_claims_v2 where place_id=p_place and status='verified');
$$;

create or replace function lit_private.feed_base_v6(p_places jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result_places jsonb; result_posts jsonb:='[]'::jsonb;
begin
  if p_places is null or jsonb_typeof(p_places)<>'array' then raise exception 'Expected a list of places.'; end if;
  if jsonb_array_length(p_places)>250 or octet_length(p_places::text)>250000 then raise exception 'Too many places in one request.'; end if;
  with requested as (select distinct item->>'id' as pid from jsonb_array_elements(p_places) items(item)
    where jsonb_typeof(item)='object' and length(item->>'id') between 1 and 512),
  matched as (select distinct on (r.pid) r.pid,p.* from requested r join public.lit_places_v2 p
    on r.pid=lit_private.pid(p.provider,p.provider_place_id) order by r.pid,p.created_at,p.id)
  select coalesce(jsonb_agg(jsonb_build_object('pid',pid,'place_id',id,'name',name,'lat',latitude,'lon',longitude,
    'category',category,'address',address,'provider_verified',provider_verified,'score',null,
    'activity',case when provider_verified then lit_private.activity(id) else null end,
    'claimed',exists(select 1 from public.lit_business_claims_v2 where place_id=m.id and status='verified'),
    'promos','[]'::jsonb) order by pid),'[]'::jsonb) into result_places from matched m;
  if auth.uid() is not null then
    select coalesce(jsonb_agg(row_data order by created_at desc,id),'[]'::jsonb) into result_posts from (
      select post.id,post.created_at,jsonb_build_object('id',post.id,'place_id',post.place_id,'pid',place->>'pid',
        'video_path',post.video_path,'post_type',post.post_type,'created_at',post.created_at,'expires_at',post.expires_at) row_data
      from public.lit_venue_posts_v2 post join jsonb_array_elements(result_places) places(place) on (place->>'place_id')::uuid=post.place_id
      where post.deleted_at is null and post.expires_at>now() and post.created_at>now()-interval '24 hours' and post.created_at<=now()
      order by post.created_at desc,post.id limit 250) active_posts;
  end if;
  return jsonb_build_object('server_time',now(),'places',result_places,'posts',result_posts);
end $$;

create or replace function lit_private.place_base_v6(p_pid text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare p public.lit_places_v2%rowtype;
begin
  if p_pid is null or length(p_pid)>512 then raise exception 'Invalid venue link.'; end if;
  select * into p from public.lit_places_v2 where lit_private.pid(provider,provider_place_id)=p_pid order by created_at,id limit 1;
  if p.id is null or not p.provider_verified then return null; end if;
  return jsonb_build_object('venue',jsonb_build_object('id',p_pid,'name',p.name,'lat',p.latitude,'lon',p.longitude,'category',p.category,'address',p.address),
    'place',jsonb_build_object('pid',p_pid,'place_id',p.id,'provider_verified',true,'score',null,'activity',lit_private.activity(p.id),
      'claimed',exists(select 1 from public.lit_business_claims_v2 where place_id=p.id and status='verified'),'promos','[]'::jsonb));
end $$;

create or replace function public.lit_nearby_feed(p_places jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;places jsonb;
begin
 result:=lit_private.feed_base_v6(p_places);
 select coalesce(jsonb_agg(p||jsonb_build_object('promos',lit_private.public_promotions((p->>'place_id')::uuid)) order by p->>'pid'),'[]'::jsonb) into places from jsonb_array_elements(result->'places') x(p);
 return jsonb_set(result,'{places}',places);
end $$;
create or replace function public.lit_public_place(p_pid text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 result:=lit_private.place_base_v6(p_pid);if result is null then return null;end if;
 return jsonb_set(result,'{place,promos}',lit_private.public_promotions((result->'place'->>'place_id')::uuid));
end $$;
create or replace function public.lit_business_dashboard(p_place uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare place_data jsonb;promos jsonb;checks bigint;
begin
 perform lit_private.require_business(p_place);
 select jsonb_build_object('place_id',id,'name',name,'pid',lit_private.pid(provider,provider_place_id)) into place_data from public.lit_places_v2 where id=p_place;
 select count(distinct user_id) into checks from lit_private.arrivals where place_id=p_place and checked_at>now()-interval '24 hours';
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'kind',kind,'title',title,'details',details,'starts_at',starts_at,'ends_at',ends_at,'active',archived_at is null and starts_at<=now() and ends_at>now(),'archived',archived_at is not null,'version',revision,'views',null,'taps',null) order by created_at desc,id),'[]'::jsonb) into promos from (select * from lit_private.promotions where place_id=p_place and (created_at>now()-interval '30 days' or ends_at>now()) order by created_at desc,id limit 50) p;
 return jsonb_build_object('generated_at',now(),'place',place_data,'go',jsonb_build_object('current_count',(lit_private.activity(p_place)->>'going_count')::bigint,'updated_at',now(),'expires_after_hours',12),'crew',jsonb_build_object('planning_count',(lit_private.activity(p_place)->>'planning_count')::bigint,'updated_at',now()),'arrivals',jsonb_build_object('count_24h',checks,'method','client_location_check'),'score',null,'history','[]'::jsonb,'totals','{}'::jsonb,'hourly','[]'::jsonb,'daily','[]'::jsonb,'videos','[]'::jsonb,'feedback',lit_private.feedback_summary(p_place),'promotions',promos,'profile',(public.lit_place_details(p_place)->'profile'),'capabilities',jsonb_build_object('go_totals',true,'crew_totals',true,'arrival_feedback',true,'full_analytics',false,'business_profile',true,'promotions',true));
end $$;
revoke all on all tables in schema lit_private from public,anon,authenticated;
revoke all on all functions in schema lit_private from public,anon,authenticated;
revoke all on function public.lit_confirm_arrival(uuid,double precision,double precision,double precision),public.lit_submit_feedback(uuid,text,integer,text,boolean),public.lit_save_promotion(uuid,uuid,text,text,text,timestamptz,timestamptz,integer),public.lit_archive_promotion(uuid,integer) from public,anon,authenticated;
grant execute on function public.lit_confirm_arrival(uuid,double precision,double precision,double precision),public.lit_submit_feedback(uuid,text,integer,text,boolean),public.lit_save_promotion(uuid,uuid,text,text,text,timestamptz,timestamptz,integer),public.lit_archive_promotion(uuid,integer) to authenticated;
notify pgrst,'reload schema';
commit;
