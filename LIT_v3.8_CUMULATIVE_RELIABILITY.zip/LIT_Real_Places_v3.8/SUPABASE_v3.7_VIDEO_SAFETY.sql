-- LIT v3.7. Run after the complete v3.6 migration. No existing videos are deleted by installation.
begin;
create table if not exists lit_private.worker_health(singleton boolean primary key default true check(singleton),seen_at timestamptz not null);
create table if not exists lit_private.video_sessions(
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,
 upload_path text not null unique,mime text not null,started_at timestamptz not null default now(),expires_at timestamptz not null default now()+interval '10 minutes',
 start_lat double precision,start_lon double precision,state text not null default 'recording' check(state in('recording','pending','processing','ready','failed','removed')),
 place_id uuid references public.lit_places_v2(id) on delete cascade,post_id uuid not null unique default gen_random_uuid(),declared_ms integer,
 lease uuid,lease_until timestamptz,attempts integer not null default 0,next_attempt timestamptz not null default now(),output_path text,error_code text,
 measured_ms integer,bytes bigint,width integer,height integer
);
create table if not exists lit_private.moderators(user_id uuid primary key references auth.users(id) on delete cascade,granted_at timestamptz not null default now());
create table if not exists lit_private.reports(
 id uuid primary key default gen_random_uuid(),post_id uuid references public.lit_venue_posts_v2(id) on delete set null,
 reporter_id uuid references auth.users(id) on delete set null,reason text not null,details text not null default '',created_at timestamptz not null default now(),
 resolved_at timestamptz,decision text,reviewer_id uuid references auth.users(id) on delete set null,review_note text,unique(post_id,reporter_id)
);
create table if not exists lit_private.blocks(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,author_id uuid not null references auth.users(id) on delete cascade,created_at timestamptz not null default now(),unique(user_id,author_id),check(user_id<>author_id));
create table if not exists lit_private.media_cleanup(
 id uuid primary key default gen_random_uuid(),bucket text not null,path text not null,created_at timestamptz not null default now(),done_at timestamptz,
 lease uuid,lease_until timestamptz,attempts integer not null default 0,next_attempt timestamptz not null default now(),unique(bucket,path)
);
-- No FK: this minimal receipt survives Auth deletion. No email/password/notes are retained here.
create table if not exists lit_private.deletion_requests(id uuid primary key default gen_random_uuid(),user_id uuid not null unique,requested_at timestamptz not null default now(),finished_at timestamptz,lease uuid,lease_until timestamptz,attempts integer not null default 0,next_attempt timestamptz not null default now());
create index if not exists lit_video_work_v7 on lit_private.video_sessions(state,next_attempt);
create index if not exists lit_report_queue_v7 on lit_private.reports(created_at) where resolved_at is null;
create index if not exists lit_cleanup_queue_v7 on lit_private.media_cleanup(next_attempt) where done_at is null;
create index if not exists lit_posts_author_v7 on public.lit_venue_posts_v2(author_id);
create index if not exists lit_posts_video_path_v7 on public.lit_venue_posts_v2(video_path);
do $$declare t text;begin foreach t in array array['worker_health','video_sessions','moderators','reports','blocks','media_cleanup','deletion_requests'] loop execute format('alter table lit_private.%I enable row level security',t);end loop;end $$;

create or replace function lit_private.require_active()
returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not exists(select 1 from auth.users where id=auth.uid()) then raise exception 'Sign in with an active LIT account.' using errcode='42501';end if;
 perform pg_catalog.pg_advisory_xact_lock_shared(pg_catalog.hashtextextended('lit:account:'||auth.uid()::text,0));
 if exists(select 1 from lit_private.deletion_requests where user_id=auth.uid()) then raise exception 'Account deletion is in progress. This account cannot make further changes.' using errcode='42501';end if;
end $$;
create or replace function lit_private.require_worker_online()
returns void language plpgsql security definer set search_path='' as $$
begin if not exists(select 1 from lit_private.worker_health where seen_at>now()-interval '5 minutes') then raise exception 'The processing service is offline. Please try again later.';end if;end $$;
create or replace function lit_private.can_moderate()
returns boolean language sql stable security definer set search_path='' as $$select lit_private.is_owner() or exists(select 1 from lit_private.moderators where user_id=auth.uid());$$;
create or replace function lit_private.require_moderator()
returns void language plpgsql security definer set search_path='' as $$
begin perform lit_private.require_active();perform 1 from lit_private.owner_config where user_id=auth.uid() for share;if found then return;end if;perform 1 from lit_private.moderators where user_id=auth.uid() for share;if not found then raise exception 'Content moderator access is required.' using errcode='42501';end if;end $$;
create or replace function public.lit_safety_access()
returns jsonb language plpgsql security definer set search_path='' as $$
begin perform lit_private.require_active();return jsonb_build_object('can_moderate',lit_private.can_moderate(),'is_owner',lit_private.is_owner());end $$;
create or replace function public.lit_manage_moderator(p_email text,p_enabled boolean)
returns jsonb language plpgsql security definer set search_path='' as $$
declare target uuid;
begin perform lit_private.require_active();perform lit_private.require_owner();if p_enabled is null then raise exception 'Choose grant or revoke.';end if;
 select id into target from auth.users where lower(email)=lower(btrim(p_email)) and email_confirmed_at is not null;
 if target is null or exists(select 1 from lit_private.deletion_requests where user_id=target) then raise exception 'A confirmed active LIT account is required.';end if;
 if target=auth.uid() then raise exception 'You retain owner access.';end if;
 if p_enabled then insert into lit_private.moderators(user_id) values(target) on conflict(user_id) do nothing;else delete from lit_private.moderators where user_id=target;end if;
 insert into lit_private.verification_audit(actor_id,action,details) values(auth.uid(),case when p_enabled then 'moderator_grant' else 'moderator_revoke' end,jsonb_build_object('user_id',target));return jsonb_build_object('saved',true);
end $$;
create or replace function public.lit_list_moderators()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;begin perform lit_private.require_active();perform lit_private.require_owner();select coalesce(jsonb_agg(jsonb_build_object('email',u.email,'granted_at',m.granted_at) order by m.granted_at),'[]'::jsonb) into result from lit_private.moderators m join auth.users u on u.id=m.user_id;return result;end $$;
create or replace function public.lit_begin_capture(p_lat double precision,p_lon double precision,p_mime text,p_accuracy double precision default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();s lit_private.video_sessions;ext text;
begin perform lit_private.require_active();perform lit_private.require_worker_online();
 if not exists(select 1 from auth.users where id=u and email_confirmed_at is not null) then raise exception 'Confirm your account email first.';end if;
 if p_lat is null or p_lon is null or p_lat not between -90 and 90 or p_lon not between -180 and 180 or p_accuracy is null or p_accuracy<=0 or p_accuracy>150 then raise exception 'A fresh precise location is required. Try outdoors with precise location enabled.';end if;
 if p_mime is null or p_mime not in('video/mp4','video/webm','video/quicktime') then raise exception 'This recording format is unsupported.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:capture:'||u::text,0));
 if (select count(*) from lit_private.video_sessions where user_id=u and started_at>now()-interval '24 hours')>=20 then raise exception 'Daily recording limit reached.';end if;
 if (select count(*) from lit_private.video_sessions where user_id=u and ((state='recording' and expires_at>now()) or state in('pending','processing')))>=3 then raise exception 'Finish or discard an existing recording first.';end if;
 ext:=case p_mime when 'video/webm' then 'webm' when 'video/quicktime' then 'mov' else 'mp4' end;
 s.id:=gen_random_uuid();insert into lit_private.video_sessions(id,user_id,upload_path,mime,start_lat,start_lon) values(s.id,u,u::text||'/'||s.id::text||'.'||ext,p_mime,p_lat,p_lon) returning * into s;
 return jsonb_build_object('session_id',s.id,'upload_path',s.upload_path,'mime_type',s.mime,'bucket','lit-video-quarantine','expires_at',s.expires_at);
end $$;
create or replace function public.lit_publish_capture(p_session uuid,p_place uuid,p_duration_ms integer,p_lat double precision,p_lon double precision,p_accuracy double precision default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare s lit_private.video_sessions;v public.lit_places_v2;distance double precision;size_bytes bigint;
begin perform lit_private.require_active();select * into s from lit_private.video_sessions where id=p_session and user_id=auth.uid() for update;
 if s.id is null then raise exception 'Recording unavailable for this account.' using errcode='42501';end if;
 if s.state in('pending','processing','ready') then if s.place_id<>p_place then raise exception 'Recording was already submitted to another venue.';end if;return jsonb_build_object('post_id',s.post_id,'state',s.state);end if;
 if s.state<>'recording' or s.expires_at<=now() then raise exception 'This recording expired or was discarded. Record again.';end if;
 perform lit_private.require_worker_online();
 if now()<s.started_at+interval '10 seconds' or p_duration_ms is null or p_duration_ms not between 10000 and 30000 then raise exception 'Record a complete 10–30 second clip.';end if;
 if p_lat is null or p_lon is null or p_lat not between -90 and 90 or p_lon not between -180 and 180 or p_accuracy is null or p_accuracy<=0 or p_accuracy>150 then raise exception 'A fresh precise location is required.';end if;
 select * into v from public.lit_places_v2 where id=p_place and provider_verified and latitude is not null and longitude is not null;
 if v.id is null then raise exception 'Choose a provider-verified venue.';end if;
 distance:=6371000*acos(greatest(-1.0,least(1.0,sin(radians(p_lat))*sin(radians(v.latitude))+cos(radians(p_lat))*cos(radians(v.latitude))*cos(radians(p_lon-v.longitude)))));
 if distance>400 then raise exception 'You need to be within 400 metres of this venue.';end if;
 distance:=6371000*acos(greatest(-1.0,least(1.0,sin(radians(s.start_lat))*sin(radians(v.latitude))+cos(radians(s.start_lat))*cos(radians(v.latitude))*cos(radians(s.start_lon-v.longitude)))));
 if distance>400 then raise exception 'The recording must start near this venue.';end if;
 select case when (metadata->>'size') ~ '^[0-9]{1,12}$' then (metadata->>'size')::bigint else null end into size_bytes from storage.objects where bucket_id='lit-video-quarantine' and name=s.upload_path;
 if size_bytes is null or size_bytes<=0 or size_bytes>78643200 then raise exception 'Upload a valid recording within the 75 MiB limit first.';end if;
 update lit_private.video_sessions set place_id=p_place,declared_ms=p_duration_ms,state='pending',start_lat=null,start_lon=null where id=s.id;
 return jsonb_build_object('post_id',s.post_id,'state','pending');
end $$;
create or replace function public.lit_my_uploads()
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;begin perform lit_private.require_active();select coalesce(jsonb_agg(jsonb_build_object('id',id,'post_id',post_id,'state',state,'created_at',started_at,'expires_at',started_at+interval '24 hours','error_code',error_code) order by started_at desc),'[]'::jsonb) into result from (select * from lit_private.video_sessions where user_id=auth.uid() and started_at>now()-interval '7 days' order by started_at desc limit 30) s;return result;end $$;
create or replace function public.lit_discard_capture(p_session uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare s lit_private.video_sessions;begin perform lit_private.require_active();select * into s from lit_private.video_sessions where id=p_session and user_id=auth.uid() for update;if s.id is null then raise exception 'Recording unavailable.';end if;
 update lit_private.video_sessions set state='removed',start_lat=null,start_lon=null where id=s.id;
 update public.lit_venue_posts_v2 set deleted_at=coalesce(deleted_at,now()) where id=s.post_id;
 insert into lit_private.media_cleanup(bucket,path) values('lit-video-quarantine',s.upload_path) on conflict(bucket,path) do nothing;
 if s.output_path is not null then insert into lit_private.media_cleanup(bucket,path) values('lit-fresh-videos',s.output_path) on conflict(bucket,path) do nothing;end if;
 return jsonb_build_object('removed',true);end $$;
create or replace function lit_private.visible_post(p_id uuid)
returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.lit_venue_posts_v2 p where p.id=p_id and p.deleted_at is null and p.expires_at>now() and p.created_at<=now() and not exists(select 1 from lit_private.deletion_requests d where d.user_id=p.author_id) and not exists(select 1 from lit_private.blocks b where b.user_id=auth.uid() and b.author_id=p.author_id));$$;
create or replace function public.lit_report_post(p_post uuid,p_reason text,p_details text)
returns jsonb language plpgsql security definer set search_path='' as $$
begin perform lit_private.require_active();if not lit_private.visible_post(p_post) then raise exception 'This video is no longer available.';end if;
 if p_reason is null or p_reason not in('not_fresh','wrong_venue','inappropriate','spam','safety','other') or length(coalesce(p_details,''))>500 then raise exception 'Choose a valid reason and details within 500 characters.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:report:'||auth.uid()::text,0));
 if exists(select 1 from lit_private.reports where post_id=p_post and reporter_id=auth.uid()) then return jsonb_build_object('reported',true);end if;
 if (select count(*) from lit_private.reports where reporter_id=auth.uid() and created_at>now()-interval '24 hours')>=20 then raise exception 'Daily reporting limit reached.';end if;
 insert into lit_private.reports(post_id,reporter_id,reason,details) values(p_post,auth.uid(),p_reason,btrim(coalesce(p_details,'')));return jsonb_build_object('reported',true);end $$;
create or replace function public.lit_moderation_queue(p_limit integer default 25)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;begin perform lit_private.require_moderator();
 select coalesce(jsonb_agg(jsonb_build_object('id',r.id,'post_id',r.post_id,'reason',r.reason,'details',r.details,'at',r.created_at,'venue',p.name,'unavailable',v.id is null or v.deleted_at is not null or v.expires_at<=now()) order by r.created_at),'[]'::jsonb) into result from (select * from lit_private.reports where resolved_at is null order by created_at,id limit greatest(1,least(coalesce(p_limit,25),25))) r left join public.lit_venue_posts_v2 v on v.id=r.post_id left join public.lit_places_v2 p on p.id=v.place_id;
 return jsonb_build_object('authorized',true,'reports',result);end $$;
-- Moderator preview is still private, expires quickly and does not reveal author/reporter identities.
create or replace function public.lit_moderation_preview(p_report uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare media_path text;begin perform lit_private.require_moderator();select p.video_path into media_path from lit_private.reports r join public.lit_venue_posts_v2 p on p.id=r.post_id where r.id=p_report and r.resolved_at is null and p.deleted_at is null and p.expires_at>now();if media_path is null then raise exception 'This clip is no longer available.';end if;return jsonb_build_object('path',media_path);end $$;
create or replace function public.lit_resolve_report(p_report uuid,p_decision text,p_note text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare r lit_private.reports;media_path text;
begin perform lit_private.require_moderator();if p_decision is null or p_decision not in('remove','dismiss') or p_note is null or length(btrim(p_note)) not between 3 and 500 then raise exception 'Choose a decision and a 3–500 character review note.';end if;
 select * into r from lit_private.reports where id=p_report for update;if r.id is null then raise exception 'Report unavailable.';end if;
 if r.resolved_at is not null then if r.decision=p_decision then return jsonb_build_object('resolved',true);end if;raise exception 'This report was already resolved. Refresh the queue.';end if;
 if p_decision='remove' and r.post_id is not null then
 update public.lit_venue_posts_v2 set deleted_at=coalesce(deleted_at,now()) where id=r.post_id returning video_path into media_path;
 update lit_private.video_sessions set state='removed' where post_id=r.post_id;
 if media_path is not null then insert into lit_private.media_cleanup(bucket,path) values('lit-fresh-videos',media_path) on conflict(bucket,path) do nothing;end if;
 end if;
 update lit_private.reports set resolved_at=now(),decision=p_decision,reviewer_id=auth.uid(),review_note=btrim(p_note) where id=p_report;
 insert into lit_private.verification_audit(actor_id,action,details) values(auth.uid(),'report_'||p_decision,jsonb_build_object('report_id',p_report,'post_id',r.post_id));return jsonb_build_object('resolved',true);end $$;
create or replace function public.lit_delete_my_post(p_post uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare media_path text;begin perform lit_private.require_active();select video_path into media_path from public.lit_venue_posts_v2 where id=p_post and author_id=auth.uid() for update;if media_path is null then raise exception 'This is not your video.' using errcode='42501';end if;
 update public.lit_venue_posts_v2 set deleted_at=coalesce(deleted_at,now()) where id=p_post;update lit_private.video_sessions set state='removed' where post_id=p_post;
 insert into lit_private.media_cleanup(bucket,path) values('lit-fresh-videos',media_path) on conflict(bucket,path) do nothing;return jsonb_build_object('removed',true);end $$;
create or replace function public.lit_block_post_author(p_post uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare author uuid;begin perform lit_private.require_active();select author_id into author from public.lit_venue_posts_v2 where id=p_post and deleted_at is null and expires_at>now();if author is null or author=auth.uid() then raise exception 'Choose another available creator.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:blocks:'||auth.uid()::text,0));
 if (select count(*) from lit_private.blocks where user_id=auth.uid())>=500 and not exists(select 1 from lit_private.blocks where user_id=auth.uid() and author_id=author) then raise exception 'Block limit reached. Unblock a creator first.';end if;
 insert into lit_private.blocks(user_id,author_id) values(auth.uid(),author) on conflict(user_id,author_id) do nothing;return jsonb_build_object('blocked',true);end $$;
create or replace function public.lit_my_blocks()
returns jsonb language plpgsql security definer set search_path='' as $$declare result jsonb;begin perform lit_private.require_active();select coalesce(jsonb_agg(jsonb_build_object('id',id) order by created_at),'[]'::jsonb) into result from lit_private.blocks where user_id=auth.uid();return result;end $$;
create or replace function public.lit_unblock_creator(p_block uuid)
returns jsonb language plpgsql security definer set search_path='' as $$begin perform lit_private.require_active();delete from lit_private.blocks where id=p_block and user_id=auth.uid();return jsonb_build_object('unblocked',true);end $$;

-- Re-authentication is performed by the server endpoint before this service-only request.
create or replace function public.lit_request_account_deletion(p_actor uuid,p_confirmation text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare receipt uuid;
begin
 if p_actor is null or p_confirmation is distinct from 'DELETE' then raise exception 'Type DELETE to confirm.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:account:'||p_actor::text,0));
 if exists(select 1 from lit_private.owner_config where user_id=p_actor) then raise exception 'The platform owner cannot delete this account. Transfer platform ownership through an operator procedure first.';end if;
 if not exists(select 1 from auth.users where id=p_actor) then raise exception 'Account unavailable.';end if;
 perform lit_private.require_worker_online();
 insert into lit_private.deletion_requests(user_id) values(p_actor) on conflict(user_id) do nothing;
 select id into receipt from lit_private.deletion_requests where user_id=p_actor;
 -- Remove access immediately; physical cleanup and Auth deletion run in the trusted worker.
 update public.lit_venue_posts_v2 set deleted_at=coalesce(deleted_at,now()) where author_id=p_actor;
 update lit_private.video_sessions set state='removed',start_lat=null,start_lon=null where user_id=p_actor;
 update public.profiles set username=null,display_name=null,avatar_url=null where id=p_actor;
 delete from public.lit_go_intents_v2 where user_id=p_actor;
 update public.lit_business_claims_v2 set status='rejected',review_version=review_version+1,updated_at=now() where claimant_id=p_actor;
 delete from lit_private.reviewers where user_id=p_actor;delete from lit_private.moderators where user_id=p_actor;
 delete from lit_private.crews where owner_id=p_actor;
 delete from lit_private.crew_outings where organizer_id=p_actor;
 delete from lit_private.crew_members where user_id=p_actor;
 delete from lit_private.outing_responses where user_id=p_actor;
 return jsonb_build_object('requested',true,'receipt',receipt,'state','pending');
end $$;
create or replace function public.lit_deletion_status(p_receipt uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;begin
 select jsonb_build_object('state',case when finished_at is not null then 'completed' when attempts>=5 then 'needs_operator' else 'pending' end,'requested_at',requested_at,'completed_at',finished_at) into result from lit_private.deletion_requests where id=p_receipt;
 if result is null then raise exception 'Deletion receipt unavailable.';end if;return result;end $$;
-- Service-only maintenance handles expiry, orphaned uploads and deletion receipts.
create or replace function public.lit_worker_claim()
returns jsonb language plpgsql security definer set search_path='' as $$
#variable_conflict use_column
declare c lit_private.media_cleanup;s lit_private.video_sessions;d lit_private.deletion_requests;token uuid;
begin
 insert into lit_private.worker_health(singleton,seen_at) values(true,now()) on conflict(singleton) do update set seen_at=now();
 update lit_private.video_sessions set state='failed',error_code='SESSION_EXPIRED',start_lat=null,start_lon=null where state='recording' and expires_at<=now();
 update lit_private.video_sessions set state='failed',error_code='PROCESSING_EXPIRED',start_lat=null,start_lon=null where state in('pending','processing') and started_at<now()-interval '24 hours';
 insert into lit_private.media_cleanup(bucket,path)
 select 'lit-video-quarantine',upload_path from lit_private.video_sessions where state in('failed','removed','ready')
 union select 'lit-fresh-videos',video_path from public.lit_venue_posts_v2 where deleted_at is not null or expires_at<=now()
 union select 'lit-fresh-videos',output_path from lit_private.video_sessions where state in('failed','removed') and output_path is not null
 union select o.bucket_id,o.name from storage.objects o where o.bucket_id='lit-fresh-videos' and o.name ~ '^[a-f0-9-]{36}/[a-f0-9-]{36}/[a-f0-9-]{36}\.mp4$' and o.created_at<now()-interval '15 minutes' and not exists(select 1 from public.lit_venue_posts_v2 p where p.video_path=o.name and p.deleted_at is null and p.expires_at>now()) and not exists(select 1 from lit_private.video_sessions s where s.output_path=o.name and s.state='processing' and s.lease_until>now())
 on conflict(bucket,path) do nothing;
 -- Queue all objects owned by a deleting account, including older buckets. Never delete provider venue records.
 insert into lit_private.media_cleanup(bucket,path)
 select o.bucket_id,o.name from storage.objects o join lit_private.deletion_requests d on d.finished_at is null and ((to_jsonb(o)->>'owner_id')=d.user_id::text or (to_jsonb(o)->>'owner')=d.user_id::text or (o.bucket_id in('lit-video-quarantine','lit-fresh-videos','lit-videos') and split_part(o.name,'/',1)=d.user_id::text))
 union select 'lit-fresh-videos',p.video_path from public.lit_venue_posts_v2 p join lit_private.deletion_requests d on d.user_id=p.author_id where d.finished_at is null
 on conflict(bucket,path) do nothing;
 select * into c from lit_private.media_cleanup where done_at is null and next_attempt<=now() and (lease_until is null or lease_until<now()) order by created_at,id for update skip locked limit 1;
 if c.id is not null then token:=gen_random_uuid();update lit_private.media_cleanup set lease=token,lease_until=now()+interval '5 minutes',attempts=attempts+1 where id=c.id;return jsonb_build_object('kind','cleanup','id',c.id,'lease',token,'bucket',c.bucket,'path',c.path);end if;
 select * into d from lit_private.deletion_requests where finished_at is null and next_attempt<=now() and (lease_until is null or lease_until<now()) and attempts<5 order by requested_at,id for update skip locked limit 1;
 if d.id is not null then
 if exists(select 1 from storage.objects o where (to_jsonb(o)->>'owner_id')=d.user_id::text or (to_jsonb(o)->>'owner')=d.user_id::text or (o.bucket_id in('lit-video-quarantine','lit-fresh-videos','lit-videos') and split_part(o.name,'/',1)=d.user_id::text)) or exists(select 1 from public.lit_venue_posts_v2 p join lit_private.media_cleanup c on c.bucket='lit-fresh-videos' and c.path=p.video_path where p.author_id=d.user_id and c.done_at is null) then
 update lit_private.deletion_requests set next_attempt=now()+interval '10 seconds' where id=d.id;
 else token:=gen_random_uuid();update lit_private.deletion_requests set lease=token,lease_until=now()+interval '5 minutes',attempts=attempts+1 where id=d.id;return jsonb_build_object('kind','deletion','id',d.id,'lease',token,'user_id',d.user_id);end if;
 end if;
 select * into s from lit_private.video_sessions where ((state='pending' and next_attempt<=now()) or (state='processing' and lease_until<now())) and attempts<3 and started_at>now()-interval '24 hours' and not exists(select 1 from lit_private.deletion_requests d where d.user_id=video_sessions.user_id) order by started_at,id for update skip locked limit 1;
 if s.id is not null then
 token:=gen_random_uuid();update lit_private.video_sessions set state='processing',lease=token,lease_until=now()+interval '10 minutes',attempts=attempts+1,output_path=user_id::text||'/'||id::text||'/'||token::text||'.mp4' where id=s.id returning * into s;
 return jsonb_build_object('kind','video','id',s.id,'lease',token,'bucket','lit-video-quarantine','path',s.upload_path,'output_path',s.output_path,'declared_ms',s.declared_ms);end if;
 update lit_private.video_sessions set state='failed',error_code='PROCESSING_FAILED' where state='processing' and lease_until<now() and attempts>=3;
 return null;
end $$;
create or replace function public.lit_worker_result(p_kind text,p_id uuid,p_lease uuid,p_ok boolean,p_metadata jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare s lit_private.video_sessions;ms integer;size_bytes bigint;w integer;h integer;u uuid;
begin
 if p_ok is null then raise exception 'Worker outcome required.';end if;
 if p_kind='cleanup' then
 update lit_private.media_cleanup set done_at=case when p_ok then now() else null end,lease_until=null,next_attempt=now()+interval '1 minute' where id=p_id and lease=p_lease and lease_until>now();if not found then raise exception 'Worker lease expired.';end if;
 elsif p_kind='deletion' then
 select user_id into u from lit_private.deletion_requests where id=p_id and lease=p_lease and lease_until>now() for update;if u is null then raise exception 'Worker lease expired.';end if;
 if p_ok and exists(select 1 from auth.users where id=u) then raise exception 'Auth deletion has not completed.';end if;
 update lit_private.deletion_requests set finished_at=case when p_ok then now() else null end,lease_until=null,next_attempt=now()+interval '1 minute' where id=p_id;
 elsif p_kind='video' then
 select * into s from lit_private.video_sessions where id=p_id and lease=p_lease and lease_until>now() and state='processing' for update;
 if s.id is null then raise exception 'Worker lease expired or recording was removed.';end if;
 if exists(select 1 from lit_private.deletion_requests where user_id=s.user_id) then raise exception 'Account deletion is in progress.';end if;
 if p_ok then
 ms:=(p_metadata->>'duration_ms')::integer;size_bytes:=(p_metadata->>'bytes')::bigint;w:=(p_metadata->>'width')::integer;h:=(p_metadata->>'height')::integer;
 if ms is null or ms not between 10000 and 30100 or abs(ms-s.declared_ms)>1000 or size_bytes is null or size_bytes<=0 or size_bytes>78643200 or w is null or h is null or w<2 or h<2 or w>1280 or h>1280 or p_metadata->>'content_type' is distinct from 'video/mp4' then raise exception 'Processed metadata failed validation.';end if;
 if not exists(select 1 from storage.objects where bucket_id='lit-fresh-videos' and name=s.output_path and (metadata->>'size')::bigint=size_bytes) then raise exception 'Processed object unavailable.';end if;
 if s.started_at<now()-interval '24 hours' then raise exception 'Recording freshness expired.';end if;
 insert into public.lit_venue_posts_v2(id,place_id,author_id,video_path,post_type,created_at,expires_at) values(s.post_id,s.place_id,s.user_id,s.output_path,case when exists(select 1 from public.lit_business_claims_v2 where place_id=s.place_id and claimant_id=s.user_id and status='verified') then 'business' else 'community' end,s.started_at,s.started_at+interval '24 hours') on conflict(id) do nothing;
 update lit_private.video_sessions set state='ready',measured_ms=ms,bytes=size_bytes,width=w,height=h,lease_until=null,error_code=null where id=s.id;
 else
 update lit_private.video_sessions set state=case when attempts>=3 or p_metadata->>'code'='MEDIA_INVALID' then 'failed' else 'pending' end,error_code=case when p_metadata->>'code'='MEDIA_INVALID' then 'MEDIA_INVALID' else 'PROCESSING_FAILED' end,lease_until=null,next_attempt=now()+interval '1 minute' where id=s.id;
 end if;
 else raise exception 'Unknown worker task.';end if;
 return jsonb_build_object('saved',true);
end $$;
-- Recover an uncertain publication response without deleting a successfully committed object.
create or replace function public.lit_worker_result_status(p_id uuid,p_lease uuid)
returns jsonb language sql stable security definer set search_path='' as $$select jsonb_build_object('published',state='ready' and lease=p_lease,'state',state) from lit_private.video_sessions where id=p_id;$$;
-- Purge known application rows before the worker calls the Supabase Auth Admin API.
create or replace function public.lit_worker_purge_account(p_id uuid,p_lease uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid;t record;idlist uuid[];
begin
 select user_id into u from lit_private.deletion_requests where id=p_id and lease=p_lease and lease_until>now() and finished_at is null for update;if u is null then raise exception 'Worker lease expired.';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lit:account:'||u::text,0));
 if exists(select 1 from lit_private.owner_config where user_id=u) then raise exception 'Owner deletion is prohibited.';end if;
 if exists(select 1 from storage.objects o where (to_jsonb(o)->>'owner_id')=u::text or (to_jsonb(o)->>'owner')=u::text or (o.bucket_id in('lit-video-quarantine','lit-fresh-videos','lit-videos') and split_part(o.name,'/',1)=u::text)) then raise exception 'Storage cleanup is not complete.';end if;
 select array_agg(id) into idlist from public.lit_business_claims_v2 where claimant_id=u;
 delete from lit_private.verification_audit where claim_id=any(coalesce(idlist,'{}'::uuid[]));
 update lit_private.verification_audit set actor_id=null where actor_id=u;
 update lit_private.reports set reporter_id=null,details='' where reporter_id=u;
 update lit_private.reports set reviewer_id=null,review_note=null where reviewer_id=u;
 delete from lit_private.blocks where user_id=u or author_id=u;
 delete from lit_private.video_sessions where user_id=u;
 delete from lit_private.arrivals where user_id=u;
 delete from lit_private.crews where owner_id=u;delete from lit_private.crew_outings where organizer_id=u;delete from lit_private.crew_members where user_id=u;delete from lit_private.outing_responses where user_id=u;
 delete from lit_private.crew_request_limits where user_id=u;delete from lit_private.place_lookup_limits where user_id=u;delete from lit_private.reviewers where user_id=u;delete from lit_private.moderators where user_id=u;
 -- Optional legacy tables use the known inventory's user columns. Shared venues/events stay with owner/creator detached.
 for t in select * from (values('follows','user_id','delete'),('going_intents','user_id','delete'),('engagement_events','actor_id','delete'),('lit_engagement_events_v2','user_id','delete'),('lit_crew_members_v2','user_id','delete'),('lit_crew_members_v2','member_id','delete'),('lit_outing_invites_v2','invitee_id','delete'),('lit_outings_v2','organizer_id','delete'),('venues','owner_id','detach'),('posts','creator_id','delete'),('events','creator_id','detach')) x(tab,col,mode) loop
 if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t.tab and column_name=t.col) then
 if t.mode='delete' then execute format('delete from public.%I where %I=$1',t.tab,t.col) using u;else execute format('update public.%I set %I=null where %I=$1',t.tab,t.col,t.col) using u;end if;end if;end loop;
 delete from public.lit_go_intents_v2 where user_id=u;delete from public.lit_business_claims_v2 where claimant_id=u;delete from public.lit_venue_posts_v2 where author_id=u;delete from public.profiles where id=u;
 return jsonb_build_object('purged',true,'user_id',u);
end $$;

create or replace function public.lit_operator_status()
returns jsonb language plpgsql security definer set search_path='' as $$
begin perform lit_private.require_active();perform lit_private.require_owner();return jsonb_build_object('worker_seen_at',(select seen_at from lit_private.worker_health where singleton),'worker_online',exists(select 1 from lit_private.worker_health where seen_at>now()-interval '5 minutes'),'video_pending',(select count(*) from lit_private.video_sessions where state in('pending','processing')),'video_failed_7d',(select count(*) from lit_private.video_sessions where state='failed' and started_at>now()-interval '7 days'),'media_cleanup_pending',(select count(*) from lit_private.media_cleanup where done_at is null),'deletions_pending',(select count(*) from lit_private.deletion_requests where finished_at is null),'deletions_needing_attention',(select count(*) from lit_private.deletion_requests where finished_at is null and attempts>=5));end $$;
create or replace function public.lit_retry_deletions()
returns jsonb language plpgsql security definer set search_path='' as $$
begin perform lit_private.require_active();perform lit_private.require_owner();update lit_private.deletion_requests set attempts=0,next_attempt=now() where finished_at is null and attempts>=5 and (lease_until is null or lease_until<now());insert into lit_private.verification_audit(actor_id,action) values(auth.uid(),'deletion_retry');return jsonb_build_object('saved',true);end $$;

-- Delivery authorization: blocked/deleted/expired videos cannot receive fresh signed URLs.
revoke insert,update,delete,truncate,references,trigger on public.lit_venue_posts_v2 from public,anon,authenticated;
drop policy if exists lit_posts_read_v2 on public.lit_venue_posts_v2;
create policy lit_posts_read_v2 on public.lit_venue_posts_v2 for select to authenticated using(lit_private.visible_post(id));
-- Avoid recursive table policies by using the security-definer helper. Remove earlier broad read policy names.
drop policy if exists posts_read on public.lit_venue_posts_v2;
drop policy if exists lit_video_own_upload on storage.objects;
drop policy if exists lit_video_authenticated_read on storage.objects;
drop policy if exists lit_video_own_cleanup on storage.objects;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('lit-video-quarantine','lit-video-quarantine',false,78643200,array['video/webm','video/mp4','video/quicktime']) on conflict(id) do update set public=false,file_size_limit=78643200,allowed_mime_types=excluded.allowed_mime_types;
update storage.buckets set public=false where id='lit-fresh-videos';
drop policy if exists lit_quarantine_upload_v7 on storage.objects;
create policy lit_quarantine_upload_v7 on storage.objects for insert to authenticated with check(bucket_id='lit-video-quarantine' and exists(select 1 from lit_private.video_sessions s where s.user_id=auth.uid() and s.upload_path=name and s.state='recording' and s.expires_at>now()) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid()));
drop policy if exists lit_processed_read_v7 on storage.objects;
create policy lit_processed_read_v7 on storage.objects for select to authenticated using(bucket_id='lit-fresh-videos' and exists(select 1 from public.lit_venue_posts_v2 p where p.video_path=name and p.deleted_at is null and p.expires_at>now() and (lit_private.visible_post(p.id) or lit_private.can_moderate())) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid()));
-- Policies need carefully scoped public helpers, not access to private tables.
create or replace function public.lit_video_upload_allowed(p_path text)
returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from lit_private.video_sessions where user_id=auth.uid() and upload_path=p_path and state='recording' and expires_at>now()) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid());$$;
create or replace function public.lit_video_read_allowed(p_path text)
returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.lit_venue_posts_v2 p where video_path=p_path and deleted_at is null and expires_at>now() and (lit_private.visible_post(p.id) or lit_private.can_moderate())) and exists(select 1 from auth.users where id=auth.uid()) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid());$$;
drop policy lit_quarantine_upload_v7 on storage.objects;
create policy lit_quarantine_upload_v7 on storage.objects for insert to authenticated with check(bucket_id='lit-video-quarantine' and public.lit_video_upload_allowed(name));
drop policy lit_processed_read_v7 on storage.objects;
create policy lit_processed_read_v7 on storage.objects for select to authenticated using(bucket_id='lit-fresh-videos' and public.lit_video_read_allowed(name));
-- Direct post reads use a public boolean helper so no private-schema grants are required.
create or replace function public.lit_post_visible(p_id uuid)
returns boolean language sql stable security definer set search_path='' as $$select lit_private.visible_post(p_id) and exists(select 1 from auth.users where id=auth.uid()) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid());$$;
drop policy lit_posts_read_v2 on public.lit_venue_posts_v2;
create policy lit_posts_read_v2 on public.lit_venue_posts_v2 for select to authenticated using(public.lit_post_visible(id));

-- Restrictive guards also cover direct legacy table/storage API requests with an old token.
create or replace function public.lit_account_active()
returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from auth.users where id=auth.uid()) and not exists(select 1 from lit_private.deletion_requests where user_id=auth.uid());$$;
drop policy if exists lit_active_storage_v7 on storage.objects;
create policy lit_active_storage_v7 on storage.objects as restrictive for all to authenticated using((select public.lit_account_active())) with check((select public.lit_account_active()));
do $$declare t record;begin for t in select c.relname from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r' and (c.relname like 'lit_%' or c.relname in('profiles','posts','follows','boosts','areas','engagement_events','venues','events','going_intents')) loop
 execute format('alter table public.%I enable row level security',t.relname);
 execute format('drop policy if exists lit_active_account_v7 on public.%I',t.relname);
 execute format('create policy lit_active_account_v7 on public.%I as restrictive for all to authenticated using((select public.lit_account_active())) with check((select public.lit_account_active()))',t.relname);
 end loop;end $$;

-- Copy the v3.6 feed and filter blocked/removed authors without changing any other fields.
create or replace function lit_private.feed_base_v7(p_places jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;places jsonb;
begin
 result:=lit_private.feed_base_v6(p_places);
 select coalesce(jsonb_agg(p||jsonb_build_object('promos',lit_private.public_promotions((p->>'place_id')::uuid)) order by p->>'pid'),'[]'::jsonb) into places from jsonb_array_elements(result->'places') x(p);
 return jsonb_set(result,'{places}',places);
end $$;
create or replace function public.lit_nearby_feed(p_places jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;posts jsonb;begin
 if auth.uid() is not null then perform lit_private.require_active();end if;
 result:=lit_private.feed_base_v7(p_places);
 select coalesce(jsonb_agg(p||jsonb_build_object('mine',v.author_id=auth.uid()) order by p->>'created_at' desc,p->>'id'),'[]'::jsonb) into posts from jsonb_array_elements(result->'posts') x(p) join public.lit_venue_posts_v2 v on v.id=(p->>'id')::uuid where lit_private.visible_post(v.id);
 return jsonb_set(result,'{posts}',posts);
end $$;
-- Guard previous mutating/read RPCs against stale tokens after a deletion request.
-- Uses only our existing public PL/pgSQL functions, retaining their signatures and permissions.
do $guard$
declare f record;definition text;body text;
begin
 for f in select p.oid,p.prosrc,p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace join pg_language l on l.oid=p.prolang where n.nspname='public' and l.lanname='plpgsql' and p.proname like 'lit_%' and p.prosecdef and p.proname not like 'lit_worker_%' and p.proname not in('lit_request_account_deletion','lit_deletion_status','lit_register_verified_place','lit_reserve_place_lookup') loop
 if position('lit_private.require_active()' in f.prosrc)=0 then
 body:=regexp_replace(f.prosrc,'\mbegin\M','begin if auth.uid() is not null then perform lit_private.require_active();end if;','i');
 if body=f.prosrc then raise exception 'Cannot guard function %',f.proname;end if;
 definition:=pg_get_functiondef(f.oid);execute replace(definition,f.prosrc,body);
 end if;
 end loop;
end $guard$;
revoke all on all tables in schema lit_private from public,anon,authenticated;
revoke all on all functions in schema lit_private from public,anon,authenticated;
do $$declare f record;begin for f in select p.oid::regprocedure name,p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname in('lit_operator_status','lit_retry_deletions','lit_account_active','lit_safety_access','lit_manage_moderator','lit_list_moderators','lit_begin_capture','lit_publish_capture','lit_my_uploads','lit_discard_capture','lit_report_post','lit_moderation_queue','lit_moderation_preview','lit_resolve_report','lit_delete_my_post','lit_block_post_author','lit_my_blocks','lit_unblock_creator','lit_video_upload_allowed','lit_video_read_allowed','lit_post_visible','lit_worker_claim','lit_worker_result_status','lit_worker_result','lit_worker_purge_account','lit_request_account_deletion','lit_deletion_status') loop
 execute format('revoke all on function %s from public,anon,authenticated',f.name);
 if f.proname like 'lit_worker_%' or f.proname='lit_request_account_deletion' then execute format('grant execute on function %s to service_role',f.name);
 elsif f.proname='lit_deletion_status' then execute format('grant execute on function %s to anon,authenticated',f.name);
 else execute format('grant execute on function %s to authenticated',f.name);end if;
 end loop;end $$;
notify pgrst,'reload schema';
commit;
