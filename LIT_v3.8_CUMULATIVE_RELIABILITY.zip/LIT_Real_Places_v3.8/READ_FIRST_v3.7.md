# LIT v3.7 — video processing, moderation, blocks and account deletion

This is cumulative. All v3.6 files/features are retained. Owner-controlled business verification, GO, private Crew planning, arrivals, private feedback, promotions and bookmarks stay included.

## Installation

1. If the complete v3.6 backend is installed, run **SUPABASE_v3.7_VIDEO_SAFETY.sql** in your existing Supabase SQL Editor. If you have not run v3.6 yet, use **SUPABASE_COMPLETE_v3.7.sql** instead. The complete script runs the migrations in order and preserves existing records. Do not run an older migration alone afterward.
2. Keep the existing owner setup. Only run SUPABASE_OWNER_SETUP.sql if the platform owner has never been configured; it still uses Nickmccrae11@gmail.com and refuses to replace a different owner.
3. Start the trusted worker described in WORKER_SETUP_v3.7.md. **Video processing and account deletion require this running service.** The worker is not a Netlify browser asset or a public upload endpoint. It uses the same Supabase project and server-only service-role key. No new paid video API is required, but hosting/operating the worker has its own cost.
4. Deploy the whole app folder to the existing Netlify project once, including its Functions. Keep SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY and GEOAPIFY_API_KEY available to Production Functions. The new delete-account Function uses the existing server variables.

The Netlify configuration now excludes **only SUPABASE_URL** from secret-value scanning because it is intentionally public browser configuration. Scanning remains enabled for the service-role and Geoapify keys. Do not exclude those keys or turn scanning off. The package includes no actual service-role/Geoapify credentials. This fixes the public-URL false-positive case shown by the screenshots; the exact production match was not provided, so an unrelated real-key match still needs removal if Netlify reports one.

## What is implemented

### Video

- Confirmed signed-in accounts get server-owned recording sessions, upload paths, ten-minute session expiry and account quotas.
- The client records through the camera; there is no gallery/file picker. Server timing, device location and measured media checks reduce invalid uploads, but cannot prove that client GPS or footage claims are honest.
- A precise fresh location is required at recording and submission, with both positions within 400 metres of a provider-verified venue. The recording-start coordinates are kept privately for this short session, then cleared on submission/discard/expiry maintenance. Arrival checks still do not store raw GPS. Coordinates never appear in the public post or Crew data.
- Uploads go to the private quarantine bucket. A client cannot overwrite an existing upload, upload to a different session, write processed media or insert a public post directly.
- Submission creates a processing job. Clips do not appear publicly until the worker decodes/measures/transcodes the media, removes embedded metadata, uploads the processed H.264/AAC MP4 and commits valid metadata under its current lease.
- Browser WebM without container duration is measured using bounded packet timestamps. Malformed, short, long and oversized media are rejected. Time-limited leases and up to three processing attempts recover interrupted jobs. An uncertain successful publish response does not cause the worker to delete a committed clip.
- A clip expires 24 hours after recording started, not 24 hours after delayed processing. My videos in Settings shows recording, waiting, processing, published, failed and removed states; Refresh checks progress. Failed clips require recording again.
- Removed, expired and abandoned media is queued for physical cleanup. Older existing posts/files remain on installation and follow their previous expiry/deletion state; they are not retroactively claimed to have passed this worker.

Limits: 20 sessions per account/day, three current recording/processing sessions, 75 MiB upload/processed size, camera duration 10–30 seconds, worker dimensions at most 1280 and metadata duration tolerance. No worker heartbeat within five minutes means new recording sessions/deletion requests fail with a clear offline message. A queued job is not represented as live video.

### Moderation and account blocks

- Guests can report available videos; repeated reports by the same account/post are deduplicated. Twenty reports per day per account.
- The platform owner can review reports and grant/revoke content moderators by confirmed LIT email. This is separate from business verification/reviewer access. Neither a venue claim nor an editable profile role grants moderator rights. Only the platform owner can delegate access.
- Moderators get report details and an authorized short-lived clip preview without author/reporter account IDs. They remove or dismiss reports with a required review note. Every resolution is recorded privately. A removed clip disappears from subsequent feeds/media authorization and is queued for file cleanup.
- Account blocks apply server-side to the caller's feed and fresh media authorizations. They do not remove a creator's videos globally. Blocks can be managed/unblocked in Settings; creator account identities are not listed. Manual device-only hiding remains separate.
- New signed media URLs last two minutes. Existing issued URLs/downloaded copies may remain usable until expiry or physical cleanup. Access changes cannot retract already-downloaded copies.

### Account deletion

- Settings provides an explicit permanent-deletion form: current password plus typing DELETE. The server verifies the signed-in identity and re-authenticates that same account with Supabase before requesting deletion; caller-supplied user IDs are ignored. Tokens/passwords are not returned or logged.
- Accounts that use an external sign-in provider must set a password using the existing password-reset flow before this confirmation. The platform-owner account is protected; ownership transfer is not implemented by this form.
- On a confirmed request, the account is denied further app changes, its profile is cleared, videos hidden, GO removed, claims rejected, delegated permissions revoked and owned Crew plans/memberships removed. Old tokens are guarded in both RPCs and direct application/storage policies.
- The worker removes owned storage objects (including older buckets), purges the known LIT application records and calls Supabase Auth Admin deletion. A UUID receipt allows a private status check: pending, completed or needs operator attention. Do not share the receipt; possession allows checking status. The UI does not say deletion completed until Auth deletion is confirmed.
- Minimal receipts, processed file cleanup records and safety audit entries can remain. Deleted applicants' claim audits are removed; other safety/reviewer actor references and reporter details are detached/cleared. No automatic fixed retention policy for remaining audit/receipt records is invented here. Operator policies should explain retention and backups.
- Shared real venue listings remain. This cannot erase other people's downloads, provider listings or hosting backups. Legacy venue ownership is detached, not used to delete the venue. A worker/database failure leaves an explicit pending request. After five deletion attempts, the owner sees operator attention and can retry after fixing the failure.

## Owner controls

Sign in as the configured platform owner, open **Settings & privacy → Report review tools**. The panel shows the worker heartbeat/queue status, stalled deletion count and the separate content moderation team. Business verification remains in its existing dashboard.

## Acceptance after deployment

Use test accounts and non-sensitive test videos before inviting more users:

1. Confirm the worker is online in the owner status panel.
2. Record 10–30 seconds near a real venue; check waiting/processing then Published in My videos and playback from a second account. Verify iPhone Safari/Android Chrome separately.
3. Try invalid location/short recordings and another account's upload path; no post should be published.
4. Report the clip; confirm a normal guest/business reviewer cannot read the queue. Grant a separate moderator, remove/dismiss a test report, then revoke that moderator.
5. Block/unblock a creator and confirm the feed changes. Refresh after removing a clip and test fresh signed URL refusal.
6. With a disposable account, confirm wrong-password deletion is refused. Then request deletion, check pending/completed receipt and confirm the old account cannot sign in or modify data. Never use the platform owner as this test account.
7. Retest GO/cancel, private Crew invitations/plans, feedback privacy and business promotions.

These changes are prepared and tested locally. **Production SQL, deployment and worker hosting were not performed.** See VALIDATION_v3.7.md for exactly what was tested and its limits.

## Still outstanding

Trusted activity-score calculation, full event-specific RSVP/ticketing, genuine view/watch/promotion analytics, push/email notifications, operator terms/privacy/support and retention policy, physical-device acceptance, production alerts/backups, stronger distributed abuse controls and automatic content classification. Moderation here is a manual queue requiring real operators; it does not automatically judge or approve all new clips.
