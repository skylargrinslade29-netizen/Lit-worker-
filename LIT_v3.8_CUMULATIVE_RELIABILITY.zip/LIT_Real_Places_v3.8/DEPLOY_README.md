# v3.2 cumulative video reliability and safety integration

Includes all v3.1 features, upload retry and signed-video playback recovery. Adds a runnable FFmpeg processing worker and optional account-blocking/moderation interfaces. Backend-dependent safety controls stay disabled until real server contracts are implemented; see SAFETY_BACKEND_CONTRACT.md. The video worker is tested locally but not connected to live uploads; see VIDEO_PIPELINE_SETUP.md. Supabase remains unchanged. No deployment was performed.

Follow the existing project deployment steps below for one cumulative frontend/functions update. The separate worker needs a backend job-processing environment and is not installed by Netlify deployment. Do not enable prepared controls as a substitute for working server permissions.

# v3.2 anonymous intent display

All v3.0 features are retained. WATCH/PICK/GO/venue details now show aggregate Going and Planning to go, a numeric LIT score and update timing. Real totals require activity data from the existing lit_nearby_feed backend; missing/stale totals show —. No example numbers appear as live data. Read ACTIVITY_BACKEND_CONTRACT.md for the response contract and included tested server aggregation helper. Supabase remains unchanged at the user's request; the helper is not connected to the live RPC.

Use one deployment to the existing project following the guide below. This is frontend/aggregation-helper code, not confirmation of live counts, video transcoding or global moderation systems.

# v3.2 cumulative app essentials

Includes every v2.9 file/feature and adds saved places, autoplay/preloading preferences, offline/reconnect notices, home-screen manifest metadata, live-page expired-clip pruning and configurable support/policy links. Nothing was deployed or changed in Supabase. Follow OPERATOR_SETUP.md to add real operator resource URLs. No legal documents or contacts were fabricated.

Saved places and video hiding are device-local. The manifest is not an offline app; no authenticated API or video content is cached by a service worker. The package does not implement global blocking/deletion/moderation or server fraud controls. All earlier GPS and category-recovery code remains. Use one deployment to the existing project following the cumulative guide below.

# v3.2 app usability update — no Supabase changes

This cumulative package adds loaded-venue name/address search, Help & Safety guidance and device-local hiding of videos. It fixes old-location Ask responses, adds a 10-second Ask timeout with local genuine-venue matching, excludes expired Tonight promotions and opens an incoming venue link only once. All earlier discovery, GPS and account/camera fixes remain.

Name search searches already loaded provider results, not a nationwide directory. Hiding a video is local to the device; it does not block the creator, delete the post or send a report. Clear device data resets hiding preferences. No database changes are included or required for these additions.

Full public readiness is still unverified. Global moderation/user blocking/account deletion, server-side permission/media/score enforcement, provider directory completeness, real-phone testing and published legal/support details remain outstanding. Read REMAINING_WORK.md. The user asked to defer Supabase work; this release does so.

Deploy this cumulative version once to the existing glowing-crepe-8a40b0 project using the instructions below. It requires functions deployment. Nothing was deployed by the assistant.

# v3.2 current-location fix

This cumulative release includes category recovery and all previous readiness fixes. The current-location button requests fresh GPS, keeps the previous search if permission or positioning fails, provides browser permission guidance, and has a bounded wait when the browser never returns a callback. It remains usable after ZIP/city searches. Deploy this version once using the instructions below, including the functions.

On your phone, open the HTTPS production URL in Safari or Chrome. Allow location for that website and turn on device Location Services. A code update cannot override a denied browser permission. If permission is blocked, enable it in browser/site settings, then tap Use my current location again; ZIP/city search remains available.

Local mock regression checks passed, including manual-to-GPS switching, fresh options, denial preserving existing results, invalid GPS data and a missing browser callback. Physical iPhone/Android tests and production provider/backend access remain unverified.

# LIT v3.2 category recovery update

This cumulative package includes all v2.6 fixes plus targeted backup recovery for failed venue categories. Read READINESS_AUDIT.md for launch blockers and BACKEND_CONTRACTS.json for required RPCs. These changes improve the source; they do not certify the uninspected database/backend or replace real-device testing.

Use the deployment steps below for one batch to glowing-crepe-8a40b0. No Netlify deployment or credit-consuming build was started during this audit.

# LIT v3.2 — real nearby places fix

Deploy this package to the EXISTING Netlify project **glowing-crepe-8a40b0**.
Production URL confirmed in your screenshots: https://glowing-crepe-8a40b0.netlify.app

## Nightlife coverage update

Your v2.4 deployment is confirmed by you to be loading real venues. This v3.2 update addresses food crowding out nightlife, while retaining those reliability fixes.

- Four parallel Geoapify category searches, each with its own 100-record limit: nightclubs, bars/pubs, entertainment, food. Food cannot consume the nightclub request's slots.
- Public OSM fallback likewise uses four output budgets in a single provider request.
- The merged list can retain up to 400 genuine records instead of cutting the whole collection down to 300.
- PICK's All list mixes categories with equal actual evidence; verified scores/fresh-video evidence still take priority. Party's visible filter label is now Nightclubs.
- The 250-record live-feed registration limit is balanced across categories too.
- A failed category search retains successful results and queries only the failed categories through the OSM backup. If recovery fails, the incomplete-results warning remains. Backup queries are capped at about 7.5 miles; wider searches explicitly warn of incomplete category coverage. Successful empty Geoapify categories do not trigger extra requests.
- Provider logs now include counts per normalized category and category recovery outcomes.
- Four Geoapify requests are made per uncached lookup instead of one; short caching and duplicate-request coalescing remain. This does not create additional Netlify function invocations for one search, but provider request/quota usage differs.

The result is not an exhaustive directory. A venue must exist and be categorized in the provider data, have a name/coordinates, lie inside the selected radius, and fit the category query's 100-record limit. Some nightclubs are mapped only as bars. Increasing the radius or selecting Nightclubs cannot manufacture absent provider records. A missing specific venue requires checking its provider listing/location/categories.

## What this fixes

- Correct Geoapify category keys, including adult.nightclub. The old source used unsupported/undocumented keys: entertainment.nightclub, entertainment.theatre, entertainment.music_venue.
- Independent provider timeouts: a failed attempt no longer aborts every fallback.
- Explicit provider HTTP status, timeout/schema diagnostics, request IDs and runtime key-presence boolean. No keys, provider URLs, query text or coordinates are logged.
- Correct URLSearchParams encoding for GPS and manual ZIP/city requests; malformed whole-query encoding is rejected clearly.
- Manual location search stays available after GPS success/failure and a previous manual search.
- Old GPS/geocode/radius/video-feed responses cannot replace newer searches.
- Real venues render before the separate Supabase live-video feed finishes. Missing video backend support cannot block nearby place discovery.
- Successful empty provider results stay genuinely empty. No fake venues/activity are generated.
- Short success caching/coalescing reduces repeat provider requests. Recent genuine results can be reused during a brief outage, with a visible stale-result warning.
- OSM fallback coverage is capped at approximately 7.5 miles and honestly labeled if the requested radius is larger.
- ZIP geocoding is constrained to US postcodes; city searches can include an explicit state/country. ZIP/city results select an area center, not your exact GPS position.
- Browser assets are in public/; server source, tests and notes are outside the published directory.
- All three APIs are explicitly routed: /api/places, /api/geocode, /api/ask.

## Deployment (frontend AND functions together)

**Do not upload public/ alone or assume dragging this source ZIP into Netlify Drop updates the functions.** Use Netlify CLI or a connected repository build. This is a source ZIP, not a prebuilt Netlify function bundle.

### Recommended: one production deploy using Netlify CLI

1. Download and extract the ZIP. Open a terminal in the extracted **LIT_Real_Places_v3.2** folder (the folder containing netlify.toml and deploy.sh).
2. Use Node.js 22 or newer, with npm available.
3. Check Netlify Environment variables: GEOAPIFY_API_KEY must have a Production value and Functions scope. Your screenshot already shows these; do not put its value into this ZIP or the terminal commands.
4. On Linux/macOS, run:

   ```sh
   bash deploy.sh
   ```

   The script runs local checks, opens Netlify login, then performs ONE production deployment to the existing project. It explicitly selects the production environment context and includes the functions. It does not create a new project or change domains. CLI installation downloads tools but is not a Netlify build. Production deployment/provider usage may consume credits.

   Alternatively, on any platform, run these commands in that folder:

   ```sh
   node scripts/check.mjs
   npx --yes netlify-cli@latest login
   npx --yes netlify-cli@latest deploy --site glowing-crepe-8a40b0 --context production --prod --dir public --functions netlify/functions --no-build --skip-functions-cache --message "LIT v3.2 real nearby places reliability fix"
   ```

   Sign into the Netlify account containing glowing-crepe-8a40b0. If login/project access fails, stop and resolve that access; do not create a replacement project. If you encounter an error, share the error text with secrets hidden.

### Chromebook

The commands require a Linux terminal with Node/npm. If Linux development is already enabled, place the extracted folder in Linux files and run the commands there. If no terminal is available, share this source package through a connected Git repository and configure Netlify with publish directory public and functions directory netlify/functions. A static folder drop alone is not the documented function deployment workflow.

### Connected repository alternative

Commit all the package files to the repository connected to the existing project. The netlify.toml declares publish = "public" and functions = "netlify/functions". No frontend build or package dependency installation is necessary for this plain-JavaScript app. Use one commit/deployment for the batch. Keep the same Netlify project and production environment variables.

## After deployment

1. Deploy summary should include **3 functions**: places, geocode, ask. CLI function bundling must complete successfully.
2. Refresh the live site (Ctrl+Shift+R on desktop). Choose PICK → Use my GPS location; allow browser location access. Real nearby venues should appear in PICK.
3. Search your ZIP, then city/state. Verify the area label and returned places. WATCH remains video-first; without available fresh clips it directs you to real nearby places in PICK.
4. Try 5 and 10 miles. For 25/50-mile requests served by public OSM fallback, the UI must show the reduced-coverage warning.
5. A successful /api/places or /api/geocode response includes X-LIT-Discovery-Version: 3.2. Failures carry a request ID to correlate with function logs.

If 503 remains, open Cloud compute → Functions → places and reproduce ONE search. New structured logs identify provider_failure.provider, status, reason and request_id. key_configured shows whether the deployed runtime actually received a non-empty key.

- key_configured = false: check the Production/Functions variable scope and that all functions were freshly deployed.
- Geoapify HTTP 400: request rejected; category mismatch was fixed here, so inspect provider/account diagnostics for the remaining rejection.
- Geoapify HTTP 401/403: inspect key validity, project permissions and key restrictions in Geoapify. Browser-only referrer/origin restrictions may reject server-side calls; configure a key appropriate for server-side use. Do not expose its value.
- HTTP 429: provider rate/quota issue. Netlify credits and Geoapify quota are separate.
- timeout/network or HTTP 5xx: provider connectivity/outage; fallback attempts and recent-result cache may help, but neither guarantees availability.

## Verification limits

Local regression checks pass using mocked providers and a minimal DOM harness: query validation/encoding, provider categories, real-record normalization, empty results, failure/fallback/coverage, cache/coalescing and safe diagnostics, GPS denial/manual form, overlapping GPS/geocode/radius/feed requests, and venue display independent of live-feed completion. These fixtures are only in checks/, outside public/. Every JavaScript file passes syntax and relative-import checks.

The current session cannot reach live APIs because its network proxy is unavailable, and has no Netlify credentials. Therefore the production key, Geoapify response, Netlify function bundling, real-device GPS and live venue loading are not yet verified. This is a tested discovery fix prepared for your requested deployment, not a guarantee against invalid credentials or upstream outages.

Existing WATCH/CREW/PICK/GO/Business modules and public Supabase configuration are preserved. Remaining backend/event/billing requirements are recorded in RELEASE_STATUS.md; this package does not invent missing Supabase RPCs, scores, members, analytics or events.

References:
- https://apidocs.geoapify.com/docs/places/
- https://docs.netlify.com/build/functions/get-started/
- https://docs.netlify.com/api-and-cli-guides/cli-guides/manage-functions/
- https://cli.netlify.com/commands/deploy/
