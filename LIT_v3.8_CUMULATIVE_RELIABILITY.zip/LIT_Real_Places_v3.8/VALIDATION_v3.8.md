# Validation scope

Source and endpoint regression checks use npm test. Browser validation uses mobile/desktop Chromium with the local PostgreSQL fixture, mock Supabase SDK and synthetic accounts. The reliability checks cover live venue GO/cancel state, sign-in returning to the intended venue, draft restoration/clearing, owner-only worker checklist and connection recovery controls. Existing business authorization, GO counts and profile refresh checks are retained.

No production changes or hosting were performed here. VisualViewport integration is implemented; actual iOS keyboard behavior requires a real-device check. Draft storage is limited to selected non-credential forms in this browser tab. Hosting the video/deletion worker remains separate.

Results: npm test passed. The business browser suite and engagement browser suite passed. The dedicated mobile reliability suite passed with deliberately delayed GO RPCs: saving/disabled state, saved/cancelled labels, owner checklist and absence of browser errors. Draft restore/clear and sign-in continuation were exercised in the business suite.
