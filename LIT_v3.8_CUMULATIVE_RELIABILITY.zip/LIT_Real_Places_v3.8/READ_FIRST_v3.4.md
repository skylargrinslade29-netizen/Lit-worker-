# LIT v3.4 cumulative update

All v3.3 files and features are retained, including owner-controlled business verification, delegated reviewers, private review history, authenticated GO and verified business profiles.

## Added in this batch

- Save and unsave inside venue details, including shared venues.
- Search bookmarks by name, address or category.
- Sort alphabetically or by distance from your selected area.
- Open saved venues outside your current discovery area without changing your selected location.
- Export/import validated public venue bookmark backups. Imports merge duplicates and enforce the 100-place limit. Backups contain no account, claim or GO data.
- Copy venue addresses, with a manual copy fallback.

## Install once

Follow READ_FIRST_v3.3.md. The database migration is unchanged: no additional SQL is needed if v3.3 is already installed. SUPABASE_OWNER_SETUP.sql is configured for Nickmccrae11@gmail.com, which must be an existing confirmed LIT account. If nothing is installed yet, run the combined v3.3 migration then the owner setup, configure the server variables and deploy this full v3.4 folder.

## Next recommended backend batches

1. Video processing and server validation: duration, location checks, expiry cleanup and a working global moderation queue.
2. Full Crew plans: authorized invitations, responses, cancellation and reliable private membership.
3. Events/RSVP: verified venue publishing, event lifecycle and real attendance-intent totals.
4. Account controls: supported deletion, blocking and privacy preferences backed by server permissions.
5. Trusted activity scoring and operator monitoring after genuine backend signals exist.

These are remaining tasks, not implemented features in this ZIP. Bookmark backups provide device-local portability, not automatic cloud synchronization. Business verification is manual review, not automated proof of legal ownership. This release has not been deployed to production.
