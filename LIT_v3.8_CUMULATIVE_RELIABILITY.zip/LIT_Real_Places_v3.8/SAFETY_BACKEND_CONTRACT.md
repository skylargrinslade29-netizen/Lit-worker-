# Optional safety integration — v3.2

## Added interfaces
Report review with remove/dismiss decisions and mandatory review notes. Account block and block management. Existing reporting, personal hide, Crew privacy and venue-score rules are retained. Optional buttons remain OFF in public/lit-config.js until the following server contracts are implemented and tested. Hiding client buttons is not authorization.

## Required authenticated RPCs
- lit_moderation_queue(p_limit integer): checks server-owned moderator privileges, returns {authorized:true,reports:[{id,reason,details}]}; limit 25. Reject unauthorized callers; do not disclose the queue.
- lit_resolve_report(p_report uuid,p_decision text,p_note text): checks moderator privileges and allowed decision (remove/dismiss), requires 3–500 character note, atomically resolves an open report, records reviewer/time/action in an access-controlled audit trail; returns {resolved:true}. Removal must propagate to feeds/object delivery and signed URLs according to the platform's retention policy.
- lit_block_post_author(p_post uuid): derives the actual author from a visible post, prevents spoofed IDs/self-block, stores a deduplicated caller-owned block and returns {blocked:true}. It must filter blocked authors from the caller's future feed. It must not reveal the creator's identity.
- lit_my_blocks(): returns only the authenticated caller's blocks as [{id}], without public identity lists.
- lit_unblock_creator(p_block uuid): caller-owned block only, returns {unblocked:true}.

Apply RLS/ownership checks, reasonable server rate limits and server-side validation. Replays must be safe. The existing report RPC also requires deduplication/limits and a real operator review process. Moderators cannot be self-appointed through browser configuration, profile fields or request data. Do not return unrestricted media paths or private Crew information in this queue. To inspect a reported clip, implement an authorized time-limited media preview endpoint; this version's queue is text-only.

## Activation
Keep features.accountBlocking and features.moderationTools false until these controls are live and verified with normal users, a moderator and a second account. Then enable the appropriate flag. The review button is a convenience, not a moderator entitlement. No RPC implementations/migrations are guessed or deployed here because the existing schema has not been supplied and Supabase changes were deferred.

## Scope
This prepares client workflows; it is not an operating moderation service, abuse detection model or guarantee of removal from already-issued signed URLs. Ensure staff, escalation and emergency processes exist before public video launch.
