## v3.8 current release

See READ_FIRST_v3.8.md for the cumulative reliability batch. No further SQL is needed after successful v3.7 and the missing-v3.6 repair. This package has not been deployed by this assistant; worker hosting remains separate. Older sections below describe earlier versions.

## v3.7 update

Video processing, reporting, owner-delegated moderation, blocking and confirmed account deletion now have source implementations and local fixture validation. This release has not been deployed here. Processing and deletion require the included trusted worker to run continuously. See READ_FIRST_v3.7.md and WORKER_SETUP_v3.7.md; older sections below describe prior releases.

# v3.6 cumulative update

Arrival location checks, private grouped guest feedback, verified venue promotions and venue-saving diagnostics are implemented and locally tested in this release. All previous files remain. See READ_FIRST_v3.6.md. Location checks do not prove attendance. Event announcements do not implement full Events/RSVP or ticketing. Video server enforcement, global moderation, trusted scores, account deletion/blocking and full analytics remain outstanding. Historical statements below about missing arrival/feedback or promotion backend functions are superseded by v3.6 source. This package has not been deployed or applied to production.

# v3.5 cumulative release

Private Crew backend and client workflow are implemented and tested locally. All prior files remain. See READ_FIRST_v3.5.md and VALIDATION_v3.5.md. No production deployment or SQL execution performed.

# v3.3 cumulative business verification system

Current release: owner-controlled business claim review, delegated reviewers, private audit history, follow-up/rejection/revocation, verified venue profile editing, GO expiry/anonymous counts, dashboard refresh, shared-link lookup and account recovery. Run SUPABASE_v3.3_BUSINESS_SYSTEM.sql and SUPABASE_OWNER_SETUP.sql, then deploy the complete source once. READ_FIRST_v3.3.md supersedes earlier setup instructions. PostgreSQL-fixture and mobile/desktop Chromium checks passed; live installation/deployment remains unperformed. No owner identity is guessed or automatically assigned. Historical notes and other launch requirements below are retained.

# GO authentication and registration follow-up (historical)

Signed-out GO now requires sign-in and no longer saves device-only intent. Signed-in GO registers missing venues through an authenticated Netlify route using provider-returned data and a server-only Supabase key. See GO_FIX_SETUP.md. Supabase batches 1 and 2 were reported installed by the user. This frontend/function update is not deployed; the existing production site retains its prior behavior until a complete Netlify deployment. Other backend release gaps remain.

# v3.2 cumulative reliability/safety preparation

Active additions: bounded retry for transient upload failures, manual playback recovery with signed URL renewal. Prepared additions: text moderation queue and decision UI, account blocking/management UI behind disabled flags, real FFmpeg media worker. All earlier code/features retained. Supabase/worker integration, full global removal enforcement, CDN/job processing and public moderation operations are not deployed or verified.

# v3.2 anonymous intent counts and numeric score

Added identity-free GO/planning summaries, timestamps/freshness validation, numeric score labels and refresh after GO/RSVP. Includes a pure server aggregate helper for trusted database row integration. No live RPC/schema changes made; live counts remain unavailable until backend integration. All earlier features retained. Streaming/transcoding and global moderation work remain outstanding.

# v3.2 cumulative app essentials

Added saved places, video preferences, connection notices, home-screen metadata, expired-clip pruning and optional genuine support/policy resource links. Existing files/features retained. No Supabase changes. Source/mock tests cover bookmarks, expiration, connection states, persistence and resource URL validation. Production/backend/device verification remains outstanding.

# v3.2 app usability update

Added loaded-venue search, device-local video hiding, Help & Safety, Ask timeout/location isolation, expired-promotion filtering and one-time shared-link opening. Supabase work explicitly deferred. Local test coverage includes name matching/no matches, local hide/reset, stale Ask responses and promotion expiration. Global moderation, account blocking/deletion, legal/support details and server validation remain outstanding. No deployment performed.

# v3.2 location flow update

Fresh current-location requests, permission/timeout guidance, previous-search preservation on GPS failure, pending button state, and bounded callback waiting added. All local checks pass. No live deployment or backend changes performed. Public launch prerequisites remain in READINESS_AUDIT.md.

# v3.2 tested category recovery

Failed Geoapify category requests now use targeted OSM recovery while keeping successful categories. Safe diagnostics include category counts. All local source, provider, client and readiness regression checks passed. Live credentials/provider coverage, database permissions and physical phone flows remain unverified. This package has not been deployed.

# LIT v3.2 audit and frontend readiness patch

Cumulative source: includes v2.4 discovery reliability and v2.5 nightlife improvements. Concrete readiness defects patched and regression-tested. READINESS_AUDIT.md documents findings and remaining release blockers; BACKEND_CONTRACTS.json inventories 27 required RPCs; SUPABASE_READONLY_CHECK.sql provides a non-mutating metadata inventory.

Local checks pass. No production deployment or backend modifications were made. Public launch of the complete app still requires backend/storage/moderation/freshness/score verification and real-device testing. The historical handoff below remains retained; no requirement was removed or replaced with fake activity.

# LIT v2.5 nightlife coverage batch

User confirms v2.4 now loads genuine nearby venues in production, predominantly food/some bars. v2.5 addresses category starvation with four separate managed category requests and isolated result limits, OSM output budgets, a 400-record merge cap, category-balanced PICK/All and live-feed registration, and an explicit Nightclubs chip. All reliability changes remain.

Local regression checks include a dense-food fixture with a separately retrieved club, partial-category failure warning, category-mixed UI preserving stronger genuine scores, and balanced live-feed registration. No claim of complete venue directory coverage or verification of v2.5 live results. No deployment was performed here.

Deploy once using deploy.sh to existing glowing-crepe-8a40b0. See DEPLOY_README.md. Historical v2.4/handoff status below is retained as background.

# Current release: LIT v2.4 discovery fix

This package is prepared for the user's explicitly requested deployment of nearby-place discovery fixes to **glowing-crepe-8a40b0**. This supersedes the original blanket do-not-deploy instruction for this focused update. It does not assert completion of the entire LIT backlog.

Production domain: https://glowing-crepe-8a40b0.netlify.app (confirmed from user domain-settings screenshot).
Credits: approximately 29 per user screenshot. No Netlify deployment or build was triggered in this session.

Implemented and locally checked: documented Geoapify categories; separate fallback timeouts; safe status diagnostics; query encoding/validation; manual location recovery; stale-request protection; real places independent of video backend; bounded real-result cache; truthful fallback coverage; full frontend/function deployment layout.

Local server/client regression tests and syntax/import/route checks pass. Live provider/key, Netlify bundling and iPhone GPS verification remain unavailable. See DEPLOY_README.md for one-batch deployment and verification steps.

## Original handoff and prior investigation notes (historical)

The material below is retained to preserve all outstanding requirements. Statements about unknown domain/key status or older source behavior are historical; the current status above and deployment guide describe this package.

# LIT — Consolidated working batch (NOT production-ready)

This package is a cumulative working source snapshot. It is NOT a claim that all requested functionality is implemented, deployed, or tested. Do not deploy until the release gate is satisfied.

## Included source
- Existing mobile WATCH / CREW / PICK / GO / Business Mode UI and code.
- Camera capture frontend and Netlify Places + Ask functions from the current working source.
- Geoapify provider with OpenStreetMap fallback (requires Netlify GEOAPIFY_API_KEY and live verification).

## Mandatory additive release backlog — do not remove or regress
1. WATCH: 10–30 second fresh camera-only capture, secure backend capture/publish, freshness and feed verification; no gallery uploads; video-first UX.
2. REAL PLACES: actual GPS, provider-independent IDs, provider/caching/radius/category matching, no fake activity; live iPhone + endpoint verification.
3. ASK LIT / PICK: intent-aware video-evidence-first nearby recommendations, score transparency, radius controls, Now/Tonight, honest empty states.
4. CREW: real LIT member lists, invitations, outing decisions and I’m In/Maybe/Pass/Waiting responses, privacy, deduplication.
5. GO: persistent per-user intent, toggle/cancel, real aggregate counts, directions, Crew integration.
6. LIT SCORE: genuine fresh video/GO/engagement evidence, server-side decay, fraud resistance, history and explainability; never fabricate activity.
7. BUSINESS: preserve existing full dashboard and Business Pro foundation; implement/test RPCs lit_my_business, lit_business_dashboard, lit_request_claim, lit_save_business_profile, lit_save_promotion, lit_archive_promotion; verified claims, permissions/RLS, real metrics.
8. EVENTS: verified business create/edit/publish/cancel upcoming venue events; date/time/timezone/category/description and optional fresh camera-captured promo video; Coming Up and clearly labeled future-event feed cards, distinct from live status.
9. EVENT RSVP: event-specific Going/Interested/cancel and deduplicated per-user counts; Crew invitations and accepted invitations map to Going once; distinguish event RSVP from present-tense venue GO.
10. EVENT BUSINESS ANALYTICS: genuine impressions, qualified views, event Going, invites/acceptances, directions/tickets, attribution; aggregate privacy protections.
11. PAID PROMOTION FOUNDATION: entitlements/campaigns/attribution/billing architecture for optional boosts and Business Pro; sponsored labeling; payment cannot buy score or ON FIRE status; pricing not fixed.
12. MOBILE: polished safe-area, responsive, no overlapping controls, clear WATCH → CREW → PICK → GO → ARRIVE → VERIFY journey, no fake/demo people or counts.

## Release gate / still unverified
- All relevant Supabase backend RPC signatures and RLS permissions, event database and billing not implemented/verified here.
- Netlify GEOAPIFY_API_KEY presence unknown; live Places endpoint not verified.
- Real iPhone GPS/camera testing and full end-to-end discovery/post/GO/event/business analytics not performed.
- No Netlify deployment was made. Supabase SQL must be separately provided IN CHAT and is not included in this ZIP.

Keep this file with every subsequent working batch until all gates pass.


## 2026-10-09 continuation
- Added manual ZIP/city location fallback through `/api/geocode`.
- Geoapify geocoding is used when configured; OpenStreetMap/Nominatim is the fallback.
- Manual locations feed the same real `/api/places` venue pipeline as GPS.
- PICK and WATCH now recover from denied/failed GPS by directing users to ZIP/city search.
- Ask LIT remains grounded only in returned real venues; no synthetic venue/activity fallback was added.
- GO continues to work from real venue records; ARRIVE still requires fresh device GPS verification.
- Syntax checks pass. Live provider/iPhone verification still required before deployment.

## 2026-10-09 Places investigation batch
- User screenshots confirm production domain https://glowing-crepe-8a40b0.netlify.app and approximately 29 credits remaining. Ignore earlier classy-starlight and credits-exhausted claims.
- Production screenshots show GEOAPIFY_API_KEY configured in Production with Functions scope; key validity and deployed runtime availability remain unverified.
- Logs showed only execution duration/memory. Added key-presence boolean, provider/status/timing diagnostics, and terminal failure events. No keys, URLs, query text, or coordinates are logged.
- Independent 5-second provider attempt budgets replace the shared timeout that could abort all fallback requests. Geocoding budgets total at most approximately 10 seconds; Places approximately 15 seconds for three attempts, plus execution overhead.
- Successful empty responses now stay empty rather than triggering extra requests.
- Geoapify Places uses documented catering categories, adult.nightclub and the entertainment parent category. Official docs list adult.nightclub and entertainment.culture.theatre; original entertainment.nightclub / entertainment.theatre do not match, and entertainment.music_venue is not listed. Source mismatch confirmed; actual live upstream rejection remains unverified. Reference: https://apidocs.geoapify.com/docs/places/
- Frontend geocoding and Places use URLSearchParams. Original source used ordinary separators; the reported %26 request cannot be attributed to this ZIP. Malformed whole-query encoding is rejected, not silently repaired.
- Invalid empty coordinates are rejected. OSM partial/error payloads are rejected; fallback radius coverage warnings remain truthful.
- Mocked-provider tests pass: valid GPS coordinates, manual ZIP/city/special-character query encoding, invalid query rejection, real-record normalization, empty results, 401/400/429/503 failure paths, alternate OSM failover, fallback coverage, timeout isolation, and no secret leakage in logs. All JS/MJS syntax checks pass.
- No production deploy performed and no Netlify builds triggered. Live network/provider checks blocked by this environment's unreachable proxy. This uploaded source has not been compared with production deployed files.
- Next: inspect deployed provider status logs/runtime key presence with this batch once the applicable release gate is satisfied; verify a real GPS and manual ZIP/city search, including known nearby venues and radius behavior. Do not claim reliable live discovery until these checks pass.
- Existing mandatory backlog and release gate above remain in force. Supabase migrations/backend access and real-device tests are still required for remaining LIT requirements.

## Additional 503 trace
- Original handler reproduced under mocks: Geoapify HTTP 400, first Overpass HTTP 503, second Overpass HTTP 429 results in the same generic application HTTP 503. These statuses are fixtures, not production observations.
- Screenshot runtimes (~0.8 seconds) do not support a 19-second timeout as the explanation for those specific requests. Immediate upstream rejection/network failure remains possible.
- Public endpoint could not be fetched through shell (unreachable proxy) or web retrieval (tool reports inaccessible). Root cause of live requests remains unconfirmed.
