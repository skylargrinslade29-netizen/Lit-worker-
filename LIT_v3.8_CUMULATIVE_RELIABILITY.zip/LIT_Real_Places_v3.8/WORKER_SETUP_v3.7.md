# Trusted LIT worker

The app's Netlify Functions do not run FFmpeg. Run this private worker on a server/container host that can stay running. It needs outbound HTTPS access to your Supabase project and a current FFmpeg/FFprobe installation. There are no inbound routes or ports to expose.

## Python option

On the trusted host, use Python 3.12+ and current FFmpeg/FFprobe. Supply SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY through the host's private secret manager, then run:

```sh
python workers/lit_worker.py
```

Use a service supervisor that restarts on failure and monitors logs. The service-role key belongs only on this trusted host and Netlify Functions. Do not put it in public/lit-config.js, Git, screenshots, deployment command arguments or the app ZIP. Use a dedicated worker directory; it needs only temporary scratch disk for each job.

## Docker option

Build from the worker folder:

```sh
docker build -f workers/Dockerfile.service -t lit-worker workers
```

Put the two variables in your host's secret injection, or a private env file outside the repository. Run with that file path (replace the placeholder path):

```sh
docker run -d --name lit-worker --restart unless-stopped --read-only --tmpfs /tmp:rw,noexec,nosuid,size=384m --cpus=2 --memory=1g --pids-limit=128 --security-opt=no-new-privileges --env-file /secure/path/lit-worker.env lit-worker
```

This is a prepared configuration, not a deployed/built image. Adjust the host's resources after measuring real clips. Keep the image/FFmpeg patched. The service's Python adapter needs Supabase network access; media subprocesses allow only file/pipe protocols and have bounded execution times. The container has no public server. Do not deploy a public endpoint that accepts arbitrary filesystem paths or worker job arguments.

## Operation

The worker polls a service-only RPC. SQL selects/leases an eligible task atomically, with SKIP LOCKED so multiple workers do not claim the same live lease. Browser roles cannot call worker RPCs or inspect private queue tables.

- Video: download only the server-selected quarantine object to a fixed local filename, measure/transcode/strip metadata, upload under a lease-specific server path, then finish only a current lease. Ready posts reference only the committed processed object. Stale/removed leases cannot publish.
- Cleanup: delete through the Supabase Storage API (not SQL deletion of storage metadata), then mark completion. Abandoned recordings, expired/removed posts and unreferenced managed processed objects are queued by maintenance.
- Deletion: wait for owned storage cleanup, purge the known LIT records, delete the sign-in account through the Supabase Auth Admin API, and complete the minimal receipt. Account access is already denied when the request is accepted.

Logs contain task type, task ID and fixed error codes. Do not add credentials, private HTTP bodies, raw media URLs, notes or GPS to logs. `worker_connection_failed` indicates a configuration/network/API failure; check the service's secret bindings and migration version. The owner-only panel shows heartbeat, pending tasks and deletions requiring attention. It is a basic status panel, not an external alerting service.

The worker performs continuous maintenance only while running. Database timestamp filters prevent expired posts from appearing even if cleanup is delayed. No background job is started by merely uploading the ZIP or running the SQL. New captures and deletion requests are refused while the worker heartbeat is offline; existing pending jobs resume on return.

Do not use --once as the production service; it processes at most one job and exits. It is available for controlled local/operator diagnostics. Local tests use fixtures and do not require real credentials.
