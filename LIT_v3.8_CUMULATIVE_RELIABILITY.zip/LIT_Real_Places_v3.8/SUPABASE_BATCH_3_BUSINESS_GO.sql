-- Verified-claim business access and current GO totals. Does not verify claims.
begin;
create function public.lit_my_business()
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); result jsonb;
begin
  if u is null then raise exception 'Sign in first.' using errcode='42501'; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
    'place_id',c.place_id,'status',c.status,'name',p.name,
    'requested_at',c.created_at
  ) order by c.created_at desc,c.id),'[]'::jsonb) into result
  from public.lit_business_claims_v2 c
  join public.lit_places_v2 p on p.id=c.place_id
  where c.claimant_id=u;
  return result;
end $$;

create function public.lit_business_dashboard(p_place uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); current_count bigint; place_data jsonb;
begin
  if u is null or not exists(
    select 1 from public.lit_business_claims_v2
    where place_id=p_place and claimant_id=u and status='verified'
  ) then
    raise exception 'A verified claim for this venue is required.' using errcode='42501';
  end if;
  select count(distinct user_id) into current_count
    from public.lit_go_intents_v2 where place_id=p_place;
  select jsonb_build_object('place_id',id,'name',name,'pid',case
    when provider_place_id like 'geoapify:%' or provider_place_id like 'osm:%' then provider_place_id
    when provider='geoapify' then 'geoapify:'||provider_place_id
    when provider in ('osm','openstreetmap') then 'osm:'||provider_place_id
    else provider||':'||provider_place_id end
  ) into place_data from public.lit_places_v2 where id=p_place;
  return jsonb_build_object(
    'generated_at',now(),'place',place_data,
    'go',jsonb_build_object('current_count',current_count,'updated_at',now()),
    'score',null,'history','[]'::jsonb,'totals','{}'::jsonb,
    'hourly','[]'::jsonb,'daily','[]'::jsonb,'videos','[]'::jsonb,
    'feedback',jsonb_build_object('accuracy','{}'::jsonb,'recent','[]'::jsonb),
    'promotions','[]'::jsonb,'profile',null,
    'capabilities',jsonb_build_object('go_totals',true,'full_analytics',false,
      'business_profile',false,'promotions',false)
  );
end $$;
revoke all on function public.lit_my_business() from public,anon;
revoke all on function public.lit_business_dashboard(uuid) from public,anon;
grant execute on function public.lit_my_business() to authenticated;
grant execute on function public.lit_business_dashboard(uuid) to authenticated;
notify pgrst,'reload schema';
commit;
