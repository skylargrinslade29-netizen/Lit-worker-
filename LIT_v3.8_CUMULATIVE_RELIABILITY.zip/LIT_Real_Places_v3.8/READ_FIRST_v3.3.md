# LIT v3.3 — one cumulative business-system update

This ZIP includes all files from your v3.2 cumulative video/safety ZIP, the GO fix, and the business verification system. It has not been deployed. Start with the two SQL files below, then deploy the complete source once to your existing Netlify site.

## Setup: two SQL runs, one deployment

1. In the **existing Lit Supabase project → SQL Editor**, paste and run `SUPABASE_v3.3_BUSINESS_SYSTEM.sql`. This is the combined migration; it replaces the earlier batches 1, 2 and 3. Do not run the older batch files again. It adds verification/profile tables, private reviewer permissions, business functions, anonymous GO totals, GO expiry, provider-verified registration and lookup limits. It preserves existing place/claim UUIDs and claim statuses. Direct browser writes to claim, venue-registration and GO tables are restricted to the authenticated functions; it does not drop your existing tables.
2. Open `SUPABASE_OWNER_SETUP.sql`. Replace **only** `REPLACE_WITH_YOUR_LIT_ACCOUNT_EMAIL` with your own existing, confirmed Lit account email. Run it in the same SQL Editor. Nobody can review claims until the owner is configured. There is no first-user-wins registration or public bootstrap API. The script will not replace a different existing owner. Owner access is attached to the account UUID, not an editable profile field.
3. In your **existing Netlify site → Production environment variables → Functions scope**, set `SUPABASE_URL` to `https://mvyjaoxenjnjoquhadds.supabase.co` and `SUPABASE_SERVICE_ROLE_KEY` to the project's server-only service-role key. Keep your existing `GEOAPIFY_API_KEY`. Never place the service-role key in `public/lit-config.js`, this ZIP, a browser or chat.
4. Deploy the complete project to **glowing-crepe-8a40b0**, including `netlify/functions`. Use your repository's Netlify deployment workflow or the supplied `deploy.sh`. A static upload of only `public` does not install the registration function. No Netlify deployment or build was triggered during preparation of this ZIP.
5. Refresh the app and sign in as yourself. **Profile → Business verification** opens your review queue. You can also open it from Business Mode. If you do not see it, confirm the owner email belongs to the same signed-in Lit account and that the owner setup succeeded.

The files are cumulative: keep the existing Netlify site, Supabase project and public publishable key. Do not create a new project.

## Your verification workflow

1. The business representative signs in, opens a real venue, chooses **Claim it**, and provides their role, business email, optional phone, official business page and a short note.
2. The request stays **Pending review** and grants no business privileges. A confirmed login email is not business verification.
3. In **Business verification → Pending**, tap **Review request**. Open the independent public listing, check the venue/address, and confirm authorization through a public business contact or another documented method. Applicant-supplied contact information is labelled separately.
4. Choose a method, record the independent source and a short internal note, tick the authorization confirmation, and save **Approve access**. If the venue already has verified accounts, explicitly confirm the additional account's authorization as well.
5. Use **Request information** for follow-up or **Reject request** with a message. The applicant sees your message and status in Business Mode and can update/resubmit. Requests are rate-limited and versioned, so an older open review cannot approve a changed request.
6. In the **Verified** tab, open a record and choose **Revoke access** to remove its business permissions. Decisions record the actor, time, action, method, source and notes in private audit history.

Status messages are in-app; this batch does not send emails automatically. Reviewers cannot approve their own claims. If you claim your own venue, a reviewer you authorize must review it.

## Give someone review access without more SQL

The person creates a Lit account and confirms their email. As the owner, open **Business verification → Manage review team**, enter their account email and tap **Grant reviewer access**. They can review claims but cannot grant others access. Tap **Revoke** to remove their review permission. Permission is checked on every privileged server call, not merely by hiding buttons. Only the sole owner can manage the review team; profile account types and browser flags grant no review access.

Supabase database administrator access is required for the initial owner setup or owner recovery. The app does not offer ownership transfer to reviewers.

## Also included in this batch

- Signed-out GO requires sign-in. Signed-in GO saves, changes to Going, cancels and persists across refresh. Choosing another venue removes the previous destination.
- GO expires **12 hours after saving**. Expired rows no longer count; a repeated active save does not extend expiry. These are intent counts, not attendance. The server enforces expiry without needing a scheduled cleanup job.
- Consumers get anonymous current GO totals for registered, provider-verified venues. Planning totals stay unavailable until the separate Crew aggregation is connected.
- Verified business accounts get the same current GO total. The dashboard refreshes every **45 seconds while visible**, with manual refresh available. Refresh updates totals without replacing an unfinished profile form.
- Verified representatives can edit the venue description, hours, phone and HTTP/HTTPS website. Profiles are published only while the venue has a verified claim. Revoked accounts cannot continue editing or reading private dashboards.
- Stored venue links open outside the recipient's current discovery radius without moving their search location. New share links include public venue coordinate hints so an unregistered link can be checked against the provider. Old unknown links without hints show recovery guidance.
- Server registration uses provider-returned data, retains existing matching place IDs, and marks the record provider-verified. Old records are rechecked when needed. Client-created registrations are blocked. Authenticated provider registration is limited to 12 new lookups/minute and 200/day per account, using database counters.
- Expired sessions clear private client state and show sign-in. Failed network requests and stale claim decisions have explicit retry/recovery messages. Mutations are not automatically replayed.

## Live acceptance check

Use separate accounts for you, a reviewer, a business applicant and a consumer:

1. Confirm the applicant cannot open the review queue or approve themselves.
2. Grant a reviewer; confirm they can review but cannot manage reviewers.
3. Submit a claim, request information, update it, then approve it using an independently checked business contact.
4. Confirm business profile editing is enabled only after approval.
5. Consumer GO: sign-in required, Going after success, persists after refresh. Business count increases; cancellation/switch/expiry removes it. Names and user IDs are never returned in totals.
6. Revoke reviewer access and verify their next privileged request is denied. Revoke a business claim and verify dashboard/profile permissions stop.
7. Open a shared venue link from a fresh browser outside its radius.

Local checks passed against PostgreSQL fixtures and real mobile/desktop Chromium. They do not establish the state of your live Supabase project, Netlify configuration, upstream provider availability or actual phone camera behavior. See `VALIDATION_v3.3.md` for reproducible checks.

## Still outside this batch

Secure video capture/publishing and worker wiring, global video moderation/blocking, the full Crew backend, arrivals/feedback, anti-fraud score computation, complete Events/RSVP, promotions/billing, account deletion and actual operator policy/support URLs remain outstanding. Their original source files and historical requirements are retained. Existing verified claims are not automatically revoked; inspect them in the queue if they predate your current verification process. Cross-provider venue identity consolidation is still separate work. Public provider endpoints need broader distributed abuse protection; the new per-account limits protect authenticated registration only.
