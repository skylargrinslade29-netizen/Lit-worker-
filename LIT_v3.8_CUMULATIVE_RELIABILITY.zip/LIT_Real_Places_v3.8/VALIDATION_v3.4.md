# v3.4 validation

- `npm test` passed: syntax/import/route checks plus existing provider, auth isolation, GO, registration and client/server regressions.
- Real Chromium at 390 px passed: saved-place search, escaped names, JSON export, invalid import rejection, duplicate-safe import, alphabetical sorting, removal, no horizontal overflow, venue reopening without changing discovery location, and Save toggle.
- Reproduce the bookmark browser check with Python Playwright and Chromium installed: serve `public` on localhost port 8766 and run `python checks/browser_saved.py`.
- Business database and mobile/desktop workflow results from v3.3 remain documented in VALIDATION_v3.3.md. The migration and verification code are unchanged in v3.4.
- No production migration or deployment performed. Physical iPhone/Android acceptance remains required.
