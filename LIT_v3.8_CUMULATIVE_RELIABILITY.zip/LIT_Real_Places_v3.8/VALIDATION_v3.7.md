# v3.7 validation

Local PostgreSQL (PGlite) checks passed for capture ownership, proximity, elapsed time, quarantine access, leases, validated publication, blocks, reports, moderator authorization and revocation, stale-token deletion protection, cleanup, application purge, completion receipts, and cumulative migration reruns.

Real FFmpeg tests passed for MP4 conversion and streaming WebM duration measurement, metadata stripping, invalid/short/long clips and overwrite rejection. Worker adapter tests covered purge-before-Auth-delete, cleanup, safe logging, and preserving published output after an uncertain RPC response. Netlify account-deletion endpoint tests covered password reauthentication, identity binding and owner protection.

Chromium mobile (390px) and desktop (1280px) video safety flows passed: actual fake-camera MediaRecorder recording, queue/status UI, block/unblock, reports, delegated moderation/removal/revocation, confirmed deletion and completion receipts. These browser tests use local PostgreSQL and fixture Storage/Auth/worker adapters; they do not establish production playback or hosted worker operation.

The source scan found no embedded service-role JWT or real Geoapify credential. Only the intentionally public SUPABASE_URL is excluded from Netlify's environment-value scanner. Actual failing production log matches were unavailable.

No production Supabase changes, Netlify deployment, worker hosting, Docker build or physical-device checks were performed. Legal policies, production monitoring/backups and full business analytics remain separate launch work.

Existing business verification/delegation, signed-out GO gate and signed-in GO/cancel counts, private Crew invites/RSVP/cancel/rotation, arrival feedback privacy, and promotion create/edit/archive also passed against the v3.7 PostgreSQL browser fixture. Final npm source/endpoint regression checks passed.
