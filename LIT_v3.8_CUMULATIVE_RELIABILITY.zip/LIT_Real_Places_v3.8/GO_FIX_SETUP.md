# Historical GO fix setup

For the current cumulative v3.3 package, use READ_FIRST_v3.3.md instead. Its single migration replaces all older batch SQL and adds protected provider registration, expiry, verified business profiles and owner-controlled verification. Do not run the older batches again. The instructions below describe the earlier GO-only patches.

Requires Supabase batches 1 and 2 from this chat. The GO authentication/registration fix alone needs no additional SQL; the owner-dashboard addition below needs Batch 3.

For the added verified-owner GO totals, also run SUPABASE_BATCH_3_BUSINESS_GO.sql once. It provides lit_my_business and lit_business_dashboard for existing claims. It does not create or verify claims. Only the caller's claim with status=verified for the same lit_places_v2 place UUID grants dashboard access. The dashboard shows current distinct GO users, excluding cancelled/switched destinations, on open or manual refresh. It does not send notifications or live-push changes. No names or user IDs are returned. Totals have no automatic expiration yet; they represent saved intent until cancellation/switching, not people present at the venue. Historical GO charts and other analytics remain unavailable.

In the existing Netlify site's Production environment variables with Functions scope, set:

- SUPABASE_URL: https://mvyjaoxenjnjoquhadds.supabase.co
- SUPABASE_SERVICE_ROLE_KEY: the existing project's legacy service_role key, kept only in Netlify server environment variables. Do not use the publishable/anon key here and do not put this key in public/lit-config.js or chat.
- Keep GEOAPIFY_API_KEY configured for discovery.

Deploy the complete package, including netlify/functions, to the existing site using its normal Netlify build/CLI workflow. A static public-folder upload does not install server functions. This patch has not been deployed by this session.

Signed-out GO opens sign-in and clears legacy local intent. After successful sign-in, the pending GO action resumes. Missing venues are rechecked against a real provider response through the authenticated server route, registered without replacing existing venue records, then saved with lit_set_go. The UI changes to Going only after the authenticated save succeeds. Provider verification may fail for venues absent from a fresh bounded provider search; errors are shown rather than saving an unverified record.

Local/mock tests do not replace live checks. Test signed-out tap, sign-in continuation, signed-in GO, cancel and refresh persistence with both existing and newly discovered venues. Full video, Crew, arrivals and business backends remain outstanding. Existing database policies still need the broader permission review; this route does not harden direct table insertion policies. Distributed provider abuse controls remain a launch prerequisite.
