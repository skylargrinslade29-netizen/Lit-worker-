# Operator setup — v3.2

All earlier app features and source files are retained. Supabase is unchanged.

## Public resources
In public/lit-config.js, fill links.terms, links.privacy, links.support and links.deletion with actual published HTTPS URLs. They appear in sign-up/settings. Empty/invalid URLs are omitted. Never put credentials or service-role keys in this browser file. A deletion request link is not automated deletion; provide a real monitored workflow.

Legal documents must reflect the actual operator, contact, data handling, age rules, retention and deletion processes. No policies or support contacts were invented. The existing sign-up terms reference still needs real published documents before public launch.

## Added device features
Saved places store up to 100 provider-returned bookmarks on this device and are independent of GO. Clearing device data removes them. Video autoplay and preloading controls are in Settings, accessible from PICK even signed out. Device preferences do not affect other devices/accounts. Hiding remains local and separate from reports.

## Connectivity and home screen
The offline/reconnect banner uses browser connection events; it cannot guarantee provider availability. Refresh is manual to conserve provider calls. The web manifest adds standalone/home-screen metadata and an SVG icon; installation support varies by browser. No service worker or offline API/video cache was added.

## Still needs backend or operational work
Nationwide venue completeness and any new licensed provider; server-side permissions/media validation/anti-fraud; global moderation/user blocking/account deletion; complete Events/RSVP; physical device QA. These are documented in REMAINING_WORK.md and READINESS_AUDIT.md. This source update is not public-launch certification.
