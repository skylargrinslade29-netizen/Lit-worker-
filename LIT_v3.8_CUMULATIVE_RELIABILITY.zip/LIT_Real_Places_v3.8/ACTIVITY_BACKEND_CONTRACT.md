# Anonymous GO / plan totals — v3.2

## Display implemented
WATCH, PICK, GO and venue details display Going, Planning to go, numeric LIT score and count update timing. Video timestamps remain unchanged. No names, user IDs, Crew names, member lists or precise locations are rendered in the public count summary. Existing private Crew features are retained.

Going means distinct people with active GO intent. Planning to go means distinct people with accepted active plans for the reported window, not invitations or a count of plan records. A person can appear in both categories; do not add the totals together. Counts are not attendance. Signed-out GO remains local and does not add a public participant.

## Required existing backend response addition
For each venue returned by lit_nearby_feed (in places), supply:

```json
{
  "pid": "existing-provider-id",
  "activity": {
    "going_count": 50,
    "planning_count": 75,
    "updated_at": "SERVER_ISO_TIMESTAMP",
    "window_start": "SERVER_ISO_WINDOW_START",
    "window_end": "SERVER_ISO_WINDOW_END"
  },
  "score": {"score": 84}
}
```

Numbers above are documentation examples, not seeded live data. Counts must be JSON nonnegative safe integers. Timestamps must be actual server ISO values. The UI accepts a window containing now and an update no more than 15 minutes old; otherwise it shows —/unavailable. Actual zero remains zero. Scores stay independent from raw counts and come from the existing score calculation.

## Server aggregation helper included
netlify/functions/lib/intent-aggregate.mjs provides a tested aggregateIntent helper for an existing trusted server integration. It deduplicates each metric per user, rejects expired/cancelled GO, ignores nonaccepted/cancelled plans and revoked members, separates venues, and returns counts/timing only. Map actual database rows to its documented fields before use. Never feed it browser-provided participant claims. It does not query the database and is not connected to the live RPC yet.

GO row fields: place_id, user_id, active(boolean), created_at, expires_at.
Plan row fields: place_id, user_id, response(in/maybe/pass), status(active/cancelled), member_active(boolean), starts_at.

The database implementations/schema were not supplied and Supabase changes remain deferred. Consequently the client display and aggregation helper are implemented, but real totals cannot become available until the existing backend returns activity. This ZIP does not fabricate counts, increment optimistic totals or install unverified database migrations.

## Refresh and privacy
Signed-in GO changes and Crew RSVP changes refresh the existing nearby feed. The minute timer updates count freshness without issuing provider requests; it does not provide realtime subscriptions. Server-side transactions/expiry/privacy/rate limits are still necessary. Do not return identity lists for aggregate totals. Preserve existing private Crew access controls. Test with actual accounts before treating the counts as production-verified.
