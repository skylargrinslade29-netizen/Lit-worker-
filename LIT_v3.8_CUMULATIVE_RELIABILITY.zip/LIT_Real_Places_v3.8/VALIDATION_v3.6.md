# LIT v3.6 local validation

Checked against a local PostgreSQL engine (PGlite) and Chromium, using synthetic test accounts and provider records. No production database commands or Netlify deployment were performed. Browser GPS is simulated; physical iPhone/Android GPS and live runtime credentials remain unverified.

## Passed

- `npm test`: all JS/MJS syntax and relative imports, API routes/manifest, provider and client regressions, account/response isolation, GO guards, camera safeguards, safe URLs, registration provider validation and trusted records. Registration failure references match safe structured logs; raw backend messages and service keys are not returned or logged by this error handler.
- `checks/business-database.mjs`: owner bootstrap/delegation, verified-only access, private audit/direct-write denial, GO/cancel/switch/expiry, anonymous totals and registration quotas.
- `checks/crew-database.mjs`: private membership, limited invite disclosure, owner-only management, invite quota/expiry/rotation, plans/RSVP/cancellation, member departure, deduplicated totals, rerun and deletion.
- `checks/engagement-database.mjs`: signed-in/current-GO requirements; valid, precise, nearby location and NaN rejection; retry idempotency and six-hour cooldown; private arrival/feedback table denial; own-visit feedback and input checks; duplicate submission protection; threshold suppression and note consent; identity-free results; representative exclusion, including after later approval; verified-only promotion edits/archive; stale revision rejection; creation retries; future event vs future special visibility; expiry; claim revocation; complete migration rerun preserving feedback records.
- `checks/browser_business.py`: actual claim form, delegated review/approval/revocation, signed-out GO authentication then signed-in GO/cancel, business totals/profile drafts, shared venue links and denied unauthorized access.
- `checks/browser_crew.py`: actual create/invite/join forms, owner-only controls, venue plan creation, RSVP, business totals, unsaved profile preservation, link consent, cancellation, rotation and deletion on the v3.6 backend.
- `checks/browser_engagement.py` at widths 390 and 1280: fresh simulated GPS arrival; actual feedback choices, note draft preservation during polling and submission; three-account privacy threshold/opt-in notes; business aggregate display; promotion publish/edit; signed-out public shared-link display; ending removes the promotion from public backend responses; no horizontal page overflow or JS page errors.

Screenshots in previews/feedback-390.png, feedback-1280.png, business-engagement-390.png and business-engagement-1280.png use local synthetic fixture accounts/records only. No fixture server or synthetic venues are wired into production routes.

## Run locally

Install optional `@electric-sql/pglite` outside the distributed app, or provide its module path through LIT_PGLITE_MODULE. Database tests need that optional module. Browser tests require Python Playwright and Chromium; the included browser-server.mjs loads the same migrations into a private local database.

Start the browser server with LIT_TEST_PORT=8768, then set LIT_TEST_BASE=http://127.0.0.1:8768 for browser tests. Run these tests sequentially because each resets the shared local fixture. Set LIT_BROWSER_WIDTH=1280 for the desktop engagement test. No production credentials are required.

## Limits of this validation

This is a source/backend fixture check, not proof of live Supabase project configuration, deployed Netlify Functions or real attendance. Client GPS can be spoofed. Grouped feedback/consent reduces disclosure; it is not a guarantee that free-text notes cannot identify someone. No new video processing/moderation, full Events/RSVP, account deletion, billing or trusted score engine is implemented. Promotion view/tap metrics remain unavailable. The worker integration tests were not rerun because the worker was unchanged.
