import places from './places.mjs'

const reply = (body, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } })
export default async function registerPlace(request) {
  const reference=crypto.randomUUID()
  let stage='configuration'
  const fail=(message,code,status=503,backendStatus=null,backendCode=null)=>{
    console.warn(JSON.stringify({event:'venue_registration_failed',reference,stage,code,status,backend_status:backendStatus,backend_code:typeof backendCode==='string' && /^[A-Z0-9_]{1,20}$/.test(backendCode) ? backendCode : null}))
    return reply({error:message,code,reference},status)
  }
  if (request.method !== 'POST') return reply({ error: 'POST required.' }, 405)
  const authorization = request.headers.get('authorization') || ''
  if (!/^Bearer \S+$/.test(authorization)) return reply({ error: 'Sign in to save GO.' }, 401)
  const url = process.env.SUPABASE_URL?.replace(/\/$/, '')
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!url || !key) return fail('Venue saving is not configured yet. The LIT owner needs to finish server setup.','REG_CONFIGURATION')
  if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url)) return fail('Venue saving is not configured yet. The LIT owner needs to finish server setup.','REG_CONFIGURATION')
  try {
    stage='account_check'
    const user = await fetch(`${url}/auth/v1/user`, {
      headers: { apikey: key, Authorization: authorization }, signal: AbortSignal.timeout(8000),
    })
    if (!user.ok) return fail('Your account could not be checked. Sign in again or ask the LIT owner to check server setup.','REG_ACCOUNT',401,user.status)
    const identity = await user.json()
    if (!identity.id) return reply({ error: 'Please sign in again.' }, 401)
    const raw = await request.text()
    if (raw.length > 2048) return reply({ error: 'Request too large.' }, 413)
    let input
    try { input = JSON.parse(raw) } catch { return reply({ error: 'Invalid request.' }, 400) }
    if (!input || typeof input.id !== 'string' || input.id.length > 512 ||
      !/^(geoapify:.+|osm:(node|way|relation):\d+)$/.test(input.id) ||
      !Number.isFinite(input.lat) || !Number.isFinite(input.lon) ||
      Math.abs(input.lat) > 90 || Math.abs(input.lon) > 180) return reply({ error: 'Invalid venue.' }, 400)
    const headers = { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }
    const backend = (name, body) => fetch(`${url}/rest/v1/rpc/${name}`, {
      method: 'POST', headers, body: JSON.stringify(body), signal: AbortSignal.timeout(8000),
    })
    stage='venue_lookup'
    const known = await backend('lit_public_place', { p_pid: input.id })
    if (!known.ok) { const failure=await known.json().catch(()=>({}));return fail('Venue saving could not reach the database. The LIT owner should check the backend installation.','REG_DATABASE',503,known.status,failure.code) }
    const existing = await known.json()
    if (existing?.place?.provider_verified) return reply({ place: existing.place })
    stage='lookup_quota'
    const reserved = await backend('lit_reserve_place_lookup', { p_actor: identity.id })
    if (!reserved.ok) {
      const failure = await reserved.json().catch(() => ({}))
      const quota = /limit reached|wait a minute/i.test(failure.message || '')
      return fail(quota ? 'Venue lookup limit reached. Wait a minute or try again later.' : 'Venue saving could not start. The LIT owner should check the backend installation.',quota ? 'REG_QUOTA' : 'REG_DATABASE',quota ? 429 : 503,reserved.status,failure.code)
    }
    // Coordinates guide a new provider search; only the provider response is stored.
    const search = new URL('https://lit.internal/api/places')
    search.search = new URLSearchParams({ lat: input.lat, lon: input.lon, radius: 5 }).toString()
    stage='provider_check'
    const discovery = await places(new Request(search))
    if (!discovery.ok) return fail('The places provider could not check this venue. Try again shortly.','REG_PROVIDER',503,discovery.status)
    const verified = (await discovery.json()).venues?.find(v => v.id === input.id)
    if (!verified) return reply({ error: 'This venue could not be verified with the places provider. Refresh nearby places.' }, 422)
    stage='venue_save'
    const saved = await backend('lit_register_verified_place', { p_actor: identity.id, p_place: verified })
    if (!saved.ok) {const failure=await saved.json().catch(()=>({}));return fail('The venue could not be saved to the database. Please try again.','REG_SAVE',503,saved.status,failure.code)}
    const place = await saved.json()
    if (!place?.place_id || place.pid !== verified.id) return reply({ error: 'Venue registration could not be confirmed.' }, 503)
    return reply({ place })
  } catch {
    return fail('Venue saving could not finish. Check your connection and try again.','REG_CONNECTION')
  }
}
export const config = { path: '/api/register-place' }
