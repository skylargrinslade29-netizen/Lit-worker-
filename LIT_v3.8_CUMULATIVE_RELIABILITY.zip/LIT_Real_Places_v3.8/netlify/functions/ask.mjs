// Recommendations use only the venue records supplied by the discovery UI.
const intents = [[/drink|cocktail|bar|beer|wine|pub/i,['Bars']], [/date|dinner|eat|food|restaurant|brunch|taco|pizza|sushi/i,['Food']], [/dance|club|party|dj/i,['Party']], [/music|concert|band|jazz|live/i,['Live Music']], [/comedy|laugh|stand.?up/i,['Comedy']], [/movie|theatre|bowling|arcade|game|fun/i,['Entertainment']]]
const json = (body,status=200) => Response.json(body,{status,headers:{'Cache-Control':'no-store'}})
const number = (value,fallback) => value != null && value !== '' && Number.isFinite(Number(value)) ? Number(value) : fallback
export default async request => {
  if(request.method!=='POST')return json({error:'POST required'},405)
  const text = await request.text()
  if(text.length>65536)return json({error:'Request is too large'},413)
  let body
  try{body=JSON.parse(text)}catch{return json({error:'Invalid JSON'},400)}
  if(!body||typeof body!=='object'||Array.isArray(body))return json({error:'Invalid request'},400)
  const q=String(body.query||'').slice(0,240)
  const venues=(Array.isArray(body.venues)?body.venues:[]).slice(0,100)
    .filter(v=>v&&typeof v.id==='string'&&typeof v.name==='string'&&v.id.length<160&&v.name.trim()&&v.name.length<200)
    .map(v=>({...v,miles:Math.max(0,number(v.miles,999)),videos:Math.max(0,Math.floor(number(v.videos,0))),score:Math.max(0,Math.min(100,number(v.score,0))),category:['Bars','Food','Party','Live Music','Comedy','Entertainment'].includes(v.category)?v.category:'Entertainment'}))
  const intent=intents.find(([re])=>re.test(q)),matching=intent?venues.filter(v=>intent[1].includes(v.category)):venues
  const picks=matching.sort((a,b)=>(b.videos>0?1:0)-(a.videos>0?1:0)||b.score-a.score||a.miles-b.miles).slice(0,3)
    .map(v=>({id:v.id,reason:`${v.category} · ${v.miles!==999?v.miles.toFixed(1)+' mi away · ':''}${v.videos>0?`${v.videos} fresh clip(s)`:'No fresh LIT activity'}`}))
  return json({summary:picks.length?'Nearby real venues matching your request, ranked by available current evidence.':'No matching nearby venues found. Try another category or expand your radius.',picks})
}
export const config={path:'/api/ask'}
