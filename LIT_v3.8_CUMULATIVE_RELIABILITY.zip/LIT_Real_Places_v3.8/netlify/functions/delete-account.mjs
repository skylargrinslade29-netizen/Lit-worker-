// Password re-authentication precedes the service-only deletion request.
const reply=(body,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}})
export default async function deleteAccount(request){
 if(request.method!=='POST')return reply({error:'POST required.'},405)
 const authorization=request.headers.get('authorization')||''
 if(!/^Bearer \S+$/.test(authorization))return reply({error:'Sign in first.'},401)
 const url=process.env.SUPABASE_URL?.replace(/\/$/,''),key=process.env.SUPABASE_SERVICE_ROLE_KEY
 if(!url || !/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url) || !key)return reply({error:'Account deletion is not configured yet.'},503)
 try{
  const user=await fetch(url+'/auth/v1/user',{headers:{apikey:key,Authorization:authorization},signal:AbortSignal.timeout(8000)})
  if(!user.ok)return reply({error:'Your session expired. Sign in again.'},401)
  const identity=await user.json();if(!identity.id || !identity.email)return reply({error:'Use your confirmed account to continue.'},401)
  const raw=await request.text();if(raw.length>2048)return reply({error:'Request too large.'},413)
  let body;try{body=JSON.parse(raw)}catch{return reply({error:'Invalid request.'},400)}
  if(body?.confirmation!=='DELETE' || typeof body.password!=='string' || !body.password || body.password.length>512)return reply({error:'Enter your current password and type DELETE.'},400)
  const auth=await fetch(url+'/auth/v1/token?grant_type=password',{method:'POST',headers:{apikey:key,'Content-Type':'application/json'},body:JSON.stringify({email:identity.email,password:body.password}),signal:AbortSignal.timeout(8000)})
  if(!auth.ok)return reply({error:'Your password could not be confirmed. Reset it if needed, then try again.'},401)
  const verified=await auth.json();if(verified.user?.id!==identity.id)return reply({error:'Account verification failed.'},401)
  // Never return the new tokens, password, service key or Auth response.
  const response=await fetch(url+'/rest/v1/rpc/lit_request_account_deletion',{method:'POST',headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({p_actor:identity.id,p_confirmation:'DELETE'}),signal:AbortSignal.timeout(8000)})
  const result=await response.json().catch(()=>null)
  if(!response.ok){const owner=/platform owner|Owner deletion/i.test(result?.message||'');const offline=/processing service is offline/i.test(result?.message||'');return reply({error:owner ? 'Your platform-owner account cannot be deleted here. Ownership must be transferred first.' : offline ? 'The processing service is offline. No deletion was requested; try again later.' : 'Deletion could not be requested. Please try again later.'},owner?403:503)}
  if(result?.requested!==true || !result.receipt)return reply({error:'The deletion request could not be confirmed.'},503)
  return reply(result)
 }catch{return reply({error:'Could not connect to account services. Please try again.'},503)}
}
export const config={path:'/api/delete-account'}
