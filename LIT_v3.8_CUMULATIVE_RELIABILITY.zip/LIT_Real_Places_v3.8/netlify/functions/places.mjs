import { providerJson, diagnostics, json, validCoords, distance } from './lib/provider.mjs'

// These are Geoapify's documented categories, not OSM amenity names.
const GEO_GROUPS = { clubs: 'adult.nightclub', bars: 'catering.bar,catering.pub', entertainment: 'entertainment', food: 'catering.restaurant,catering.cafe,catering.fast_food' }
const OSM_CATEGORIES = { bar: 'Bars', pub: 'Bars', biergarten: 'Bars', restaurant: 'Food', cafe: 'Food', fast_food: 'Food', nightclub: 'Party', music_venue: 'Live Music', theatre: 'Entertainment', cinema: 'Entertainment', arts_centre: 'Entertainment' }
const cache = new Map()
const inFlight = new Map()
const TTL = 90000

function normalize(items, lat, lon, meters) {
  const seen = new Set()
  return items.filter((v) => typeof v.id === 'string' && typeof v.name === 'string' && v.name.trim() && validCoords(v.lat, v.lon) && distance(lat, lon, v.lat, v.lon) <= meters)
    .sort((a, b) => distance(lat, lon, a.lat, a.lon) - distance(lat, lon, b.lat, b.lon))
    .filter((v) => {
      const key = `${v.name.trim().toLowerCase()}|${v.lat.toFixed(4)}|${v.lon.toFixed(4)}`
      if (seen.has(key)) return false
      seen.add(key)
      v.name = v.name.trim()
      return true
    }).slice(0, 400)
}

async function geoapify(lat, lon, meters, key, trace) {
  // Dedicated limits stop dense food listings from consuming nightlife's slots.
  const results = await Promise.allSettled(Object.entries(GEO_GROUPS).map(async ([group, categories]) => {
    const url = new URL('https://api.geoapify.com/v2/places')
    url.search = new URLSearchParams({ categories, filter: `circle:${lon},${lat},${meters}`, bias: `proximity:${lon},${lat}`, limit: '100', apiKey: key })
    const data = await providerJson(`geoapify_places_${group}`, url, { timeout: 7000, trace, validate: (d) => Array.isArray(d?.features) && d.features.every((f) => f && typeof f === 'object') })
    trace({ event: 'category_result', group, count: data.features.length, limit_reached: data.features.length === 100 })
    return data.features.map((feature) => {
      const p = feature.properties || {}
      const cats = Array.isArray(p.categories) ? p.categories : []
      const category = cats.includes('adult.nightclub') ? 'Party' : cats.some((c) => c.includes('music')) ? 'Live Music' : cats.some((c) => c === 'catering.bar' || c === 'catering.pub') ? 'Bars' : cats.some((c) => c.startsWith('catering')) ? 'Food' : 'Entertainment'
      return { id: p.place_id ? `geoapify:${p.place_id}` : null, name: p.name || '', lat: feature.geometry?.coordinates?.[1], lon: feature.geometry?.coordinates?.[0], category, address: p.formatted || '' }
    })
  }))
  if (results.every((r) => r.status === 'rejected')) throw new Error('All managed category searches failed')
  return { venues: results.flatMap((r) => r.status === 'fulfilled' ? r.value : []), failedGroups: Object.keys(GEO_GROUPS).filter((group, i) => results[i].status === 'rejected') }
}

async function osm(lat, lon, meters, trace, groups = Object.keys(GEO_GROUPS)) {
  const around = `around:${meters},${lat},${lon}`
  // Each output group has its own budget, still using one Overpass request.
  const selectors = {
    clubs: `nwr(${around})[amenity=nightclub];out center 100;`,
    bars: `nwr(${around})[amenity~"^(bar|pub|biergarten)$"];out center 100;`,
    entertainment: `(nwr(${around})[amenity~"^(theatre|cinema|arts_centre|music_venue)$"];nwr(${around})[club=music];);out center 100;`,
    food: `nwr(${around})[amenity~"^(restaurant|cafe|fast_food)$"];out center 100;`,
  }
  const query = `[out:json][timeout:5];${groups.map((group) => selectors[group]).join('')}`

  let last
  for (const endpoint of ['https://overpass.kumi.systems/api/interpreter', 'https://overpass-api.de/api/interpreter']) {
    try {
      const data = await providerJson(new URL(endpoint).hostname, endpoint, {
        timeout: 6000, trace, method: 'POST', body: new URLSearchParams({ data: query }),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        validate: (d) => Array.isArray(d?.elements) && !d.remark && d.elements.every((x) => x && typeof x === 'object'),
      })
      return data.elements.map((x) => {
        const p = x.tags || {}
        return { id: x.id != null && x.type ? `osm:${x.type}:${x.id}` : null, name: p.name || '', lat: x.lat ?? x.center?.lat, lon: x.lon ?? x.center?.lon, category: OSM_CATEGORIES[p.amenity || 'music_venue'] || 'Entertainment', address: [p['addr:housenumber'], p['addr:street'], p['addr:city']].filter(Boolean).join(' ') }
      })
    } catch (error) { last = error }
  }
  throw last
}

async function discover(lat, lon, radius, trace) {
  const meters = Math.round(radius * 1609.344)
  const key = process.env.GEOAPIFY_API_KEY?.trim()
  let venues = null
  let provider = 'geoapify'
  let warning = null
  let coverage = radius
  if (key) {
    try {
      const result = await geoapify(lat, lon, meters, key, trace)
      venues = result.venues
      if (result.failedGroups.length) {
        trace({ event: 'category_fallback_start', groups: result.failedGroups })
        try {
          const capped = Math.min(meters, 12000)
          const recovered = await osm(lat, lon, capped, trace, result.failedGroups)
          const categories = { clubs: ['Party'], bars: ['Bars'], entertainment: ['Entertainment', 'Live Music'], food: ['Food'] }
          const allowed = new Set(result.failedGroups.flatMap((group) => categories[group]))
          venues.push(...recovered.filter((v) => allowed.has(v.category)))
          provider = 'geoapify+openstreetmap'
          warning = capped < meters ? 'Some categories use backup results within about 7.5 miles. Results beyond that may be incomplete.' : null
          trace({ event: 'category_fallback_complete', groups: result.failedGroups, count: recovered.length })
        } catch {
          warning = 'Some venue categories are temporarily unavailable. Results may be incomplete.'
        }
      }
    } catch { /* Status/reason logged by providerJson. */ }
  }
  if (venues === null) {
    const capped = Math.min(meters, 12000)
    venues = await osm(lat, lon, capped, trace)
    provider = 'openstreetmap'
    coverage = Math.min(radius, 12000 / 1609.344)
    warning = capped < meters ? 'Extended search is unavailable. Showing real places within about 7.5 miles.' : null
  }
  const result = { venues: normalize(venues, lat, lon, meters), area: 'Near you', provider, warning, coverage_miles: coverage }
  trace({ event: 'places_result', provider, count: result.venues.length, coverage_miles: coverage, counts: Object.fromEntries(['Party', 'Bars', 'Food', 'Entertainment', 'Live Music'].map((category) => [category, result.venues.filter((v) => v.category === category).length])) })
  return result
}

export default async (request) => {
  if (request.method !== 'GET') return json({ error: 'GET required' }, 405)
  const params = new URL(request.url).searchParams
  const latText = params.get('lat')?.trim()
  const lonText = params.get('lon')?.trim()
  const lat = Number(latText)
  const lon = Number(lonText)
  const radius = params.has('radius') ? Number(params.get('radius')) : 5
  if (!latText || !lonText || !validCoords(lat, lon) || ![5, 10, 25, 50].includes(radius) || ['lat', 'lon', 'radius'].some((k) => params.getAll(k).length > 1)) {
    return json({ error: 'Invalid location or radius. Use separate lat, lon and radius query parameters.', code: 'INVALID_LOCATION' }, 400)
  }
  const { requestId, trace } = diagnostics('places', { radius })
  // Credential never appears in a cache key. Env changes invalidate warm cached results.
  const key = `${lat}|${lon}|${radius}`
  const cached = cache.get(key)
  const credential = process.env.GEOAPIFY_API_KEY?.trim() || ''
  if (cached && cached.credential === credential && Date.now() - cached.at < TTL) {
    trace({ event: 'cache_hit', count: cached.result.venues.length })
    return json(cached.result, 200, requestId)
  }
  try {
    let pending = inFlight.get(key)
    if (!pending || pending.credential !== credential) {
      pending = { credential, requestId, promise: discover(lat, lon, radius, trace) }
      inFlight.set(key, pending)
    } else trace({ event: 'request_coalesced', related_request_id: pending.requestId })
    let result
    try { result = await pending.promise } finally { if (inFlight.get(key) === pending) inFlight.delete(key) }
    if (cache.size >= 100) cache.delete(cache.keys().next().value)
    cache.set(key, { result, at: Date.now(), credential })
    return json(result, 200, requestId)
  } catch {
    if (cached && cached.credential === credential && Date.now() - cached.at < 15 * 60 * 1000) {
      trace({ event: 'stale_cache_hit', count: cached.result.venues.length })
      return json({ ...cached.result, warning: [cached.result.warning, 'Search refresh is temporarily unavailable. Showing real places loaded within the last 15 minutes.'].filter(Boolean).join(' ') }, 200, requestId)
    }
    trace({ event: 'places_unavailable' })
    return json({ error: 'Real places are temporarily unavailable. Please retry shortly.', code: 'PLACES_UNAVAILABLE', request_id: requestId }, 503, requestId)
  }
}

export const config = { path: '/api/places' }
