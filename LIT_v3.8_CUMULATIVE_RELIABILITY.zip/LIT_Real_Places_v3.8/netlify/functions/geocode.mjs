import { providerJson, diagnostics, json, validCoords } from './lib/provider.mjs'

const label = (p, fallback) => [p.city || p.town || p.village || p.county, p.state].filter(Boolean).join(', ') || fallback
const cache = new Map()
const hasCoords = (p) => p && p.lat != null && p.lon != null && validCoords(Number(p.lat), Number(p.lon))

async function managed(query, key, trace) {
  const url = new URL('https://api.geoapify.com/v1/geocode/search')
  // Keep ZIP searches consistent with the US fallback; other city searches remain worldwide.
  url.search = new URLSearchParams({ text: query, format: 'json', limit: '1', apiKey: key, ...(/^\d{5}(?:-\d{4})?$/.test(query) ? { filter: 'countrycode:us', type: 'postcode' } : {}) })
  const data = await providerJson('geoapify_geocode', url, { timeout: 5000, trace, validate: (d) => Array.isArray(d?.results) && (!d.results.length || hasCoords(d.results[0])) })
  const p = data.results[0]
  if (!p) return null
  if (p.lat == null || p.lon == null || !validCoords(Number(p.lat), Number(p.lon))) throw new Error('Invalid coordinates')
  return { lat: Number(p.lat), lon: Number(p.lon), area: label(p, query), provider: 'geoapify' }
}

async function osm(query, trace) {
  const url = new URL('https://nominatim.openstreetmap.org/search')
  url.search = new URLSearchParams({ q: query, format: 'jsonv2', addressdetails: '1', limit: '1', ...(/^\d{5}(?:-\d{4})?$/.test(query) ? { countrycodes: 'us' } : {}) })
  const data = await providerJson('nominatim', url, { timeout: 5000, trace, headers: { 'User-Agent': 'LIT-local-discovery/3.2', 'Accept-Language': 'en-US,en;q=0.8' }, validate: (d) => Array.isArray(d) && (!d.length || hasCoords(d[0])) })
  const p = data[0]
  if (!p) return null
  if (p.lat == null || p.lon == null || !validCoords(Number(p.lat), Number(p.lon))) throw new Error('Invalid coordinates')
  return { lat: Number(p.lat), lon: Number(p.lon), area: label(p.address || {}, query), provider: 'openstreetmap' }
}

export default async (request) => {
  if (request.method !== 'GET') return json({ error: 'GET required' }, 405)
  const params = new URL(request.url).searchParams
  const query = (params.get('q') || '').trim()
  if (query.length < 2 || query.length > 100 || params.getAll('q').length !== 1) return json({ error: 'Enter a ZIP code or city (2–100 characters).' }, 400)
  const { requestId, trace } = diagnostics('geocode')
  const credential = process.env.GEOAPIFY_API_KEY?.trim() || ''
  const cacheKey = query.toLowerCase()
  const cached = cache.get(cacheKey)
  if (cached && cached.credential === credential && Date.now() - cached.at < 3600000) return json(cached.result, 200, requestId)
  try {
    let result
    if (credential) {
      try { result = await managed(query, credential, trace) } catch { result = undefined }
    }
    // Null means a successful, genuinely empty result; undefined means provider failure/missing key.
    if (result === undefined) result = await osm(query, trace)
    if (!result) return json({ error: 'Location not found. Try a ZIP code or city and state.', code: 'LOCATION_NOT_FOUND' }, 404, requestId)
    if (cache.size >= 100) cache.delete(cache.keys().next().value)
    cache.set(cacheKey, { result, credential, at: Date.now() })
    trace({ event: 'geocode_result', provider: result.provider })
    return json(result, 200, requestId)
  } catch {
    trace({ event: 'geocode_unavailable' })
    return json({ error: 'Location search is temporarily unavailable. Use GPS or retry shortly.', code: 'GEOCODE_UNAVAILABLE', request_id: requestId }, 503, requestId)
  }
}

export const config = { path: '/api/geocode' }
